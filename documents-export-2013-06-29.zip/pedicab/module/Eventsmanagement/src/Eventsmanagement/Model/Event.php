<?php
namespace Eventsmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Event implements InputFilterAwareInterface
{
    public $shift_request_id;
    public $fk_shift_id;
    public $fk_user_id;
	public $shift_request_status;
	public $fk_shift_dt_id;
	public $shift_occurs;
	public $shift_request_isdelete;
	public $shift_request_created_date;
	public $shift_request_updated_date;
	
    public function exchangeArray($data)
    {
		$this->shift_request_id			= (isset($data['shift_request_id'])) ? $data['shift_request_id'] : null;
		$this->fk_shift_id				= (isset($data['fk_shift_id'])) ? $data['fk_shift_id'] : null;
        $this->fk_user_id				= (isset($data['fk_user_id'])) ? $data['fk_user_id'] : null;
        $this->shift_request_status		= (isset($data['shift_request_status'])) ? $data['shift_request_status'] : null;
		$this->fk_shift_dt_id			= (isset($data['fk_shift_dt_id'])) ? $data['fk_shift_dt_id'] : null;
		$this->shift_occurs				= (isset($data['shift_occurs'])) ? $data['shift_occurs'] : null;
		$this->shift_request_isdelete	= (isset($data['shift_request_isdelete'])) ? $data['shift_request_isdelete'] : null;
		$this->shift_request_created_date	= (isset($data['shift_request_created_date'])) ? $data['shift_request_created_date'] : null;
		$this->shift_request_updated_date	= (isset($data['shift_request_updated_date'])) ? $data['shift_request_updated_date'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
