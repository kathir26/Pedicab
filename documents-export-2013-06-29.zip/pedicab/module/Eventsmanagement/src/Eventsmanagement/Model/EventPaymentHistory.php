<?php
namespace Eventsmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class EventPaymentHistory implements InputFilterAwareInterface
{
    public $payment_id;
	public $fk_event_id;
    public $payment_date;
    public $payment_cost;
	public $payment_method;
	public $payment_creation_date;
	public $payment_updated_date;
	public $payment_isdelete;
	
    public function exchangeArray($data)
    {
		$this->payment_id				= (isset($data['payment_id'])) ? $data['payment_id'] : null;
		$this->fk_event_id				= (isset($data['fk_event_id'])) ? $data['fk_event_id'] : null;
		$this->payment_date				= (isset($data['payment_date'])) ? $data['payment_date'] : null;
        $this->payment_cost				= (isset($data['payment_cost'])) ? $data['payment_cost'] : null;
        $this->payment_method			= (isset($data['payment_method'])) ? $data['payment_method'] : null;
		$this->payment_creation_date	= (isset($data['payment_creation_date'])) ? $data['payment_creation_date'] : null;
        $this->payment_updated_date		= (isset($data['payment_updated_date'])) ? $data['payment_updated_date'] : null;
		$this->payment_isdelete			= (isset($data['payment_isdelete'])) ? $data['payment_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
