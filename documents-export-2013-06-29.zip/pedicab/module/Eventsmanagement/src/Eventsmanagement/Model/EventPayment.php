<?php
namespace Eventsmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class EventPayment implements InputFilterAwareInterface
{
    public $event_payment_id;
    public $fk_event_id;
    public $pay_per_driver;
	public $additional_pay_event_manager;
	public $other_costs_labels;
	public $other_costs_values;
	public $total_costs;
	public $price_quote_client;
	public $company_net;
	public $payment_details;
	public $balance_owed;
	
    public function exchangeArray($data)
    {
		$this->event_payment_id				= (isset($data['event_payment_id'])) ? $data['event_payment_id'] : null;
		$this->fk_event_id					= (isset($data['fk_event_id'])) ? $data['fk_event_id'] : null;
        $this->pay_per_driver				= (isset($data['pay_per_driver'])) ? $data['pay_per_driver'] : null;
        $this->additional_pay_event_manager	= (isset($data['additional_pay_event_manager'])) ? $data['additional_pay_event_manager'] : null;
		$this->other_costs_labels			= (isset($data['other_costs_labels'])) ? $data['other_costs_labels'] : null;
		$this->other_costs_values			= (isset($data['other_costs_values'])) ? $data['other_costs_values'] : null;
		$this->total_costs					= (isset($data['total_costs'])) ? $data['total_costs'] : null;
		$this->price_quote_client			= (isset($data['price_quote_client'])) ? $data['price_quote_client'] : null;
		$this->company_net					= (isset($data['company_net'])) ? $data['company_net'] : null;
		$this->payment_details				= (isset($data['payment_details'])) ? $data['payment_details'] : null;
		$this->balance_owed					= (isset($data['balance_owed'])) ? $data['balance_owed'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
