<?php
namespace Eventsmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class EventPaymentHistoryTable extends AbstractTableGateway
{
    protected $table = 'event_payment_history';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new EventPayment());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getEventPaymentHistory($payment_id)
    {
        $id  	= (int) $payment_id;
        $rowset = $this->select(array('payment_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveEventPaymentHistory($paymentDetails)
    {
		$data = array();
		foreach($paymentDetails as $key => $value) {
			if($key != 'payment_id') {
				$data[$key]	= $paymentDetails[$key];
			}
		}
		
        $payment_id = (int)$paymentDetails["payment_id"];
        if (!$payment_id) {
			$data['payment_creation_date']	=  $paymentDetails['payment_creation_date'];
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getEventPaymentHistory($payment_id)) {
                $this->update($data, array('payment_id' => $payment_id));
				return $payment_id;
            } else {
                throw new \Exception('Form payment_id does not exist');
            }
        }
    }
	
	/*
	*	Get the Event details listing
	*/
	public function getEventPaymentList()
	{
		$listingSession 	 = new Container('eventPaymentListing');
		$fk_event_id		 = $listingSession->event_id;
		$whereClause   	  	 = ' WHERE 1 And event.event_isdelete = 0 and event_payment_history.payment_isdelete = 0 and event_payment_history.fk_event_id = '.$fk_event_id;
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = 'event_payment_history';
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY event_payment_history.payment_id DESC';
		}
		
		$sql	= 'SELECT event.event_id, event.event_title, event.event_date, event.event_type, event.event_quote_type, event.event_category,
				   payment_id, fk_event_id, payment_date, payment_cost, payment_method, payment_creation_date, payment_updated_date, payment_isdelete
				   FROM event_payment_history as event_payment_history 
				   left join event as event on (event.event_id = event_payment_history.fk_event_id)';
		$sql	.= $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==result==><pre>"; print_r($result); echo "</pre><==";
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	/*
	*	Get the Event Payment details for view
	*/
	public function getEventPaymentDetail($paymentId)
	{
		$sql	= 'SELECT event.event_id, event.event_title, event.event_date, event.event_type, event.event_quote_type, event.event_category,
				   payment_id, fk_event_id, payment_date, payment_cost, payment_method, payment_creation_date, payment_updated_date, payment_isdelete
				   FROM event_payment_history as event_payment_history 
				   left join event as event on (event.event_id = event_payment_history.fk_event_id)
				   WHERE 1 and event_payment_history.payment_id = '.$paymentId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getEventPaymentDetail==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Delete the Event Payment details
	*/
	public function deleteEventPaymentHistory($payment_id)
    {
        $data = array(
				'payment_isdelete'	=> '1'
        );
		$this->update($data, array('payment_id' => $payment_id));
    }
}