<?php
namespace Eventsmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class EventTable extends AbstractTableGateway
{
    protected $table = 'event';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Event());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getEvent($event_id)
    {
        $id  	= (int) $event_id;
        $rowset = $this->select(array('event_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveEvent($eventDetails)
    {
		$data = array();
		foreach($eventDetails as $key => $value) {
			if($key != 'event_id') {
				$data[$key]	= $eventDetails[$key];
			}
		}
		
        $event_id = (int)$eventDetails["event_id"];
        if (!$event_id) {
			$data['event_creation_date'] = $eventDetails["event_creation_date"];
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getEvent($event_id)) {
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
                $this->update($data, array('event_id' => $event_id));
				return $event_id;
            } else {
                throw new \Exception('Form event_id does not exist');
            }
        }
    }
	
	public function saveEventImages($eventImage)
    {
        $data 	  =  array(
			'upload_bike_install'	=> $eventImage["upload_bike_install"],
			'upload_post_install'	=> $eventImage["upload_post_install"]
        );
        $event_id = (int)$eventImage["event_id"];
        if ($this->getEvent($event_id)) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==save image==><pre>"; print_r($data); echo "</pre><==";
            $this->update($data, array('event_id' => $event_id));
        } else {
            throw new \Exception('Form event_id does not exist');
        }
    }
	
	/*
	*	Get the Event details
	*/
	public function getEventDetail($eventId)
	{
		$sql		= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, shift.shift_occurs, 
					   event.event_id, event.event_title, event.event_date, event.event_category, event.event_quote_type, event.event_status, event.shift_bike_available, event.event_total_bikes,
					   event.shift_manager_id, event.event_manager_phone, event.event_type, event.bike_reserved_type, event.bike_reserved_ids, event.contact_client_id, event.contact_client_phone, 
					   event.contact_client_email, event.pickup_location, event.dropoff_location, event.upload_bike_install, event.upload_post_install, event.install_bonus_location_manager, 
					   event.special_instructions, event.special_notes, event_payment.event_payment_id, event_payment.pay_per_driver, event_payment.additional_pay_event_manager, 
					   event_payment.other_costs_labels, event_payment.other_costs_values, event_payment.total_costs, event_payment.price_quote_client, event_payment.company_net, 
					   event_payment.payment_details, event_payment.balance_owed
					   FROM event as event
					   left join shift as shift on (shift.shift_id = event.fk_shift_id)
					   left join event_payment as event_payment on (event_payment.fk_event_id = event.event_id)
					   WHERE 1 and event.event_id = '.$eventId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getEventDetail==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Get the Event details listing
	*/
	public function getEventList($quote_confirmed)
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		// Condition handling for Clients login view
		$clientView			 = ($pcUser->user_role_id == 6) ? $pcUser->user_role_id : false;
		$userId			 	 = $pcUser->user_id;
		
		$locationId			 = $pcUser->location_id;
		$whereClause   	  	 = ' WHERE 1 And event.event_isdelete = 0 and event.event_type = 2 And event.event_quote_type = "'.$quote_confirmed.'" And shift.fk_location_id = "'.$locationId.'" ';
		if($clientView) {
			$whereClause   	.= ' And event.contact_client_id = '.$userId;
		}
		
		if($clientView) {
			$sessionKey		 = ($quote_confirmed == 2) ? "clientConfirmedEventListing" : "clientQuotedEventListing";
		} else {
			$sessionKey		 = ($quote_confirmed == 2) ? "confirmedEventListing" : "quotedEventListing";
		}
		
		$listingSession 	 = new Container($sessionKey);
		
		if($listingSession->offsetExists('event_date') && $listingSession->event_date != '') {
			$tempDate		 = str_replace('-', '/', $listingSession->event_date);
			$event_date      = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND event.event_date = "' . $event_date . '"';
		}
		
		if($listingSession->offsetExists('event_title') && $listingSession->event_title != '') {
			$whereClause	.= ' AND event.event_title like "%' . addslashes($listingSession->event_title) . '%"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "shift_start_time") ? "shift" : "event";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY event.event_id DESC';
		}
		
		$sql	= 'SELECT event.event_id, event.event_title, event.event_date, event.event_type, event.event_quote_type, event.event_category, event.shift_manager_id, 
				   event.event_manager_phone, event.shift_bike_available, event.event_total_bikes, event.event_approved_status,shift.shift_id, shift.fk_location_id, 
				   shift.shift_type, shift.shift_start_time, shift.shift_end_time, shift.shift_occurs, event_payment.event_payment_id, event_payment.total_costs, 
				   event_payment.price_quote_client, event_payment.company_net, event_payment.payment_details, event_payment.balance_owed, user.user_firstname, 
				   user.user_lastname, user.location_id
				   FROM event as event 
				   left join shift as shift on (shift.shift_id = event.fk_shift_id)
				   left join event_payment as event_payment on (event_payment.fk_event_id = event.event_id)
				   left join user as user on (user.user_id = event.shift_manager_id)';
		$sql	.= $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==result==><pre>"; print_r($result); echo "</pre><==";
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	/*
	*	Get the Payment Event details listing
	*/
	public function getPaymentEventList($payStatus)
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		// Condition handling for Clients login view
		$userId			 	 = $pcUser->user_id;
		$locationId			 = $pcUser->location_id;
		
		$whereClause   	  	 = ' WHERE 1 And event.event_isdelete = 0 and event.event_type = 2 And shift.fk_location_id = "'.$locationId.'" ';
		
		if($payStatus && $payStatus == 1) {
			$whereClause   	.= ' And (event_payment.balance_owed != 0 || event_payment.balance_owed != "")';
		} else {
			$whereClause   	.= ' And (event_payment.balance_owed = 0 || event_payment.balance_owed = "")';
		}
		
		$sessionKey		 	 = ($payStatus == 1) ? "openEventListing" : "closedEventListing";
		$listingSession 	 = new Container($sessionKey);
		
		if($listingSession->offsetExists('event_date') && $listingSession->event_date != '') {
			$tempDate		 = str_replace('-', '/', $listingSession->event_date);
			$event_date      = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND event.event_date = "' . $event_date . '"';
		}
		
		if($listingSession->offsetExists('event_title') && $listingSession->event_title != '') {
			$whereClause	.= ' AND event.event_title like "%' . addslashes($listingSession->event_title) . '%"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "shift_start_time") ? "shift" : "event";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY event.event_id DESC';
		}
		
		$sql	= 'SELECT event.event_id, event.event_title, event.event_date, event.event_type, event.event_quote_type, event.event_category, event.shift_manager_id, 
				   event.event_manager_phone, event.shift_bike_available, event.event_total_bikes, event.event_approved_status,shift.shift_id, shift.fk_location_id, 
				   shift.shift_type, shift.shift_start_time, shift.shift_end_time, shift.shift_occurs, event_payment.event_payment_id, event_payment.total_costs, 
				   event_payment.price_quote_client, event_payment.company_net, event_payment.payment_details, event_payment.balance_owed, user.user_firstname, 
				   user.user_lastname, user.location_id
				   FROM event as event 
				   left join shift as shift on (shift.shift_id = event.fk_shift_id)
				   left join event_payment as event_payment on (event_payment.fk_event_id = event.event_id)
				   left join user as user on (user.user_id = event.shift_manager_id)';
		$sql	.= $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==result==><pre>"; print_r($result); echo "</pre><==";
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	/*
	*	Get the Event details for view
	*/
	public function getViewEventDetail($eventId)
	{
		$sql		= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, shift.shift_occurs, 
					   event.event_id, event.event_title, event.event_date, event.event_category, event.event_quote_type, event.event_status, event.shift_bike_available, 
					   event.event_total_bikes, event.shift_manager_id, event.event_manager_phone, event.event_type, event.bike_reserved_type, event.bike_reserved_ids, 
					   event.contact_client_id, event.contact_client_phone, event.contact_client_email, event.pickup_location, event.dropoff_location, event.upload_bike_install, 
					   event.upload_post_install, event.install_bonus_location_manager, event.special_instructions, event.special_notes, event.event_approved_status,
					   event_payment.event_payment_id, event_payment.pay_per_driver, event_payment.additional_pay_event_manager, event_payment.other_costs_labels, 
					   event_payment.other_costs_values, event_payment.total_costs, event_payment.price_quote_client, event_payment.company_net, event_payment.payment_details, 
					   event_payment.balance_owed, user.user_firstname, user.user_lastname, user.location_id, CONCAT(user.user_firstname," ",user.user_lastname) as contact_client_name , location.loc_title
					   FROM event as event
					   left join shift as shift on (shift.shift_id = event.fk_shift_id)
					   left join event_payment as event_payment on (event_payment.fk_event_id = event.event_id)
					   left join user as user on (user.user_id = event.contact_client_id)
					   left join location as location on (location.loc_id = shift.fk_location_id)
					   WHERE 1 and event.event_id = '.$eventId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getEventDetail==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Get the Event details for view
	*/
	public function getViewClientEventDetail($eventId)
	{
		$sql		= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, shift.shift_occurs, 
					   event.event_id, event.event_title, event.event_date, event.event_category, event.event_quote_type, event.event_status, event.shift_bike_available, 
					   event.event_total_bikes, event.shift_manager_id, event.event_manager_phone, event.event_type, event.bike_reserved_type, event.bike_reserved_ids, 
					   event.contact_client_id, event.contact_client_phone, event.contact_client_email, event.pickup_location, event.dropoff_location, 
					   event.install_bonus_location_manager, event.special_instructions, event.special_notes, event_payment.event_payment_id, event_payment.pay_per_driver, 
					   event_payment.additional_pay_event_manager, event_payment.other_costs_labels, event_payment.other_costs_values, event_payment.total_costs, 
					   event_payment.price_quote_client, event_payment.company_net, event_payment.payment_details, event_payment.balance_owed,
					   user.user_firstname, user.user_lastname, user.location_id, CONCAT(user.user_firstname," ",user.user_lastname) as shift_manager_name
					   FROM event as event
					   left join shift as shift on (shift.shift_id = event.fk_shift_id)
					   left join event_payment as event_payment on (event_payment.fk_event_id = event.event_id)
					   left join user as user on (user.user_id = event.shift_manager_id)
					   WHERE 1 and event.event_id = '.$eventId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getEventDetail==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Delete the Event details
	*/
	public function deleteEvent($fk_shift_id)
    {
        $data = array(
				'event_isdelete'	=> '1'
        );
		$this->update($data, array('fk_shift_id' => $fk_shift_id));
		
		$updateSql = "update shift set shift_isdelete = 1 where shift_id = ".$fk_shift_id;
		$statement = $this->adapter->query($updateSql);
		$results   = $statement->execute();
    }
}