<?php
namespace Eventsmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class EventPaymentTable extends AbstractTableGateway
{
    protected $table = 'event_payment';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new EventPayment());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getEventPayment($event_payment_id)
    {
        $id  	= (int) $event_payment_id;
        $rowset = $this->select(array('event_payment_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveEventPayment($eventDetails)
    {
		$data = array();
		foreach($eventDetails as $key => $value) {
			if($key != 'event_payment_id') {
				$data[$key]	= $eventDetails[$key];
			}
		}
		
        $event_payment_id = (int)$eventDetails["event_payment_id"];
        if (!$event_payment_id) {
			//echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Insert==><pre>"; print_r($data); echo "</pre><==";
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getEventPayment($event_payment_id)) {
				//echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
                $this->update($data, array('event_payment_id' => $event_payment_id));
				return $event_payment_id;
            } else {
                throw new \Exception('Form event_payment_id does not exist');
            }
        }
    }
	
	/*
	*	Update the Payment in Events Payment.
	*/
	public function updateBalanceOwed($data)
	{
		$sql		= ' update event_payment set balance_owed = (balance_owed - '.$data['costs'].') where fk_event_id = '.$data['eventId'];
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==updateBalanceOwed==>".$sql;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	
}