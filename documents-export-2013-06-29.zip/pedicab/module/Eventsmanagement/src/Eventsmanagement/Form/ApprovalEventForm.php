<?php
namespace Eventsmanagement\Form;

use Zend\Form\Form;

class ApprovalEventForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('eventsmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_approval_event_form');
		$this->setAttribute('id', 'pc_approval_event_form');
		
		$this->add(array(
            'name' => 'shift_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'shift_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'status_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'status_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_date',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_date'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'approval_cost',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'approval_cost',
				'class'								=> 'wid131',
				'tabindex'							=> '1',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Price is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Price',
            ),
            'options' => array(
            ),
        ));
		
		
		$this->add(array(
            'name'		 => 'approval_manager_note',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'approval_manager_note',
				'class'								=> 'note2-manager',
				'tabindex'							=> '2',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Manager Note is required!',
            ),
            'options' => array(
            ),
        ));
		
		
        $this->add(array(
            'name' 		=> 'approval_save',
            'attributes'=> array(
				'id'	=> 'approval_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'approval_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'approval_reset',
            ),
        ));
    }
}
?>