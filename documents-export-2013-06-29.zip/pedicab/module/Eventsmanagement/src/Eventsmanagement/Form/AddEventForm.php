<?php
namespace Eventsmanagement\Form;

use Zend\Form\Form;

class AddEventForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('eventsmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_event_form');
		$this->setAttribute('id', 'pc_add_event_form');
		
		$this->add(array(
            'name' => 'event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_payment_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_payment_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'hidden_event_category_type',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hidden_event_category_type'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_shift_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_shift_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_location_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_location_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'event_quote_type',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Quote',
                    '2' => 'Confirmed',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'event_quote_type',
				'tabindex'	=> '1',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_title',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '1',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Event Title is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'event_category_type',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> '',
				'tabindex'							=> '2',
				'id'   								=> 'event_category_type',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event Category is required!',
            )
        ));
		
		/*$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'fk_location_id',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> '',
				'tabindex'							=> '3',
				'id'   								=> 'fk_location_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event Location is required!',
            )
        ));*/
		
        $this->add(array(
            'name' => 'event_start_time',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_start_time',
				'class'								=> 'clock-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '3',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event Start Time is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_end_time',
            'attributes' => array(
				'type' 								=> 'text',
				'class'								=> 'clock-txbox datepicker',
                'value' 							=> '',
				'tabindex'							=> '4',
				'id'  								=> 'event_end_time',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event End Time is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '5',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Event Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' => 'shift_bike_available',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'shift_bike_available'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_total_bikes',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_total_bikes',
				'class'								=> 'wid71',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '6',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Bike Reserve count is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Bike count',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'bike_reserved_type',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Any Bikes',
                    '2' => 'Specific Bike(s)',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'bike_reserved_type',
				'tabindex'	=> '7',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'name' => 'bike_reserved_ids',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'bike_reserved_ids'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'contact_client_id',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> '',
				'tabindex'							=> '8',
				'id'   								=> 'contact_client_id',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Contact name is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'contact_client_phone',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'contact_client_phone',
				'class'								=> 'in-wid211',
				'tabindex'							=> '9',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Contact Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid phone number',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'contact_client_email',
            'attributes' => array(
				                'type'  							=> 'Zend\Form\Element\Email',
								'id'								=> 'contact_client_email',
								'class'								=> '',
								'autofocus'							=> '',
								'PlaceHolder' 						=> '',
								'tabindex'							=> '10',
								'data-validation-engine' 			=> 'validate[optional,custom[email]]',
								'data-errormessage-value-missing' 	=> 'Contact Email is required!',
								'data-errormessage-custom-error' 	=> 'Can you enter some thing as : abc@abc.abc',
								'data-errormessage' 			 	=> 'Entered Contact Email is Invalid',
				            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'name' 		 => 'pickup_location',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'pickup_location',
				'class'								=> '',
				'tabindex'							=> '12',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Pickup Location is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'dropoff_location',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'dropoff_location',
				'class'								=> '',
				'tabindex'							=> '12',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Dropoff Location is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_manager_id',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> '',
				'tabindex'							=> '13',
				'id'   								=> 'shift_manager_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event Manager is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_manager_phone',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_manager_phone',
				'class'								=> 'in-wid211',
				'tabindex'							=> '14',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid phone number',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'special_instructions',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'special_instructions',
				'class'								=> '',
				'tabindex'							=> '15',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Special Instructions is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'special_notes',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'special_notes',
				'class'								=> '',
				'tabindex'							=> '16',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Special Notes is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'upload_bike_install',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'upload_bike_install',
				'class'								=> 'filepc',
				'size'								=> '30',
				'tabindex'							=> '17',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Bike Install photo is required!',
				//'data-errormessage' 			 	=> 'Bike Install photo is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'upload_post_install',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'upload_post_install',
				'class'								=> 'filepc',
				'size'								=> '30',
				'tabindex'							=> '18',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Post-Install photo is required!',
				//'data-errormessage' 			 	=> 'Post-Install photo is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'install_bonus_location_manager',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'install_bonus_location_manager',
				'class'								=> '',
				'tabindex'							=> '19',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Location Manager Bonus is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Bonus',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'pay_per_driver',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'pay_per_driver',
				'class'								=> '',
				'tabindex'							=> '20',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Driver pay is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Driver pay',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'additional_pay_event_manager',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'additional_pay_event_manager',
				'class'								=> '',
				'tabindex'							=> '21',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Event Manager Additional Pay is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Pay',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_costs_labels[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_costs_labels_1',
				'class'								=> '',
				'tabindex'							=> '22',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Other Costs type is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_costs_values[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_costs_values_1',
				'class'								=> 'wid90',
				'tabindex'							=> '23',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Other Cost is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Cost',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'total_costs',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'total_costs',
				'class'								=> '',
				'tabindex'							=> '24',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Total costs is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Cost',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'price_quote_client',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'price_quote_client',
				'class'								=> '',
				'tabindex'							=> '25',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Price is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Price',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'company_net',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'company_net',
				'class'								=> '',
				'tabindex'							=> '26',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Company Net Cost is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Company Net Cost',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'payment_details',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'payment_details',
				'class'								=> '',
				'tabindex'							=> '27',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Payment Details is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'balance_owed',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'balance_owed',
				'class'								=> 'wid132',
				'tabindex'							=> '28',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Balance Owed is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Balance Owed Cost',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'event_save',
            'attributes'=> array(
				'id'	=> 'event_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> 'fnone',
            ),
        ));
    }
}
?>