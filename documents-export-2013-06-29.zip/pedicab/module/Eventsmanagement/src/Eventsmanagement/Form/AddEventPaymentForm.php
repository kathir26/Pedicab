<?php
namespace Eventsmanagement\Form;

use Zend\Form\Form;

class AddEventPaymentForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('eventsmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_event_payment_form');
		$this->setAttribute('id', 'pc_add_event_payment_form');
		
		$this->add(array(
            'name' => 'payment_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'payment_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'balance_owed',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'balance_owed'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_title',
				'class'								=> '',
				'readonly'							=> 'readonly',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '1',
//				'data-validation-engine' 			=> 'validate[required]',
//				'data-errormessage-value-missing' 	=> 'Event Title is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'payment_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'payment_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '2',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Payment Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'payment_cost',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'payment_cost',
				'class'								=> 'wid141',
				'tabindex'							=> '3',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Payment amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'payment_method',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid141',
				'tabindex'							=> '4',
				'id'   								=> 'payment_method',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Payment method is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'payment_save',
            'attributes'=> array(
				'id'	=> 'payment_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'payment_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'payment_reset',
            ),
        ));
    }
}
?>