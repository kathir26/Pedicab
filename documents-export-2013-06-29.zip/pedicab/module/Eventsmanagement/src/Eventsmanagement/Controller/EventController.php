<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Eventsmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Eventsmanagement\Form\AddEventForm,
	Eventsmanagement\Form\EventFilterForm,
	Eventsmanagement\Form\AddEventPaymentForm,
	Eventsmanagement\Form\ApprovalEventForm;

//	Models
use Usermanagement\Model\Aclresources,
	Schedulemanagement\Model\Shift;
use Usermanagement\Model\MyAuthenticationAdapter;

class EventController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $shiftIconArray;
	protected $shiftArray;
	protected $eventCategoryArray;
	protected $balanceDueArrray;
	protected $quotedStatusArrray;
	protected $editCategoryArray;
	protected $paymentMethodArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->shiftIconArray		=  array('1' => 'icon-day','2' => 'icon-nite', '3' => 'icon-double','4' => 'icon-special');
		$this->shiftArray			=  array('' => 'All Shifts', '1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$this->eventCategoryArray	=  array('' => 'Select Event Category', '1' => 'Ad Install', '2' => 'Dedicated Ad Event', '3' => 'Ride Request (not prepaid)', '4' => 'Tour', '5' => 'Wedding', 
											 '6' => 'Pre-paid Ride', '7' => 'Birthday', '8' => 'Bachelorette/Bachelor Party', '9' => 'Corporate', '10' => 'Group', '11' => 'Other');
		$this->editCategoryArray	=  array('4' => 'Tour', '5' => 'Wedding', '6' => 'Pre-paid Ride', '7' => 'Birthday', '8' => 'Bachelorette/Bachelor Party', '9' => 'Corporate', '10' => 'Group', '11' => 'Other');
		$this->balanceDueArrray		=  array('' => '-', '1' => 'Fully Paid', '2' => 'Not Paid');
		$this->quotedStatusArrray	=  array('1' => 'Quoted','2' => 'Confirmed');
		$this->paymentMethodArray	=  array('' => 'Select Payment', '1' => 'Cash', '2' => 'Cheque', '4' => 'Master Card', '3' => 'Visa');
		
		/*
		-	Ad Install
		-	Dedicated Ad Event
		-	Ride Request (not prepaid)
		-	Tour, Wedding, Pre-paid Ride, Birthday, Bachelorette/Bachelor Party, Corporate, Group and Other
		*/
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "EventTable" => "Event-Table", "EventPaymentHistoryTable" => "Event-Payment-History-Table", "EventPaymentTable" => "Event-Payment-Table", "UsersTable" => "Users-Table", "ShiftRequestTable" => "Shift-Request-Table", "BikeTable" => "Bike-Table", "locationTable" => "location-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Add Events
	*	Detail	:	Used to add the events
	*	TODO	:	Mail sending is inprocess
	*/
	public function addEventAction()
    {
		$request 	  = $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$event_category_type 	= (int) $this->params()->fromRoute('id', '4');
		$message  			 	= '';
		
		// Create Filter form
		$addEventsJsonArray 	=  array();
		$notifications			=  array();
		$addEventForm		 	=  new AddEventForm();
		
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
			$Files    			=  $this->params()->fromFiles();
			$formData		 	=  $postData;
			
			$eventQuoteType		=  $formData['event_quote_type'];
			$eventCategorytype	=  $formData['event_category_type'];
			$bikeReservedType	=  (isset($formData['bike_reserved_type']) && !empty($formData['bike_reserved_type'])) ? $formData['bike_reserved_type'] : 1;
			
			// Drivers
			$allDrivers			=  (isset($formData['event_all_drivers_hidden_ids']) && is_array($formData['event_all_drivers_hidden_ids']) && count($formData['event_all_drivers_hidden_ids'])) ? $formData['event_all_drivers_hidden_ids'] : array();
			$preConfirmedDriver	=  (isset($formData['event_confirmed_drivers_hidden_ids']) && is_array($formData['event_confirmed_drivers_hidden_ids']) && count($formData['event_confirmed_drivers_hidden_ids'])) ? $formData['event_confirmed_drivers_hidden_ids'] : array();
			$confirmedDriver	=  (isset($formData['event_confirmed_drivers_ids']) && is_array($formData['event_confirmed_drivers_ids']) && count($formData['event_confirmed_drivers_ids'])) ? $formData['event_confirmed_drivers_ids'] : array();
			// Bikes
			$confirmedBikes		=  (isset($formData['event_confirmed_bikes_ids']) && is_array($formData['event_confirmed_bikes_ids']) && count($formData['event_confirmed_bikes_ids'])) ? $formData['event_confirmed_bikes_ids'] : array();
			
			// Set the Notifications shift date and types
		    //$notifications['notify_date']	= $formData['event_date'];
		    $notifications['notify_type']	= 4;		//	Event Allocation
			
			// Condition handling for Install images.
			// My File uplaod plugins
			$uploadBikeInstall			=	$uploadPostInstall	=  '';
			$myFileUpload   			=   $this->MyFileUpload();
			$myFileUpload->fileTypes	=	$this->imageTypes;
			$myFileUpload->fileSizes	=	$this->imageSizes;
			
			// Bike install
			if(isset($formData['upload_bike_install_fakefilepc']) && !empty($formData['upload_bike_install_fakefilepc'])) {
				$fileNameArray			=	array("upload_bike_install");
				$uploadBikeInstall		=   $myFileUpload->checkUploadFiles($fileNameArray);
			}
			
			// Post install
			if(isset($formData['upload_post_install_fakefilepc']) && !empty($formData['upload_post_install_fakefilepc'])) {
				$fileNameArray			=	array("upload_post_install");
				$uploadPostInstall		=   $myFileUpload->checkUploadFiles($fileNameArray);
			}
			
			// Condition handling for Drivers selections
			$totalConfirmedDriver		=	count($confirmedDriver);
			$totalConfirmedBikes		=	count($confirmedBikes);
			if(($eventQuoteType == 1 || $eventCategorytype == 1 || $totalConfirmedDriver) && ($bikeReservedType == 1 || $totalConfirmedBikes)) {
				
				// Condition check for Available Bikes and Assigned drivers
				$totalBikeAvailable 	=  (int) ($totalConfirmedDriver - count($preConfirmedDriver));
				if($eventQuoteType == 1 || ($totalBikeAvailable <= $formData['shift_bike_available'])) {
				
					// Condition handling for Images
					if(!$uploadBikeInstall && !$uploadPostInstall) {
						$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
						
						if(strpos($formData['event_date'], '-') !== false ) {
							$formData['event_date']	=  str_replace('-', '/', $formData['event_date']);
							$event_date =  $datetime->getDates(strtotime($formData['event_date']), 0, 'Y-m-d');
						} else {
							$event_date =  '0000-00-00';
						}
						
						$fk_shift_id	=  (isset($formData['fk_shift_id']) && !empty($formData['fk_shift_id'])) ? $formData['fk_shift_id'] : 0;
						
						$shiftArray 				  =  array(
							'shift_id'			  	  => $fk_shift_id,
							'fk_location_id'		  => $this->getCommonDataObj()->customIsset('fk_location_id', $formData),
				            'shift_type'			  => 4,
							'shift_start_time'		  => $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_start_time', $formData),1),
							'shift_end_time'		  => $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_end_time', $formData),1),
							'shift_occurs'			  => 2,
							'shift_created_date'	  => $createdDate,
							'shift_updated_date'	  => $createdDate,
							'shift_status'			  => 1,
							'shift_isdelete'		  => 0
						);
						$shiftId  					  =  $this->getTable("ShiftTable")->saveShift($shiftArray);								//	Insert Shift details
						
						$upload_bike_install 		  = $upload_post_install  = '';
						$event_total_bikes   		  = $formData['event_total_bikes'];
						$shift_bike_available 		  = $event_total_bikes - $totalConfirmedDriver;
						
						if(isset($formData['bike_reserved_type']) && !empty($formData['bike_reserved_type'])) {
							$bike_reserved_ids	 	  = ($formData['bike_reserved_type'] == 2) ? implode(',', $confirmedBikes) : '';
						} else {
							$formData['bike_reserved_type'] = 1;
							$bike_reserved_ids  	  =  '';
						}
						$event_id		 	 		  =  (isset($formData['event_id']) && !empty($formData['event_id'])) ? $formData['event_id'] : 0;
						$formData['event_title']	  =  ucfirst($formData['event_title']);
						$eventArray 				  =  array(
							'event_id'			  	  => $event_id,
							'fk_shift_id'			  => $shiftId,
				            'event_title'			  => $formData['event_title'],
							'event_date'			  => $event_date,
				            'event_type'		  	  => 2,
							'event_quote_type'		  => $formData['event_quote_type'],
							'event_category' 		  => $formData['event_category_type'],
							'shift_manager_id'	  	  => $this->getCommonDataObj()->customIsset('shift_manager_id', $formData),
							'event_manager_phone'	  => $this->getCommonDataObj()->customIsset('event_manager_phone', $formData),
							'shift_bike_available'	  => $shift_bike_available,
							'event_total_bikes'	  	  => $event_total_bikes,
							'bike_reserved_type'	  => $this->getCommonDataObj()->customIsset('bike_reserved_type', $formData),
							'bike_reserved_ids'	  	  => $bike_reserved_ids,
							'contact_client_id'	  	  => $this->getCommonDataObj()->customIsset('contact_client_id', $formData),
							'contact_client_phone'	  => $this->getCommonDataObj()->customIsset('contact_client_phone', $formData),
							'contact_client_email'	  => $this->getCommonDataObj()->customIsset('contact_client_email', $formData),
							'pickup_location'	  	  => $this->getCommonDataObj()->customIsset('pickup_location', $formData),
							'dropoff_location'	  	  => $this->getCommonDataObj()->customIsset('dropoff_location', $formData),
							'upload_bike_install'	  => $upload_bike_install,
							'upload_post_install'	  => $upload_post_install,
							'install_bonus_location_manager'  => $this->getCommonDataObj()->customIsset('install_bonus_location_manager', $formData),
							'special_instructions'	  => $this->getCommonDataObj()->customIsset('special_instructions', $formData),
							'special_notes'	  		  => $this->getCommonDataObj()->customIsset('special_notes', $formData),
							'event_creation_date'	  => $createdDate,
							'event_updated_date'	  => $createdDate,
				            'event_status' 			  => 1,
							'event_isdelete' 		  => 0,
				        );
						$eventId  					  =  $this->getTable("EventTable")->saveEvent($eventArray);								//	Insert Event details
						
						// Condition handling for Images
						$uploadBikeInstallImage		  =  (isset($formData['upload_bike_install_fakefilepc']) && !empty($formData['upload_bike_install_fakefilepc'])) ? true : false;
						$uploadPostInstallImage		  =  (isset($formData['upload_post_install_fakefilepc']) && !empty($formData['upload_post_install_fakefilepc'])) ? true : false;
						if($eventCategorytype == 2 && ($uploadBikeInstallImage || $uploadPostInstallImage)) {
							// Image upload for bike install
							if($uploadBikeInstallImage) {
								$fileNameArray			  =	 array("upload_bike_install");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/upload_bike_install";
								$upload_bike_install	  =  $myFileUpload->uploadFiles($eventId, $fileNameArray);
							}
							
							// Image upload for post install
							if($uploadPostInstallImage) {
								$fileNameArray			  =	 array("upload_post_install");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/upload_post_install";
								$upload_post_install	  =  $myFileUpload->uploadFiles($eventId, $fileNameArray);
							}
							
							// Save Install images
							$eventImageArray 			  = array(
								'event_id'			  	  => $eventId,
								'upload_bike_install'	  => $upload_bike_install,
								'upload_post_install'	  => $upload_post_install
					        );
							$eventImageId  				  =  $this->getTable("EventTable")->saveEventImages($eventImageArray);		//	Insert or Update Install images
						}
						
						if($eventCategorytype != 1) {
							$event_payment_id		 	  =  (isset($formData['event_payment_id']) && !empty($formData['event_payment_id'])) ? $formData['event_payment_id'] : 0;
							$other_costs_labels			  =  (isset($formData['other_costs_labels']) && is_array($formData['other_costs_labels']) && count($formData['other_costs_labels'])) ? implode(',', $formData['other_costs_labels']) : '';
							$other_costs_values			  =  (isset($formData['other_costs_values']) && is_array($formData['other_costs_values']) && count($formData['other_costs_values'])) ? implode(',', $formData['other_costs_values']) : '';
							
							$eventPaymentArray 			  =  array(
								'event_payment_id'		  => $event_payment_id,
								'fk_event_id'		  	  => $eventId,
					            'pay_per_driver'		  => $formData['pay_per_driver'],
								'additional_pay_event_manager' => $formData['additional_pay_event_manager'],
								'other_costs_labels'	  => $other_costs_labels,
								'other_costs_values'	  => $other_costs_values,
					            'total_costs'			  => $formData['total_costs'],
								'price_quote_client'	  => $formData['price_quote_client'],
								'company_net'		      => $formData['company_net'],
								'payment_details'		  => $formData['payment_details'],
					            'balance_owed'			  => $formData['balance_owed'],
							);
							$eventPaymentId  			  =  $this->getTable("EventPaymentTable")->saveEventPayment($eventPaymentArray);					//	Insert Shift payment details
							
							$shiftRequests 				  =  array(
								'fk_shift_id'			  	 => $shiftId,
					            'shift_occurs'			  	 => 2,
								'event_id'			  	 	 => $eventId,
					            'shift_request_updated_date' => $createdDate,
								'shift_request_status'		 => 2,		//	Shift Confirmed
					            'shift_request_isdelete'     => 0
					        );
							
							/*
							*	Condition handling for Confirmed Events. We allow the Confirmed events only to assign the drivers, oncall list and event managers
							*	One more handling to detect the bike counts for the other Shifts or Events bikes affects on same day.
							*/
							if($eventQuoteType == 2) {
								// Findout and Assigned the On-call drivers
								$notifications['shift_id']    = $shiftId;
								$notifications['notify_date'] = $event_date;
								$onCallList					  = array_diff($preConfirmedDriver, $confirmedDriver);
								if(isset($onCallList) && is_array($onCallList) && count($onCallList)) {
								   $shiftRequests['shift_request_status']  =  3;			//	On-call list
								   $updateStatus			  =  $this->getTable("ShiftRequestTable")->updateConfirmedDrivers($shiftRequests, $onCallList);
								   
								   // Send the Notifications for On-Call Drivers
								   $notifications['subject']  = 'Your are assigned as on On-Call list for this Event';
								   $this->sendShiftAllocationNote($onCallList, $identity, $notifications);
								}
								
								// Findout the confirmed drivers
								$insertDrivers	=  array_diff($confirmedDriver, $preConfirmedDriver);
								if(isset($insertDrivers) && is_array($insertDrivers) && count($insertDrivers)) {
									$shiftRequests['shift_request_created_date']  =  $createdDate;
									$shiftRequests['shift_request_status']  	  =  2;		//	Shift Confirmed
									$insertStatus 								  =  $this->getTable("ShiftRequestTable")->insertConfirmedDrivers($shiftRequests, $insertDrivers);
									
									// Send the Notifications for Confirmed Drivers
								    $notifications['subject'] 	= 'Event Confirmed';
									$this->sendShiftAllocationNote($insertDrivers, $identity, $notifications);
								}
								
								// Update shift manager.
								$shiftRequests['shift_manager'] = (isset($formData['shift_manager_id'])) ? $formData['shift_manager_id'] : 0;
								$shiftManagerStatus 			= $this->getTable("ShiftRequestTable")->updateShiftManager($shiftRequests);
								
								/*
								*	Mail Sending for Quoted Events to Client
								*/
								if($eventQuoteType == 1) {
									$results		  = $this->getTable("EventTable")->getViewClientEventDetail($eventId);
									foreach($results as $event) {
										$eventDetails = $event;
									}
									
									$locationManagersResult		= $this->getTable("UsersTable")->getLocationManagerDetail(3);
									if($locationManagersResult) {
										foreach($locationManagersResult as $locationManager) {
											$locationManagers 	=  $locationManager;
										}
									}
									
									$mailArray			    =  array(
										'subject'		  	=> 'Email Quote to Client',
							            'from_email'	  	=> '',
										'from_name' 	  	=> '',
										'to_email' 	  	  	=> $eventDetails['contact_client_email'],
										'mail_title' 	  	=> 'Email Quote to Client',
										'mail_descriptions' => 'Quoted Event details are shown below, You want do further changes, Please contact the location manager.',
										'mail_preview' 		=> 0,
										'template_path' 	=> 'usermanagement/mail_templates/event_quote_mail_template',
							        );
									
									// Date
									$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
									if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
										$event_date	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
									} else {
										$event_date	= '-';
									}
									
									$shift_start_time		=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_start_time'], 1);
									$shift_end_time			=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_end_time'], 1);
									$event_category			=  (isset($this->eventCategoryArray[$eventDetails['event_category']]) && !empty($this->eventCategoryArray[$eventDetails['event_category']])) ? $this->eventCategoryArray[$eventDetails['event_category']] : '';
									
									$mailDetails			=  array(
										'Event Date'				=>	$event_date,
										'Event Category'			=>	$event_category,
										'Event Title'				=>	$eventDetails['event_title'],
										'Start Time'				=>	$shift_start_time,
										'End Time'					=>	$shift_end_time,
										'No of Bikes Reserved'		=>	$eventDetails['event_total_bikes'],
										'Pickup Location'			=>	$eventDetails['pickup_location'],
										'Dropoff Location'			=>	$eventDetails['dropoff_location'],
										'Location Manager'			=>	$locationManagers['location_manager_name'],
										'Location Manager Phone'	=>	$locationManagers['user_telephone_number'],
										'Event Manager'				=>	$eventDetails['shift_manager_name'],
										'Special Instructions'		=>	$eventDetails['special_instructions'],
										'Price Quote to Client'		=>	'$'.$eventDetails['price_quote_client'],
										'Payment Details'			=>	$eventDetails['payment_details'],
										'Balance Owed'				=>	'$'.$eventDetails['balance_owed']
									);
									$this->getCommonDataObj()->siteMailSending($mailDetails, $mailArray);
									// End	 : MailSending for the Quoted Events to Client
								}
								
								/*
								*	Mail Sending for Events To Drivers
								*/
								if($eventQuoteType == 2) {
									$results		  = $this->getTable("EventTable")->getViewClientEventDetail($eventId);
									foreach($results as $event) {
										$eventDetails = $event;
									}
									
									$locationManagersResult		= $this->getTable("UsersTable")->getLocationManagerDetail(3);
									if($locationManagersResult) {
										foreach($locationManagersResult as $locationManager) {
											$locationManagers 	=  $locationManager;
										}
									}
									
									// Drivers Working, Get the Allocated drivers for a particular Events.
									$allocatedDrivers 		=  array();
									$driversWorking  		=  array();
									$driversCCEmail  		=  array();
									$shiftId 				=  $eventDetails['shift_id'];
									$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
									if($requestResults) {
										$requestedToArray	=  $requestResults->toArray();
										if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
											foreach($requestedToArray as $keys => $values) {
												if($values['shift_request_status'] == 2) {
													$allocatedDrivers[$values['fk_user_id']]	=  $values;
													$driversWorking[$values['fk_user_id']]		=  $values['user_full_name'];
													$driversCCEmail[$values['fk_user_id']]		=  $values['user_email'];
												}
											}
										}
									}
									$showDrivers 	= implode('<br/>', $driversWorking);
									
									$mailArray			    =  array(
										'subject'		  	=> 'Event Reminder email',
							            'from_email'	  	=> '',
										'from_name' 	  	=> '',
										'to_email' 	  	  	=> $driversCCEmail,
										'mail_title' 	  	=> 'Event reminder email',
										'mail_descriptions' => 'Event details are shown below, You want further details, Please contact the Event or location manager.',
										'mail_preview' 		=> 0,
										'template_path' 	=> 'usermanagement/mail_templates/event_quote_mail_template',
										//'cc_mail' 	  	  	=> $driversCCEmail,
							        );
									
									// Date
									$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
									if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
										$event_date	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
									} else {
										$event_date	= '-';
									}
									
									$shift_start_time		=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_start_time'], 1);
									$shift_end_time			=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_end_time'], 1);
									$event_category			=  (isset($this->eventCategoryArray[$eventDetails['event_category']]) && !empty($this->eventCategoryArray[$eventDetails['event_category']])) ? $this->eventCategoryArray[$eventDetails['event_category']] : '';
									
									$mailDetails			=  array(
										'Event Date'				=>	$event_date,
										'Event Category'			=>	$event_category,
										'Event Title'				=>	$eventDetails['event_title'],
										'Start Time'				=>	$shift_start_time,
										'End Time'					=>	$shift_end_time,
										'No of Bikes Reserved'		=>	$eventDetails['event_total_bikes'],
										'Pickup Location'			=>	$eventDetails['pickup_location'],
										'Dropoff Location'			=>	$eventDetails['dropoff_location'],
										'Location Manager'			=>	$locationManagers['location_manager_name'],
										'Location Manager Phone'	=>	$locationManagers['user_telephone_number'],
										'Event Manager'				=>	$eventDetails['shift_manager_name'],
										'Pay per driver'			=>	'$'.$eventDetails['pay_per_driver'],
										'Drivers working'			=>	$showDrivers
									);
									// End	 : Mail Sending for Events To Drivers
								}
								
								/*
								*	Function to Check the Bike Availability
								*	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
								*/
								$shiftDetails		=  array(
								   'shift_date' 	=> $event_date,
								   'start_time'		=> $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_start_time', $formData),1),
								   'end_time'		=> $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_end_time', $formData),1),
								   'shift_id'		=> $shiftId,
								   'special_id'		=> $eventId,
								   'shift_occurs'	=> 2,
								);
								$this->getCommonDataObj()->checkBikeAvailability($shiftDetails, 1, $this->pcUser);
							}
						}
						
						$message			= 'Drivers Assign successfully !';
						return $this->redirect()->toRoute('eventsmanagement', array('controller' => 'event', 'action' => 'event-listing'));
						/*
						$addEventsJsonArray['redirect_url'] 		 		= '/eventsmanagement/event/event-listing';
						$addEventsJsonArray['event_confirmed_drivers_div'] 	= true;
						$addEventsJsonArray['err_msg']	  			 		= "";
						*/
					} else {
						// upload_bike_install, upload_post_install,  !$uploadBikeInstall && !$uploadPostInstall
						/*$keys							  = (!$uploadBikeInstall) ? "upload_bike_install" : "upload_post_install";
						$err_msg						  = (!$uploadBikeInstall) ? "Bike Install photo is required!" : "Post-Install photo is required!";
						$addEventsJsonArray[$keys] 	 	  = false;
						$addEventsJsonArray['err_msg']	  = $err_msg;
						*/
					}
				} else {
					//$addEventsJsonArray['event_confirmed_drivers_div'] 	= false;
					//$addEventsJsonArray['err_msg']	  			 		= "Available Drivers is exist, You want to select more drivers, Please remove the existing drivers and then select the required drivers, No. of Drivers Needed : ".$formData['shift_bike_available']."!";
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				/*$keys							  = (!$totalConfirmedDriver) ? "event_confirmed_drivers_div" : "event_confirmed_bikes_div";
				$err_msg						  = (!$totalConfirmedDriver) ? "Assign the drivers, It's required" : "Select the Bikes, Its required!";
				$addEventsJsonArray[$keys] 	 	  = false;
				$addEventsJsonArray['err_msg']	  = $err_msg;*/
			}
        }
		
		// Start : Drivers assignment process
		$requestedDrivers		=  $requestedDriversId	=  $allocatedDrivers = $allDrivers  =  array();
		$shiftManagers			=  array('' => 'Select Event manager');
		
		// Get Requested Drivers for the shift
		/*
		$shiftId 				=  35;	// TODO : it's change later, IT's via dynamic shift id based on the Events
		$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
		if($requestResults) {
			$requestedToArray	=  $requestResults->toArray();
			if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
				foreach($requestedToArray as $keys => $values) {
					$requestedDrivers[$values['fk_user_id']]		=  $values;
					if($values['shift_request_status'] == 2) {
						$allocatedDrivers[$values['fk_user_id']]	=  $values;
						$shiftManagers[$values['fk_user_id']]		=  $values['user_firstname'].' '.$values['user_lastname'];
					}
				}
			}
			$requestedDriversId	 =  (is_array($requestedDrivers) && count($requestedDrivers)) ? array_keys($requestedDrivers) : '';
		}
		*/
		
		// Get All Drivers details for the particulat locations
		//	TODO : Need to handle some conditions, In case the drivers already exist in other shifts in that day
		$allDriversResults		 =  $this->getTable("UsersTable")->getUserDetailsForShiftAssign($requestedDriversId);
		if($allDriversResults) {
			$allDriversToArray	 =  $allDriversResults->toArray();
			if($allDriversToArray && is_array($allDriversToArray) && count($allDriversToArray)) {
				foreach($allDriversToArray as $key => $value) {
					$allDrivers[$value['user_id']]	=  $value;
				}
			}
		}
		
		// Get All Bikes for the particulat locations
		$bikesIds			= array();  // TODO : Condition handling for Already alocated bikes, bike_reserved_ids
		$allBikes			= $allocatedBikes  =  array();
		$allBikesResults	= $this->getTable("BikeTable")->GetAllBikes();
		if($allBikesResults) {
			foreach($allBikesResults as $key => $value) {
				$bikeId		= $value['bike_id'];
				if(is_array($bikesIds) && count($bikesIds) && in_array($bikeId, $bikesIds)) {
					$allocatedBikes[$bikeId] = $value;
				} else {
					$allBikes[$bikeId] 	     = $value;
				}
			}
		}
		
		// Get All Clients details for the particulat locations
		$allClientsSession 	 =  new Container('allClients');
		$allClients	 		 =  array();
		$allClientsOptions	 =  array(''  => 'Select Client');
		if($allClientsSession->offsetExists('clients') && $allClientsSession->clients != '' ) {
			$allClients 	 	= $allClientsSession->clients;
			$allClientsOptions  = $allClientsSession->clientOptions;
		} else {
			$clientsResults	 =  $this->getTable('UsersTable')->getAllClientsDetail();
			if($clientsResults && $clientsResults->count()) {
				$results	 =  $clientsResults;
				foreach($results as $result) {
					$allClients[$result["user_id"]]  		=  $result;
					$allClientsOptions[$result["user_id"]]  =  $result['user_firstname'].' '.$result['user_lastname'];
				}
			}
			$allClientsSession->clients  	   = $allClients;
			$allClientsSession->clientOptions  = $allClientsOptions;
		}
		
		// Get the All Locations
		$allLocationSession 	= new Container('allLocations');
		$allLocations			= array();
		if($allLocationSession->offsetExists('locations') && $allLocationSession->locations != '' ) {
			$allLocations		= $allLocationSession->locations;
		} else {
			$allLocations		= array(''  => 'Select Location');
			$locations			= $this->getTable('locationTable')->getAllLocationDetails();
			if($locations) {
				foreach($locations as $location) {
					$allLocations[$location->loc_id]  =  $location->loc_title;
				}
			}
			$allLocationSession->locations  =  $allLocations;
		}
		
		/*$addEventForm->get('fk_location_id')->setValueOptions($allLocations);
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
			$addEventForm->get('fk_location_id')->setValue($this->pcUser->location_id);
		}*/
		$addEventForm->get('fk_location_id')->setValue($this->pcUser->location_id);
		$addEventForm->get('contact_client_id')->setValueOptions($allClientsOptions);
		$addEventForm->get('event_category_type')->setValueOptions($this->eventCategoryArray);
		$addEventForm->get('event_category_type')->setValue($event_category_type);
		$addEventForm->get('hidden_event_category_type')->setValue($event_category_type);
		$addEventForm->get('shift_manager_id')->setValueOptions($shiftManagers);
		
		// Testing process : Start
		/*
		$shiftDetails		=  array(
		   'shift_date' 	=> '2013-03-30',
		   'start_time' 	=> '16:00:00',
		   'end_time'		=> '19:00:00',
		   'shift_id'		=> 53,
		   'special_id'		=> 1,
		   'shift_occurs'	=> 2,
		);
		$this->getCommonDataObj()->checkBikeAvailability($shiftDetails, 1, $this->pcUser);
		*/
		// Testing process : End
		
		$datetime = $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addEventForm'			=> $addEventForm,
			'allDrivers'			=> $allDrivers,
			'allClients'			=> $allClients,
			'allBikes'				=> $allBikes,
			'event_category_type'	=> $event_category_type,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Edit Events
	*	Detail	:	Used to add the events
	*	TODO	:	Mail sending is inprocess
	*/
	public function editEventAction()
    {
		$request 	  = $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$eventId 	  = (int) $this->params()->fromRoute('eventId', '');
		$categoryId   = (int) $this->params()->fromRoute('categoryId', '');
		$message  	  = '';
		
		// Create Filter form
		$addEventsJsonArray 	=  array();
		$notifications			=  array();
		$editEventForm		 	=  new AddEventForm();
		
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
			$Files    			=  $this->params()->fromFiles();
			$formData		 	=  $postData;
			
			$eventQuoteType		=  $formData['event_quote_type'];
			$eventCategorytype	=  $formData['event_category_type'];
			$bikeReservedType	=  (isset($formData['bike_reserved_type']) && !empty($formData['bike_reserved_type'])) ? $formData['bike_reserved_type'] : 1;
			
			// Drivers
			$allDrivers			=  (isset($formData['event_all_drivers_hidden_ids']) && is_array($formData['event_all_drivers_hidden_ids']) && count($formData['event_all_drivers_hidden_ids'])) ? $formData['event_all_drivers_hidden_ids'] : array();
			$preConfirmedDriver	=  (isset($formData['event_confirmed_drivers_hidden_ids']) && is_array($formData['event_confirmed_drivers_hidden_ids']) && count($formData['event_confirmed_drivers_hidden_ids'])) ? $formData['event_confirmed_drivers_hidden_ids'] : array();
			$confirmedDriver	=  (isset($formData['event_confirmed_drivers_ids']) && is_array($formData['event_confirmed_drivers_ids']) && count($formData['event_confirmed_drivers_ids'])) ? $formData['event_confirmed_drivers_ids'] : array();
			// Bikes
			$confirmedBikes		=  (isset($formData['event_confirmed_bikes_ids']) && is_array($formData['event_confirmed_bikes_ids']) && count($formData['event_confirmed_bikes_ids'])) ? $formData['event_confirmed_bikes_ids'] : array();
			
			// Set the Notifications shift date and types
		    //$notifications['notify_date']	= $formData['event_date'];
		    $notifications['notify_type']	= 4;		//	Event Allocation
			
			// Condition handling for Install images.
			// My File uplaod plugins
			$uploadBikeInstall			=	$uploadPostInstall	=  $uploadBikeInstallFlag  =  $uploadPostInstallFlag =  '';
			$myFileUpload   			=   $this->MyFileUpload();
			$myFileUpload->fileTypes	=	$this->imageTypes;
			$myFileUpload->fileSizes	=	$this->imageSizes;
			
			// Bike install
			if(isset($formData['upload_bike_install_fakefilepc']) && !empty($formData['upload_bike_install_fakefilepc'])) {
				$uploadBikeInstallFlag	=   ($formData['upload_bike_install_hidden'] != $formData['upload_bike_install_fakefilepc']) ? true : false;
				if($uploadBikeInstallFlag) {
					$fileNameArray		=	array("upload_bike_install");
					$uploadBikeInstall	=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
			}
			
			// Post install
			if(isset($formData['upload_post_install_fakefilepc']) && !empty($formData['upload_post_install_fakefilepc'])) {
				$uploadBikeInstallFlag	=  ($formData['upload_post_install_hidden'] != $formData['upload_post_install_fakefilepc']) ? true : false;
				if($uploadBikeInstallFlag) {
					$fileNameArray		=  array("upload_post_install");
					$uploadPostInstall	=  $myFileUpload->checkUploadFiles($fileNameArray);
				}
			}
			
			// Condition handling for Drivers selections
			$totalConfirmedDriver		=  count($confirmedDriver);
			$totalConfirmedBikes		=  count($confirmedBikes);
			if(($eventQuoteType == 1 || $eventCategorytype == 1 || $totalConfirmedDriver) && ($bikeReservedType == 1 || $totalConfirmedBikes)) {
				
				// Condition check for Available Bikes and Assigned drivers
				$totalBikeAvailable 	=  (int) ($totalConfirmedDriver - count($preConfirmedDriver));
				if($eventQuoteType == 1 || ($totalBikeAvailable <= $formData['shift_bike_available'])) {
					
					// Condition handling for Images
					if(!$uploadBikeInstall && !$uploadPostInstall) {
						$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
						
						if(strpos($formData['event_date'], '-') !== false ) {
							$formData['event_date']	=  str_replace('-', '/', $formData['event_date']);
							$event_date =  $datetime->getDates(strtotime($formData['event_date']), 0, 'Y-m-d');
						} else {
							$event_date =  '0000-00-00';
						}
						$fk_shift_id	=  (isset($formData['fk_shift_id']) && !empty($formData['fk_shift_id'])) ? $formData['fk_shift_id'] : 0;
						
						$shiftArray 				  =  array(
							'shift_id'			  	  => $fk_shift_id,
							'fk_location_id'		  => $this->getCommonDataObj()->customIsset('fk_location_id', $formData),
				            'shift_type'			  => 4,
							'shift_start_time'		  => $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_start_time', $formData),1),
							'shift_end_time'		  => $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_end_time', $formData),1),
							'shift_occurs'			  => 2,
							'shift_created_date'	  => $createdDate,
							'shift_updated_date'	  => $createdDate,
							'shift_status'			  => 1,
							'shift_isdelete'		  => 0
						);
						$shiftId  					  =  $this->getTable("ShiftTable")->saveShift($shiftArray);								//	Insert Shift details
						
						$upload_bike_install 		  = $upload_post_install  = '';
						$event_total_bikes   		  = $formData['event_total_bikes'];
						$shift_bike_available 		  = $event_total_bikes - $totalConfirmedDriver;
						
						if(isset($formData['bike_reserved_type']) && !empty($formData['bike_reserved_type'])) {
							$bike_reserved_ids	 	  = ($formData['bike_reserved_type'] == 2) ? implode(',', $confirmedBikes) : '';
						} else {
							$formData['bike_reserved_type'] = 1;
							$bike_reserved_ids  	  =  '';
						}
						$event_id		 	 		  =  (isset($formData['event_id']) && !empty($formData['event_id'])) ? $formData['event_id'] : 0;
						
						$eventArray 				  =  array(
							'event_id'			  	  => $event_id,
							'fk_shift_id'			  => $shiftId,
				            'event_title'			  => $formData['event_title'],
							'event_date'			  => $event_date,
				            'event_type'		  	  => 2,
							'event_quote_type'		  => $formData['event_quote_type'],
							'event_category' 		  => $formData['event_category_type'],
							'shift_manager_id'	  	  => $formData['shift_manager_id'],
							'event_manager_phone'	  => $formData['event_manager_phone'],
							'shift_bike_available'	  => $shift_bike_available,
							'event_total_bikes'	  	  => $event_total_bikes,
							'bike_reserved_type'	  => $formData['bike_reserved_type'],
							'bike_reserved_ids'	  	  => $bike_reserved_ids,
							'contact_client_id'	  	  => $this->getCommonDataObj()->customIsset('contact_client_id', $formData),
							'contact_client_phone'	  => $this->getCommonDataObj()->customIsset('contact_client_phone', $formData),
							'contact_client_email'	  => $this->getCommonDataObj()->customIsset('contact_client_email', $formData),
							'pickup_location'	  	  => $this->getCommonDataObj()->customIsset('pickup_location', $formData),
							'dropoff_location'	  	  => $this->getCommonDataObj()->customIsset('dropoff_location', $formData),
							'install_bonus_location_manager'  => $this->getCommonDataObj()->customIsset('install_bonus_location_manager', $formData),
							'special_instructions'	  => $this->getCommonDataObj()->customIsset('special_instructions', $formData),
							'special_notes'	  		  => $this->getCommonDataObj()->customIsset('special_notes', $formData),
							'event_updated_date'	  => $createdDate,
				            'event_status' 			  => 1,
							'event_isdelete' 		  => 0,
				        );
						$eventId  					  =  $this->getTable("EventTable")->saveEvent($eventArray);								//	Insert Event details
						
						// Condition handling for Images
						$uploadBikeInstallImage		  =  (isset($formData['upload_bike_install_fakefilepc']) && !empty($formData['upload_bike_install_fakefilepc'])) ? true : false;
						$uploadPostInstallImage		  =  (isset($formData['upload_post_install_fakefilepc']) && !empty($formData['upload_post_install_fakefilepc'])) ? true : false;
						if($eventCategorytype == 2 && (($uploadBikeInstallFlag && $uploadBikeInstallImage) || ($uploadBikeInstallFlag && $uploadPostInstallImage))) {
							// Save Install images
							$eventImageArray  = array(
								'event_id'	  => $eventId
					        );
							
							// Image upload for bike install
							if($uploadBikeInstallFlag && $uploadBikeInstallImage) {
								$fileNameArray			  =	 array("upload_bike_install");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/upload_bike_install";
								if(isset($formData['upload_bike_install_hidden']) && $formData['upload_bike_install_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/upload_bike_install/".$formData['upload_bike_install_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$upload_bike_install	  =  $myFileUpload->uploadFiles($eventId, $fileNameArray);
								$eventImageArray['upload_bike_install']	 =  $upload_bike_install;
							}
							
							// Image upload for post install
							if($uploadBikeInstallFlag && $uploadPostInstallImage) {
								$fileNameArray			  =	 array("upload_post_install");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/upload_post_install";
								if(isset($formData['upload_post_install_hidden']) && $formData['upload_post_install_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/upload_post_install/".$formData['upload_post_install_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$upload_post_install	  =  $myFileUpload->uploadFiles($eventId, $fileNameArray);
								$eventImageArray['upload_post_install']	 =  $upload_post_install;
							}
							
							$eventImageId  				  =  $this->getTable("EventTable")->saveEventImages($eventImageArray);		//	Insert or Update Install images
						}
						
						if($eventCategorytype != 1) {
							$event_payment_id		 	  =  (isset($formData['event_payment_id']) && !empty($formData['event_payment_id'])) ? $formData['event_payment_id'] : 0;
							$other_costs_labels			  =  (isset($formData['other_costs_labels']) && is_array($formData['other_costs_labels']) && count($formData['other_costs_labels'])) ? implode(',', $formData['other_costs_labels']) : '';
							$other_costs_values			  =  (isset($formData['other_costs_values']) && is_array($formData['other_costs_values']) && count($formData['other_costs_values'])) ? implode(',', $formData['other_costs_values']) : '';
							
							$eventPaymentArray 			  =  array(
								'event_payment_id'		  => $event_payment_id,
								'fk_event_id'		  	  => $eventId,
					            'pay_per_driver'		  => $formData['pay_per_driver'],
								'additional_pay_event_manager' => $formData['additional_pay_event_manager'],
								'other_costs_labels'	  => $other_costs_labels,
								'other_costs_values'	  => $other_costs_values,
					            'total_costs'			  => $formData['total_costs'],
								'price_quote_client'	  => $formData['price_quote_client'],
								'company_net'		      => $formData['company_net'],
								'payment_details'		  => $formData['payment_details'],
					            'balance_owed'			  => $formData['balance_owed'],
							);
							$eventPaymentId  			  =  $this->getTable("EventPaymentTable")->saveEventPayment($eventPaymentArray);					//	Insert Shift payment details
							
							$shiftRequests 				  =  array(
								'fk_shift_id'			  	 => $shiftId,
					            'shift_occurs'			  	 => 2,
								'event_id'			  	 	 => $eventId,
					            'shift_request_updated_date' => $createdDate,
								'shift_request_status'		 => 2,		//	Shift Confirmed
					            'shift_request_isdelete'     => 0
					        );
							
							// Findout and Assigned the On-call drivers
							$notifications['shift_id']	  = $shiftId;
							$notifications['notify_date'] = $event_date;
							$onCallList					  = array_diff($preConfirmedDriver, $confirmedDriver);
							if(isset($onCallList) && is_array($onCallList) && count($onCallList)) {
							   $shiftRequests['shift_request_status']  =  3;			//	On-call list
							   $updateStatus						   =  $this->getTable("ShiftRequestTable")->updateConfirmedDrivers($shiftRequests, $onCallList);
							   
							   // Send the Notifications for On-Call Drivers
							   $notifications['subject'] = 'Your are assigned as on On-Call list for this Event';
							   $this->sendShiftAllocationNote($onCallList, $identity, $notifications);
							}
							
							// Findout the confirmed drivers
							$insertDrivers		=  array_diff($confirmedDriver, $preConfirmedDriver);
							if(isset($insertDrivers) && is_array($insertDrivers) && count($insertDrivers)) {
								$shiftRequests['shift_request_created_date']  =  $createdDate;
								$shiftRequests['shift_request_status']  	  =  2;		//	Shift Confirmed
								$insertStatus 				=  $this->getTable("ShiftRequestTable")->insertConfirmedDrivers($shiftRequests, $insertDrivers);
								
								// Send the Notifications for Confirmed Drivers
							    $notifications['subject'] 	= 'Event Confirmed';
								$this->sendShiftAllocationNote($insertDrivers, $identity, $notifications);
							}
							
							// Update shift manager.
							$shiftRequests['shift_manager'] = (isset($formData['shift_manager_id'])) ? $formData['shift_manager_id'] : 0;
							$shiftManagerStatus 			= $this->getTable("ShiftRequestTable")->updateShiftManager($shiftRequests);
							
							/*
							*	Function to Check the Bike Availability
							*	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
							*/
							$shiftDetails		=  array(
							   'shift_date' 	=> $event_date,
							   'start_time' 	=> $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_start_time', $formData),1),
							   'end_time'		=> $this->getCommonDataObj()->convertTimeFormat($this->getCommonDataObj()->customIsset('event_end_time', $formData),1),
							   'shift_id'		=> $shiftId,
							   'special_id'		=> $eventId,
							   'shift_occurs'	=> 2,
							);
//							$this->getCommonDataObj()->checkBikeAvailability($shiftDetails, 1, $this->pcUser);
						}
						
						$message = 'Drivers Assign successfully !';
						return $this->redirect()->toRoute('eventsmanagement', array('controller' => 'event', 'action' => 'event-listing'));
					} else {
						// upload_bike_install, upload_post_install,  !$uploadBikeInstall && !$uploadPostInstall
						/*$keys							  = (!$uploadBikeInstall) ? "upload_bike_install" : "upload_post_install";
						$err_msg						  = (!$uploadBikeInstall) ? "Bike Install photo is required!" : "Post-Install photo is required!";
						$addEventsJsonArray[$keys] 	 	  = false;
						$addEventsJsonArray['err_msg']	  = $err_msg;
						*/
					}
				} else {
					//$addEventsJsonArray['event_confirmed_drivers_div'] 	= false;
					//$addEventsJsonArray['err_msg']	  			 		= "Available Drivers is exist, You want to select more drivers, Please remove the existing drivers and then select the required drivers, No. of Drivers Needed : ".$formData['shift_bike_available']."!";
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				/*$keys							  = (!$totalConfirmedDriver) ? "event_confirmed_drivers_div" : "event_confirmed_bikes_div";
				$err_msg						  = (!$totalConfirmedDriver) ? "Assign the drivers, It's required" : "Select the Bikes, Its required!";
				$addEventsJsonArray[$keys] 	 	  = false;
				$addEventsJsonArray['err_msg']	  = $err_msg;*/
			}
        }
		
		// get Event details
		$results		= $this->getTable("EventTable")->getEventDetail($eventId);
		if($results) {
			foreach($results as $event) {
				$eventDetail = $event;
			}
			
			// Start : Drivers assignment process
			$requestedDrivers		=  $requestedDriversId	=  $allocatedDrivers = $allDrivers  =  array();
			$shiftManagers			=  array('' => 'Select Event manager');
			
			// Get Requested Drivers for the shift
			$shiftId 				=  $eventDetail['shift_id'];
			$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
			if($requestResults) {
				$requestedToArray	=  $requestResults->toArray();
				if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
					foreach($requestedToArray as $keys => $values) {
						$requestedDrivers[$values['fk_user_id']]		=  $values;
						if($values['shift_request_status'] == 2) {
							$allocatedDrivers[$values['fk_user_id']]	=  $values;
							$shiftManagers[$values['fk_user_id']]		=  $values['user_firstname'].' '.$values['user_lastname'];
						}
					}
				}
				$requestedDriversId	 =  (is_array($requestedDrivers) && count($requestedDrivers)) ? array_keys($requestedDrivers) : '';
			}
			
			// Get All Drivers details for the particulat locations
			$allDriversResults		 =  $this->getTable("UsersTable")->getUserDetailsForShiftAssign($requestedDriversId);		//	$requestedDriversId
			if($allDriversResults) {
				$allDriversToArray	 =  $allDriversResults->toArray();
				if($allDriversToArray && is_array($allDriversToArray) && count($allDriversToArray)) {
					foreach($allDriversToArray as $key => $value) {
						$allDrivers[$value['user_id']]	=  $value;
					}
				}
			}
			
			// Get All Bikes for the particulat locations
			$bikesIds			= (isset($eventDetail['bike_reserved_type']) && !empty($eventDetail['bike_reserved_type'])) ? explode(',', $eventDetail['bike_reserved_ids']): array();  // TODO : Condition handling for Already alocated bikes, bike_reserved_ids
			$allBikes			= $allocatedBikes  =  array();
			$allBikesResults	= $this->getTable("BikeTable")->GetAllBikes();
			if($allBikesResults) {
				foreach($allBikesResults as $key => $value) {
					$bikeId		= $value['bike_id'];
					if(is_array($bikesIds) && count($bikesIds) && in_array($bikeId, $bikesIds)) {
						$allocatedBikes[$bikeId] = $value;
					} else {
						$allBikes[$bikeId] 	     = $value;
					}
				}
			}
			
			// Get All Clients details for the particulat locations
			$allClientsSession 	 =  new Container('allClients');
			$allClients	 		 =  array();
			$allClientsOptions	 =  array(''  => 'Select Client');
			if($allClientsSession->offsetExists('clients') && $allClientsSession->clients != '' ) {
				$allClients 	 =  $allClientsSession->clients;
				$allClientsOptions  = $allClientsSession->clientOptions;
			} else {
				$clientsResults	 =  $this->getTable('UsersTable')->getAllClientsDetail();
				if($clientsResults && $clientsResults->count()) {
					$results	 =  $clientsResults;
					foreach($results as $result) {
						$allClients[$result["user_id"]]  		=  $result;
						$allClientsOptions[$result["user_id"]]  =  $result['user_firstname'].' '.$result['user_lastname'];
					}
				}
				$allClientsSession->clients  	   = $allClients;
				$allClientsSession->clientOptions  = $allClientsOptions;
			}
			
			// Get the All Locations
			$allLocationSession 	= new Container('allLocations');
			$allLocations			= array();
			if($allLocationSession->offsetExists('locations') && $allLocationSession->locations != '' ) {
				$allLocations		= $allLocationSession->locations;
			} else {
				$allLocations		= array(''  => 'Select Location');
				$locations			= $this->getTable('locationTable')->getAllLocationDetails();
				if($locations) {
					foreach($locations as $location) {
						$allLocations[$location->loc_id]  =  $location->loc_title;
					}
				}
				$allLocationSession->locations  =  $allLocations;
			}
			
			// Shift
			$editEventForm->get('fk_shift_id')->setValue($eventDetail['shift_id']);
			$editEventForm->get('fk_location_id')->setValueOptions($allLocations);
			$editEventForm->get('fk_location_id')->setValue($eventDetail['fk_location_id']);
			$editEventForm->get('event_start_time')->setValue($this->getCommonDataObj()->convertTimeFormat($eventDetail['shift_start_time']));
			$editEventForm->get('event_end_time')->setValue($this->getCommonDataObj()->convertTimeFormat($eventDetail['shift_end_time']));
			
			// Event
			$editEventForm->get('event_id')->setValue($eventDetail['event_id']);
			$editEventForm->get('event_title')->setValue($eventDetail['event_title']);
			$editEventForm->get('event_quote_type')->setValue($eventDetail['event_quote_type']);
			$editEventForm->get('shift_manager_id')->setValueOptions($shiftManagers);
			$editEventForm->get('shift_manager_id')->setValue($eventDetail['shift_manager_id']);
			$editEventForm->get('event_manager_phone')->setValue($eventDetail['event_manager_phone']);
			$editEventForm->get('bike_reserved_type')->setValue($eventDetail['bike_reserved_type']);
			$editEventForm->get('bike_reserved_ids')->setValue($eventDetail['bike_reserved_ids']);
			$editEventForm->get('contact_client_id')->setValueOptions($allClientsOptions);
			$editEventForm->get('contact_client_id')->setValue($eventDetail['contact_client_id']);
			$editEventForm->get('contact_client_phone')->setValue($eventDetail['contact_client_phone']);
			$editEventForm->get('contact_client_email')->setValue($eventDetail['contact_client_email']);
			$editEventForm->get('pickup_location')->setValue($eventDetail['pickup_location']);
			$editEventForm->get('dropoff_location')->setValue($eventDetail['dropoff_location']);
			$editEventForm->get('install_bonus_location_manager')->setValue($eventDetail['install_bonus_location_manager']);
			$editEventForm->get('special_instructions')->setValue($eventDetail['special_instructions']);
			$editEventForm->get('special_notes')->setValue($eventDetail['special_notes']);
			
			// Date
			$datetime	 =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$event_date	 =  $datetime->getDates(strtotime($eventDetail['event_date']), 0, 'n-j-Y');
			$editEventForm->get('event_date')->setValue($event_date);
			
			// Images
			$editEventForm->get('upload_bike_install')->setValue($eventDetail['upload_bike_install']);
			$editEventForm->get('upload_post_install')->setValue($eventDetail['upload_post_install']);
			
			// Available Bikes and Drivers
			$available_bike_count	= $eventDetail['event_total_bikes'] - count($allocatedBikes);
			$available_driver_count = $eventDetail['shift_bike_available'];
			$editEventForm->get('shift_bike_available')->setValue($available_driver_count);
			$editEventForm->get('event_total_bikes')->setValue($eventDetail['event_total_bikes']);
			
			// Event Payment
			$editEventForm->get('event_payment_id')->setValue($eventDetail['event_payment_id']);
			$editEventForm->get('pay_per_driver')->setValue($eventDetail['pay_per_driver']);
			$editEventForm->get('additional_pay_event_manager')->setValue($eventDetail['additional_pay_event_manager']);
			$editEventForm->get('total_costs')->setValue($eventDetail['total_costs']);
			$editEventForm->get('price_quote_client')->setValue($eventDetail['price_quote_client']);
			$editEventForm->get('company_net')->setValue($eventDetail['company_net']);
			$editEventForm->get('payment_details')->setValue($eventDetail['payment_details']);
			$editEventForm->get('balance_owed')->setValue($eventDetail['balance_owed']);
			
			// Other Costa label
			$other_costs_labels	 	 =  $other_costs_values	 =  array();
			if(isset($eventDetail['other_costs_labels']) && !empty($eventDetail['other_costs_labels'])) {
				$other_costs_labels	 =  explode(',', $eventDetail['other_costs_labels']);
			}
			
			// Other Costa value
			if(isset($eventDetail['other_costs_values']) && !empty($eventDetail['other_costs_values'])) {
				$other_costs_values	 =  explode(',', $eventDetail['other_costs_values']);
			}
			
			// Condition handling for Event category types
			$event_category_type	 =  $eventDetail['event_category'];
			if(isset($event_category_type) && $event_category_type == 1)
				$editCategoryArray	 =  array('' => 'Select Event Category', '1' => 'Ad Install');
			else if(isset($event_category_type) && $event_category_type == 2)
				$editCategoryArray	 =  array('' => 'Select Event Category', '2' => 'Dedicated Ad Event');
			else if(isset($event_category_type) && $event_category_type == 3)
				$editCategoryArray	 =  array('' => 'Select Event Category', '3' => 'Ride Request (not prepaid)');
			else
				$editCategoryArray	 =  $this->editCategoryArray;
			
			$editEventForm->get('event_category_type')->setValueOptions($editCategoryArray);
			$editEventForm->get('event_category_type')->setValue($eventDetail['event_category']);
			$editEventForm->get('hidden_event_category_type')->setValue($eventDetail['event_category']);
			
			return new ViewModel(array(
				'userObject'				=> $identity,
				'editEventForm'				=> $editEventForm,
				'allDrivers'				=> $allDrivers,
				'allocatedDrivers'			=> $allocatedDrivers,
				'allClients'				=> $allClients,
				'allBikes'					=> $allBikes,
				'allocatedBikes'			=> $allocatedBikes,
				'eventId'					=> $eventId,
				'categoryId'				=> $categoryId,
				'available_bike_count'		=> $available_bike_count,
				'available_driver_count'	=> $available_driver_count,
				'other_costs_labels'		=> $other_costs_labels,
				'other_costs_values'		=> $other_costs_values,
				'event_category_type'		=> $event_category_type,
				'eventDetail'				=> $eventDetail,
				'pc_users'					=> $this->pcUser,
				'message'					=> $message,
				'datetime'			    	=> $datetime,
				'sitePath'	 				=> $this->sitePath,
				'siteImagePath'	 			=> $this->siteImagePath,
				'siteImageUploadPath'		=> $this->siteImageUploadPath,
				'controller'				=> $this->params('controller'),
				'commonData'				=> $this->getCommonDataObj()
			));
		} else {
			return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'manage-shift'));
			die();
		}
    }
	
	/*	Action	: 	Ajax Add Event
	*	Detail	:	Add the new events via ajax
	*	TODO	:	Mail sending is inprocess
	*/
	public function ajaxAddEventAction() {
		$auth 		  		    = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addEventsJsonArray 	=  array();
		$addEventForm		 	=  new AddEventForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$addEventsJsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData				=  $request->getPost()->toArray();
			$Files    				=  $this->params()->fromFiles();
			
            if (is_array($postData)) {
				$formData		 	=  $postData;
				
				$eventQuoteType		=  $formData['event_quote_type'];
				$eventCategorytype	=  $formData['event_category_type'];
				
				// Drivers
				$allDrivers			=  (isset($formData['event_all_drivers_hidden_ids']) && is_array($formData['event_all_drivers_hidden_ids']) && count($formData['event_all_drivers_hidden_ids'])) ? $formData['event_all_drivers_hidden_ids'] : array();
				$preConfirmedDriver	=  (isset($formData['event_confirmed_drivers_hidden_ids']) && is_array($formData['event_confirmed_drivers_hidden_ids']) && count($formData['event_confirmed_drivers_hidden_ids'])) ? $formData['event_confirmed_drivers_hidden_ids'] : array();
				$confirmedDriver	=  (isset($formData['event_confirmed_drivers_ids']) && is_array($formData['event_confirmed_drivers_ids']) && count($formData['event_confirmed_drivers_ids'])) ? $formData['event_confirmed_drivers_ids'] : array();
				
				// Bikes
				$confirmedBikes		=  (isset($formData['event_confirmed_bikes_ids']) && is_array($formData['event_confirmed_bikes_ids']) && count($formData['event_confirmed_bikes_ids'])) ? $formData['event_confirmed_bikes_ids'] : array();
				
				// Condition handling for Install images.
				// My File uplaod plugins
				$uploadBikeInstall			=	$uploadPostInstall	=  '';
				$myFileUpload   			=   $this->MyFileUpload();
				$myFileUpload->fileTypes	=	$this->imageTypes;
				$myFileUpload->fileSizes	=	$this->imageSizes;
				
				// Bike install
				if(isset($formData['upload_bike_install_fakefilepc']) && !empty($formData['upload_bike_install_fakefilepc'])) {
					$fileNameArray			=	array("upload_bike_install");
					$uploadBikeInstall		=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
				
				// Post install
				if(isset($formData['upload_post_install_fakefilepc']) && !empty($formData['upload_post_install_fakefilepc'])) {
					$fileNameArray			=	array("upload_post_install");
					$uploadPostInstall		=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
				
				// Condition handling for Drivers selections
				$totalConfirmedDriver		=	count($confirmedDriver);
				$totalConfirmedBikes		=	count($confirmedBikes);
				if($totalConfirmedDriver && $totalConfirmedBikes) {
					
					// Condition check for Available Bikes and Assigned drivers
					$totalBikeAvailable 	=  (int) ($totalConfirmedDriver - count($preConfirmedDriver));
					if($totalBikeAvailable <= $formData['shift_bike_available']) {
						// Condition handling for Images
						if(!$uploadBikeInstall && !$uploadPostInstall) {
							$addEventsJsonArray['event_confirmed_drivers_div'] 	= true;
							$addEventsJsonArray['err_msg']	  			 		= "";
						} else {
							// upload_bike_install, upload_post_install,  !$uploadBikeInstall && !$uploadPostInstall
							$keys							  = (!$uploadBikeInstall) ? "upload_bike_install" : "upload_post_install";
							$err_msg						  = (!$uploadBikeInstall) ? "Bike Install photo is required!" : "Post-Install photo is required!";
							$addEventsJsonArray[$keys] 	 	  = false;
							$addEventsJsonArray['err_msg']	  = $err_msg;
						}
					} else {
						$addEventsJsonArray['event_confirmed_drivers_div'] 	= false;
						$addEventsJsonArray['err_msg']	  			 		= "Available Drivers is exist, You want to select more drivers, Please remove the existing drivers and then select the required drivers, No. of Drivers Needed : ".$formData['shift_bike_available']."!";
					}
				} else {
					// $errorMessages	= $addUserForm->getMessages();
					$keys							  = (!$totalConfirmedDriver) ? "event_confirmed_drivers_div" : "event_confirmed_bikes_div";
					$err_msg						  = (!$totalConfirmedDriver) ? "Assign the drivers, It's required" : "Select the Bikes, Its required!";
					$addEventsJsonArray[$keys] 	 	  = false;
					$addEventsJsonArray['err_msg']	  = $err_msg;
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$addEventsJsonArray['event_confirmed_drivers_div'] 	= false;
				$addEventsJsonArray['err_msg']				 		= "Assign the drivers, It's required";
			}
        } else {
				$addEventsJsonArray['event_confirmed_drivers_div']  = false;
				$addEventsJsonArray['err_msg']				 		= "Assign the drivers, It's required";
		}
		
		echo json_encode($addEventsJsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	Event listing
	*	Detail	:	Used to List the Events details
	*/
	public function eventListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$eventFilterForm 	  	  = new EventFilterForm();
		$request 				  = $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			  = $this->getCommonDataObj()->destroySessionVariables(array('quotedEventListing', 'confirmedEventListing'));
		}
		$quotedEventSession  	  = new Container('quotedEventListing');
		$confirmedEventSession    = new Container('confirmedEventListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$eventFilterForm->setData($request->getPost());
			if(isset($formData['event_quoted']) && $formData['event_quoted'] == 1) {							// Quoted Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$quotedEventSession->event_date	 	 = $formData['event_date'];
				else
					$quotedEventSession->event_date	 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$quotedEventSession->event_title	 = $formData['event_title'];
				else
					$quotedEventSession->event_title	 = '';
			} else if(isset($formData['event_quoted']) && $formData['event_quoted'] == 2) {						// Confirmed Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$confirmedEventSession->event_date   = $formData['event_date'];
				else
					$confirmedEventSession->event_date 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$confirmedEventSession->event_title	 = $formData['event_title'];
				else
					$confirmedEventSession->event_title	 = '';
			}
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Confirmed Events Listing
		$perPage					= $this->defaultPerPage;
		$quote_confirmed			= 2;		//		1 = Quote; 2 = Confirmed
		$iteratorAdapter_confirmed	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventList($quote_confirmed));
		$paginator_confirmed		= new \Zend\Paginator\Paginator($iteratorAdapter_confirmed);
		$paginator_confirmed->setCurrentPageNumber($page);
		$paginator_confirmed->setItemCountPerPage($perPage);
		
		$paginator_quoted			= '';
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'eventFilterForm'		=> $eventFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_confirmed'	=> $paginator_confirmed,
			'paginator_quoted'		=> $paginator_quoted,
			'perPage'				=> $perPage,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Event list, Ajax action
	*	Detail	:	Used to list the Events details via Ajax
	*/
	public function eventListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$quoted		= $matches->getParam('quoted', '');
		
		//	Session for Role listing
		$sessionsContainer	= (isset($quoted) && $quoted == 1) ? 'quotedEventListing' : 'confirmedEventListing';
		$eventsSession 	= new Container($sessionsContainer);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($eventsSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$eventsSession->sortBy	= $sortBy;
		} else if($eventsSession->offsetExists('sortBy')) {
			$sortBy	= $eventsSession->sortBy;
		}
		if($sortType != '') {
			if($eventsSession->sortType == $sortType && $columnFlag == 1)
				$eventsSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$eventsSession->sortType	= $sortType;
		} else if($eventsSession->offsetExists('sortType')) {
			$sortType	= $eventsSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$eventsSession->perPage	= $perPage;
		} else if($eventsSession->offsetExists('perPage')) {
			$perPage		= $eventsSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$quote_confirmed	= (isset($quoted) && $quoted == 1) ? $quoted : 2;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventList($quote_confirmed));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		if(isset($quoted) && $quoted == 2) {
			$paginator_quoted		= '';
			$paginator_confirmed	= $paginator;
		} else {
			$paginator_quoted		= $paginator;
			$paginator_confirmed	= '';
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_confirmed'	=> $paginator_confirmed,
			'paginator_quoted'		=> $paginator_quoted,
			'perPage'				=> $perPage,
			'quoted'				=> $quoted,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Event
	*	Detail	:	To View the Accident details
	*/
	public function viewEventAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			=  $this->getRequest();
			$message			=  '';
			$eventId 			= (int) $this->params()->fromRoute('id', 0);
			$eventDetails		= '';
			
			if ($eventId) {
				$results		= $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails = $event;
					}
					
					// Date
					$datetime	=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
						$eventDetails['event_date']	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
					} else {
						$eventDetails['event_date']	= '-';
					}
					
					// Start : Drivers assignment process
					$requestedDrivers		=  $allocatedDrivers =  array();
					$shiftManagers			=  array();
					
					// Get Requested Drivers for the shift
					$shiftId 				=  $eventDetails['shift_id'];
					$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
					if($requestResults) {
						$requestedToArray	=  $requestResults->toArray();
						if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
							foreach($requestedToArray as $keys => $values) {
								$requestedDrivers[$values['fk_user_id']]		=  $values;
								if($values['shift_request_status'] == 2) {
									$allocatedDrivers[$values['fk_user_id']]	=  $values;
									if($eventDetails['shift_manager_id'] == $values['fk_user_id']) {
										$shiftManagers[$values['fk_user_id']]	=  $values['user_firstname'].' '.$values['user_lastname'];
									}
								}
							}
						}
					}
					
					// Get All Bikes for the particulat locations
					$allocatedBikes  	= array();
					if (isset($eventDetails['bike_reserved_type']) && !empty($eventDetails['bike_reserved_type']) && $eventDetails['bike_reserved_type'] == 2) {
						$bikesIds			= $eventDetails['bike_reserved_ids'];
						$allBikesResults	= $this->getTable("BikeTable")->GetSelectedBikes($bikesIds);
						if($allBikesResults) {
							foreach($allBikesResults as $key => $value) {
								$bikeId					 = $value['bike_id'];
								$allocatedBikes[$bikeId] = $value;
							}
						}
					}
					
					// Other Costa label
					$other_costs_labels	 	 =  $other_costs_values	 =  array();
					if(isset($eventDetails['other_costs_labels']) && !empty($eventDetails['other_costs_labels'])) {
						$other_costs_labels	 =  explode(',', $eventDetails['other_costs_labels']);
					}
					
					// Other Costa value
					if(isset($eventDetails['other_costs_values']) && !empty($eventDetails['other_costs_values'])) {
						$other_costs_values	 =  explode(',', $eventDetails['other_costs_values']);
					}
					
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'balanceDueArrray'	 	 => $this->balanceDueArrray,
					'quotedStatusArrray' 	 => $this->quotedStatusArrray,
					'eventDetails'	 	 	 => $eventDetails,
					'allocatedDrivers'		 => $allocatedDrivers,
					'allocatedBikes'		 => $allocatedBikes,
					'other_costs_labels'	 => $other_costs_labels,
					'other_costs_values'	 => $other_costs_values,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'eventCategoryArray'	 => $this->eventCategoryArray,
					'quotedStatusArrray'	 => $this->quotedStatusArrray,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Event details, Ajax action
	*	Detail	:	Used to Delete the Event details
	*	TODO 	:	Need to Send the Notifications and Mail for the Shift cancel informations for the allocated drivers.
	*/
	public function deleteEventAction()
    {
		$shift_id = (int) $this->params()->fromRoute('id', 0);
        if ($shift_id) {
			$this->getTable("EventTable")->deleteEvent($shift_id);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Client Event listing
	*	Detail	:	Used to List the Events details 
	*/
	public function clientEventListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$eventFilterForm 	  	  = new EventFilterForm();
		$request 				  = $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			  = $this->getCommonDataObj()->destroySessionVariables(array('clientQuotedEventListing', 'clientConfirmedEventListing'));
		}
		$quotedEventSession  	  = new Container('clientQuotedEventListing');
		$confirmedEventSession    = new Container('clientConfirmedEventListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$eventFilterForm->setData($request->getPost());
			if(isset($formData['event_quoted']) && $formData['event_quoted'] == 1) {							// Quoted Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$quotedEventSession->event_date	 	 = $formData['event_date'];
				else
					$quotedEventSession->event_date	 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$quotedEventSession->event_title	 = $formData['event_title'];
				else
					$quotedEventSession->event_title	 = '';
			} else if(isset($formData['event_quoted']) && $formData['event_quoted'] == 2) {						// Confirmed Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$confirmedEventSession->event_date   = $formData['event_date'];
				else
					$confirmedEventSession->event_date 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$confirmedEventSession->event_title	 = $formData['event_title'];
				else
					$confirmedEventSession->event_title	 = '';
			}
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Confirmed Events Listing
		$perPage					= $this->defaultPerPage;
		$quote						= 1;		//		1 = Quote; 2 = Confirmed
		$iteratorAdapter_confirmed	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventList($quote));
		$paginator_quoted			= new \Zend\Paginator\Paginator($iteratorAdapter_confirmed);
		$paginator_quoted->setCurrentPageNumber($page);
		$paginator_quoted->setItemCountPerPage($perPage);
		
		$paginator_confirmed		= '';
		// Date
		$datetime		  			=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$eventStatusClasses			=  array(1 => 'he-confirmed', 2 => 'he-request');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'eventFilterForm'		=> $eventFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'eventStatusClasses'	=> $eventStatusClasses,
			'paginator_confirmed'	=> $paginator_confirmed,
			'paginator_quoted'		=> $paginator_quoted,
			'perPage'				=> $perPage,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Client Event list, Ajax action
	*	Detail	:	Used to list the Events details via Ajax
	*/
	public function clientEventListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$quoted		= $matches->getParam('quoted', '');
		
		//	Session for Role listing
		$sessionsContainer	= (isset($quoted) && $quoted == 1) ? 'clientQuotedEventListing' : 'clientConfirmedEventListing';
		$eventsSession 	= new Container($sessionsContainer);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($eventsSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$eventsSession->sortBy	= $sortBy;
		} else if($eventsSession->offsetExists('sortBy')) {
			$sortBy	= $eventsSession->sortBy;
		}
		if($sortType != '') {
			if($eventsSession->sortType == $sortType && $columnFlag == 1)
				$eventsSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$eventsSession->sortType	= $sortType;
		} else if($eventsSession->offsetExists('sortType')) {
			$sortType	= $eventsSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$eventsSession->perPage	= $perPage;
		} else if($eventsSession->offsetExists('perPage')) {
			$perPage		= $eventsSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$quote				= (isset($quoted)) ? $quoted : 1;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventList($quote));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		if(isset($quoted) && $quoted == 2) {
			$paginator_quoted		= '';
			$paginator_confirmed	= $paginator;
		} else {
			$paginator_quoted		= $paginator;
			$paginator_confirmed	= '';
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$eventStatusClasses			=  array(1 => 'he-confirmed', 2 => 'he-request');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_confirmed'	=> $paginator_confirmed,
			'paginator_quoted'		=> $paginator_quoted,
			'perPage'				=> $perPage,
			'quoted'				=> $quoted,
			'eventStatusClasses'	=> $eventStatusClasses,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View ClientEvent
	*	Detail	:	To View the Accident details
	*/
	public function viewClientEventAction()
    {
		$result 	  = new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			= $this->getRequest();
			$message			=  '';
			$eventId 			= $this->params()->fromRoute('id', 0);
			
			$eventDetails		= '';
			if ($eventId) {
				$results		= $this->getTable("EventTable")->getViewClientEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails = $event;
					}
					
					// Date
					$datetime	=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
						$eventDetails['event_date']	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
					} else {
						$eventDetails['event_date']	= '-';
					}
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'eventDetails'	 	 	 => $eventDetails,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'eventCategoryArray'	 => $this->eventCategoryArray,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Approval ClientEvent
	*	Detail	:	To View the Accident details
	*/
	public function approvalClientEventAction()
    {
		$result 	  = new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity 			= $auth->getIdentity();
			$request 			=  $this->getRequest();
			$message			=  '';
			$eventId 			=  (int) $this->params()->fromRoute('eventId', 0);
			$statusId 			=  (int) $this->params()->fromRoute('statusId', 0);
			
			$eventDetails		=  '';
			$statusFlag			=  false;
			
			// Create Instant for Approval Event form
			$approvalEventForm  = new ApprovalEventForm();
			
			if ($eventId) {
				$results		= $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails = $event;
					}
					
					$approvalEventForm->get('shift_id')->setValue($eventDetails['shift_id']);
					$approvalEventForm->get('event_id')->setValue($eventDetails['event_id']);
					$approvalEventForm->get('approval_cost')->setValue($eventDetails['price_quote_client']);
					
					// Date
					$datetime	 =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$event_date	 =  $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
					$approvalEventForm->get('event_date')->setValue($event_date);
					
					// Assign the Event Status like Approved or Rejected.
					// $statusId , $eventId		//	$eventDetails['event_approved_status']
					if($statusId != $eventDetails['event_approved_status']) {
						$approvalEventForm->get('status_id')->setValue($statusId);
						$statusFlag			=  true;
					}
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'eventDetails'	 	 	 => $eventDetails,
					'approvalEventForm'	 	 => $approvalEventForm,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'statusId'			 	 => $statusId,
					'statusFlag'			 => $statusFlag,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Ajax Approval Client Event
	*	Detail	:	Approve the events by client and also send the Notifications to Location managers
	*	TODO	:	Mail sending is inprocess. Need to check
	*/
	public function ajaxApprovalClientEventAction() {
		$auth 		  		    = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray 				= array();
		$notifications			= array();
		$approvalEventForm  	= new ApprovalEventForm();
	 	$request 				= $this->getRequest();
		$message				= '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
			
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$shiftId		=  (isset($formData['shift_id']) && !empty($formData['shift_id'])) ? $formData['shift_id'] : 0;
				$event_id		=  (isset($formData['event_id']) && !empty($formData['event_id'])) ? $formData['event_id'] : 0;
				$status_id		=  (isset($formData['status_id']) && !empty($formData['status_id'])) ? $formData['status_id'] : 0;
				
				$approvalArray 	=  array(
					'event_id'	=> $event_id,
					'event_approved_status'	=> $status_id 					//	'0:Not Yet Approved,1:Approved,2:Rejected'
				);
				$eventId  		=  $this->getTable("EventTable")->saveEvent($approvalArray);				//	Save Approval Event status
				
				// Send Manager Note Notification	//	TODO
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				if(strpos($formData['event_date'], '-') !== false ) {
					$formData['event_date']	=  str_replace('-', '/', $formData['event_date']);
					$event_date =  $datetime->getDates(strtotime($formData['event_date']), 0, 'Y-m-d');
				} else {
					$event_date =  '0000-00-00';
				}
				$notifications['shift_id']    	 = $shiftId;
				$notifications['notify_date'] 	 = $event_date;
				if($status_id == 1) {
				   $notifications['notify_type'] = 9;		//	9:Event Approved, 10:Event Rejected
			       $notifications['subject']  	 = 'Event Approved. Price : $'.$formData['approval_cost'].', <br/>Note for Manager : '.$formData['approval_manager_note'];
				} else {
				   $notifications['notify_type'] = 10;		//	9:Event Approved, 10:Event Rejected
			       $notifications['subject']  	 = 'Event Rejected. <br/>Note for Manager : '.$formData['approval_manager_note'];
				}
				
				// Get Location Manager Details
				$locationManagersResult		= $this->getTable("UsersTable")->getLocationManagerDetail(3);
				$locationManagers			= array();
				if($locationManagersResult) {
					foreach($locationManagersResult as $locationManager) {
						$locationManagers[] =  $locationManager['user_id'];
					}
				}
			    $this->sendShiftAllocationNote($locationManagers, $identity, $notifications);
				
				// Set the Json values
				$jsonArray['event_id'] 			 = $eventId;
				$jsonArray['shift_id'] 			 = $shiftId;
				$jsonArray['status_id'] 		 = $status_id;
				$jsonArray['event_payment_cost'] = true;
				$jsonArray['err_msg']			 = "Event Approved successfully done !";
				
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$jsonArray['approval_cost'] 	 = false;
				$jsonArray['err_msg']			 = "Check the Approval fields, It's required";
			}
        } else {
				$jsonArray['approval_cost']  	 = false;
				$jsonArray['err_msg']		 	 = "Check the Approval fields, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	
	/*	Action	: 	Event Payments
	*	Detail	:	Used to add the event payment historys
	*/
	public function eventPaymentsAction()
    {
		$request 	  = $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$message  	= '';
		$eventId 	= (int) $this->params()->fromRoute('id', 0);
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$datetime 		     = $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$addEventPaymentForm =  new AddEventPaymentForm();
		$eventDetails		 = '';
		if ($eventId) {
			$results		= $this->getTable("EventTable")->getViewEventDetail($eventId);
			if($results) {
				foreach($results as $event) {
					$eventDetails = $event;
				}
				
				$addEventPaymentForm->get('fk_event_id')->setValue($eventDetails['event_id']);
				$addEventPaymentForm->get('event_title')->setValue($eventDetails['event_title']);
				$addEventPaymentForm->get('payment_method')->setValueOptions($this->paymentMethodArray);
				$addEventPaymentForm->get('balance_owed')->setValue($eventDetails['balance_owed']);
				
				/*
				* 	Event Payment details Listings
				*/
				//	Destroy listing Session Vars
				$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('eventPaymentListing'));
				$listingSession 	= new Container('eventPaymentListing');
				$listingSession->event_id = $eventDetails['event_id'];
				
				$perPage			= 5;		//	$this->defaultPerPage
				$message			= '';
				$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventPaymentHistoryTable')->getEventPaymentList());
				$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
				$paginator->setCurrentPageNumber($page);
				$paginator->setItemCountPerPage($perPage);
				
				return new ViewModel(array(
					'userObject'			=> $identity,
					'addEventPaymentForm'	=> $addEventPaymentForm,
					'pc_users'				=> $this->pcUser,
					'message'				=> $message,
					'page'					=> $page,
					'sortBy'				=> $sortBy,
					'paginator'				=> $paginator,
					'perPage'				=> $perPage,
					'datetime'				=> $datetime,
					'paymentMethodArray'	=> $this->paymentMethodArray,
					'perPageArray'			=> $this->perPageArray,
					'controller'			=> $this->params('controller'),
					'commonData'			=> $this->getCommonDataObj()
				));
				
			} else {
				return $this->redirect()->toRoute('eventsmanagement', array('controller' => 'event', 'action' => 'event-listing'));
			}
		} else {
			return $this->redirect()->toRoute('eventsmanagement', array('controller' => 'event', 'action' => 'event-listing'));
		}
    }
	
	/*	Action	: 	Ajax Event Payment list, Ajax action
	*	Detail	:	Used to list the Events payment listings
	*/
	public function eventPaymentsListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('eventPaymentListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= 5;	//	$this->defaultPerPage
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventPaymentHistoryTable')->getEventPaymentList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime 		    = $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'datetime'				=> $datetime,
			'paymentMethodArray'	=> $this->paymentMethodArray,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Add Event Payment
	*	Detail	:	Add the new events via ajax
	*	TODO	:	Mail sending is inprocess
	*/
	public function ajaxAddEventPaymentAction() {
		$auth 		  		    = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addEventsJsonArray 	=  array();
		$addEventForm		 	=  new AddEventForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$addEventsJsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
			$Files    			=  $this->params()->fromFiles();
			
            if (is_array($postData)) {
				$formData			=  $postData;
				$paymentCost 		= $formData['payment_cost'];
				$balanceOwed 		= $formData['balance_owed'];
				if($paymentCost <= $balanceOwed) {
					$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
					
					if(strpos($formData['payment_date'], '-') !== false ) {
						$formData['payment_date']	=  str_replace('-', '/', $formData['payment_date']);
						$payment_date = $datetime->getDates(strtotime($formData['payment_date']), 0, 'Y-m-d');
					} else {
						$payment_date = '0000-00-00';
					}
					$payment_id		  = (isset($formData['payment_id']) && !empty($formData['payment_id'])) ? $formData['payment_id'] : 0;
					$paymentArray 	  =  array(
						'payment_id'		 	=> $payment_id,
						'fk_event_id'		 	=> $formData['fk_event_id'],
			            'payment_date'		 	=> $payment_date,
						'payment_cost'			=> $formData['payment_cost'],
						'payment_method'	 	=> $formData['payment_method'],
						'payment_updated_date' 	=> $createdDate,
						'payment_isdelete'	 	=> 0
					);
					
					if(!$payment_id) {
						$paymentArray['payment_creation_date']  = $createdDate;
					}
					
					$paymentId     =  $this->getTable("EventPaymentHistoryTable")->saveEventPaymentHistory($paymentArray);								//	Insert Event Payments
					
					// Update the Payment in Events Payment.
					$data		   =  array(
						'eventId'  => $formData['fk_event_id'],
						'costs'	   => $formData['payment_cost']
					);
					$this->getTable("EventPaymentTable")->updateBalanceOwed($data);
					
					// view-event-payment
					$addEventsJsonArray['payment_flag'] = true;
					$addEventsJsonArray['event_id'] 	= $formData['fk_event_id'];
					$addEventsJsonArray['payment_cost'] = $formData['payment_cost'];
					$addEventsJsonArray['balance_owed'] = $formData['balance_owed'];
					$addEventsJsonArray['err_msg']		= "Event payment successfully saved";
				} else {
					// $errorMessages	= $addUserForm->getMessages();
					$addEventsJsonArray['payment_flag'] = false;
					$addEventsJsonArray['err_msg']		= "Entered Payment is greater than the actual amount, <br/>Please check the Event total cost";
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$addEventsJsonArray['payment_flag'] 	= false;
				$addEventsJsonArray['err_msg']			= "Check the Event payment fields, It's required";
			}
        } else {
				$addEventsJsonArray['payment_flag']  	= false;
				$addEventsJsonArray['err_msg']			= "Check the Event payment fields, It's required";
		}
		
		echo json_encode($addEventsJsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	View Event Payment
	*	Detail	:	To View the Accident details
	*/
	public function viewEventPaymentAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			=  $this->getRequest();
			$message			=  '';
			$paymentId 			= (int) $this->params()->fromRoute('id', 0);
			$details			= '';
			
			if ($paymentId) {
				$results		= $this->getTable("EventPaymentHistoryTable")->getEventPaymentDetail($paymentId);
				if($results) {
					foreach($results as $event) {
						$details = $event;
					}
					
					// Date
					$datetime	=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($details['payment_date']) && $details['payment_date'] != "0000-00-00 00:00:00") {
						$details['payment_date'] = $datetime->getDates(strtotime($details['payment_date']), 0, 'n-j-Y');
					} else {
						$details['payment_date'] = '-';
					}
				}
			}
			
			$result->setVariables(array(
					'details'	 	 	 	=> $details,
					'datetime'				=> $datetime,
					'paymentMethodArray'	=> $this->paymentMethodArray,
					'controller'			=> $this->params('controller'),
					'commonData'			=> $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Event Payment details, Ajax action
	*	Detail	:	Used to Delete the Event Payment details
	*	TODO 	:	Need to Send the Notifications and Mail for the Shift cancel informations for the allocated drivers.
	*/
	public function deleteEventPaymentAction()
    {
		$payment_id = (int) $this->params()->fromRoute('id', 0);
        if ($payment_id) {
			$this->getTable("EventPaymentHistoryTable")->deleteEventPaymentHistory($payment_id);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	private function sendShiftAllocationNote($driversArray = false, $identity, $notifications)
    {
        if($driversArray && is_array($driversArray) && count($driversArray)) {
			foreach($driversArray as $driver_key => $driver_value) {
				$insert_array[]		 = "'".$notifications['shift_id']."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifications['subject'])."','".addslashes($notifications['notify_date'])."','".addslashes($notifications['notify_type'])."'";
			}
			if(is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
			}
		}
    }
	
	/*	Action	: 	Mail Testing
	*	Detail	:	Used to for testing process
	*/
	public function mailTestAction()
	{
		$eventId 			= (int) $this->params()->fromRoute('id', 0);
		$eventDetails		= '';
		
		if ($eventId) {
			$results		= $this->getTable("EventTable")->getViewClientEventDetail($eventId);
			if($results) {
				foreach($results as $event) {
					$eventDetails = $event;
				}
				/*
				$locationManagersResult		= $this->getTable("UsersTable")->getLocationManagerDetail(3);
				if($locationManagersResult) {
					foreach($locationManagersResult as $locationManager) {
						$locationManagers 	=  $locationManager;
					}
				}
				
				$mailArray			    =  array(
					'subject'		  	=> 'Email Quote to Client',
		            'from_email'	  	=> '',
					'from_name' 	  	=> '',
					'to_email' 	  	  	=> $eventDetails['contact_client_email'],
					'mail_title' 	  	=> 'Email Quote to Client',
					'mail_descriptions' => 'Quoted Event details are shown below, You want do further changes, Please contact the location manager.',
					'mail_preview' 		=> 0,
					'template_path' 	=> 'usermanagement/mail_templates/event_quote_mail_template',
		        );
				
				// Date
				$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
					$event_date	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
				} else {
					$event_date	= '-';
				}
				
				$shift_start_time		=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_start_time'], 1);
				$shift_end_time			=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_end_time'], 1);
				$event_category			=  (isset($this->eventCategoryArray[$eventDetails['event_category']]) && !empty($this->eventCategoryArray[$eventDetails['event_category']])) ? $this->eventCategoryArray[$eventDetails['event_category']] : '';
				
				$mailDetails			=  array(
					'Event Date'				=>	$event_date,
					'Event Category'			=>	$event_category,
					'Event Title'				=>	$eventDetails['event_title'],
					'Start Time'				=>	$shift_start_time,
					'End Time'					=>	$shift_end_time,
					'No of Bikes Reserved'		=>	$eventDetails['event_total_bikes'],
					'Pickup Location'			=>	$eventDetails['pickup_location'],
					'Dropoff Location'			=>	$eventDetails['dropoff_location'],
					'Location Manager'			=>	$locationManagers['location_manager_name'],
					'Location Manager Phone'	=>	$locationManagers['user_telephone_number'],
					'Event Manager'				=>	$eventDetails['shift_manager_name'],
					'Special Instructions'		=>	$eventDetails['special_instructions'],
					'Price Quote to Client'		=>	'$'.$eventDetails['price_quote_client'],
					'Payment Details'			=>	$eventDetails['payment_details'],
					'Balance Owed'				=>	'$'.$eventDetails['balance_owed']
				);
				$this->getCommonDataObj()->siteMailSending($mailDetails, $mailArray);
				*/
				
				$locationManagersResult		= $this->getTable("UsersTable")->getLocationManagerDetail(3);
				if($locationManagersResult) {
					foreach($locationManagersResult as $locationManager) {
						$locationManagers 	=  $locationManager;
					}
				}
				
				$mailArray			    =  array(
					'subject'		  	=> 'Event reminder email',
		            'from_email'	  	=> '',
					'from_name' 	  	=> '',
					'to_email' 	  	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
					'mail_title' 	  	=> 'Event reminder email',
					'mail_descriptions' => 'Event details are shown below, You want further details, Please contact the Event or location manager.',
					'mail_preview' 		=> 0,
					'template_path' 	=> 'usermanagement/mail_templates/event_quote_mail_template',
					//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
		        );
				
				// Drivers Working, Get the Allocated drivers for a particular Events.
				$allocatedDrivers 		=  array();
				$driversWorking  		=  array();
				$shiftId 				=  $eventDetails['shift_id'];
				$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
				if($requestResults) {
					$requestedToArray	=  $requestResults->toArray();
					if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
						foreach($requestedToArray as $keys => $values) {
							if($values['shift_request_status'] == 2) {
								$allocatedDrivers[$values['fk_user_id']]	=  $values;
								$driversWorking[$values['fk_user_id']]		=  $values['user_full_name'];
							}
						}
					}
				}
				$showDrivers 	= implode('<br/>', $driversWorking);
				
				// Date
				$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
					$event_date	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
				} else {
					$event_date	= '-';
				}
				
				$shift_start_time		=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_start_time'], 1);
				$shift_end_time			=  $this->getCommonDataObj()->getTimeFormate($eventDetails['shift_end_time'], 1);
				$event_category			=  (isset($this->eventCategoryArray[$eventDetails['event_category']]) && !empty($this->eventCategoryArray[$eventDetails['event_category']])) ? $this->eventCategoryArray[$eventDetails['event_category']] : '';
				
				$mailDetails			=  array(
					'Event Date'				=>	$event_date,
					'Event Category'			=>	$event_category,
					'Event Title'				=>	$eventDetails['event_title'],
					'Start Time'				=>	$shift_start_time,
					'End Time'					=>	$shift_end_time,
					'No of Bikes Reserved'		=>	$eventDetails['event_total_bikes'],
					'Pickup Location'			=>	$eventDetails['pickup_location'],
					'Dropoff Location'			=>	$eventDetails['dropoff_location'],
					'Location Manager'			=>	$locationManagers['location_manager_name'],
					'Location Manager Phone'	=>	$locationManagers['user_telephone_number'],
					'Event Manager'				=>	$eventDetails['shift_manager_name'],
					'Pay per driver'			=>	'$'.$eventDetails['pay_per_driver'],
					'Drivers working'			=>	$showDrivers
				);
				
				$this->getCommonDataObj()->siteMailSending($mailDetails, $mailArray);
			}
		}
		
		// drivers working
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."====>End<==";
		return $this->getResponse();
	}
	
	public function testAction()
	{
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
