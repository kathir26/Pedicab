<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Eventsmanagement\Controller\Event',
                        'action'     => 'event-listing',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'eventsmanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/eventsmanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'event-listing',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/eventsmanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'approval-client-event' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/approval-client-event[/[:eventId[/[:statusId]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Eventsmanagement\Controller',
                        'controller'   		 => 'Event',
                        'action'       		 => 'approval-client-event',
						'eventId' 	 		 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'statusId' 		 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'eventsmanagement/event/edit-event' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/eventsmanagement/event/edit-event[/[:eventId[/[:categoryId]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Eventsmanagement\Controller',
                        'controller'   		 => 'Event',
                        'action'       		 => 'edit-event',
						'eventId' 	 		 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'categoryId' 		 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'event-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/event-page[/[:quoted[/[:pageid]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'event-list',
						'quoted' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'event-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/event-list[/[:quoted[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'event-list',
						'quoted' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'event-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/event-listcount[/[:quoted[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'   => 'Event',
                        'action'       => 'event-list',
						'quoted' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-event-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-event-page[/[:quoted[/[:pageid]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'client-event-list',
						'quoted' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-event-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-event-list[/[:quoted[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'client-event-list',
						'quoted' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-event-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-event-listcount[/[:quoted[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'   => 'Event',
                        'action'       => 'client-event-list',
						'quoted' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'event-payments-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/event-payments-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'    => 'Event',
                        'action'        => 'event-payments-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'event-payments-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/event-payments-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Eventsmanagement\Controller',
                        'controller'   => 'Event',
                        'action'       => 'event-payments-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'Eventsmanagement\Controller\Event' 			=> 'Eventsmanagement\Controller\EventController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
