<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Eventsmanagement;

use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;

// Models
use Usermanagement\Model\UsersTable,
	Eventsmanagement\Model\EventTable,
	Eventsmanagement\Model\EventPaymentTable,
	Eventsmanagement\Model\EventPaymentHistoryTable,
	Schedulemanagement\Model\ShiftTable,
	Schedulemanagement\Model\ShiftRequestTable;
	
use Zend\ModuleManager\Feature\AutoloaderProviderInterface,
	Zend\ModuleManager\Feature\ConfigProviderInterface,
	Zend\ModuleManager\Feature\ServiceProviderInterface;

class Module implements AutoloaderProviderInterface, ConfigProviderInterface
{
   	public function onBootstrap(MvcEvent $e)
    {
        $e->getApplication()->getServiceManager()->get('translator');
	    $e->getApplication()->getServiceManager()->get('viewhelpermanager')->setFactory('eventsmanagement', function($sm) use ($e) {
	        $viewHelper = new View\Helper\Eventsmanagement($e->getRouteMatch());
	        return $viewHelper;
	    });
		$eventManager        = $e->getApplication()->getEventManager();
		$eventManager->attach('route', array($this, 'loadConfiguration'), 2);
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
    }
	
	public function loadConfiguration(MvcEvent $e)
    {
        $application   = $e->getApplication();
		$sm            = $application->getServiceManager();
		$sharedManager = $application->getEventManager()->getSharedManager();
		
        $router  	   = $sm->get('router');
		$request 	   = $sm->get('request');
		
		$matchedRoute = $router->match($request);
		if (null !== $matchedRoute) { 
           $sharedManager->attach('Zend\Mvc\Controller\AbstractActionController','dispatch', 
                function($e) use ($sm) {
		   $sm->get('ControllerPluginManager')->get('Myplugin')
                      ->doAuthorization($e); //pass to the plugin...
	       },2
           );
        }
    }
	
	/*	public function onBootstrap(\Zend\EventManager\EventInterface $e)
	{
	    $app = $e->getApplication();
	    $app->getEventManager()->attach(
	        'dispatch',
	        function($e) {
	            $routeMatch = $e->getRouteMatch();
	            $viewModel = $e->getViewModel();
	            $viewModel->setVariable('controller', $routeMatch->getParam('controller'));
	            $viewModel->setVariable('action', $routeMatch->getParam('action'));
	        },
	        -100
	    );
	}	*/
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
	
    public function getAutoloaderConfig()
    {
		return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
	
	public function getServiceConfig()
    {
        return array(
            'factories' => array(
				'db-adapter' => function($sm) {
					$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
					return $dbAdapter;
				},
				'Shift-Table' => function($sm) {
					$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new ShiftTable($dbAdapter);
                    return $table;
				},
				'Event-Table' => function($sm) {
					$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new EventTable($dbAdapter);
                    return $table;
				},
				'Event-Payment-Table' => function($sm) {
					$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new EventPaymentTable($dbAdapter);
                    return $table;
				},
				'Shift-Request-Table' => function($sm) {
					$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new ShiftRequestTable($dbAdapter);
                    return $table;
				},
				'Users-Table' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new UsersTable($dbAdapter);
                    return $table;
                },
				'Event-Payment-History-Table' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table     = new EventPaymentHistoryTable($dbAdapter);
                    return $table;
                },
				
            ),
        );
    }
	
	public function getViewHelperConfig()
	{
	   return array(
	         'factories' => array(
	            'Usermanagement' => function ($sm) {
	               $match = $sm->getServiceLocator()->get('application')->getMvcEvent()->getRouteMatch();
	               $viewHelper = new \Usermanagement\View\Helper\Usermanagement($match);
	               return $viewHelper;
	            },
				'Datetime' => function($sm) {
                   $match = $sm->getServiceLocator()->get('application')->getMvcEvent()->getRouteMatch();
	               $viewHelper = new \Usermanagement\View\Helper\Datetime($match);
	               return $viewHelper;
                },
				'Requesthelper' => function($sm){
				   $helper = new View\Helper\Requesthelper;
				   $request = $sm->getServiceLocator()->get('Request');
				   $helper->setRequest($request);
				   return $helper;
				},
	         ),
	   );
	}
}
