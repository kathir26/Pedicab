<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Managernotemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Managernotemanagement\Form\AddDriverNoteForm,
	Managernotemanagement\Form\FilterDriverNoteForm,
	Managernotemanagement\Form\AddClientNoteForm,
	Managernotemanagement\Form\FilterClientNoteForm,
	Managernotemanagement\Form\FilterDriverReceiveForm,
	Managernotemanagement\Form\FilterClientReceiveForm,
	Managernotemanagement\Form\FilterLocationNoteForm,
	Managernotemanagement\Form\FilterLocationReceiveForm,
	Managernotemanagement\Form\AddLocationNoteForm,
	Managernotemanagement\Form\AddMechanicNoteForm,
	Managernotemanagement\Form\FilterMechanicReceiveForm,
	Managernotemanagement\Form\FilterMechanicNoteForm;

//	Models
use Usermanagement\Model\Aclresources,
	Schedulemanagement\Model\Shift;
use Usermanagement\Model\MyAuthenticationAdapter;

class NoteController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $shiftIconArray;
	protected $shiftArray;
	protected $shiftRequestStatusArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->shiftIconArray		=  array('1' => 'icon-day','2' => 'icon-nite', '3' => 'icon-double','4' => 'icon-special');
		$this->shiftArray			=  array('' => 'All Shifts', '1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$this->shiftRequestStatusArray	=  array('1' => 'Not Allocated', '2' => 'Confirmed', '3' => 'On-call Waiting list');
		
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("NoteTable" => "Note-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Add Driver note
	*	Detail	:	Used to add the manager send note
	*	TODO	:	Mail sending is inprocess
	*/
	public function addDriverNoteAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$user_details_array = '';
		$driver_array = $general_manager_array = $mechanic_array = array();
		$addDriverNoteForm		=  new AddDriverNoteForm();
		$datetime				= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$shift_array			= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$addDriverNoteForm->get('shift_type')->setValueOptions($shift_array);
		$where					= " and location_id = '".$identity->location_id."' and user_role_id in (1,2,3) and user_id != '".$identity->user_id."'";
		$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
		if(is_object($user_details_array) && count($user_details_array) > 0)
		{
			foreach($user_details_array as $user_key => $user_value)
			{
				if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 1)
				{
					$driver_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 3)
				{
					$general_manager_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 2)
				{
					$mechanic_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
			}
		}
		$addDriverNoteForm->get('driver_select')->setValueOptions($driver_array);
		$addDriverNoteForm->get('general_manager')->setValueOptions($general_manager_array);
		$addDriverNoteForm->get('mechanic_select')->setValueOptions($mechanic_array);
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addDriverNoteForm'		=> $addDriverNoteForm,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Driver note listing
	*	Detail	:	Used to list the drivers note
	*	TODO	:	Mail sending is inprocess
	*/
	public function driverNoteListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterDriverNoteForm		=  new FilterDriverNoteForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('managernoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterDriverNoteForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getManageNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterDriverNoteForm'	=> $filterDriverNoteForm,
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function driverNoteListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('managernoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getManageNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function saveNoteAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array = array();
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$json_array['err']	= 2;
			$shift_date	= $where = $driver_ids = $user_details_array = $check_shift_details = $shift_type = $manager_note_id = $insert_multi_string = $ge_current_lm = '';
			$driver_array = $insert_array = $merge_array = array();
			$form_data		= $request->getPost();
			/*if(isset($form_data['note_send_to_lm']) && $form_data['note_send_to_lm'] == 1)
			{
				$where					= " and location_id = '".$identity->location_id."' and user_role_id in (3)";
				$ge_current_lm			= $this->getTable('NoteTable')->getuserDetails($where);
				if(is_object($ge_current_lm) && count($ge_current_lm) > 0)
				{
					foreach($ge_current_lm as $user_ke => $user_valu)
					{
						$driver_array[]			= $user_valu['user_id'];
						$driver_ids				.= $user_valu['user_id'].",";
					}
					$merge_array				= $driver_array;
				}
			}*/
			if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 1)
			{
				$where					= "  and location_id = '".$identity->location_id."' and user_role_id in (1)";
				$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
				if(is_object($user_details_array) && count($user_details_array) > 0)
				{
					foreach($user_details_array as $user_key => $user_value)
					{
						if($user_value['user_id'] != $identity->user_id)
						{
							$driver_array[]	= $user_value['user_id'];
							$driver_ids		.= $user_value['user_id'].",";
						}
					}
					$driver_ids			= rtrim(trim($driver_ids),",");
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 2)
			{
				if(isset($form_data['shift_date']) && $form_data['shift_date'] != '')
				{
					$shif_date			= explode('-',$form_data['shift_date']);
					if(is_array($shif_date) && count($shif_date) > 0)
					{
						$shift_date		= $shif_date[2]."-".$shif_date[0]."-".$shif_date[1];
					}
				}
				$shift_type				= $form_data['shift_type'];
				$where					= " and s.shift_type = '".addslashes($shift_type)."' and sdt.shift_dt_start_date = '".$shift_date."' and sr.shift_request_status = 2 and s.fk_location_id = '".$identity->location_id."' and sr.fk_user_id != '".$identity->user_id."'";
				$check_shift_details	= $this->getTable('NoteTable')->checkShiftDetails($where);
				if(count($check_shift_details) == 0)
				{
					$json_array['err']	= 1;
				}
				else
				{
					if(is_object($check_shift_details) && count($check_shift_details) > 0)
					{
						foreach($check_shift_details as $shift_key => $shift_value)
						{
							$driver_array[]	= $shift_value['fk_user_id'];
							$driver_ids		.= $shift_value['fk_user_id'].",";
						}
						$driver_ids			= rtrim(trim($driver_ids),",");
					}
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 3)
			{
				if(is_array($form_data['driver_select']) && count($form_data['driver_select']) > 0)
				{
					$driver_array			= $form_data['driver_select'];
					$driver_ids				.= implode(",",$form_data['driver_select']);
					/*if(isset($form_data['note_send_to_lm']) && $form_data['note_send_to_lm'] == 1)
					{
						$driver_array		= array_merge($merge_array,$driver_array);
					}*/
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 4)
			{
				if(is_array($form_data['general_manager']) && count($form_data['general_manager']) > 0)
				{
					$driver_array			= $form_data['general_manager'];
					$driver_ids				.= implode(",",$form_data['general_manager']);
					/*if(isset($form_data['note_send_to_lm']) && $form_data['note_send_to_lm'] == 1)
					{
						$driver_array		= array_merge($merge_array,$driver_array);
					}*/
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 5)
			{
				if(is_array($form_data['headquarters']) && count($form_data['headquarters']) > 0)
				{
					$driver_array			= $form_data['headquarters'];
					$driver_ids				.= implode(",",$form_data['headquarters']);
					/*if(isset($form_data['note_send_to_lm']) && $form_data['note_send_to_lm'] == 1)
					{
						$driver_array		= array_merge($merge_array,$driver_array);
					}*/
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 6)
			{
				if(is_array($form_data['mechanic_select']) && count($form_data['mechanic_select']) > 0)
				{
					$driver_array			= $form_data['mechanic_select'];
					$driver_ids				= implode(",",$form_data['mechanic_select']);
				}
			}
			if(isset($json_array['err']) && $json_array['err'] == 1)
			{
				$json_array['err']	= 1;
			}
			else
			{
				if(isset($driver_ids) && $driver_ids != '')
				{
					$json_array['err']			= 0;
					$json_array['url']			= '/managernotemanagement/note/driver-note-listing';
					$insert_string				= " fk_user_id			= '".$identity->user_id."',
													fk_role_id			= '".$identity->user_role_id."',
													note_subject		= '".addslashes($form_data['note_subject'])."',
													note_send_type		= '".$form_data['note_send_to']."',
													note_shift_date		= '".$shift_date."',
													note_shift_type		= '".$shift_type."',
													note_send_to_ids	= '".$driver_ids."',
													note_message		= '".addslashes($form_data['editor_data'])."',
													note_created_date	= now(),
													note_is_delete		= 0";
					$manager_note_id			= $this->getTable('NoteTable')->insertManagerNote($insert_string);
					if(isset($manager_note_id) && $manager_note_id != '')
					{
						$notification_subject = '';
						if(is_array($driver_array) && count($driver_array) > 0)
						{
							$notification_subject	= $form_data['note_subject'];
							foreach($driver_array as $driver_key => $driver_value)
							{
								$insert_array[]		= "'".$manager_note_id."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".date('Y-m-d')."'";
							}
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_multi_string	= "(".implode("),(",$insert_array).")";
							}
							if(isset($insert_multi_string) && $insert_multi_string != '')
							{
								$this->getTable('NoteTable')->insertManagerNotification($insert_multi_string);
							}
						}
					}
				}
			}
		}
		echo json_encode($json_array);
		die();
	}
	public function deleteDriverNoteAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$notif_id		= $matches->getParam('notificationId', '');
			$type			= $matches->getParam('type', '');
			if(isset($notif_id) && $notif_id != '')
			{
				if(isset($type) && $type == 1)
				{
					$data		= " notification_sender_delete = 1 ";
				}
				else
				{
					$data		= " notification_receiver_delete = 1 ";
				}
				$where		= " notification_id = ".$notif_id;
				$this->getTable("NoteTable")->updateDriverNote($data,$where);
			}
		}
		echo 1;die();
	}
	public function viewDriverNoteAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function addClientNoteAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$user_details_array = $location_manager = '';
		$addClientNoteForm		=  new AddClientNoteForm();
		$datetime				= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$where					= " and location_id = '".$identity->location_id."' and user_role_id in (3)";
		$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
		if(is_object($user_details_array) && count($user_details_array) > 0)
		{
			foreach($user_details_array as $user_key => $user_value)
			{
				$location_manager	.= $user_value['user_firstname']." ".$user_value['user_lastname'].", ";
			}
			$location_manager			= rtrim(trim($location_manager),",");
		}
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addClientNoteForm'		=> $addClientNoteForm,
			'location_manager'		=> $location_manager,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function saveClientNoteAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array = array();
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$shift_date	= $where = $driver_ids = $user_details_array = $check_shift_details = $shift_type = $manager_note_id = $insert_multi_string = '';
			$driver_array = $insert_array = array();
			$form_data		= $request->getPost();
			$where					= "  and location_id = '".$identity->location_id."' and user_role_id in (3)";//4
			$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
			if(is_object($user_details_array) && count($user_details_array) > 0)
			{
				foreach($user_details_array as $user_key => $user_value)
				{
					$driver_array[]	= $user_value['user_id'];
					$driver_ids		.= $user_value['user_id'].",";
				}
				$driver_ids			= rtrim(trim($driver_ids),",");
			}
			if(isset($driver_ids) && $driver_ids != '')
			{
				$json_array['err']			= 0;
				$json_array['url']			= '/managernotemanagement/note/client-note-listing';
				$insert_string				= " fk_user_id			= '".$identity->user_id."',
												fk_role_id			= '".$identity->user_role_id."',
												note_subject		= '".addslashes($form_data['note_subject'])."',
												note_send_type		= '6',
												note_shift_date		= '',
												note_shift_type		= '',
												note_send_to_ids	= '".$driver_ids."',
												note_message		= '".addslashes($form_data['editor_data'])."',
												note_created_date	= now(),
												note_is_delete		= 0";
				$manager_note_id			= $this->getTable('NoteTable')->insertManagerNote($insert_string);
				if(isset($manager_note_id) && $manager_note_id != '')
				{
					$notification_subject = '';
					if(is_array($driver_array) && count($driver_array) > 0)
					{
						$notification_subject	= $form_data['note_subject'];
						foreach($driver_array as $driver_key => $driver_value)
						{
							$insert_array[]		= "'".$manager_note_id."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".date('Y-m-d')."'";
						}
						if(is_array($insert_array) && count($insert_array) > 0)
						{
							$insert_multi_string	= "(".implode("),(",$insert_array).")";
						}
						if(isset($insert_multi_string) && $insert_multi_string != '')
						{
							$this->getTable('NoteTable')->insertManagerNotification($insert_multi_string);
						}
					}
				}
			}
			else
			{
				$json_array['err']	= 2;
			}
		}
		echo json_encode($json_array);
		die();
	}
	public function clientNoteListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterClientNoteForm	=  new FilterClientNoteForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('managerClientNoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterClientNoteForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getManageClientNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterClientNoteForm'	=> $filterClientNoteForm,
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function clientNoteListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('managerClientNoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getManageClientNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewClientNoteAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function deleteClientNoteAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$notif_id		= $matches->getParam('notificationId', '');
			$type			= $matches->getParam('type', '');
			if(isset($notif_id) && $notif_id != '')
			{
				if(isset($type) && $type == 1)
				{
					$data		= " notification_sender_delete = 1 ";
				}
				else
				{
					$data		= " notification_receiver_delete = 1 ";
				}
				$where		= " notification_id = ".$notif_id;
				$this->getTable("NoteTable")->updateDriverNote($data,$where);
			}
		}
		echo 1;die();
	}
	public function driverReceiveListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterDriverReceiveForm		=  new FilterDriverReceiveForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('driverReceiveNoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterDriverReceiveForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getDriverReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'filterDriverReceiveForm'	=> $filterDriverReceiveForm,
			'pc_users'					=> $this->pcUser,
			'page'			 			=> $page,
			'sortBy'		 			=> $sortBy,
			'paginator'		 			=> $paginator,
			'perPageArray'				=> $this->perPageArray,
			'perPage'		 			=> $perPage,
			'datetime'			    	=> $datetime,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
    }
	public function driverReceiveListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('driverReceiveNoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getDriverReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewDriverReceiveAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
			$data					= " notification_status = 1";
			$where					= " notification_id = ".$notif_id;
			$this->getTable('NoteTable')->updateDriverNote($data,$where);
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function clientReceiveListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterClientReceiveForm	=  new FilterClientReceiveForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('clientReceiveNoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterClientReceiveForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getClientReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'filterClientReceiveForm'	=> $filterClientReceiveForm,
			'pc_users'					=> $this->pcUser,
			'page'			 			=> $page,
			'sortBy'		 			=> $sortBy,
			'paginator'		 			=> $paginator,
			'perPageArray'				=> $this->perPageArray,
			'perPage'		 			=> $perPage,
			'datetime'			    	=> $datetime,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
    }
	public function clientReceiveListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('clientReceiveNoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getClientReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewClientReceiveAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
			$data					= " notification_status = 1";
			$where					= " notification_id = ".$notif_id;
			$this->getTable('NoteTable')->updateDriverNote($data,$where);
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function dashboardNotificationAction()
	{
		$json_array	= array();
		$notification_details = '';
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			if(isset($this->pcUser->user_id) && $this->pcUser->user_id != '')
			{
				$where					= " and fk_receiver_user_id = ".$this->pcUser->user_id;
				$notification_details	= $this->getTable('NoteTable')->getUserNotificationDetails($where);
				if(is_object($notification_details) && count($notification_details) > 0)
				{
					$e = $count = 0;
					foreach($notification_details as $notif_key => $notif_value)
					{
						if(isset($notif_value['notification_status']) && $notif_value['notification_status'] == 0)
						{
							$count++;
						}
						$json_array[$e]['notif_id']			= $notif_value['notification_id'];
						$json_array[$e]['shift_id']			= $notif_value['fk_shift_id'];
						$json_array[$e]['note_id']			= $notif_value['fk_manager_note_id'];
						$json_array[$e]['notif_date']		= date("n-j-Y",strtotime($notif_value['notification_created_date']));
						$json_array[$e]['notif_sub']		= $notif_value['notification_subject'];
						$json_array[$e]['notif_stat']		= $notif_value['notification_status'];
						$json_array[$e]['notif_name']		= $notif_value['name'];
						$json_array[$e]['notif_role']		= $this->pcUser->user_role_id;
						$json_array[$e]['notif_type']		= $notif_value['notification_type'];
						$e++;
					}
					$json_array['notif_count']		= $count;
				}
			}
		}
		echo json_encode($json_array);die();
	}
	public function viewNotificationAction()
	{
		$json_array	= array();
		$notification_details = '';
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			if(isset($this->pcUser->user_id) && $this->pcUser->user_id != '')
			{
				$data					= " notification_status = 1";
				$where					= " fk_receiver_user_id = ".$this->pcUser->user_id;
				$this->getTable('NoteTable')->updateDriverNote($data,$where);
			}
		}
		echo 1;die();
	}
	public function addLocationNoteAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$user_details_array = '';
		$driver_array = $general_manager_array = $mechanic_array = $client_array = array();
		$addLocationNoteForm	=  new AddLocationNoteForm();
		$datetime				= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$shift_array			= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$addLocationNoteForm->get('shift_type')->setValueOptions($shift_array);
		$where					= " and location_id = '".$identity->location_id."' and user_role_id in (1,2,3,6) and user_id != '".$identity->user_id."'";
		$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
		if(is_object($user_details_array) && count($user_details_array) > 0)
		{
			foreach($user_details_array as $user_key => $user_value)
			{
				if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 1)
				{
					$driver_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 3)
				{
					$general_manager_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 2)
				{
					$mechanic_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 6)
				{
					$client_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
			}
		}
		$addLocationNoteForm->get('driver_select')->setValueOptions($driver_array);
		$addLocationNoteForm->get('general_manager')->setValueOptions($general_manager_array);
		$addLocationNoteForm->get('mechanic_select')->setValueOptions($mechanic_array);
		$addLocationNoteForm->get('client_select')->setValueOptions($client_array);
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addLocationNoteForm'	=> $addLocationNoteForm,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function saveLocationNoteAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array = array();
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$json_array['err']	= 2;
			$shift_date	= $where = $driver_ids = $user_details_array = $check_shift_details = $shift_type = $manager_note_id = $insert_multi_string = '';
			$driver_array = $insert_array = array();
			$form_data		= $request->getPost();
			if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 1)
			{
				$where					= "  and location_id = '".$identity->location_id."' and user_role_id in (1)";
				$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
				if(is_object($user_details_array) && count($user_details_array) > 0)
				{
					foreach($user_details_array as $user_key => $user_value)
					{
						$driver_array[]	= $user_value['user_id'];
						$driver_ids		.= $user_value['user_id'].",";
					}
					$driver_ids			= rtrim(trim($driver_ids),",");
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 2)
			{
				if(isset($form_data['shift_date']) && $form_data['shift_date'] != '')
				{
					$shif_date			= explode('-',$form_data['shift_date']);
					if(is_array($shif_date) && count($shif_date) > 0)
					{
						$shift_date		= $shif_date[2]."-".$shif_date[0]."-".$shif_date[1];
					}
				}
				$shift_type				= $form_data['shift_type'];
				$where					= " and s.shift_type = '".addslashes($shift_type)."' and sdt.shift_dt_start_date = '".$shift_date."' and sr.shift_request_status = 2 and s.fk_location_id = '".$identity->location_id."' and sr.fk_user_id != '".$identity->user_id."'";
				$check_shift_details	= $this->getTable('NoteTable')->checkShiftDetails($where);
				if(count($check_shift_details) == 0)
				{
					$json_array['err']	= 1;
				}
				else
				{
					if(is_object($check_shift_details) && count($check_shift_details) > 0)
					{
						foreach($check_shift_details as $shift_key => $shift_value)
						{
							$driver_array[]	= $shift_value['fk_user_id'];
							$driver_ids		.= $shift_value['fk_user_id'].",";
						}
						$driver_ids			= rtrim(trim($driver_ids),",");
					}
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 3)
			{
				if(is_array($form_data['driver_select']) && count($form_data['driver_select']) > 0)
				{
					$driver_array			= $form_data['driver_select'];
					$driver_ids				= implode(",",$form_data['driver_select']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 4)
			{
				if(is_array($form_data['general_manager']) && count($form_data['general_manager']) > 0)
				{
					$driver_array			= $form_data['general_manager'];
					$driver_ids				= implode(",",$form_data['general_manager']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 5)
			{
				if(is_array($form_data['headquarters']) && count($form_data['headquarters']) > 0)
				{
					$driver_array			= $form_data['headquarters'];
					$driver_ids				= implode(",",$form_data['headquarters']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 6)
			{
				if(is_array($form_data['mechanic_select']) && count($form_data['mechanic_select']) > 0)
				{
					$driver_array			= $form_data['mechanic_select'];
					$driver_ids				= implode(",",$form_data['mechanic_select']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 7)
			{
				if(is_array($form_data['client_select']) && count($form_data['client_select']) > 0)
				{
					$driver_array			= $form_data['client_select'];
					$driver_ids				= implode(",",$form_data['client_select']);
				}
			}
			if(isset($driver_ids) && $driver_ids != '')
			{
				$json_array['err']			= 0;
				$json_array['url']			= '/managernotemanagement/note/location-note-listing';
				$insert_string				= " fk_user_id			= '".$identity->user_id."',
												fk_role_id			= '".$identity->user_role_id."',
												note_subject		= '".addslashes($form_data['note_subject'])."',
												note_send_type		= '".$form_data['note_send_to']."',
												note_shift_date		= '".$shift_date."',
												note_shift_type		= '".$shift_type."',
												note_send_to_ids	= '".$driver_ids."',
												note_message		= '".addslashes($form_data['editor_data'])."',
												note_created_date	= now(),
												note_is_delete		= 0";
				$manager_note_id			= $this->getTable('NoteTable')->insertManagerNote($insert_string);
				if(isset($manager_note_id) && $manager_note_id != '')
				{
					$notification_subject = '';
					if(is_array($driver_array) && count($driver_array) > 0)
					{
						$notification_subject	= $form_data['note_subject'];
						foreach($driver_array as $driver_key => $driver_value)
						{
							$insert_array[]		= "'".$manager_note_id."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".date('Y-m-d')."'";
						}
						if(is_array($insert_array) && count($insert_array) > 0)
						{
							$insert_multi_string	= "(".implode("),(",$insert_array).")";
						}
						if(isset($insert_multi_string) && $insert_multi_string != '')
						{
							$this->getTable('NoteTable')->insertManagerNotification($insert_multi_string);
						}
					}
				}
			}
		}
		echo json_encode($json_array);
		die();
	}
	public function locationNoteListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterLocationNoteForm	=  new FilterLocationNoteForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('locationnoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterLocationNoteForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getLocationNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterLocationNoteForm'=> $filterLocationNoteForm,
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function locationNoteListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('locationnoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getLocationNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function deleteLocationNoteAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$notif_id		= $matches->getParam('notificationId', '');
			$type			= $matches->getParam('type', '');
			if(isset($notif_id) && $notif_id != '')
			{
				if(isset($type) && $type == 1)
				{
					$data		= " notification_sender_delete = 1 ";
				}
				else
				{
					$data		= " notification_receiver_delete = 1 ";
				}
				$where		= " notification_id = ".$notif_id;
				$this->getTable("NoteTable")->updateDriverNote($data,$where);
			}
		}
		echo 1;die();
	}
	public function viewLocationNoteAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function locationReceiveListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterLocationReceiveForm		=  new FilterLocationReceiveForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('locationReceiveNoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterLocationReceiveForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getLocationReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'filterLocationReceiveForm'	=> $filterLocationReceiveForm,
			'pc_users'					=> $this->pcUser,
			'page'			 			=> $page,
			'sortBy'		 			=> $sortBy,
			'paginator'		 			=> $paginator,
			'perPageArray'				=> $this->perPageArray,
			'perPage'		 			=> $perPage,
			'datetime'			    	=> $datetime,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
    }
	public function locationReceiveListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('locationReceiveNoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getLocationReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewLocationReceiveAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
			$data					= " notification_status = 1";
			$where					= " notification_id = ".$notif_id;
			$this->getTable('NoteTable')->updateDriverNote($data,$where);
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function addMechanicNoteAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$user_details_array = '';
		$driver_array = $general_manager_array = array();
		$addMechanicNoteForm	=  new AddMechanicNoteForm();
		$datetime				= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$where					= " and location_id = '".$identity->location_id."' and user_role_id in (1,3) and user_id != '".$identity->user_id."'";
		$user_details_array		= $this->getTable('NoteTable')->getuserDetails($where);
		if(is_object($user_details_array) && count($user_details_array) > 0)
		{
			foreach($user_details_array as $user_key => $user_value)
			{
				if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 1)
				{
					$driver_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
				else if(isset($user_value['user_role_id']) && $user_value['user_role_id'] == 3)
				{
					$general_manager_array[$user_value['user_id']]	= $user_value['user_firstname']." ".$user_value['user_lastname'];
				}
			}
		}
		$addMechanicNoteForm->get('driver_select')->setValueOptions($driver_array);
		$addMechanicNoteForm->get('general_manager')->setValueOptions($general_manager_array);
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addMechanicNoteForm'	=> $addMechanicNoteForm,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function saveMechanicNoteAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array = array();
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$json_array['err']	= 2;
			$shift_date	= $where = $driver_ids = $user_details_array = $check_shift_details = $shift_type = $manager_note_id = $insert_multi_string = $ge_current_lm = '';
			$driver_array = $insert_array = $merge_array = array();
			$form_data		= $request->getPost();
			if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 3)
			{
				if(is_array($form_data['driver_select']) && count($form_data['driver_select']) > 0)
				{
					$driver_array			= $form_data['driver_select'];
					$driver_ids				.= implode(",",$form_data['driver_select']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 4)
			{
				if(is_array($form_data['general_manager']) && count($form_data['general_manager']) > 0)
				{
					$driver_array			= $form_data['general_manager'];
					$driver_ids				.= implode(",",$form_data['general_manager']);
				}
			}
			else if(isset($form_data['note_send_to']) && $form_data['note_send_to'] == 5)
			{
				if(is_array($form_data['headquarters']) && count($form_data['headquarters']) > 0)
				{
					$driver_array			= $form_data['headquarters'];
					$driver_ids				.= implode(",",$form_data['headquarters']);
				}
			}
			if(isset($json_array['err']) && $json_array['err'] == 1)
			{
				$json_array['err']	= 1;
			}
			else
			{
				if(isset($driver_ids) && $driver_ids != '')
				{
					$json_array['err']			= 0;
					$json_array['url']			= '/managernotemanagement/note/mechanic-note-listing';
					$insert_string				= " fk_user_id			= '".$identity->user_id."',
													fk_role_id			= '".$identity->user_role_id."',
													note_subject		= '".addslashes($form_data['note_subject'])."',
													note_send_type		= '".$form_data['note_send_to']."',
													note_send_to_ids	= '".$driver_ids."',
													note_message		= '".addslashes($form_data['editor_data'])."',
													note_created_date	= now(),
													note_is_delete		= 0";
					$manager_note_id			= $this->getTable('NoteTable')->insertManagerNote($insert_string);
					if(isset($manager_note_id) && $manager_note_id != '')
					{
						$notification_subject = '';
						if(is_array($driver_array) && count($driver_array) > 0)
						{
							$notification_subject	= $form_data['note_subject'];
							foreach($driver_array as $driver_key => $driver_value)
							{
								$insert_array[]		= "'".$manager_note_id."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".date('Y-m-d')."'";
							}
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_multi_string	= "(".implode("),(",$insert_array).")";
							}
							if(isset($insert_multi_string) && $insert_multi_string != '')
							{
								$this->getTable('NoteTable')->insertManagerNotification($insert_multi_string);
							}
						}
					}
				}
			}
		}
		echo json_encode($json_array);
		die();
	}
	public function mechanicNoteListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterMechanicNoteForm	=  new FilterMechanicNoteForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('mechanicnoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterMechanicNoteForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getMechanicNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterMechanicNoteForm'=> $filterMechanicNoteForm,
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function mechanicNoteListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('mechanicnoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getMechanicNoteList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewMechanicNoteAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
	public function deleteMechanicNoteAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$notif_id		= $matches->getParam('notificationId', '');
			$type			= $matches->getParam('type', '');
			if(isset($notif_id) && $notif_id != '')
			{
				if(isset($type) && $type == 1)
				{
					$data		= " notification_sender_delete = 1 ";
				}
				else
				{
					$data		= " notification_receiver_delete = 1 ";
				}
				$where		= " notification_id = ".$notif_id;
				$this->getTable("NoteTable")->updateDriverNote($data,$where);
			}
		}
		echo 1;die();
	}
	public function mechanicReceiveListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message  = '';
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$filterMechanicReceiveForm		=  new FilterMechanicReceiveForm();
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$managernoteSession 	= new Container('mechanicReceiveNoteListing');
		$sessionArray			= array();
		foreach($managernoteSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$managernoteSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$filterMechanicReceiveForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['note_date']) && !empty($formData['note_date']))
			{
				$managernoteSession->note_date	= $formData['note_date'];
			}
			else
				$managernoteSession->note_date	= '';
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getMechanicReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'filterMechanicReceiveForm'	=> $filterMechanicReceiveForm,
			'pc_users'					=> $this->pcUser,
			'page'			 			=> $page,
			'sortBy'		 			=> $sortBy,
			'paginator'		 			=> $paginator,
			'perPageArray'				=> $this->perPageArray,
			'perPage'		 			=> $perPage,
			'datetime'			    	=> $datetime,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
    }
	public function mechanicReceiveListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		$managernoteSession 	= new Container('mechanicReceiveNoteListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($managernoteSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$managernoteSession->sortBy	= $sortBy;
		} else if($managernoteSession->offsetExists('sortBy')) {
			$sortBy	= $managernoteSession->sortBy;
		}
		if($sortType != '') {
			if($managernoteSession->sortType == $sortType && $columnFlag == 1)
				$managernoteSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$managernoteSession->sortType	= $sortType;
		} else if($managernoteSession->offsetExists('sortType')) {
			$sortType	= $managernoteSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$managernoteSession->perPage	= $perPage;
		} else if($managernoteSession->offsetExists('perPage')) {
			$perPage		= $managernoteSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('NoteTable')->getMechanicReceiveList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator'		 		=> $paginator,
			'perPageArray'			=> $this->perPageArray,
			'perPage'		 		=> $perPage,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewMechanicReceiveAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$notif_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$json_view_array = array();
		if($notif_id)
		{
			$where					= " and notif.notification_id = ".$notif_id;
			$view_details_array		= $this->getTable('NoteTable')->getNoteDetails($where);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array['note_subject']	= $view_value['note_subject'];
					$json_view_array['note_message']	= $view_value['note_message'];
					$json_view_array['note_date']		= $view_value['note_created_date'];
				}
			}
			$data					= " notification_status = 1";
			$where					= " notification_id = ".$notif_id;
			$this->getTable('NoteTable')->updateDriverNote($data,$where);
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'datetime'			=> $datetime
		));
		return $result;
    }
}