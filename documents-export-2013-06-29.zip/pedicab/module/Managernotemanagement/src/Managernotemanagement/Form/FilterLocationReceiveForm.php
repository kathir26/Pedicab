<?php
namespace Managernotemanagement\Form;

use Zend\Form\Form;

class FilterLocationReceiveForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('managernotemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_location_receive_form');
		$this->setAttribute('id', 'pc_location_receive_form');
		
		$this->add(array(
            'name' => 'hid_note_send_to',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hid_note_send_to'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'note_date',
            'attributes' => array(
				'type' 								=> 'text',
				'class'								=> 'calc-txbox',
                'value' 							=> '',
				'id'  								=> 'note_date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'note_search',
            'attributes'=> array(
				'id'	=> 'note_search',
                'type'  => 'submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'note_reset',
            'attributes' => array(
				'id'	=> 'note_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>