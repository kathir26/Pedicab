<?php
namespace Managernotemanagement\Form;

use Zend\Form\Form;

class AddClientNoteForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('managernotemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_client_note_form');
		$this->setAttribute('id', 'pc_client_note_form');
		
		$this->add(array(
            'name' => 'hid_note_send_to',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hid_note_send_to'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'hid_note_message',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hid_note_message'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'note_subject',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'note_subject',
				'class'								=> 'wid436',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Subject is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'note_message',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'note_message',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Message is required!',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' 		=> 'note_save',
            'attributes'=> array(
				'id'	=> 'note_save',
                'type'  => 'submit',
                'value' => 'Send',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'note_reset',
            'attributes' => array(
				'id'	=> 'note_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>