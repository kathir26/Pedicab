<?php
namespace Managernotemanagement\Form;

use Zend\Form\Form;

class AddDriverNoteForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('managernotemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_driver_note_form');
		$this->setAttribute('id', 'pc_driver_note_form');
		
		$this->add(array(
            'name' => 'hid_note_send_to',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hid_note_send_to'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'hid_note_message',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'hid_note_message'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'note_subject',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'note_subject',
				'class'								=> 'wid436',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Subject is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'note_message',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'note_message',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Message is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'note_send_to',
            'options'   => array(
                'value_options' => array(
                    '1' => 'All Active Drivers',
                    '2' => 'All Drivers on a Particular Shift',
					'3' => 'Select Drivers',
					'4' => 'General Managers',
					'5' => 'Headquarters',
					'6' => 'Select Mechanics'
                ),
            ),
            'attributes' => array(
				'id'    	=> 'note_send_to',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> 'sel_note_opt'
            )
        ));
		
		$this->add(array(
            'name' => 'shift_date',
            'attributes' => array(
				'type' 								=> 'text',
				'class'								=> 'calc-txbox datepicker',
                'value' 							=> '',
				'id'  								=> 'shift_date',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Shift Date is required!',
            )
        ));
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_type',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'   								=> 'shift_type',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift Type is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'driver_select',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'multiple'							=> 'multiple',
				'id'   								=> 'driver_select',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Driver is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Checkbox',
            'name' => 'note_send_to_lm',
            'options' => array(
            ),
            'attributes' => array(
                'value' 			=> '1',
				'id'   				=> 'note_send_to_lm',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'general_manager',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'multiple'							=> 'multiple',
				'id'   								=> 'general_manager',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'General Manager is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'headquarters',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'multiple'							=> 'multiple',
				'id'   								=> 'headquarters',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Headquarters is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'mechanic_select',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'multiple'							=> 'multiple',
				'id'   								=> 'mechanic_select',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Driver is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'note_save',
            'attributes'=> array(
				'id'	=> 'note_save',
                'type'  => 'submit',
                'value' => 'Send',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'note_reset',
            'attributes' => array(
				'id'	=> 'note_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>