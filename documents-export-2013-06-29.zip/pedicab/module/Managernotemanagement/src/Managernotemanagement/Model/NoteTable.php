<?php
namespace Managernotemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class NoteTable extends AbstractTableGateway
{
    protected $table = 'shift_request';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Note());
        $this->initialize();
    }
	public function getuserDetails($where)
	{
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function checkShiftDetails($where)
	{
		$sql 		= "Select sr.fk_user_id,s.shift_id,sr.shift_request_id,sdt.shift_dt_id from shift_date_timing as sdt 
					   left join shift_request as sr on (sdt.shift_dt_id = sr.fk_shift_dt_id) 
					   left join shift as s on (sdt.fk_shift_id = s.shift_id) 
					   where s.shift_isdelete = 0 and sdt.shift_dt_status = 1 and sr.shift_request_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertManagerNote($insert_string)
    {
        $sql 				= "insert into manager_note set ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertManagerNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_manager_note_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getManageNoteList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('managernoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_receiver_user_id = user.user_id)
					where note.note_is_delete = 0 and notif.fk_sender_user_id = "'.$pcUser->user_id.'"  and notif.notification_sender_delete = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function updateDriverNote($data,$where)
    {
	    $sql		= " update manager_notification set ".$data." where ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getNoteDetails($where)
	{
		$sql 		= " SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id from manager_notification as notif 
						Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
						where note.note_is_delete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getManageClientNoteList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('managerClientNoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_receiver_user_id = user.user_id)
					where note.note_is_delete = 0 and notif.fk_sender_user_id = "'.$pcUser->user_id.'"  and notif.notification_sender_delete = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getDriverReceiveList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('driverReceiveNoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_sender_user_id = user.user_id)
					where notif.fk_receiver_user_id = "'.$pcUser->user_id.'"  and notif.notification_receiver_delete = 0 and notif.notification_type = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getClientReceiveList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('clientReceiveNoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_sender_user_id = user.user_id)
					where notif.fk_receiver_user_id = "'.$pcUser->user_id.'"  and notif.notification_receiver_delete = 0 and notif.notification_type = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getUserNotificationDetails($where)
	{
		$sql 		= "  Select notif.*,CONCAT(u.user_firstname,' ',u.user_lastname) as name  from manager_notification as notif 
						 left join user as u on (notif.fk_sender_user_id = u.user_id) 
						 where notification_receiver_delete = 0 ".$where." order by notification_status asc,notif.notification_id desc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getLocationNoteList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('locationnoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_receiver_user_id = user.user_id)
					where note.note_is_delete = 0 and notif.fk_sender_user_id = "'.$pcUser->user_id.'"  and notif.notification_sender_delete = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getLocationReceiveList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('locationReceiveNoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_sender_user_id = user.user_id)
					where notif.fk_receiver_user_id = "'.$pcUser->user_id.'"  and notif.notification_receiver_delete = 0 and notif.notification_type = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getMechanicNoteList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('mechanicnoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_receiver_user_id = user.user_id)
					where note.note_is_delete = 0 and notif.fk_sender_user_id = "'.$pcUser->user_id.'"  and notif.notification_sender_delete = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getMechanicReceiveList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$whereClause = '';
		$managernoteSession 	= new Container('mechanicReceiveNoteListing');
		
		if($managernoteSession->offsetExists('note_date') && $managernoteSession->note_date != '') {
			$tempDate		 	= str_replace('-', '/', $managernoteSession->note_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' and DATE(note.note_created_date) = "'.addslashes($shift_date).'"';
		}
		
		$orderClause		 = '';
		if($managernoteSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$managernoteSession->sortBy;
		}
		
		if($managernoteSession->offsetExists('sortType') && $managernoteSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY note.note_id DESC';
		}
		
		$sql	= ' SELECT note.note_created_date,note.note_message,note.note_subject,notif.notification_id, CONCAT(user_firstname," ", user_lastname) as name from manager_notification as notif 
					Left Join manager_note as  note on( notif.fk_manager_note_id = note.note_id)
					Left Join user as user on(notif.fk_sender_user_id = user.user_id)
					where notif.fk_receiver_user_id = "'.$pcUser->user_id.'"  and notif.notification_receiver_delete = 0 and notif.notification_type = 0 ' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
}