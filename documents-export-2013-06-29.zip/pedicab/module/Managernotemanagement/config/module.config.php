<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Managernotemanagement\Controller\Note',
                        'action'     => 'bike-listing',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'managernotemanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/managernotemanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'add-driver-note',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/managernotemanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'driver-note-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-note-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'driver-note-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-note-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-note-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'driver-note-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'managernotemanagement/note/delete-driver-note' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/managernotemanagement/note/delete-driver-note[/[:notificationId[/[:type]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Managernotemanagement\Controller',
                        'controller'   		 => 'Note',
                        'action'       		 => 'delete-driver-note',
						'notificationId' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'type' 			 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-note-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-note-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'client-note-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-note-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-note-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'client-note-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'managernotemanagement/note/delete-client-note' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/managernotemanagement/note/delete-client-note[/[:notificationId[/[:type]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Managernotemanagement\Controller',
                        'controller'   		 => 'Note',
                        'action'       		 => 'delete-client-note',
						'notificationId' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'type' 			 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-receive-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-receive-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'driver-receive-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-receive-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-receive-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'driver-receive-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-receive-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-receive-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'client-receive-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'client-receive-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/client-receive-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'client-receive-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'location-note-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/location-note-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'location-note-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'location-note-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/location-note-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'location-note-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'managernotemanagement/note/delete-location-note' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/managernotemanagement/note/delete-location-note[/[:notificationId[/[:type]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Managernotemanagement\Controller',
                        'controller'   		 => 'Note',
                        'action'       		 => 'delete-location-note',
						'notificationId' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'type' 			 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'location-receive-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/location-receive-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'location-receive-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'location-receive-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/location-receive-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'location-receive-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-note-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-note-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'mechanic-note-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-note-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-note-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'mechanic-note-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'managernotemanagement/note/delete-mechanic-note' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/managernotemanagement/note/delete-mechanic-note[/[:notificationId[/[:type]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' 	 => 'Managernotemanagement\Controller',
                        'controller'   		 => 'Note',
                        'action'       		 => 'delete-mechanic-note',
						'notificationId' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
						'type' 			 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-receive-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-receive-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'    => 'Note',
                        'action'        => 'mechanic-receive-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-receive-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-receive-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Managernotemanagement\Controller',
                        'controller'   => 'Note',
                        'action'       => 'mechanic-receive-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'Managernotemanagement\Controller\Note' 	=> 'Managernotemanagement\Controller\NoteController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
