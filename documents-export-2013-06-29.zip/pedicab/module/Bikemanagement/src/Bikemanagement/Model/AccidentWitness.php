<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class AccidentWitness implements InputFilterAwareInterface
{
    public $witness_id;
    public $witness_accident_id;
    public $witness_one_name;
	public $witness_one_phone;
	public $witness_two_name;
	public $witness_two_phone;
	public $witness_isdelete;
	
    public function exchangeArray($data)
    {
        $this->witness_id			= (isset($data['witness_id'])) ? $data['witness_id'] : null;
        $this->witness_accident_id	= (isset($data['witness_accident_id'])) ? $data['witness_accident_id'] : null;
        $this->witness_one_name		= (isset($data['witness_one_name'])) ? $data['witness_one_name'] : null;
		$this->witness_one_phone	= (isset($data['witness_one_phone'])) ? $data['witness_one_phone'] : null;
		$this->witness_two_name		= (isset($data['witness_two_name'])) ? $data['witness_two_name'] : null;
		$this->witness_two_phone	= (isset($data['witness_two_phone'])) ? $data['witness_two_phone'] : null;
		$this->witness_isdelete		= (isset($data['witness_isdelete'])) ? $data['witness_isdelete'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddAccidentWitness()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                'name'     => 'witness_one_name',
                'required' => false
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'witness_one_phone',
                'required' => false
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'witness_two_name',
                'required' => false
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'witness_two_phone',
                'required' => false
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}