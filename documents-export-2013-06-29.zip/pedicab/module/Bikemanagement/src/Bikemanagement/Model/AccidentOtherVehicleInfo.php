<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class AccidentOtherVehicleInfo implements InputFilterAwareInterface
{
    public $other_vehicle_id;
    public $other_vehicle_accident_id;
    public $other_vehicle_description;
	public $other_vehicle_license_plate;
	public $other_vehicle_insurance_carrier;
	public $other_vehicle_isdelete;
	
    public function exchangeArray($data)
    {
        $this->other_vehicle_id					= (isset($data['other_vehicle_id'])) ? $data['other_vehicle_id'] : null;
        $this->other_vehicle_accident_id		= (isset($data['other_vehicle_accident_id'])) ? $data['other_vehicle_accident_id'] : null;
        $this->other_vehicle_description		= (isset($data['other_vehicle_description'])) ? $data['other_vehicle_description'] : null;
		$this->other_vehicle_license_plate		= (isset($data['other_vehicle_license_plate'])) ? $data['other_vehicle_license_plate'] : null;
		$this->other_vehicle_insurance_carrier	= (isset($data['other_vehicle_insurance_carrier'])) ? $data['other_vehicle_insurance_carrier'] : null;
		$this->other_vehicle_isdelete			= (isset($data['other_vehicle_isdelete'])) ? $data['other_vehicle_isdelete'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddAccidentVehicleInfo()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_vehicle_description',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_vehicle_license_plate',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_vehicle_insurance_carrier',
                'required' => true
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}