<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Accident implements InputFilterAwareInterface
{
    public $accident_id;
    public $accident_date;
    public $accident_time;
	public $accident_driver_name;
	public $accident_shift_manager;
	public $accident_bike_number;
	public $accident_location;
	public $accident_createddate;
	public $accident_updateddate;
	public $accident_settled_status;
	public $accident_isdelete;
	
    public function exchangeArray($data)
    {
        $this->accident_id					= (isset($data['accident_id'])) ? $data['accident_id'] : null;
        $this->accident_date				= (isset($data['accident_date'])) ? $data['accident_date'] : null;
        $this->accident_time				= (isset($data['accident_time'])) ? $data['accident_time'] : null;
		$this->accident_driver_name			= (isset($data['accident_driver_name'])) ? $data['accident_driver_name'] : null;
		$this->accident_shift_manager		= (isset($data['accident_shift_manager'])) ? $data['accident_shift_manager'] : null;
		$this->accident_bike_number			= (isset($data['accident_bike_number'])) ? $data['accident_bike_number'] : null;
		$this->accident_location			= (isset($data['accident_location'])) ? $data['accident_location'] : null;
		$this->accident_createddate			= (isset($data['accident_createddate'])) ? $data['accident_createddate'] : null;
		$this->accident_updateddate			= (isset($data['accident_updateddate'])) ? $data['accident_updateddate'] : null;
		$this->accident_settled_status		= (isset($data['accident_settled_status'])) ? $data['accident_settled_status'] : null;
		$this->accident_isdelete			= (isset($data['accident_isdelete'])) ? $data['accident_isdelete'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddAccident()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_date',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_time',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_driver_name',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_shift_manager',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_bike_number',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'accident_location',
                'required' => true
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}