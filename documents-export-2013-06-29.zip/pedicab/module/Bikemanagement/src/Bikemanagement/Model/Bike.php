<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Bike implements InputFilterAwareInterface
{
    public $bike_id;
    public $bike_name;
    public $bike_model;
	public $bike_location;
	public $bike_serial_num;
	public $bike_age;
	public $bike_image;
	public $bike_operation;
	
    public function exchangeArray($data)
    {
		$this->bike_id				= (isset($data['bike_id'])) ? $data['bike_id'] : null;
		$this->bike_name			= (isset($data['bike_name'])) ? $data['bike_name'] : null;
        $this->bike_model			= (isset($data['bike_model'])) ? $data['bike_model'] : null;
        $this->bike_location		= (isset($data['bike_location'])) ? $data['bike_location'] : null;
		$this->bike_serial_num		= (isset($data['bike_serial_num'])) ? $data['bike_serial_num'] : 0;
		$this->bike_age_date		= (isset($data['bike_age_date'])) ? $data['bike_age_date'] : null;
		$this->bike_age				= (isset($data['bike_age'])) ? $data['bike_age'] : null;
		$this->bike_image			= (isset($data['bike_image'])) ? $data['bike_image'] : null;
		$this->bike_operation		= (isset($data['bike_operation'])) ? $data['bike_operation'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddBike()
    {
		if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			$inputFilter->add($factory->createInput(array(
                'name'     => 'bike_name',
				'id'       => 'bike_name',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
				'validators' => array(
                    array(
                      'name' =>'NotEmpty', 
                        'options' => array(
                            'messages' => array(
                                \Zend\Validator\NotEmpty::IS_EMPTY => 'Bike Name can not be empty.'
                            ),
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 1,
                            'max' => 200,
                            'messages' => array(
                                'stringLengthTooShort' => 'Please enter Bike Name between 1 to 200 character!',
                                'stringLengthTooLong' => 'Please enter Bike Name between 1 to 200 character!'
                            ),
                        ),
                    ),
                ),
            )));
			$inputFilter->add($factory->createInput(array(
                'name'     => 'bike_location',
				'id'       => 'bike_location',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
				'validators' => array(
                    array(
                      'name' =>'InArray', 
                        'options' => array(
							'haystack' => array(2,3),
                            'messages' => array(
                                \Zend\Validator\InArray::NOT_IN_ARRAY => 'Please select your Bike Operation !'
                            ),
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 1,
                            'max' => 200,
                            'messages' => array(
                                'stringLengthTooShort' => 'Please enter Bike Name between 1 to 200 character!',
                                'stringLengthTooLong' => 'Please enter Bike Name between 1 to 200 character!'
                            ),
                        ),
                    ),
                ),
            )));
            $this->inputFilter = $inputFilter;
        }
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
