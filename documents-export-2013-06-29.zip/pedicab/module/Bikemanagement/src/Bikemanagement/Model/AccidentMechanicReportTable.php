<?php
namespace Bikemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class AccidentMechanicReportTable extends AbstractTableGateway
{
    protected $table = 'accident_mechanic_report';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        //$this->resultSetPrototype->setArrayObjectPrototype(new AccidentMechanicReport());
        $this->initialize();
    }
	
    public function getMechanic($mechanic_id)
    {
        $id  	= (int) $mechanic_id;
        $rowset = $this->select(array('mechanic_report_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function saveMechanicReport($accidentMechanicReport)
    {
        /*$data = array(
			'mechanic_accident_id'		  	  => $accidentMechanicReport['mechanic_accident_id'],
            'mechanic_inspection_date'		  => $accidentMechanicReport['mechanic_inspection_date'],
			'mechanic_inspection_time'	  	  => $accidentMechanicReport['mechanic_inspection_time'],
            'epcd_pedicab' 			  	  	  => $accidentMechanicReport['epcd_pedicab'],
			'elcf_pedicab' 			  		  => $accidentMechanicReport['elcf_pedicab'],
			'mechanic_description' 			  => $accidentMechanicReport['mechanic_description'],
			'mechanic_recommendation' 		  => $accidentMechanicReport['mechanic_recommendation'],
			'driver_recommendation' 		  => $accidentMechanicReport['driver_recommendation'],
			'settlement_note' 			  	  => $accidentMechanicReport['settlement_note'],
			'mechanic_isdelete' 		 	  => $accidentMechanicReport['mechanic_isdelete']
        );*/
		$data = array();
		foreach($accidentMechanicReport as $key => $value) {
			if($key != 'mechanic_report_id') {
				$data[$key]	= $accidentMechanicReport[$key];
			}
		}
		/*
		if(isset($accidentMechanicReport["mechanic_report_id"]) && !empty($accidentMechanicReport["mechanic_report_id"])) {
			$data['mechanic_report_id'] = $accidentMechanicReport["mechanic_report_id"];
		}
		*/
        $mechanic_id = (int)$accidentMechanicReport["mechanic_report_id"];
        if (!$mechanic_id) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==insert data==><pre>"; print_r($data); echo "</pre><==";
//			return false;
			
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getMechanic($mechanic_id)) {
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==update data==><pre>"; print_r($data); echo "</pre><==";
//				return false;
                $this->update($data, array('mechanic_report_id' => $mechanic_id));
				return $mechanic_id;
            } else {
                throw new \Exception('Form mechanic_report_id does not exist');
            }
        }
    }
	
	public function getUsersList()
	{
		$whereClause   	  	 = ' WHERE 1 And user.user_isdelete = 0 And role.role_status = 1 And role.role_isdelete  = 0 ';
		$listingSession 	 = new Container('userListing');
		
		if($listingSession->offsetExists('keyward_name') && $listingSession->keyward_name != '' && $listingSession->offsetExists('keyward_value') && $listingSession->keyward_value != ''  ) {
			$joinPrefix		 = ($listingSession->keyward_name == "role_name") ? "role" : "user";
			$whereClause	.= ' AND ' . $joinPrefix.'.'.$listingSession->keyward_name . ' like "%' . addslashes($listingSession->keyward_value) . '%"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "role_name") ? "role" : "user";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT user.user_id, user.user_role_id, user.user_email, user.user_firstname, user.user_lastname, user.user_telephone_number, user.user_status, role.role_id, 
				   role.role_name, role.role_status FROM user as user left join role as role on user.user_role_id = role.role_id' . $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function getUserDetails($user_id)
    {
		$sql		= "SELECT user.*, driver_info.user_training_date, driver_info.user_drivers_license, driver_info.user_citylicense_permit, role.*, location.loc_title FROM user as user left join driver_info as driver_info on user.user_id = driver_info.user_id left join role as role on  role.role_id = user.user_role_id left join location as location on  location.loc_id = user.location_id WHERE 1 And user.user_isdelete = 0 And user.user_id ='" . $user_id ."'";
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	
	public function deleteUser($user_id)
    {
        $data = array(
				'user_isdelete'	=> '1'
        );
		$this->update($data, array('user_id' => $user_id));
    }
}