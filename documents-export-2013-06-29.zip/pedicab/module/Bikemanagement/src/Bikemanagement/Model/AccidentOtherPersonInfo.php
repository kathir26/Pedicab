<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class AccidentOtherPersonInfo implements InputFilterAwareInterface
{
    public $other_person_id;
    public $other_person_accident_id;
    public $other_person_name;
	public $other_person_license_state;
	public $other_person_phone;
	public $other_person_address;
	public $ecd_pedicab;
	public $ecd_other_vehicle;
	public $other_person_isdelete;
	
    public function exchangeArray($data)
    {
        $this->other_person_id				= (isset($data['other_person_id'])) ? $data['other_person_id'] : null;
        $this->other_person_accident_id		= (isset($data['other_person_accident_id'])) ? $data['other_person_accident_id'] : null;
        $this->other_person_name			= (isset($data['other_person_name'])) ? $data['other_person_name'] : null;
		$this->other_person_license_state	= (isset($data['other_person_license_state'])) ? $data['other_person_license_state'] : null;
		$this->other_person_phone			= (isset($data['other_person_phone'])) ? $data['other_person_phone'] : null;
		$this->other_person_address			= (isset($data['other_person_address'])) ? $data['other_person_address'] : null;
		$this->ecd_pedicab					= (isset($data['ecd_pedicab'])) ? $data['ecd_pedicab'] : null;
		$this->ecd_other_vehicle			= (isset($data['ecd_other_vehicle'])) ? $data['ecd_other_vehicle'] : null;
		$this->other_person_isdelete		= (isset($data['other_person_isdelete'])) ? $data['other_person_isdelete'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddAccidentPersonInfo()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_person_name',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_person_license_state',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_person_phone',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'other_person_address',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'ecd_pedicab',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'ecd_other_vehicle',
                'required' => true
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}