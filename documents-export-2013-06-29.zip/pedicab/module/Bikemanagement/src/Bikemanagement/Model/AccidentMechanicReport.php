<?php
namespace Bikemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class AccidentMechanicReport implements InputFilterAwareInterface
{
    public $mechanic_report_id;
    public $mechanic_accident_id;
    public $mechanic_inspection_date;
	public $mechanic_inspection_time;
	public $epcd_pedicab;
	public $elcf_pedicab;
	public $mechanic_description;
	public $mechanic_recommendation;
	public $driver_recommendation;
	public $settlement_note;
	public $mechanic_isdelete;
	
    public function exchangeArray($data)
    {
        $this->mechanic_report_id		= (isset($data['mechanic_report_id'])) ? $data['mechanic_report_id'] : null;
        $this->mechanic_accident_id		= (isset($data['mechanic_accident_id'])) ? $data['mechanic_accident_id'] : null;
        $this->mechanic_inspection_date	= (isset($data['mechanic_inspection_date'])) ? $data['mechanic_inspection_date'] : null;
		$this->mechanic_inspection_time	= (isset($data['mechanic_inspection_time'])) ? $data['mechanic_inspection_time'] : null;
		$this->epcd_pedicab				= (isset($data['epcd_pedicab'])) ? $data['epcd_pedicab'] : null;
		$this->elcf_pedicab				= (isset($data['elcf_pedicab'])) ? $data['elcf_pedicab'] : null;
		$this->mechanic_description		= (isset($data['mechanic_description'])) ? $data['mechanic_description'] : null;
		$this->mechanic_recommendation	= (isset($data['mechanic_recommendation'])) ? $data['mechanic_recommendation'] : null;
		$this->driver_recommendation	= (isset($data['driver_recommendation'])) ? $data['driver_recommendation'] : null;
		$this->settlement_note			= (isset($data['settlement_note'])) ? $data['settlement_note'] : null;
		$this->mechanic_isdelete		= (isset($data['mechanic_isdelete'])) ? $data['mechanic_isdelete'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddAccidentMechanicReport()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'mechanic_inspection_date',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'mechanic_inspection_time',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'epcd_pedicab',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'elcf_pedicab',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'mechanic_description',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'mechanic_recommendation',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'driver_recommendation',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'settlement_note',
                'required' => true
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}