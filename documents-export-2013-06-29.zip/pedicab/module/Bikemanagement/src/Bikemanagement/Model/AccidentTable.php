<?php
namespace Bikemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class AccidentTable extends AbstractTableGateway
{
    protected $table = 'accident';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        //$this->resultSetPrototype->setArrayObjectPrototype(new Accident());
        $this->initialize();
    }
	
    public function getAccident($accident_id)
    {
        $id  	= (int) $accident_id;
        $rowset = $this->select(array('accident_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function saveAccident($accidentDetails)
    {
		$data = array();
		foreach($accidentDetails as $key => $value) {
			if($key != 'accident_id') {
				$data[$key]	= $accidentDetails[$key];
			}
		}
		
        $accident_id = (int)$accidentDetails["accident_id"];
        if (!$accident_id) {
			$data['accident_createddate'] = $accidentDetails["accident_createddate"];
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getAccident($accident_id)) {
				$data['accident_report_status']	= 2;
                $this->update($data, array('accident_id' => $accident_id));
				return $accident_id;
            } else {
                throw new \Exception('Form accident_id does not exist');
            }
        }
    }
	
	public function saveAccidentImages($accidentImage)
    {
		$data = array();
		foreach($accidentImage as $key => $value) {
			if($key != 'accident_id') {
				$data[$key]	= $accidentImage[$key];
			}
		}
		
        $accident_id = (int)$accidentImage["accident_id"];
        if ($this->getAccident($accident_id)) {
            $this->update($data, array('accident_id' => $accident_id));
        } else {
            throw new \Exception('Form accident_id does not exist');
        }
    }
	
	
	public function getAccidentList($settled_status)
	{
		// $adapter->platform->quoteIdentifier('users')
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==quoteIdentifier==>".$this->adapter->platform->quoteIdentifier('users')."<==";
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			 = $pcUser->location_id;
		$userId				 = $pcUser->user_id;
		$userRoleId		 	 = $pcUser->user_role_id;
		$whereClause   	  	 = ' WHERE 1 And accident.accident_isdelete = 0 And mechanic_report.mechanic_isdelete = 0 And accident.accident_settled_status = '.$settled_status.' And user.location_id = '.$locationId;
		
		// Condition handling for Driver View
		if($userRoleId	== 1) {
			$whereClause   	.= ' And user.user_id = '.$userId;
		}
		
		$sessionKey			 = ($settled_status == 2) ? "unsettledAccidentListing" : "settledAccidentListing";
		$listingSession 	 = new Container($sessionKey);
		
		if($listingSession->offsetExists('accident_date') && $listingSession->accident_date != '') {
			$tempDate		 = str_replace('-', '/', $listingSession->accident_date);
			$accident_date   = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND accident.accident_date = "' . $accident_date . '"';
		}
		
		if($listingSession->offsetExists('damage_cost') && $listingSession->damage_cost != '') {
			$whereClause	.= ' AND mechanic_report.epcd_pedicab = "' . $listingSession->damage_cost . '"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "epcd_pedicab") ? "mechanic_report" : "accident";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY accident.accident_id DESC';
		}
		
		$sql	= 'SELECT accident.accident_id, accident.accident_date, accident.accident_bike_number, accident.accident_settled_status,
				   mechanic_report.mechanic_report_id, mechanic_report.mechanic_recommendation, mechanic_report.driver_recommendation , mechanic_report.epcd_pedicab,
				   user.user_firstname, user.user_lastname, user.location_id
				   FROM accident as accident 
				   left join accident_mechanic_report as mechanic_report on accident.accident_id = mechanic_report.mechanic_accident_id
				   left join user as user on user.user_id = accident.accident_driver_id';
		$sql	.= $whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	public function getDriversAccidentList()
	{
		 // Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$userId				 = $pcUser->user_id;
		$whereClause   	  	 = ' WHERE 1 And accident.accident_isdelete = 0 And mechanic_report.mechanic_isdelete = 0 And user.user_id = "'.$userId.'" ';
		$listingSession 	 = new Container('driverAccidentListing');
		
		if($listingSession->offsetExists('accident_date') && $listingSession->accident_date != '') {
			$tempDate		 = str_replace('-', '/', $listingSession->accident_date);
			$accident_date   = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND accident.accident_date = "' . $accident_date . '"';
		}
		
		if($listingSession->offsetExists('damage_cost') && $listingSession->damage_cost != '') {
			$whereClause	.= ' AND mechanic_report.epcd_pedicab = "' . $listingSession->damage_cost . '"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "epcd_pedicab") ? "mechanic_report" : "accident";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 .= ' ORDER BY accident.accident_id DESC';
		}
		
		$sql	= 'SELECT accident.accident_id, accident.accident_date, accident.accident_bike_number, accident.accident_settled_status,
				   mechanic_report.mechanic_report_id, mechanic_report.mechanic_recommendation, mechanic_report.driver_recommendation , mechanic_report.epcd_pedicab,
				   user.user_firstname, user.user_lastname, user.location_id
				   FROM accident as accident 
				   left join accident_mechanic_report as mechanic_report on accident.accident_id = mechanic_report.mechanic_accident_id
				   left join user as user on user.user_id = accident.accident_driver_id';
		$sql	.= $whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	public function getAccidentDetails($accident_id)
    {
		$sql		= "SELECT accident.*, vehicle_info.*, person_info.*, witness.*, mechanic_report.*
					   FROM accident as accident
					   left join accident_other_vehicle_info as vehicle_info on vehicle_info.other_vehicle_accident_id = accident.accident_id
					   left join accident_other_person_info as person_info on person_info.other_person_accident_id = accident.accident_id
					   left join accident_witness as witness on witness.witness_accident_id = accident.accident_id
					   left join accident_mechanic_report as mechanic_report on mechanic_report.mechanic_accident_id = accident.accident_id
					   WHERE 1 And accident.accident_isdelete = 0 And accident.accident_id ='" . $accident_id ."'";
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
	public function deleteAccident($accident_id)
    {
        $data = array(
				'accident_isdelete'	=> '1'
        );
		$this->update($data, array('accident_id' => $accident_id));
    }
}