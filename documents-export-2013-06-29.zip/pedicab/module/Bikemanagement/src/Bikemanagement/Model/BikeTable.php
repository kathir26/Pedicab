<?php
namespace Bikemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class BikeTable extends AbstractTableGateway
{
    protected $table = 'bike';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Bike());
        $this->initialize();
    }
	
	public function insertBike($bike)
    {
		$bike_age_date	= '';
		if(isset($bike->bike_age_date) && $bike->bike_age_date != '')
		{
			$location_date		= explode('-',$bike->bike_age_date);
			if(is_array($location_date) && count($location_date) > 0)
			{
				$bike_age_date	= $location_date[2]."-".$location_date[0]."-".$location_date[1];
			}
		}
		$data = array(
            'bike_name'				=> $bike->bike_name,
			'bike_model'			=> $bike->bike_model,
            'fk_location_id'		=> $bike->bike_location,
			'bike_serial_num' 		=> $bike->bike_serial_num,
			'bike_age_date'			=> $bike_age_date,
			'bike_age'				=> $bike->bike_age,
            'bike_operation'		=> $bike->bike_operation,
			'bike_isdelete' 		=> 0,
			'bike_status' 			=> 1,
			'bike_creation_date'	=> date('Y-m-d H:i:s')
        );
        $this->insert($data);
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updateBikeImage($bike_id,$bike_image)
    {
	    $data = array(
			'bike_image'			=> $bike_image
        );
		$this->update($data, array('bike_id' => $bike_id));
    }
	public function getBikeDetails($formData)
	{
		$where_new = '';
		if(isset($formData['bike_id']) && $formData['bike_id'] != '')
		{
			$where_new		= ' AND bike_id != '.$formData['bike_id'];
		}
		$sql 		= "Select * from ".$this->table." where bike_status = 1 and bike_isdelete = 0 and bike_name = '".addslashes($formData['bike_name'])."'".$where_new;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateBike($bike)
    {
	    $bike_age_date	= '';
		if(isset($bike->bike_age_date) && $bike->bike_age_date != '')
		{
			$location_date		= explode('-',$bike->bike_age_date);
			if(is_array($location_date) && count($location_date) > 0)
			{
				$bike_age_date	= $location_date[2]."-".$location_date[0]."-".$location_date[1];
			}
		}
		$data = array(
			'bike_name'				=> $bike->bike_name,
			'bike_model'			=> $bike->bike_model,
            'fk_location_id'		=> $bike->bike_location,
			'bike_serial_num' 		=> $bike->bike_serial_num,
			'bike_age_date'			=> $bike_age_date,
			'bike_age'				=> $bike->bike_age,
            'bike_operation'		=> $bike->bike_operation,
			'bike_updated_date'		=> date('Y-m-d H:i:s')
        );
		$this->update($data, array('bike_id' => $bike->bike_id));
    }
	public function getAllBikeList()
	{
		$whereClause	= '';
		$auth 			= new AuthenticationService();
		$user 			= $auth->getIdentity();
		$whereClause   .= ' WHERE bike_isdelete = 0 and fk_location_id = '.$user->location_id;
		
		$bikeSession 	= new Container('bikeListing');
		$whereClause	    .= '';
		
		if($bikeSession->offsetExists('bike_type') && $bikeSession->bike_type > 0) {
			if(isset($bikeSession->bike_name) && $bikeSession->bike_name != '')
			{
				if($bikeSession->bike_type == 1)
				{
					$whereClause	.= ' AND bike_name like "%' . addslashes($bikeSession->bike_name). '%"';
				}
				else if($bikeSession->bike_type == 2)
				{
					$whereClause	.= ' AND bike_model like "%' . addslashes($bikeSession->bike_name). '%"';
				}
				else if($bikeSession->bike_type == 3)
				{
					$whereClause	.= ' AND bike_serial_num like "%' . addslashes($bikeSession->bike_name). '%"';
				}
				else if($bikeSession->bike_type == 4)
				{
					$whereClause	.= ' AND bike_age = "' . addslashes($bikeSession->bike_name). '"';
				}
			}
		}
		$orderClause		 = '';
		if($bikeSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$bikeSession->sortBy;
		}
		
		if($bikeSession->offsetExists('sortType') && $bikeSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY bike_id DESC';
		}
		$sql		= 'SELECT * FROM bike' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function deleteBike($bike_id)
    {
        $data = array(
			'bike_isdelete'	=> '1'
        );
		$this->update($data, array('bike_id' => $bike_id));
    }
	public function getBikeViewDetails($bike_id)
	{
		$sql		= 'SELECT bike.*,loc.loc_title FROM bike as bike left join location as loc on(bike.fk_location_id = loc.loc_id) where bike_id = '.$bike_id;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getBikeEditDetails($bike_id)
	{
		$sql		= 'SELECT * FROM bike where bike_id = '.$bike_id;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	
	/*
	*	Get All Bikes for a particular Location
	*/
	public function GetAllBikes()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		
		$locationId	= $pcUser->location_id;
		$whereClaus = ' WHERE 1 and bike_isdelete = 0 and bike_status = 1 and fk_location_id='.$locationId;
		$sql		= 'SELECT * FROM bike'.$whereClaus;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$counts		= $result->count();
        if ($result && $counts) {
            return $result;
        } else {
			return false;
		}
	}
	
	
	/*
	*	Get Selected Bikes for a particular Location
	*/
	public function GetSelectedBikes($bike_id)
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		
		$locationId	= $pcUser->location_id;
		$whereClaus = ' WHERE 1 and bike_isdelete = 0 and bike_status = 1 and fk_location_id='.$locationId.' and bike_id in ('.$bike_id.')';
		$sql		= 'SELECT * FROM bike'.$whereClaus;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$counts		= $result->count();
        if ($result && $counts) {
            return $result;
        } else {
			return false;
		}
	}
}