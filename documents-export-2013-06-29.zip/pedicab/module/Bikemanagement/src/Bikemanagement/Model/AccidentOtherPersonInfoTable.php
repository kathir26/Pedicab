<?php
namespace Bikemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class AccidentOtherPersonInfoTable extends AbstractTableGateway
{
    protected $table = 'accident_other_person_info';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        //$this->resultSetPrototype->setArrayObjectPrototype(new AccidentOtherPersonInfo());
        $this->initialize();
    }
	
    public function getPerson($person_id)
    {
        $id  	= (int) $person_id;
        $rowset = $this->select(array('other_person_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function savePersonInfoInfo($accidenPersonInfo)
    {
        $data = array(
			'other_person_accident_id'		  => $accidenPersonInfo['other_person_accident_id'],
            'other_person_name'		  		  => $accidenPersonInfo['other_person_name'],
			'other_person_license_state'	  => $accidenPersonInfo['other_person_license_state'],
            'other_person_phone' 			  => $accidenPersonInfo['other_person_phone'],
			'other_person_address' 			  => $accidenPersonInfo['other_person_address'],
			'ecd_pedicab' 					  => $accidenPersonInfo['ecd_pedicab'],
			'ecd_other_vehicle' 			  => $accidenPersonInfo['ecd_other_vehicle'],
			'other_person_isdelete' 		  => $accidenPersonInfo['other_person_isdelete']
        );
		/*
		if(isset($accidenPersonInfo["other_person_id"]) && !empty($accidenPersonInfo["other_person_id"])) {
			$data['other_person_id'] = $accidenPersonInfo["other_person_id"];
		}
		*/
        $person_id = (int)$accidenPersonInfo["other_person_id"];
        if (!$person_id) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==insert data==><pre>"; print_r($data); echo "</pre><==";
//			return false;
			
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getPerson($person_id)) {
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==update data==><pre>"; print_r($data); echo "</pre><==";
//				return false;
                $this->update($data, array('other_person_id' => $person_id));
				return $person_id;
            } else {
                throw new \Exception('Form vehicle_id does not exist');
            }
        }
    }
	
	public function getUsersList()
	{
		$whereClause   	  	 = ' WHERE 1 And user.user_isdelete = 0 And role.role_status = 1 And role.role_isdelete  = 0 ';
		$listingSession 	 = new Container('userListing');
		
		if($listingSession->offsetExists('keyward_name') && $listingSession->keyward_name != '' && $listingSession->offsetExists('keyward_value') && $listingSession->keyward_value != ''  ) {
			$joinPrefix		 = ($listingSession->keyward_name == "role_name") ? "role" : "user";
			$whereClause	.= ' AND ' . $joinPrefix.'.'.$listingSession->keyward_name . ' like "%' . addslashes($listingSession->keyward_value) . '%"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "role_name") ? "role" : "user";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT user.user_id, user.user_role_id, user.user_email, user.user_firstname, user.user_lastname, user.user_telephone_number, user.user_status, role.role_id, 
				   role.role_name, role.role_status FROM user as user left join role as role on user.user_role_id = role.role_id' . $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function getUserDetails($user_id)
    {
		$sql		= "SELECT user.*, driver_info.user_training_date, driver_info.user_drivers_license, driver_info.user_citylicense_permit, role.*, location.loc_title FROM user as user left join driver_info as driver_info on user.user_id = driver_info.user_id left join role as role on  role.role_id = user.user_role_id left join location as location on  location.loc_id = user.location_id WHERE 1 And user.user_isdelete = 0 And user.user_id ='" . $user_id ."'";
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	
	public function deletePerson($person_id)
    {
        $data = array(
				'other_person_isdelete' => '1'
        );
		$this->update($data, array('other_person_id' => $person_id));
    }
}