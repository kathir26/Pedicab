<?php
namespace Bikemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class AccidentWitnessTable extends AbstractTableGateway
{
    protected $table = 'accident_witness';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        //$this->resultSetPrototype->setArrayObjectPrototype(new AccidentWitness());
        $this->initialize();
    }
	
    public function getWitness($witness_id)
    {
        $id  	= (int) $witness_id;
        $rowset = $this->select(array('witness_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function saveWitnessInfo($accidentWitness)
    {
        $data = array(
			'witness_accident_id'		  	  => $accidentWitness['witness_accident_id'],
            'witness_one_name'		  		  => $accidentWitness['witness_one_name'],
			'witness_one_phone'	  			  => $accidentWitness['witness_one_phone'],
            'witness_two_name' 			  	  => $accidentWitness['witness_two_name'],
			'witness_two_phone' 			  => $accidentWitness['witness_two_phone'],
			'witness_isdelete' 		 		  => $accidentWitness['witness_isdelete']
        );
		/*
		if(isset($accidentWitness["witness_id"]) && !empty($accidentWitness["witness_id"])) {
			$data['witness_id'] = $accidentWitness["witness_id"];
		}
		*/
        $witness_id = (int)$accidentWitness["witness_id"];
        if (!$witness_id) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==insert data==><pre>"; print_r($data); echo "</pre><==";
//			return false;
			
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getWitness($witness_id)) {
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==update data==><pre>"; print_r($data); echo "</pre><==";
//				return false;
                $this->update($data, array('witness_id' => $witness_id));
				return $witness_id;
            } else {
                throw new \Exception('Form vehicle_id does not exist');
            }
        }
    }
	
	public function getUsersList()
	{
		$whereClause   	  	 = ' WHERE 1 And user.user_isdelete = 0 And role.role_status = 1 And role.role_isdelete  = 0 ';
		$listingSession 	 = new Container('userListing');
		
		if($listingSession->offsetExists('keyward_name') && $listingSession->keyward_name != '' && $listingSession->offsetExists('keyward_value') && $listingSession->keyward_value != ''  ) {
			$joinPrefix		 = ($listingSession->keyward_name == "role_name") ? "role" : "user";
			$whereClause	.= ' AND ' . $joinPrefix.'.'.$listingSession->keyward_name . ' like "%' . addslashes($listingSession->keyward_value) . '%"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($listingSession->sortBy == "role_name") ? "role" : "user";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT user.user_id, user.user_role_id, user.user_email, user.user_firstname, user.user_lastname, user.user_telephone_number, user.user_status, role.role_id, 
				   role.role_name, role.role_status FROM user as user left join role as role on user.user_role_id = role.role_id' . $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function getUserDetails($user_id)
    {
		$sql		= "SELECT user.*, driver_info.user_training_date, driver_info.user_drivers_license, driver_info.user_citylicense_permit, role.*, location.loc_title FROM user as user left join driver_info as driver_info on user.user_id = driver_info.user_id left join role as role on  role.role_id = user.user_role_id left join location as location on  location.loc_id = user.location_id WHERE 1 And user.user_isdelete = 0 And user.user_id ='" . $user_id ."'";
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	
	public function deleteWitness($witness_id)
    {
        $data = array(
				'witness_isdelete'	=> '1'
        );
		$this->update($data, array('witness_id' => $witness_id));
    }
}