<?php
namespace Bikemanagement\Form;

use Zend\Form\Form;

class BikeFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('bikemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'bike_filter_form');
		$this->setAttribute('name', 'bike_filter_form');
		
		$this->add(array(
            'name' => 'bike_name_sch',
            'attributes' => array(
                'type'  		=> 'text',
				'id'			=> 'bike_name_sch',
				'class'			=> 'wid240',
				'autofocus'		=> '',
				'PlaceHolder' 	=> '',//Bike Name
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'bike_model_sch',
            'options' => array(
                'value_options' => array(
                    '' => 'Bike Model',
                ),
            ),
            'attributes' => array(
                'value' 		=> '',
				'id'   			=> 'bike_model_sch',
				'class'			=> 'wid150'
            )
        ));
        $this->add(array(
            'name' => 'search_bike_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_bike_submit',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_bike_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_bike_reset',
            ),
        ));
    }
}
?>