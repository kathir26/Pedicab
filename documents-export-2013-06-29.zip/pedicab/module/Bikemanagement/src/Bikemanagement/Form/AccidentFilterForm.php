<?php
namespace Bikemanagement\Form;

use Zend\Form\Form;

class AccidentFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('bikemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'accident_filter_form');
		$this->setAttribute('name', 'accident_filter_form');
		
		$this->add(array(
            'name' 		 => 'accident_settled',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'accident_settled'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'accident_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'accident_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Date of Accident',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Accident date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'damage_cost',
            'attributes' => array(
                'type'  		=> 'text',
				'id'			=> 'damage_cost',
				'class'			=> 'wid161',
				'autofocus'		=> '',
				'PlaceHolder' 	=> 'Cost of Damages',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Damage Cost is required!',
				'data-errormessage' 			 	=> 'Damage Cost is invalid!',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_accident_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_accident_submit',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_accident_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_accident_reset',
            ),
        ));
    }
}
?>