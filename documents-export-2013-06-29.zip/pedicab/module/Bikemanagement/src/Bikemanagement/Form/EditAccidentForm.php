<?php
namespace Bikemanagement\Form;

use Zend\Form\Form;

class EditAccidentForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('bikemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_accident_form');
		$this->setAttribute('id', 'pc_add_accident_form');
		
		$this->add(array(
            'name' 		 => 'accident_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'accident_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'accident_report_status',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'accident_report_status'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'other_vehicle_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'other_vehicle_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'other_person_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'other_person_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'witness_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'witness_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'mechanic_report_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'mechanic_report_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'accident_date_hidden',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'accident_date_hidden'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' 		 => 'accident_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'accident_date',
				'class'								=> 'calc-txbox datepicker',
				'tabindex'							=> '1',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Accident date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'accident_time',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'accident_time',
				'class'								=> 'clock-txbox datepicker',
				'tabindex'							=> '2',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[time]]',	//	custom[time]
				'data-errormessage-value-missing' 	=> 'Accident Time is required!',
				'data-errormessage' 			 	=> 'Invalid time, must be in HH:MM format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'accident_driver_id',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Driver Name',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'tabindex'							=> '3',
				'id'   								=> 'accident_driver_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Driver Name is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'accident_shift_manager',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Shift Manager',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'tabindex'							=> '4',
				'id'   								=> 'accident_shift_manager',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift Manager is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'accident_bike_number',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'accident_bike_number',
				'class'								=> 'wid141',
				'tabindex'							=> '5',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Number is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'accident_location',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'accident_location',
				'class'								=> '',
				'tabindex'							=> '6',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Accident Location is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'other_vehicle_description',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'other_vehicle_description',
				'class'								=> '',
				'tabindex'							=> '7',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Vehicle description is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_vehicle_license_plate',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_vehicle_license_plate',
				'class'								=> 'wid138',
				'tabindex'							=> '8',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'License Plate is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_vehicle_insurance_carrier',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_vehicle_insurance_carrier',
				'class'								=> 'wid138',
				'tabindex'							=> '9',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Insurance Carrier is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_person_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_person_name',
				'class'								=> '',
				'tabindex'							=> '10',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Name is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_person_license_state',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_person_license_state',
				'class'								=> '',
				'tabindex'							=> '11',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'License State is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'other_person_phone',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'other_person_phone',
				'class'								=> '',
				'tabindex'							=> '12',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid phone number',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'other_person_address',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'other_person_address',
				'class'								=> '',
				'tabindex'							=> '13',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Address is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'ecd_pedicab',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'ecd_pedicab',
				'class'								=> '',
				'tabindex'							=> '14',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Damage Estimated Cost is required!',
				'data-errormessage' 				=> 'Cost is invalid!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'ecd_other_vehicle',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'ecd_other_vehicle',
				'class'								=> '',
				'tabindex'							=> '15',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Other Vehicle(s) Damage Estimated Cost <br/>is required!',
				'data-errormessage' 				=> 'Cost is invalid!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'witness_one_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'witness_one_name',
				'class'								=> '',
				'tabindex'							=> '16',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',	//	validate[required]
				'data-errormessage-value-missing' 	=> 'Witness name is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'witness_one_phone',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'witness_one_phone',
				'class'								=> 'in-wid211',
				'tabindex'							=> '17',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid phone number',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'witness_two_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'witness_two_name',
				'class'								=> '',
				'tabindex'							=> '18',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',	//	validate[required]
				'data-errormessage-value-missing' 	=> 'Witness name is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'witness_two_phone',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'witness_two_phone',
				'class'								=> 'in-wid211',
				'tabindex'							=> '19',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid phone number',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		 => 'mechanic_inspection_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'mechanic_inspection_date',
				'class'								=> 'calc-txbox datepicker',
				'tabindex'							=> '20',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Mechanic Inspection Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, <br/>must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'mechanic_inspection_time',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'mechanic_inspection_time',
				'class'								=> 'clock-txbox datepicker',
				'tabindex'							=> '21',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[time]]',	//	custom[time]
				'data-errormessage-value-missing' 	=> 'Inspection Time is required!',
				'data-errormessage' 			 	=> 'Invalid time, <br/>must be in HH:MM format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'epcd_pedicab',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'epcd_pedicab',
				'class'								=> '',
				'tabindex'							=> '22',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Estimated Parts Cost is required!',
				'data-errormessage' 				=> 'Cost is invalid!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'elcf_pedicab',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'elcf_pedicab',
				'class'								=> '',
				'tabindex'							=> '23',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Estimated Labor Cost is required!',
				'data-errormessage' 				=> 'Cost is invalid!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'mechanic_description',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'mechanic_description',
				'class'								=> '',
				'tabindex'							=> '24',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Mechanic Description is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'mechanic_recommendation',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Ok to ride',
                    '2' => 'NOT Ok to Ride',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'mechanic_recommendation',
				'tabindex'	=> '25',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'driver_recommendation',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Ok to ride',
                    '2' => 'NOT Ok to Ride',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'driver_recommendation',
				'tabindex'	=> '26',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'name'		 => 'settlement_note',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'settlement_note',
				'class'								=> '',
				'tabindex'							=> '27',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Settlement Note is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'accident_settled_status',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Settled',
                    '2' => 'Not settled',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'accident_settled_status',
				'tabindex'	=> '28',
                'value' 	=> '2',
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'name'		 => 'accident_description',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'accident_description',
				'class'								=> 'acc-desc',
				'tabindex'							=> '29',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Accident Description is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'accident_image_one',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'accident_image_one',
				'class'								=> 'filepc',
				'size'								=> '35',
				'height'							=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Accident image is required!',
				//'data-errormessage' 			 	=> 'Accident image is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'accident_image_two',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'accident_image_two',
				'class'								=> 'filepc',
				'size'								=> '35',
				'height'							=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Accident image is required!',
				//'data-errormessage' 			 	=> 'Accident image is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'accident_image_three',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'accident_image_three',
				'class'								=> 'filepc',
				'size'								=> '35',
				'height'							=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Accident image is required!',
				//'data-errormessage' 			 	=> 'Accident image is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'accident_save',
            'attributes'=> array(
				'id'		=> 'accident_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'class'		=> 'fnone',
				'tabindex'	=> '28',
            ),
        ));
    }
}
?>