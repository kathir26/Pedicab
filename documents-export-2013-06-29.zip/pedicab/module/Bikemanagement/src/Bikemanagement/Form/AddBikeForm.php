<?php
namespace Bikemanagement\Form;

use Zend\Form\Form;

class AddBikeForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('bikemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_bike_form');
		$this->setAttribute('id', 'pc_add_bike_form');
		
		$this->add(array(
            'name' => 'bike_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'bike_id'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'bike_hid_img',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'bike_hid_img'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'bike_location',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'bike_location'
            ),
            'options' => array(
            )
        ));
        $this->add(array(
            'name' => 'bike_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bike_name',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Name is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'bike_model',
            'attributes' => array(
				'type' 								=> 'text',
                'value' 							=> '',
				'id'  								=> 'bike_model',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Model is required!',
            )
        ));
		/*$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'bike_location',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Location',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'   								=> 'bike_location',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Location is required!',
            )
        ));*/
		$this->add(array(
            'name' => 'bike_serial_num',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bike_serial_num',
				'class'								=> 'wid141',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Serial Number is required!',
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' 		 => 'bike_age_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bike_age_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',		//	,custom[date],custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Date is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' => 'bike_age',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bike_age',
				'class'								=> 'wid141',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Bike Age is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'bike_operation',
            'options' => array(
                'value_options' => array(
                    '2' => 'Out of service',
                    '1' => 'In service',
                ),
            ),
            'attributes' => array(
                'value' 							=> '1',
				'id'   								=> 'bike_operation',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Operation is required!',
            )
        ));
		$this->add(array(
            'name' 		 => 'bike_image',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'bike_image',
				'class'								=> 'filepc',
				'size'								=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkBikeFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Bike Image is required!',
				'data-errormessage' 			 	=> 'Please enter a valid number',
            ),
            'options' => array(
            ),
        ));
        $this->add(array(
            'name' 		=> 'bike_save',
            'attributes'=> array(
				'id'	=> 'bike_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'bike_reset',
            'attributes' => array(
				'id'	=> 'bike_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>