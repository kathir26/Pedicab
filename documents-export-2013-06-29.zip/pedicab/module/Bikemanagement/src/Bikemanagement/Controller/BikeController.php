<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Bikemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;
//	Forms
use Bikemanagement\Form\BikeFilterForm,
	Bikemanagement\Form\AddBikeForm;
//	Models
use Usermanagement\Model\Aclresources,
	Bikemanagement\Model\Bike;
use Usermanagement\Model\MyAuthenticationAdapter;

class BikeController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $commonData;
	protected $perPageArray;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');		//	array('10', '20', '30', '40', '50');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	public function bikeListingAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('id', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$bikeFilterForm 		= new BikeFilterForm();
		$filter_array			= array('1' => 'Bike Number','2' => 'Bike Model','3' => 'Serial Number','4' => 'Age of Bike');
		$bikeFilterForm->get('bike_model_sch')->setValueOptions($filter_array);
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		$bikeSession 			= new Container('bikeListing');
		$sessionArray			= array();
		foreach($bikeSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$bikeSession->offsetUnset($value);
		}
		if ($request->isPost()) {
			$bikeFilterForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['bike_name_sch']) && !empty($formData['bike_name_sch']))
				$bikeSession->bike_name	= $formData['bike_name_sch'];
			else
				$bikeSession->bike_name	= '';
			if(isset($formData['bike_model_sch']) && !empty($formData['bike_model_sch']))
				$bikeSession->bike_type	= $formData['bike_model_sch'];
			else
				$bikeSession->bike_type	= '';
		}
		$bike_operation		= array('1' => 'In service','2' => 'Out of service');
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('BikeTable')->getAllBikeList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'bikeFilterForm'	=> $bikeFilterForm,
			'pc_users'			=> $this->pcUser,
			'page'			 	=> $page,
			'sortBy'		 	=> $sortBy,
			'paginator'		 	=> $paginator,
			'perPage'		 	=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'bike_operation'	=> $bike_operation,
			'controller'	 	=> $this->params('controller')
		));
    }
	public function bikeListAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		//	Session for Bike listing
		$bikeSession = new Container('bikeListing');
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($bikeSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$bikeSession->sortBy	= $sortBy;
		} else if($bikeSession->offsetExists('sortBy')) {
			$sortBy	= $bikeSession->sortBy;
		}
		if($sortType != '') {
			if($bikeSession->sortType == $sortType && $columnFlag == 1)
				$bikeSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$bikeSession->sortType	= $sortType;
		} else if($bikeSession->offsetExists('sortType')) {
			$sortType	= $bikeSession->sortType;
		}
		//	Perpage
		if($perPage != '') {
			$bikeSession->perPage	= $perPage;
		} else if($bikeSession->offsetExists('perPage')) {
			$perPage	= $bikeSession->perPage;
		} else {
			$perPage	= $this->defaultPerPage;
		}
		
		$message			= '';
		$bike_operation		= array('1' => 'In service','2' => 'Out of service');
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('BikeTable')->getAllBikeList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		$result->setVariables(array(
				'message'		 	=> $message,
				'page'			 	=> $page,
				'sortBy'		 	=> $sortBy,
				'paginator'		 	=> $paginator,
				'perPage'		 	=> $perPage,
				'perPageArray'		=> $this->perPageArray,
				'bike_operation'	=> $bike_operation,
				'controller'	 	=> $this->params('controller')
		));
		return $result;
    }
	public function addBikeAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$get_bike_location	= '';
		$addBikeForm 		= new AddBikeForm();
		/*$get_bike_location	= $this->getTable('LocationTable')->getAllLocationDetails();
		$bike_loc_array		= array('' => 'Select Location');
		foreach($get_bike_location as $loc_key => $loc_value)
		{
			$bike_loc_array[$loc_value->loc_id]		= $loc_value->loc_title;
		}
		$addBikeForm->get('bike_location')->setValueOptions($bike_loc_array);
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
			$addBikeForm->get('bike_location')->setValue($this->pcUser->location_id);
		}*/
		$addBikeForm->get('bike_location')->setValue($identity->location_id);
		return new ViewModel(array(
			'userObject'		=> $identity,
			'addBikeForm'		=> $addBikeForm,
			'pc_users'			=> $this->pcUser,
		));
    }
	public function ajaxAddBikeAction()
    {
		$check_bike_details	= $bike_name = '';
		$json_array = array();
		$addBikeForm					=  new AddBikeForm();
	 	$request 						=  $this->getRequest();
		if($request->isPost())
		{
			 $bikeModel					= new Bike();
			 $formData 	 				= $request->getPost();
			 //$errorMessages				= $addBikeForm->getMessages();
			 if(is_object($formData) && count($formData) > 0)
			 {
			 	$bike_name				= $formData['bike_name'];
				$check_bike_details		= $this->getTable('BikeTable')->getBikeDetails($formData);
				if(is_object($check_bike_details) && count($check_bike_details) > 0)
				{
					$json_array['bike_name']	= false;
					$json_array['err_msg']		= 1;
				}
				else
				{
					$json_array['bike_name']	= true;
					$json_array['err_msg']		= 0;
				}
			 }
		}
		echo json_encode($json_array);
		return $this->getResponse();
    }
	public function saveBikeAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$addBikeForm					=  new AddBikeForm();
	 	$request 						=  $this->getRequest();
		$message = $bike_array = '';
		if($request->isPost())
		{
			$bikeModel					= new Bike();
			$formData  = $get_data		= $request->getPost();
			$bikeModel->exchangeArray($formData);
			if(isset($formData['bike_id']) && $formData['bike_id'] != '')
			{
				$this->getTable('BikeTable')->updateBike($formData);
				$bike_id				= $formData['bike_id'];
			}
			else
			{
				$bike_id				= $this->getTable('BikeTable')->insertBike($formData);
			}
			$fileTransfer 				= new \Zend\File\Transfer\Adapter\Http();
			$fileInfo 	  				= $fileTransfer->getFileInfo();
			if(isset($fileInfo['bike_image']['name']) && $fileInfo['bike_image']['name'] != '')
			{
				// My File uplaod plugins
				$myFileUpload   			= $this->MyFileUpload();
				$myFileUpload->fileTypes	= $this->imageTypes;
				$myFileUpload->fileSizes	= $this->imageSizes;
				// Validations for Bike image
				$fileNameArray				= array("bike_image");
				$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
				$myFileUpload->uploadPath	= $this->siteImageUploadPath."/bike_images";
				if(isset($get_data['bike_id']) && $get_data['bike_id'] != '')
				{
					if(isset($get_data['bike_hid_img']) && $get_data['bike_hid_img'] != '')
					{
						$myFileUpload->unlinkFile($this->siteImageUploadPath."/bike_images/".$get_data['bike_hid_img']);
					}
					// Todo : unlinkFile
				}
				$bike_image					= $myFileUpload->uploadFiles($bike_id, $fileNameArray);
				$this->getTable('BikeTable')->updateBikeImage($bike_id,$bike_image);
			}
			return $this->redirect()->toRoute('bikemanagement', array('controller' => 'bike', 'action' => 'bike-listing'));
		}
    }
	public function viewBikeAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$bike_id 		= (int) $this->params()->fromRoute('id', 0);
		$json_view_array = array();
		if($bike_id)
		{
			$view_details_array		= $this->getTable('BikeTable')->getBikeViewDetails($bike_id);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array[]	= $view_value;
				}
			}
		}
		$bike_operation		= array('1' => 'In service','2' => 'Out of service');
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array,
				'bike_operation'	=> $bike_operation,
				'imageRelPath'		=> $this->siteImageUploadPath,
				'imagePath'			=> $this->siteImagePath
		));
		return $result;
    }
	public function editBikeAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$bike_id 			= (int) $this->params()->fromRoute('id', 0);
		$get_bike_location	= $get_bike_details = $bike_image = '';
		$editBikeForm 		= new AddBikeForm();
		if($bike_id  != '')
		{
			/*$get_bike_location	= $this->getTable('LocationTable')->getAllLocationDetails();
			$bike_loc_array		= array('' => 'Select Location');
			foreach($get_bike_location as $loc_key => $loc_value)
			{
				$bike_loc_array[$loc_value->loc_id]		= $loc_value->loc_title;
			}
			$editBikeForm->get('bike_location')->setValueOptions($bike_loc_array);*/
			$get_bike_details	= $this->getTable('BikeTable')->getBikeEditDetails($bike_id);
			if(is_object($get_bike_details) && count($get_bike_details) > 0)
			{
				foreach($get_bike_details as $view_key => $view_value)
				{
					$bike_date	= '';
					if(isset($view_value['bike_age_date']) && $view_value['bike_age_date'] != '0000-00-00')
					{
						$bike_date	= $this->getCommonDataObj()->removeZerosInDate($view_value['bike_age_date']);
					}
					$editBikeForm->get('bike_name')->setValue(stripslashes($view_value['bike_name']));
					$editBikeForm->get('bike_model')->setValue(stripslashes($view_value['bike_model']));
					$editBikeForm->get('bike_location')->setValue(stripslashes($view_value['fk_location_id']));
					$editBikeForm->get('bike_serial_num')->setValue(stripslashes($view_value['bike_serial_num']));
					$editBikeForm->get('bike_age')->setValue(stripslashes($view_value['bike_age']));
					$editBikeForm->get('bike_age_date')->setValue(stripslashes($bike_date));
					$editBikeForm->get('bike_operation')->setValue(stripslashes($view_value['bike_operation']));
					$editBikeForm->get('bike_id')->setValue(stripslashes($view_value['bike_id']));
					$editBikeForm->get('bike_hid_img')->setValue(stripslashes($view_value['bike_image']));
					$bike_image 	= $view_value['bike_image'];
				}
			}
		}
		return new ViewModel(array(
			'userObject'		=> $identity,
			'editBikeForm'		=> $editBikeForm,
			'pc_users'			=> $this->pcUser,
			'bike_image'		=> $bike_image,
			'imageRelPath'		=> $this->siteImageUploadPath,
			'imagePath'			=> $this->siteImagePath
		));
    }
	public function deleteBikeAction()
    {
		$bike_id = (int) $this->params()->fromRoute('id', 0);
        if($bike_id)
		{
			$view_details_array		= $this->getTable('BikeTable')->getBikeViewDetails($bike_id);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					if(isset($view_value['bike_image']) && $view_value['bike_image'] != '')
					{
						$myFileUpload   			= $this->MyFileUpload();
						$myFileUpload->fileTypes	= $this->imageTypes;
						$myFileUpload->fileSizes	= $this->imageSizes;
						$myFileUpload->uploadPath	= $this->siteImageUploadPath."/bike_images";
						$myFileUpload->unlinkFile($this->siteImageUploadPath."/bike_images/".$view_value['bike_image']);
					}
				}
			}
			$this->getTable('BikeTable')->deleteBike($bike_id);
		}
        return $this->getResponse();
    }
	private function getTable($tableName)
    {
        $tableArray			 	=  array("BikeTable" => "Bike-Table", "LocationTable" => "Location-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
}
