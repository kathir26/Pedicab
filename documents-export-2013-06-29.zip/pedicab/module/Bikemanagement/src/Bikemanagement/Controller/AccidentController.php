<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Bikemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//  Forms
use Bikemanagement\Form\AddAccidentForm,
	Bikemanagement\Form\EditAccidentForm,
	Bikemanagement\Form\AccidentFilterForm;
	
//	Models
use Bikemanagement\Model\Accident,
	Usermanagement\Model\MyAuthenticationAdapter;

class AccidentController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $pcUser;
	protected $commonData;
	protected $accidentTable;
	protected $accidentVehicleInfoTable;
	protected $accidentPersonInfoTable;
	protected $accidentWitnessTable;
	protected $accidentMechanicReportTable;
	protected $recommendationArrray;
	protected $settlementStatusArrray;
	
	public function __construct() {
		$this->imageTypes	 			=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 			=  '3145728';		//	3 Mb
		$this->fileTypes	 			=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 			=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 		=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 			=  SITE_IMAGE_PATH;
		$this->sitePath 				=  SITE_PATH;
		$this->defaultPerPage 			=  10;
		$this->perPageArray				=  array('5', '10', '25', '50', '100');		//	array('10', '20', '30', '40', '50');
		$this->recommendationArrray		=  array('' => '-', '1' => 'Ok to ride','2' => 'NOT Ok to Ride');
		$this->settlementStatusArrray	= array('1' => 'Settled','2' => 'Not settled');
		
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName) {
        $tableArray			 	=  array("UsersTable" => "Users-Table", "ShiftTable" => "Shift-Table", "accidentTable" => "Accident-Table", "accidentVehicleInfoTable" => "Accident-Vehicle-Info-Table", "accidentPersonInfoTable" => "Accident-Person-Info-Table" , "accidentWitnessTable" => "Accident-Witness-Table", "accidentMechanicReportTable" => "Accident-Mechanic-ReportT-able");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	public function addAccidentAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 			=  $this->getRequest();
		$addAccidentForm 	=  new AddAccidentForm();
		if ($request->isPost()) {
            $accidentModel	=  new Accident();
            $addAccidentForm->setInputFilter($accidentModel->getInputFilterForAddAccident());
			$postData		=  $request->getPost()->toArray();
            $addAccidentForm->setData($postData);
            if (is_array($postData)) {		//	$addUserForm->isValid()
				$formData	=  $postData;
				$Files    	=  $this->params()->fromFiles();
				
				// Condition handling for Accident images.
				// My File uplaod plugins
				$accidentImageOne			=	$accidentImageTwo	=  $accidentImageThree	=  '';
				$myFileUpload   			=   $this->MyFileUpload();
				$myFileUpload->fileTypes	=	$this->imageTypes;
				$myFileUpload->fileSizes	=	$this->imageSizes;
				
				// Accident Image 1
				if(isset($formData['accident_image_one_fakefilepc']) && !empty($formData['accident_image_one_fakefilepc'])) {
					$fileNameArray			=	array("accident_image_one");
					$accidentImageOne		=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
				
				// Accident Image 2
				if(isset($formData['accident_image_two_fakefilepc']) && !empty($formData['accident_image_two_fakefilepc'])) {
					$fileNameArray			=	array("accident_image_two");
					$accidentImageTwo		=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
				
				// Accident Image 3
				if(isset($formData['accident_image_three_fakefilepc']) && !empty($formData['accident_image_three_fakefilepc'])) {
					$fileNameArray			=	array("accident_image_three");
					$accidentImageThree		=   $myFileUpload->checkUploadFiles($fileNameArray);
				}
				
				if(!$accidentImageOne && !$accidentImageTwo && !$accidentImageThree) {
					$datetime				=   $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$createdDate			=   $datetime(time(), 0, 'Y-m-d H:i:s');
					
					// Condition Handling for Driver & Location manager to Update the below fields
					if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id != 2) {
						if(strpos($formData['accident_date'], '-') !== false ) {
							$formData['accident_date']	=  str_replace('-', '/', $formData['accident_date']);
							$accident_date  =  $datetime->getDates(strtotime($formData['accident_date']), 0, 'Y-m-d H:i:s');
						} else {
							$accident_date  =  '0000-00-00 00:00:00';
						}
						$accident_time  	=  $this->getCommonDataObj()->convertTimeFormat($formData['accident_time'],1);
						
						//  Set the Notifications for Accident reports date and types
						$notifications						  =  array();
					    $notifications['notify_date']		  =  $accident_date;
						
						$accident_id						  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
						$accident_settled_status			  =  (isset($formData['accident_settled_status']) && !empty($formData['accident_settled_status'])) ? $formData['accident_settled_status'] : 0;
						$accidentArray 					  	  =  array(
							'accident_id'			  	  	  => $accident_id,
							'accident_date'			  	  	  => $accident_date,
				            'accident_time'			  	  	  => $accident_time,
							'accident_driver_id'		  	  => $formData['accident_driver_id'],
				            'accident_shift_manager'	  	  => $formData['accident_shift_manager'],
							'accident_bike_number' 		  	  => $formData['accident_bike_number'],
							'accident_location'			  	  => $formData['accident_location'],
							'accident_description'			  => $formData['accident_description'],
							'accident_updateddate'		  	  => $createdDate,
							'accident_createddate'		  	  => $createdDate,
				            'accident_isdelete'    		  	  => 0,
				        );
						if(isset($accident_settled_status) && !empty($accident_settled_status)) {
							$accidentArray['accident_settled_status'] = $accident_settled_status;
						}
						
						/*
						*  TODO : Condition handling for Drivers Accident Report status
						*  We require that reports are finalized within 24 hours of an accident so i would like if an alert could remind them to complete any missing pieces 
						*  prior to the 24 hour deadline
						*/
						if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
							if (isset($formData['accident_report_status']) && !empty($formData['accident_report_status'])) {
								$accidentArray['accident_report_status'] = 2;
							}
						}
						
						$accidentId  =  $this->getTable("accidentTable")->saveAccident($accidentArray);								//	Insert the Accident details
						
						// Condition handling for Images
						$accident_image_one	 =  $accident_image_two  =  $accident_image_three  = '';
						$accidentImageOneImage		  	  =  (isset($formData['accident_image_one_fakefilepc']) && !empty($formData['accident_image_one_fakefilepc'])) ? true : false;
						$accidentImageTwoImage		  	  =  (isset($formData['accident_image_two_fakefilepc']) && !empty($formData['accident_image_two_fakefilepc'])) ? true : false;
						$accidentImageThreeImage		  =  (isset($formData['accident_image_three_fakefilepc']) && !empty($formData['accident_image_three_fakefilepc'])) ? true : false;
						if($accidentImageOneImage || $accidentImageTwoImage || $accidentImageThreeImage) {
							// Image upload for Accident image 1
							if($accidentImageOneImage) {
								$fileNameArray			  =	 array("accident_image_one");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
								$imageName				  =  'accident_image_one_'.$accidentId;
								$accident_image_one	  	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
							}
							
							// Image upload for Accident image 2
							if($accidentImageTwoImage) {
								$fileNameArray			  =	 array("accident_image_two");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
								$imageName				  =  'accident_image_two_'.$accidentId;
								$accident_image_two	  	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
							}
							
							// Image upload for Accident image 3
							if($accidentImageThreeImage) {
								$fileNameArray			  =	 array("accident_image_three");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
								$imageName				  =  'accident_image_three_'.$accidentId;
								$accident_image_three	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
							}
							
							// Save Install images
							$accidentImageArray 		  =  array(
								'accident_id'			  => $accidentId,
								'accident_image_one'	  => $accident_image_one,
								'accident_image_two'	  => $accident_image_two,
								'accident_image_three'	  => $accident_image_three
					        );
							$accidentImageId  			  =  $this->getTable("accidentTable")->saveAccidentImages($accidentImageArray);		//	Save Accident images
						}
						
						// Insert or Update Other vehicle's info
						$vehicle_id							  =  (isset($formData['other_vehicle_id']) && !empty($formData['other_vehicle_id'])) ? $formData['other_vehicle_id'] : '';
						$accidenVehicleInfo 			  	  =  array(
							'other_vehicle_id'			  	  => $vehicle_id,
							'other_vehicle_accident_id'		  => $accidentId,
				            'other_vehicle_description'		  => $formData['other_vehicle_description'],
							'other_vehicle_license_plate'	  => $formData['other_vehicle_license_plate'],
				            'other_vehicle_insurance_carrier' => $formData['other_vehicle_insurance_carrier'],
							'other_vehicle_isdelete' 		  => 0
				        );
						$accidentVehicleId  				  =  $this->getTable("accidentVehicleInfoTable")->saveVehicleInfo($accidenVehicleInfo);		//	Insert the Accident vehicle details
						
						// Insert or Update Other Person's info
						$person_id							  =  (isset($formData['other_person_id']) && !empty($formData['other_person_id'])) ? $formData['other_person_id'] : '';
						$accidenPersonInfo 			  	  	  =  array(
							'other_person_id'			  	  => $person_id,
							'other_person_accident_id'		  => $accidentId,
				            'other_person_name'		  		  => $formData['other_person_name'],
							'other_person_license_state'	  => $formData['other_person_license_state'],
				            'other_person_phone' 			  => $formData['other_person_phone'],
							'other_person_address' 			  => $formData['other_person_address'],
							'ecd_pedicab' 					  => $formData['ecd_pedicab'],
							'ecd_other_vehicle' 			  => $formData['ecd_other_vehicle'],
							'other_person_isdelete' 		  => 0
				        );
						$accidentPersonId  					  =  $this->getTable("accidentPersonInfoTable")->savePersonInfoInfo($accidenPersonInfo);			//	Insert the Accident person details
						
						// Insert or Update Witness informations
						$witness_id							  =  (isset($formData['witness_id']) && !empty($formData['witness_id'])) ? $formData['witness_id'] : '';
						$accidentWitness 			  	  	  =  array(
							'witness_id'			  	  	  => $witness_id,
							'witness_accident_id'		  	  => $accidentId,
				            'witness_one_name'		  		  => $formData['witness_one_name'],
							'witness_one_phone'	  			  => $formData['witness_one_phone'],
				            'witness_two_name' 			  	  => $formData['witness_two_name'],
							'witness_two_phone' 			  => $formData['witness_two_phone'],
							'witness_isdelete' 		 		  => 0
				        );
						$accidentWitnessId  				  =  $this->getTable("accidentWitnessTable")->saveWitnessInfo($accidentWitness);			//	Insert the Accident witness details
					} else {
						if(strpos($formData['accident_date_hidden'], '-') !== false ) {
							$formData['accident_date_hidden'] =  str_replace('-', '/', $formData['accident_date_hidden']);
							$accident_date  =  $datetime->getDates(strtotime($formData['accident_date_hidden']), 0, 'Y-m-d H:i:s');
						} else {
							$accident_date  =  '0000-00-00 00:00:00';
						}
						//  Set the Notifications for Accident reports date and types
						$notifications						  =  array();
					    $notifications['notify_date']		  =  $accident_date;
						$accidentId						  	  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
					}
					
					/*
					*	Insert or Update Mechanic report
					*	Condition handling for the Drivers, Mechanic and Location managers views
					*/
					if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
						$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
						$accidentMechanicReport 			  =  array(
							'mechanic_report_id'			  => $mechanic_id,
							'mechanic_accident_id'		  	  => $accidentId,
							'driver_recommendation' 		  => $formData['driver_recommendation'],
							'mechanic_isdelete' 		 	  => 0
				        );
						
					    $notifications['notify_type']	= 5;		//	5:Accident Repor
						$notifications['accident_id']	= $accidentId;
						//  Send the Notifications for Accident reports
					    $notifications['subject'] 		= (isset($accident_id) && !empty($accident_id)) ? 'Drivers Accident Report Completed' : 'Drivers Accident Report Created';
					    $this->sendAccidentNotification(1, $identity, $notifications);
						
					} else if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 2) {
						if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
							$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
							$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
						} else {
							$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
						}
						$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
						$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
						$accidentMechanicReport 			  =  array(
							'mechanic_report_id'			  => $mechanic_id,
							'mechanic_accident_id'		  	  => $accidentId,
				            'mechanic_inspection_date'		  => $mechanic_inspection_date,
							'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
				            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
							'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
							'mechanic_description' 			  => $formData['mechanic_description'],
							'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
							'mechanic_isdelete' 		 	  => 0
				        );
					} else {
						if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
							$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
							$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
						} else {
							$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
						}
						$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
						$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
						$accidentMechanicReport 			  =  array(
							'mechanic_report_id'			  => $mechanic_id,
							'mechanic_accident_id'		  	  => $accidentId,
				            'mechanic_inspection_date'		  => $mechanic_inspection_date,
							'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
				            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
							'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
							'mechanic_description' 			  => $formData['mechanic_description'],
							'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
							'driver_recommendation' 		  => $formData['driver_recommendation'],
							'settlement_note' 			  	  => $formData['settlement_note'],
							'mechanic_isdelete' 		 	  => 0
				        );
					}
					$accidentMechanicReportId  			  =  $this->getTable("accidentMechanicReportTable")->saveMechanicReport($accidentMechanicReport);	//	Insert the Accident  Mechanic Report details
					
					$message							  = 'Successfully Accident report inserted';
					return $this->redirect()->toRoute('bikemanagement', array('controller' => 'accident', 'action' => 'accident-listing'));
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
			}
        } else {
				// $errorMessages	= $addUserForm->getMessages();
		}
		
		// TODO : Condition handling for Driver views
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
			$driverName				= $this->pcUser->user_firstname.' '.$this->pcUser->user_lastname;
			$driverId				= $this->pcUser->user_id;
			$allDrivers				= array($driverId => $driverName);
			$addAccidentForm->get('accident_driver_id')->setValueOptions($allDrivers);
			$addAccidentForm->get('accident_driver_id')->setValue($driverId);
		} else {
			// Get the All Drivers on particular locations
			$allDriversSession 		= new Container('allDrivers');
			$allDrivers				= array();
			if($allDriversSession->offsetExists('allDriver') && $allDriversSession->allDriver != '' ) {
				$allDrivers			= $allDriversSession->allDriver;
			} else {
				$allDrivers			= array(''  => 'Select Driver Name');
				$drivers			= $this->getTable("UsersTable")->getAllUsersDetail(1);
				if($drivers) {
					foreach($drivers as $driver) {
						$allDrivers[$driver['user_id']]  =  $driver['user_firstname'].' '.$driver['user_lastname'];
					}
				}
				$allDriversSession->allDriver  =  $allDrivers;
			}
			$addAccidentForm->get('accident_driver_id')->setValueOptions($allDrivers);
			//$addAccidentForm->get('accident_driver_id')->setValue();
		}
		
		// Condition handling for Shift Manager
		$shiftManagersSession 	= new Container('shiftManagers');
		$shiftManagers			= array();
		if($shiftManagersSession->offsetExists('shiftManager') && $shiftManagersSession->shiftManager != '' ) {
			$shiftManagers		= $shiftManagersSession->shiftManager;
		} else {
			$shiftManagers		= array(''  => 'Select Shift Manager');
			$results			= $this->getTable("UsersTable")->getAllUsersDetail(1);
			if($results) {
				foreach($results as $result) {
					$shiftManagers[$result['user_id']]  =  $result['user_firstname'].' '.$result['user_lastname'];
				}
			}
			$shiftManagersSession->shiftManager  =  $shiftManagers;
		}
		$addAccidentForm->get('accident_shift_manager')->setValueOptions($shiftManagers);
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'addAccidentForm'	=> $addAccidentForm,
			'pc_users'			=> $this->pcUser,
		));
    }
	
	public function editAccidentAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$editAccidentForm 		=  new EditAccidentForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$accidentId 			=  (int) $this->params()->fromRoute('id', 0);
		$acccidentDetails		= '';
		
		if ($accidentId) {
			$addAccidentForm 	=  new AddAccidentForm();
			if ($request->isPost()) {
	            $accidentModel	=  new Accident();
	            $addAccidentForm->setInputFilter($accidentModel->getInputFilterForAddAccident());
				$postData		=  $request->getPost()->toArray();
	            $addAccidentForm->setData($postData);
	            if (is_array($postData)) {		//	$addUserForm->isValid()
					$formData	=  $postData;
					$Files    	=  $this->params()->fromFiles();
					
					// Condition handling for Accident images.
					// My File uplaod plugins
					$accidentImageOne			=  $accidentImageTwo	  =  $accidentImageThree		=  '';
					$accidentImageOneFlag		=  $accidentImageTwoFlag  =  $accidentImageThreeFlag	=  '';
					$myFileUpload   			=  $this->MyFileUpload();
					$myFileUpload->fileTypes	=  $this->imageTypes;
					$myFileUpload->fileSizes	=  $this->imageSizes;
					
					// Accident Image 1
					if(isset($formData['accident_image_one_fakefilepc']) && !empty($formData['accident_image_one_fakefilepc'])) {
						$accidentImageOneFlag	=  ($formData['accident_image_one_hidden'] != $formData['accident_image_one_fakefilepc']) ? true : false;
						if($accidentImageOneFlag) {
							$fileNameArray		=  array("accident_image_one");
							$accidentImageOne	=  $myFileUpload->checkUploadFiles($fileNameArray);
						}
					}
					
					// Accident Image 2
					if(isset($formData['accident_image_two_fakefilepc']) && !empty($formData['accident_image_two_fakefilepc'])) {
						$accidentImageTwoFlag	=  ($formData['accident_image_two_hidden'] != $formData['accident_image_two_fakefilepc']) ? true : false;
						if($accidentImageTwoFlag) {
							$fileNameArray		=  array("accident_image_two");
							$accidentImageTwo	=  $myFileUpload->checkUploadFiles($fileNameArray);
						}
					}
					
					// Accident Image 3
					if(isset($formData['accident_image_three_fakefilepc']) && !empty($formData['accident_image_three_fakefilepc'])) {
						$accidentImageThreeFlag	=  ($formData['accident_image_three_hidden'] != $formData['accident_image_three_fakefilepc']) ? true : false;
						if($accidentImageThreeFlag) {
							$fileNameArray		=  array("accident_image_three");
							$accidentImageThree	=  $myFileUpload->checkUploadFiles($fileNameArray);
						}
					}
					
					if(!$accidentImageOne && !$accidentImageTwo && !$accidentImageThree) {
						$datetime				=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate			=  $datetime(time(), 0, 'Y-m-d H:i:s');
						
						// Condition Handling for Driver & Location manager to Update the below fields
						if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id != 2) {
							if(strpos($formData['accident_date'], '-') !== false ) {
								$formData['accident_date']	=  str_replace('-', '/', $formData['accident_date']);
								$accident_date  =  $datetime->getDates(strtotime($formData['accident_date']), 0, 'Y-m-d H:i:s');
							} else {
								$accident_date  =  '0000-00-00 00:00:00';
							}
							$accident_time  	=  $this->getCommonDataObj()->convertTimeFormat($formData['accident_time'],1);
							
							//  Set the Notifications for Accident reports date and types
							$notifications						  =  array();
						    $notifications['notify_date']		  =  $accident_date;
							
							$accident_id						  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
							$accident_settled_status			  =  (isset($formData['accident_settled_status']) && !empty($formData['accident_settled_status'])) ? $formData['accident_settled_status'] : 0;
							$accidentArray 					  	  =  array(
								'accident_id'			  	  	  => $accident_id,
								'accident_date'			  	  	  => $accident_date,
					            'accident_time'			  	  	  => $accident_time,
								'accident_driver_id'		  	  => $formData['accident_driver_id'],
					            'accident_shift_manager'	  	  => $formData['accident_shift_manager'],
								'accident_bike_number' 		  	  => $formData['accident_bike_number'],
								'accident_location'			  	  => $formData['accident_location'],
								'accident_description'			  => $formData['accident_description'],
								'accident_updateddate'		  	  => $createdDate,
								'accident_createddate'		  	  => $createdDate,
					            'accident_isdelete'    		  	  => 0,
					        );
							if(isset($accident_settled_status) && !empty($accident_settled_status)) {
								$accidentArray['accident_settled_status'] = $accident_settled_status;
							}
							
							/*
							*  TODO : Condition handling for Drivers Accident Report status
							*  We require that reports are finalized within 24 hours of an accident so i would like if an alert could remind them to complete any missing pieces 
							*  prior to the 24 hour deadline
							*/
							if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
								if (isset($formData['accident_report_status']) && !empty($formData['accident_report_status'])) {
									$accidentArray['accident_report_status'] = 2;
								}
							}
							
							$accidentId  =  $this->getTable("accidentTable")->saveAccident($accidentArray);								//	Insert the Accident details
							
							// Condition handling for Images
							$accident_image_one	 = $accident_image_two  =  $accident_image_three  = '';
							$accidentImageOneImage		  	  =  (isset($formData['accident_image_one_fakefilepc']) && !empty($formData['accident_image_one_fakefilepc'])) ? true : false;
							$accidentImageTwoImage		  	  =  (isset($formData['accident_image_two_fakefilepc']) && !empty($formData['accident_image_two_fakefilepc'])) ? true : false;
							$accidentImageThreeImage		  =  (isset($formData['accident_image_three_fakefilepc']) && !empty($formData['accident_image_three_fakefilepc'])) ? true : false;
							
							if(($accidentImageOneFlag && $accidentImageOneImage) || ($accidentImageTwoFlag && $accidentImageTwoImage) || ($accidentImageThreeFlag && $accidentImageThreeImage)) {
								// Save Install images
								$accidentImageArray 		  =  array(
									'accident_id'			  => $accidentId
						        );
								
								// Image upload for Accident image 1
								if($accidentImageOneFlag && $accidentImageOneImage) {
									$fileNameArray			  =	 array("accident_image_one");
									$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
									if(isset($formData['accident_image_one_hidden']) && $formData['accident_image_one_hidden'] != '') {
										$unlinkFile			  =	 $this->siteImageUploadPath."/accident_image/".$formData['accident_image_one_hidden'];
										$myFileUpload->unlinkFile($unlinkFile);
									}
									$imageName				  =  'accident_image_one_'.$accidentId;
									$accident_image_one	  	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
									$accidentImageArray['accident_image_one']	=	$accident_image_one;
								}
								
								// Image upload for Accident image 2
								if($accidentImageTwoFlag && $accidentImageTwoImage) {
									$fileNameArray			  =	 array("accident_image_two");
									$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
									if(isset($formData['accident_image_two_hidden']) && $formData['accident_image_two_hidden'] != '') {
										$unlinkFile			  =	 $this->siteImageUploadPath."/accident_image/".$formData['accident_image_two_hidden'];
										$myFileUpload->unlinkFile($unlinkFile);
									}
									$imageName				  =  'accident_image_two_'.$accidentId;
									$accident_image_two	  	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
									$accidentImageArray['accident_image_two']	=	$accident_image_two;
								}
								
								// Image upload for Accident image 3
								if($accidentImageThreeFlag && $accidentImageThreeImage) {
									$fileNameArray			  =	 array("accident_image_three");
									$myFileUpload->uploadPath =  $this->siteImageUploadPath."/accident_image";
									if(isset($formData['accident_image_three_hidden']) && $formData['accident_image_three_hidden'] != '') {
										$unlinkFile			  =	 $this->siteImageUploadPath."/accident_image/".$formData['accident_image_three_hidden'];
										$myFileUpload->unlinkFile($unlinkFile);
									}
									$imageName				  =  'accident_image_three_'.$accidentId;
									$accident_image_three	  =  $myFileUpload->uploadFiles($imageName, $fileNameArray);
									$accidentImageArray['accident_image_three']	=	$accident_image_three;
								}
								
								$accidentImageId  			  =  $this->getTable("accidentTable")->saveAccidentImages($accidentImageArray);		//	Save Accident images
							}
							
							// Insert or Update Other vehicle's info
							$vehicle_id							  =  (isset($formData['other_vehicle_id']) && !empty($formData['other_vehicle_id'])) ? $formData['other_vehicle_id'] : '';
							$accidenVehicleInfo 			  	  =  array(
								'other_vehicle_id'			  	  => $vehicle_id,
								'other_vehicle_accident_id'		  => $accidentId,
					            'other_vehicle_description'		  => $formData['other_vehicle_description'],
								'other_vehicle_license_plate'	  => $formData['other_vehicle_license_plate'],
					            'other_vehicle_insurance_carrier' => $formData['other_vehicle_insurance_carrier'],
								'other_vehicle_isdelete' 		  => 0
					        );
							$accidentVehicleId  				  =  $this->getTable("accidentVehicleInfoTable")->saveVehicleInfo($accidenVehicleInfo);		//	Insert the Accident vehicle details
							
							// Insert or Update Other Person's info
							$person_id							  =  (isset($formData['other_person_id']) && !empty($formData['other_person_id'])) ? $formData['other_person_id'] : '';
							$accidenPersonInfo 			  	  	  =  array(
								'other_person_id'			  	  => $person_id,
								'other_person_accident_id'		  => $accidentId,
					            'other_person_name'		  		  => $formData['other_person_name'],
								'other_person_license_state'	  => $formData['other_person_license_state'],
					            'other_person_phone' 			  => $formData['other_person_phone'],
								'other_person_address' 			  => $formData['other_person_address'],
								'ecd_pedicab' 					  => $formData['ecd_pedicab'],
								'ecd_other_vehicle' 			  => $formData['ecd_other_vehicle'],
								'other_person_isdelete' 		  => 0
					        );
							$accidentPersonId  					  =  $this->getTable("accidentPersonInfoTable")->savePersonInfoInfo($accidenPersonInfo);			//	Insert the Accident person details
							
							// Insert or Update Witness informations
							$witness_id							  =  (isset($formData['witness_id']) && !empty($formData['witness_id'])) ? $formData['witness_id'] : '';
							$accidentWitness 			  	  	  =  array(
								'witness_id'			  	  	  => $witness_id,
								'witness_accident_id'		  	  => $accidentId,
					            'witness_one_name'		  		  => $formData['witness_one_name'],
								'witness_one_phone'	  			  => $formData['witness_one_phone'],
					            'witness_two_name' 			  	  => $formData['witness_two_name'],
								'witness_two_phone' 			  => $formData['witness_two_phone'],
								'witness_isdelete' 		 		  => 0
					        );
							$accidentWitnessId  				  =  $this->getTable("accidentWitnessTable")->saveWitnessInfo($accidentWitness);			//	Insert the Accident witness details
						} else {
							if(strpos($formData['accident_date_hidden'], '-') !== false ) {
								$formData['accident_date_hidden'] =  str_replace('-', '/', $formData['accident_date_hidden']);
								$accident_date  =  $datetime->getDates(strtotime($formData['accident_date_hidden']), 0, 'Y-m-d H:i:s');
							} else {
								$accident_date  =  '0000-00-00 00:00:00';
							}
							//  Set the Notifications for Accident reports date and types
							$notifications						  =  array();
						    $notifications['notify_date']		  =  $accident_date;
							$accidentId						  	  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
						}
						
						/*
						*	Insert or Update Mechanic report
						*	Condition handling for the Drivers, Mechanic and Location managers views
						*/
						if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
							$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
							$accidentMechanicReport 			  =  array(
								'mechanic_report_id'			  => $mechanic_id,
								'mechanic_accident_id'		  	  => $accidentId,
								'driver_recommendation' 		  => $formData['driver_recommendation'],
								'mechanic_isdelete' 		 	  => 0
					        );
							
						    $notifications['notify_type']	= 5;		//	5:Accident Report
							$notifications['accident_id']	= $accidentId;
							//  Send the Notifications for Accident reports
						    $notifications['subject'] 		= (isset($accident_id) && !empty($accident_id)) ? 'Drivers Accident Report Completed' : 'Drivers Accident Report Created';
						    $this->sendAccidentNotification(1, $identity, $notifications);
							
						} else if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 2) {
							if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
								$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
								$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
							} else {
								$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
							}
							$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
							$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
							$accidentMechanicReport 			  =  array(
								'mechanic_report_id'			  => $mechanic_id,
								'mechanic_accident_id'		  	  => $accidentId,
					            'mechanic_inspection_date'		  => $mechanic_inspection_date,
								'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
					            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
								'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
								'mechanic_description' 			  => $formData['mechanic_description'],
								'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
								'mechanic_isdelete' 		 	  => 0
					        );
							
						    $notifications['notify_type']	= 5;		//	5:Accident Report
							$notifications['accident_id']	= $accidentId;
							//  Send the Notifications for Accident reports
						    $notifications['subject'] 		= 'Accident Report was completed by Mechanic';
						    $this->sendAccidentNotification(1, $identity, $notifications);
							
						} else {
							if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
								$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
								$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
							} else {
								$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
							}
							$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
							$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
							$accidentMechanicReport 			  =  array(
								'mechanic_report_id'			  => $mechanic_id,
								'mechanic_accident_id'		  	  => $accidentId,
					            'mechanic_inspection_date'		  => $mechanic_inspection_date,
								'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
					            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
								'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
								'mechanic_description' 			  => $formData['mechanic_description'],
								'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
								'driver_recommendation' 		  => $formData['driver_recommendation'],
								'settlement_note' 			  	  => $formData['settlement_note'],
								'mechanic_isdelete' 		 	  => 0
					        );
						}
						$accidentMechanicReportId  			  =  $this->getTable("accidentMechanicReportTable")->saveMechanicReport($accidentMechanicReport);	//	Insert the Accident  Mechanic Report details
						
						$message							  = 'Successfully Accident report updated';
						return $this->redirect()->toRoute('bikemanagement', array('controller' => 'accident', 'action' => 'accident-listing'));
					}
				} else {
					// $errorMessages	= $addUserForm->getMessages();
				}
	        } else {
					// $errorMessages	= $addUserForm->getMessages();
			}
			
			$results				=  $this->getTable("accidentTable")->getAccidentDetails($accidentId);
			if($results) {
				$toArray			=  $results->toArray();
				$acccidentDetails	=  (isset($toArray[0]) && count($toArray[0])) ? $toArray[0] : '';
			}
			
			// Accident detail arrays
			$accidentKeyArrays		=	array('accident_id', 'accident_bike_number', 'accident_location', 'accident_settled_status',
											  'other_vehicle_id', 'other_vehicle_description', 'other_vehicle_license_plate', 'other_vehicle_insurance_carrier',
											  'other_person_id', 'other_person_name', 'other_person_license_state', 'other_person_phone', 'other_person_address', 'ecd_pedicab', 'ecd_other_vehicle',
											  'witness_id', 'witness_one_name', 'witness_one_phone', 'witness_two_name', 'witness_two_phone',
											  'mechanic_report_id', 'epcd_pedicab', 'elcf_pedicab', 'mechanic_description', 'mechanic_recommendation', 'driver_recommendation', 'settlement_note',
											 );
			// Set the Accident details into the edit mode
			foreach($accidentKeyArrays as $key) {
				$editAccidentForm->get($key)->setValue($acccidentDetails[$key]);
			}
			// TODO : Condition handling for Driver views
			if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
				$driverName				= $this->pcUser->user_firstname.' '.$this->pcUser->user_lastname;
				$driverId				= $this->pcUser->user_id;
				$allDrivers				= array($driverId => $driverName);
				
			} else {
				// Get the All Drivers on particular locations
				$allDriversSession 		= new Container('allDrivers');
				$allDrivers				= array();
				if($allDriversSession->offsetExists('allDriver') && $allDriversSession->allDriver != '' ) {
					$allDrivers			= $allDriversSession->allDriver;
				} else {
					$allDrivers			= array(''  => 'Select Driver Name');
					$drivers			= $this->getTable("UsersTable")->getAllUsersDetail(1);
					if($drivers) {
						foreach($drivers as $driver) {
							$allDrivers[$driver['user_id']]  =  $driver['user_firstname'].' '.$driver['user_lastname'];
						}
					}
					$allDriversSession->allDriver  =  $allDrivers;
				}
			}
			$editAccidentForm->get('accident_driver_id')->setValueOptions($allDrivers);
			$editAccidentForm->get('accident_driver_id')->setValue($acccidentDetails['accident_driver_id']);
			
			// Condition handling for Shift Manager
			$shiftManagersSession 	= new Container('shiftManagers');
			$shiftManagers			= array();
			if($shiftManagersSession->offsetExists('shiftManager') && $shiftManagersSession->shiftManager != '' ) {
				$shiftManagers		= $shiftManagersSession->shiftManager;
			} else {
				$shiftManagers		= array(''  => 'Select Shift Manager');
				$results			= $this->getTable("UsersTable")->getAllUsersDetail(1);
				if($results) {
					foreach($results as $result) {
						$shiftManagers[$result['user_id']]  =  $result['user_firstname'].' '.$result['user_lastname'];
					}
				}
				$shiftManagersSession->shiftManager  =  $shiftManagers;
			}
			$editAccidentForm->get('accident_shift_manager')->setValueOptions($shiftManagers);
			$editAccidentForm->get('accident_shift_manager')->setValue($acccidentDetails['accident_shift_manager']);
			
			// Date
			$datetime					=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$accident_date				=  $datetime->getDates(strtotime($acccidentDetails['accident_date']), 0, 'n-j-Y');
			$mechanic_inspection_date	=  $datetime->getDates(strtotime($acccidentDetails['mechanic_inspection_date']), 0, 'n-j-Y');
			
			$editAccidentForm->get('accident_date')->setValue($accident_date);
			$editAccidentForm->get('accident_date_hidden')->setValue($accident_date);
			$editAccidentForm->get('mechanic_inspection_date')->setValue($mechanic_inspection_date);
			
			$editAccidentForm->get('accident_description')->setValue($acccidentDetails['accident_description']);
			
			// Images
			$editAccidentForm->get('accident_image_one')->setValue($acccidentDetails['accident_image_one']);
			$editAccidentForm->get('accident_image_two')->setValue($acccidentDetails['accident_image_two']);
			$editAccidentForm->get('accident_image_three')->setValue($acccidentDetails['accident_image_three']);
			
			// Time
			$editAccidentForm->get('accident_time')->setValue($this->getCommonDataObj()->convertTimeFormat($acccidentDetails['accident_time'],''));
			$editAccidentForm->get('mechanic_inspection_time')->setValue($this->getCommonDataObj()->convertTimeFormat($acccidentDetails['mechanic_inspection_time'],''));
			$editAccidentForm->get('accident_report_status')->setValue($acccidentDetails['accident_report_status']);
			return new ViewModel(array(
				'userObject'		 	=> $identity,
				'editAccidentForm'	 	=> $editAccidentForm,
				'message'			 	=> $message,
				'acccidentDetails'		=> $acccidentDetails,
				'pc_users'			 	=> $this->pcUser,
				'datetime'			    => $datetime,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
				'controller'			=> $this->params('controller'),
				'commonData'			=> $this->getCommonDataObj()
			));
		} else {
			return $this->redirect()->toRoute('bikemanagement', array('controller' => 'accident', 'action' => 'accident-listing'));
			die();
		}
    }
	
	/*
	public function ajaxAddAccidentAction() {
		$auth 		  		    = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addAccidentJsonArray   =  array();
		$addAccidentForm 		=  new AddAccidentForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$addAccidentJsonArray['redirect_url']	= '';
		if ($request->isPost()) {
            $accidentModel			=  new Accident();
            $addAccidentForm->setInputFilter($accidentModel->getInputFilterForAddAccident());
			$postData				= $request->getPost()->toArray();
            $addAccidentForm->setData($postData);
            if (is_array($postData)) {		//	$addUserForm->isValid()
				$formData		 	=  $postData;
				
				$datetime			=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate		=  $datetime(time(), 0, 'Y-m-d H:i:s');
				
				// Condition Handling for Driver & Location manager to Update the below fields
				if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id != 2) {
					if(strpos($formData['accident_date'], '-') !== false ) {
						$formData['accident_date']	=  str_replace('-', '/', $formData['accident_date']);
						$accident_date  =  $datetime->getDates(strtotime($formData['accident_date']), 0, 'Y-m-d H:i:s');
					} else {
						$accident_date  =  '0000-00-00 00:00:00';
					}
					$accident_time  	=  $this->getCommonDataObj()->convertTimeFormat($formData['accident_time'],1);
					
					//  Set the Notifications for Accident reports date and types
					$notifications						  =  array();
				    $notifications['notify_date']		  =  $formData['accident_date'];
					
					$accident_id						  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
					$accident_settled_status			  =  (isset($formData['accident_settled_status']) && !empty($formData['accident_settled_status'])) ? $formData['accident_settled_status'] : 0;
					$accidentArray 					  	  =  array(
						'accident_id'			  	  	  => $accident_id,
						'accident_date'			  	  	  => $accident_date,
			            'accident_time'			  	  	  => $accident_time,
						'accident_driver_id'		  	  => $formData['accident_driver_id'],
			            'accident_shift_manager'	  	  => $formData['accident_shift_manager'],
						'accident_bike_number' 		  	  => $formData['accident_bike_number'],
						'accident_location'			  	  => $formData['accident_location'],
						'accident_updateddate'		  	  => $createdDate,
						'accident_createddate'		  	  => $createdDate,
			            'accident_isdelete'    		  	  => 0,
			        );
					if(isset($accident_settled_status) && !empty($accident_settled_status)) {
						$accidentArray['accident_settled_status'] =  $accident_settled_status;
					}
					
					if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
						if (isset($formData['accident_report_status']) && !empty($formData['accident_report_status'])) {
							$accidentArray['accident_report_status'] = 2;
						}
					}
					
					$accidentId  =  $this->getTable("accidentTable")->saveAccident($accidentArray);								//	Insert the Accident details
					
					// Insert or Update Other vehicle's info
					$vehicle_id							  =  (isset($formData['other_vehicle_id']) && !empty($formData['other_vehicle_id'])) ? $formData['other_vehicle_id'] : '';
					$accidenVehicleInfo 			  	  =  array(
						'other_vehicle_id'			  	  => $vehicle_id,
						'other_vehicle_accident_id'		  => $accidentId,
			            'other_vehicle_description'		  => $formData['other_vehicle_description'],
						'other_vehicle_license_plate'	  => $formData['other_vehicle_license_plate'],
			            'other_vehicle_insurance_carrier' => $formData['other_vehicle_insurance_carrier'],
						'other_vehicle_isdelete' 		  => 0
			        );
					$accidentVehicleId  				  =  $this->getTable("accidentVehicleInfoTable")->saveVehicleInfo($accidenVehicleInfo);		//	Insert the Accident vehicle details
					
					// Insert or Update Other Person's info
					$person_id							  =  (isset($formData['other_person_id']) && !empty($formData['other_person_id'])) ? $formData['other_person_id'] : '';
					$accidenPersonInfo 			  	  	  =  array(
						'other_person_id'			  	  => $person_id,
						'other_person_accident_id'		  => $accidentId,
			            'other_person_name'		  		  => $formData['other_person_name'],
						'other_person_license_state'	  => $formData['other_person_license_state'],
			            'other_person_phone' 			  => $formData['other_person_phone'],
						'other_person_address' 			  => $formData['other_person_address'],
						'ecd_pedicab' 					  => $formData['ecd_pedicab'],
						'ecd_other_vehicle' 			  => $formData['ecd_other_vehicle'],
						'other_person_isdelete' 		  => 0
			        );
					$accidentPersonId  					  =  $this->getTable("accidentPersonInfoTable")->savePersonInfoInfo($accidenPersonInfo);			//	Insert the Accident person details
					
					// Insert or Update Witness informations
					$witness_id							  =  (isset($formData['witness_id']) && !empty($formData['witness_id'])) ? $formData['witness_id'] : '';
					$accidentWitness 			  	  	  =  array(
						'witness_id'			  	  	  => $witness_id,
						'witness_accident_id'		  	  => $accidentId,
			            'witness_one_name'		  		  => $formData['witness_one_name'],
						'witness_one_phone'	  			  => $formData['witness_one_phone'],
			            'witness_two_name' 			  	  => $formData['witness_two_name'],
						'witness_two_phone' 			  => $formData['witness_two_phone'],
						'witness_isdelete' 		 		  => 0
			        );
					$accidentWitnessId  				  =  $this->getTable("accidentWitnessTable")->saveWitnessInfo($accidentWitness);			//	Insert the Accident witness details
				} else {
					
					//  Set the Notifications for Accident reports date and types
					$notifications						  =  array();
				    $notifications['notify_date']		  =  $formData['accident_date_hidden'];
					$accidentId						  	  =  (isset($formData['accident_id']) && !empty($formData['accident_id'])) ? $formData['accident_id'] : '';
				}
				
				if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
					$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
					$accidentMechanicReport 			  =  array(
						'mechanic_report_id'			  => $mechanic_id,
						'mechanic_accident_id'		  	  => $accidentId,
						'driver_recommendation' 		  => $formData['driver_recommendation'],
						'mechanic_isdelete' 		 	  => 0
			        );
					
				    $notifications['notify_type']	= 5;
					$notifications['accident_id']	= $accidentId;
					//  Send the Notifications for Accident reports
				    $notifications['subject'] 		= (isset($accident_id) && !empty($accident_id)) ? 'Drivers Accident Report Completed' : 'Drivers Accident Report Created';
				    $this->sendAccidentNotification(1, $identity, $notifications);
					
				} else if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 2) {
					if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
						$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
						$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
					} else {
						$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
					}
					$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
					$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
					$accidentMechanicReport 			  =  array(
						'mechanic_report_id'			  => $mechanic_id,
						'mechanic_accident_id'		  	  => $accidentId,
			            'mechanic_inspection_date'		  => $mechanic_inspection_date,
						'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
			            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
						'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
						'mechanic_description' 			  => $formData['mechanic_description'],
						'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
						'mechanic_isdelete' 		 	  => 0
			        );
				} else {
					if(strpos($formData['mechanic_inspection_date'], '-') !== false ) {
						$formData['mechanic_inspection_date']	=  str_replace('-', '/', $formData['mechanic_inspection_date']);
						$mechanic_inspection_date  		  =  $datetime->getDates(strtotime($formData['mechanic_inspection_date']), 0, 'Y-m-d H:i:s');
					} else {
						$mechanic_inspection_date  		  =  '0000-00-00 00:00:00';
					}
					$mechanic_inspection_time  			  =  $formData['mechanic_inspection_time'];
					$mechanic_id						  =  (isset($formData['mechanic_report_id']) && !empty($formData['mechanic_report_id'])) ? $formData['mechanic_report_id'] : '';
					$accidentMechanicReport 			  =  array(
						'mechanic_report_id'			  => $mechanic_id,
						'mechanic_accident_id'		  	  => $accidentId,
			            'mechanic_inspection_date'		  => $mechanic_inspection_date,
						'mechanic_inspection_time'	  	  => $mechanic_inspection_time,
			            'epcd_pedicab' 			  	  	  => $formData['epcd_pedicab'],
						'elcf_pedicab' 			  		  => $formData['elcf_pedicab'],
						'mechanic_description' 			  => $formData['mechanic_description'],
						'mechanic_recommendation' 		  => $formData['mechanic_recommendation'],
						'driver_recommendation' 		  => $formData['driver_recommendation'],
						'settlement_note' 			  	  => $formData['settlement_note'],
						'mechanic_isdelete' 		 	  => 0
			        );
				}
				
				$accidentMechanicReportId  			  =  $this->getTable("accidentMechanicReportTable")->saveMechanicReport($accidentMechanicReport);	//	Insert the Accident  Mechanic Report details
				
				$message							  = 'Successfully inserted';
				$addAccidentJsonArray['redirect_url'] = '/bikemanagement/accident/accident-listing';
				
				$addAccidentJsonArray['accident']	  = true;
				$addAccidentJsonArray['err_msg']	  = "";
//				return $this->redirect()->toRoute('bikemanagement', array('controller' => 'accident', 'action' => 'accident-listing'));
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$addAccidentJsonArray['accident']	= false;
				$addAccidentJsonArray['err_msg']	= "Enter the required fields";
			}
        } else {
				$addAccidentJsonArray['accident']	= false;
				$addAccidentJsonArray['err_msg']	= "Enter the required fields";
		}
		
		echo json_encode($addAccidentJsonArray);
		return $this->getResponse();
		
		// $json_array['redirect']					= '/usermanagement/location/manage-location';
    }
	*/
	
	public function accidentListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		/*
		$router = $this->getEvent()->getRouter();
		$url    = $router->assemble(array('module' =>'bikemanagement', 'controller' =>'accident'), array('name' => 'accident-listing'));
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."====>".$url."<==";
		*/
		
		// assign default
		$message				= '';
		$matches				= $this->getEvent()->getRouteMatch();
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$settled	= $matches->getParam('settled', '');
		
		// Create Filter form
		$accidentFilterForm 	   = new AccidentFilterForm();
		$request 				   = $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			   = $this->getCommonDataObj()->destroySessionVariables(array('unsettledAccidentListing', 'settledAccidentListing'));
		}
		$unsettledAccidentSession  = new Container('unsettledAccidentListing');
		$settledAccidentSession    = new Container('settledAccidentListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$accidentFilterForm->setData($request->getPost());
			if(isset($formData['accident_settled']) && $formData['accident_settled'] == 1) {					// settled Accident Listing
				// Accident date
				if(isset($formData['accident_date']) && !empty($formData['accident_date']))
					$settledAccidentSession->accident_date	 = $formData['accident_date'];
				else
					$settledAccidentSession->accident_date	 = '';
				
				// Cost of Damages,	Estimated Parts Cost of Damages to Pedicab
				if(isset($formData['damage_cost']) && !empty($formData['damage_cost']))
					$settledAccidentSession->damage_cost	 = $formData['damage_cost'];
				else
					$settledAccidentSession->damage_cost	 = '';
			} else if(isset($formData['accident_settled']) && $formData['accident_settled'] == 2) {				// unsettled Accident Listing
				// Accident date
				if(isset($formData['accident_date']) && !empty($formData['accident_date']))
					$unsettledAccidentSession->accident_date = $formData['accident_date'];
				else
					$unsettledAccidentSession->accident_date = '';
				
				// Cost of Damages,	Estimated Parts Cost of Damages to Pedicab
				if(isset($formData['damage_cost']) && !empty($formData['damage_cost']))
					$unsettledAccidentSession->damage_cost	 = $formData['damage_cost'];
				else
					$unsettledAccidentSession->damage_cost	 = '';
			}
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// unsettled Accident Listing
		$perPage					= $this->defaultPerPage;
		$settled_status				= 2;
		$iteratorAdapter_unsettled	= new \Zend\Paginator\Adapter\Iterator($this->getTable('accidentTable')->getAccidentList($settled_status));
		$paginator_unsettled		= new \Zend\Paginator\Paginator($iteratorAdapter_unsettled);
		$paginator_unsettled->setCurrentPageNumber($page);
		$paginator_unsettled->setItemCountPerPage($perPage);
		
		// settled Accident Listing
		/*$settled_status			= 1;
		$iteratorAdapter_settled	= new \Zend\Paginator\Adapter\Iterator($this->getTable('accidentTable')->getAccidentList($settled_status));
		$paginator_settled			= new \Zend\Paginator\Paginator($iteratorAdapter_settled);
		$paginator_settled->setCurrentPageNumber($page);
		$paginator_settled->setItemCountPerPage($perPage);
		*/
		$paginator_settled			= '';		//	Need to check later, for pagination issues.
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'accidentFilterForm'	=> $accidentFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_unsettled'	=> $paginator_unsettled,
			'paginator_settled'		=> $paginator_settled,
			'perPage'				=> $perPage,
			'recommendationArrray'	=> $this->recommendationArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		
		/*return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser
		));*/
    }
	
	/*	Action	: 	Ajax Accident list, Ajax action
	*	Detail	:	Used to list the Users details via Ajax
	*/
	public function accidentListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$settled	= $matches->getParam('settled', '');
		
		//	Session for Role listing
		$sessionsContainer	= (isset($settled) && $settled == 1) ? 'settledAccidentListing' : 'unsettledAccidentListing';
		$accidentSession 	= new Container($sessionsContainer);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($accidentSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$accidentSession->sortBy	= $sortBy;
		} else if($accidentSession->offsetExists('sortBy')) {
			$sortBy	= $accidentSession->sortBy;
		}
		if($sortType != '') {
			if($accidentSession->sortType == $sortType && $columnFlag == 1)
				$accidentSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$accidentSession->sortType	= $sortType;
		} else if($accidentSession->offsetExists('sortType')) {
			$sortType	= $accidentSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$accidentSession->perPage	= $perPage;
		} else if($accidentSession->offsetExists('perPage')) {
			$perPage		= $accidentSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$settled_status		= (isset($settled) && $settled == 1) ? $settled : 2;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('accidentTable')->getAccidentList($settled_status));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		if(isset($settled) && $settled == 2) {
			$paginator_settled		= '';
			$paginator_unsettled	= $paginator;
		} else {
			$paginator_settled		= $paginator;
			$paginator_unsettled	= '';
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_unsettled'	=> $paginator_unsettled,
			'paginator_settled'		=> $paginator_settled,
			'perPage'				=> $perPage,
			'settled'				=> $settled,
			'recommendationArrray'	=> $this->recommendationArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Accident
	*	Detail	:	To View the Accident details
	*/
	public function viewAccidentAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 				=  $this->getRequest();
			$message				=  '';
			$accidentId 			= (int) $this->params()->fromRoute('id', 0);
			$acccidentDetails		= '';
			
			if ($accidentId) {
				$results			  =  $this->getTable("accidentTable")->getAccidentDetails($accidentId);
				if($results) {
					$toArray		  =  $results->toArray();
					$acccidentDetails =  (isset($toArray[0]) && count($toArray[0])) ? $toArray[0] : '';
					
					// Date
					$datetime		  =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($acccidentDetails['accident_date']) && $acccidentDetails['accident_date'] != "0000-00-00 00:00:00") {
						$acccidentDetails['accident_date']			  =  $datetime->getDates(strtotime($acccidentDetails['accident_date']), 0, 'n-j-Y');
					} else {
						$acccidentDetails['accident_date']			  =  '';
					}
					
					if(isset($acccidentDetails['mechanic_inspection_date']) && $acccidentDetails['mechanic_inspection_date'] != "0000-00-00 00:00:00") {
						$acccidentDetails['mechanic_inspection_date'] =  $datetime->getDates(strtotime($acccidentDetails['mechanic_inspection_date']), 0, 'n-j-Y');
					} else {
						$acccidentDetails['mechanic_inspection_date'] =  '';
					}
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'recommendationArrray'	 => $this->recommendationArrray,
					'settlementStatusArrray' => $this->settlementStatusArrray,
					'acccidentDetails'	 	 => $acccidentDetails,
					'pc_users'			 	 => $this->pcUser,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Accident details, Ajax action
	*	Detail	:	Used to Delete the Users details
	*/
	public function deleteAccidentAction()
    {
		$accident_id = (int) $this->params()->fromRoute('id', 0);
        if ($accident_id) {
			$this->getTable("accidentTable")->deleteAccident($accident_id);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Drivers Accident Repost listing
	*	Detail	:	Used to List the Drivers Accident reports listing
	*/
	public function driversAccidentListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default
		$message				= '';
		$matches				= $this->getEvent()->getRouteMatch();
		// ajax
		$page		= $matches->getParam('id', '');
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$settled	= $matches->getParam('settled', '');
		
		// Create Filter form
		$accidentFilterForm 	   = new AccidentFilterForm();
		$request 				   = $this->getRequest();
		
		//	Destroy listing Session Vars
		$status	 			   	  = $this->getCommonDataObj()->destroySessionVariables(array('driverAccidentListing'));
		$driverAccidentSession    = new Container('driverAccidentListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$accidentFilterForm->setData($request->getPost());
			// Accident date
			if(isset($formData['accident_date']) && !empty($formData['accident_date']))
				$driverAccidentSession->accident_date = $formData['accident_date'];
			else
				$driverAccidentSession->accident_date = '';
			
			if(isset($formData['damage_cost']) && !empty($formData['damage_cost']))
				$driverAccidentSession->damage_cost	  = $formData['damage_cost'];
			else
				$driverAccidentSession->damage_cost	  = '';
		}
		
		if($driverAccidentSession->offsetExists('accident_date') && $driverAccidentSession->accident_date != '' ) {
			$accidentFilterForm->get('accident_date')->setValue($driverAccidentSession->accident_date);
		}
		if($driverAccidentSession->offsetExists('damage_cost') && $driverAccidentSession->damage_cost != '' ) {
			$accidentFilterForm->get('damage_cost')->setValue($driverAccidentSession->damage_cost);
		}
		
		// unsettled Accident Listing
		$perPage			= $this->defaultPerPage;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('accidentTable')->getDriversAccidentList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'accidentFilterForm'	=> $accidentFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'recommendationArrray'	=> $this->recommendationArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		
    }
	
	/*	Action	: 	Ajax Drivers Accident list, Ajax action
	*	Detail	:	Used to list the Drivers Accident listing
	*/
	public function driversAccidentListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$accidentSession 	= new Container('driverAccidentListing');
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($accidentSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$accidentSession->sortBy	= $sortBy;
		} else if($accidentSession->offsetExists('sortBy')) {
			$sortBy	= $accidentSession->sortBy;
		}
		if($sortType != '') {
			if($accidentSession->sortType == $sortType && $columnFlag == 1)
				$accidentSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$accidentSession->sortType	= $sortType;
		} else if($accidentSession->offsetExists('sortType')) {
			$sortType	= $accidentSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$accidentSession->perPage	= $perPage;
		} else if($accidentSession->offsetExists('perPage')) {
			$perPage		= $accidentSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('accidentTable')->getDriversAccidentList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'recommendationArrray'	=> $this->recommendationArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	private function sendAccidentNotification($sendType = 1, $identity, $notifications)
    {
		if(isset($sendType) && $sendType == 1) {
			// Get All Location managers on particular locations
			$allLocationManagersSession = new Container('allLocationManagers');
			$allLocationManagers		= array();
			if($allLocationManagersSession->offsetExists('allLocationManager') && $allLocationManagersSession->allLocationManager != '' ) {
				$allLocationManagers	= $allLocationManagersSession->allLocationManager;
			} else {
				$users					= $this->getTable("UsersTable")->getAllUsersDetail(3);
				if($users) {
					foreach($users as $user) {
						$allLocationManagers[$user['user_id']]   =  (array)$user;
					}
				}
				$allLocationManagersSession->allLocationManager  =  $allLocationManagers;
			}
			$sendArray		= array_keys($allLocationManagers);
		}
		
        if(isset($sendArray) && is_array($sendArray) && count($sendArray)) {
			foreach($sendArray as $key => $value) {
				$insert_array[]		 = "'".$notifications['accident_id']."','".$identity->user_id."','".$value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifications['subject'])."','".addslashes($notifications['notify_date'])."','".addslashes($notifications['notify_type'])."'";
			}
			if(is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable('ShiftTable')->insertAccidentNotification($insert_multi_string);
			}
		}
    }
	
}
