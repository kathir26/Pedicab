<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddGoalsForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_goals_form');
		$this->setAttribute('id', 'pc_add_goals_form');
		
		$this->add(array(
            'name' => 'manager_goals_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'manager_goals_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_location_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_location_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'manager_goals_date_hidden',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'manager_goals_date_hidden'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'manager_goals_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'manager_goals_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '',
				'data-validation-engine' 			=> 'validate[required,custom[dateNew]]',
				'data-errormessage-value-missing' 	=> 'Goals Month is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-YYYY format',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'manager_goals_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'manager_goals_amount',
				'class'								=> 'amt-txbox dollar-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Goal for the month is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'manager_goals_target_drivers',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'manager_goals_target_drivers',
				'class'								=> 'amt-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Target No.of Driver is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'goals_save',
            'attributes'=> array(
				'id'	=> 'goals_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'goals_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'goals_reset',
            ),
        ));
    }
}
?>