<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class ExpenseFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('Financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'pc_expense_filter_form');
		$this->setAttribute('name', 'pc_expense_filter_form');
		
		$this->add(array(
            'name' => 'expense_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'expense_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'expense_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'expense_title',
				'autofocus'							=> '',
				'class'								=> 'tabindex wid240',
				'PlaceHolder' 						=> 'Title',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' 		 => 'expense_filter_save',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'expense_filter_save',
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'expense_filter_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'expense_filter_reset',
            ),
        ));
    }
}
?>