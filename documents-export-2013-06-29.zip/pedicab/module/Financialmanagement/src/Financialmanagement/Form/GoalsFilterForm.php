<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class GoalsFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('Financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'goals_filter_form');
		$this->setAttribute('name', 'goals_filter_form');
		
		$this->add(array(
            'name' => 'goals_from_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'goals_from_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'From Date',
				'data-validation-engine' 			=> 'validate[optional,custom[dateNew]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'goals_to_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'goals_to_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'To Date',
				'data-validation-engine' 			=> 'validate[optional,custom[dateNew]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'goals_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'goals_amount',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Goals for month',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Goals amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'goals_target_drivers',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'goals_target_drivers',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Target No.of Drivers',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Target No.of Drivers is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Number',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		 => 'goals_search_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'goals_search_submit',
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'goals_search_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'goals_search_reset',
            ),
        ));
    }
}
?>