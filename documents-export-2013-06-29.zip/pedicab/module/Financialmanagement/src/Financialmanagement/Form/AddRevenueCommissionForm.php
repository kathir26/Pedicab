<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddRevenueCommissionForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_revenue_commission_form');
		$this->setAttribute('id', 'pc_add_revenue_commission_form');
		
		$this->add(array(
            'name' => 'mrc_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'mrc_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'mrc_percentage',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'mrc_percentage',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Revenue Commission Percentage is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Percentage',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'mrc_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'mrc_amount',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'readonly'							=> 'readonly',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Revenue Commission Amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'revenue_commission_save',
            'attributes'=> array(
				'id'	=> 'revenue_commission_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'revenue_commission_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'revenue_commission_reset',
            ),
        ));
    }
}
?>