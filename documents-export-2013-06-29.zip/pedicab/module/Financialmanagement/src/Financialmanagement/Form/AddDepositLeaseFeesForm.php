<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddDepositLeaseFeesForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_drivers_leasefees_form');
		$this->setAttribute('id', 'pc_add_drivers_leasefees_form');
		
		$this->add(array(
            'name' => 'lease_id[]',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => ''
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'user_id[]',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => ''
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_date[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> '',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '',
				'readonly'							=> 'readonly',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift Date is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'lease_pay_amount[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> '',
				'class'								=> 'wid90 dollar-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Amount the Driver is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' => 'payment_amount[]',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => ''
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'lease_payment_amount[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> '',
				'class'								=> 'wid90 dollar-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Payment Amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Payment Amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'discount_mechanical_issue[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> '',
				'class'								=> 'wid248',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Mechanical issue discount is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'discount_bad_weather[]',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> '',
				'class'								=> 'wid191',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Bad Weather discount is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name'		 => 'discount_other_reason[]',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> '',
				'class'								=> '',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Other Discount reason is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'pay_amount_type[]',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'Payment-Type',
				'id'   								=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Payment type is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'drivers_leasefees_save',
            'attributes'=> array(
				'id'	=> 'drivers_leasefees_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> 'fnone',
            ),
        ));
		
		$this->add(array(
			'name'		=> 'drivers_leasefees_reset',
            'attributes'=> array(
				'id'	=> 'drivers_leasefees_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'fnone',
            ),
        ));
    }
}
?>