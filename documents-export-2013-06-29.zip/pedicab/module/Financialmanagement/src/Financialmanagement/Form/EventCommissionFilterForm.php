<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class EventCommissionFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('Financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'event_commission_filter_form');
		$this->setAttribute('name', 'event_commission_filter_form');
		
		$this->add(array(
            'name' 		 => 'event_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_from_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_from_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'From Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Event From date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_to_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_to_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'To Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Event To date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_title',
				'class'								=> 'wid240',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Event Title',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Event Title is required!',
				'data-errormessage' 			 	=> 'Event Title is invalid!',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_event_commission_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_event_commission_submit',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_event_commission_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_event_commission_reset',
            ),
        ));
    }
}
?>