<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddStipendForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_stipend_form');
		$this->setAttribute('id', 'pc_add_stipend_form');
		
		$this->add(array(
            'name' => 'stipend_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'stipend_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_location_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_location_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'stipend_date_hidden',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'stipend_date_hidden'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'stipend_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'stipend_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '2',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Stipend Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'stipend_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'stipend_amount',
				'class'								=> 'amt-txbox',
				'tabindex'							=> '3',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Stipend amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'stipend_save',
            'attributes'=> array(
				'id'	=> 'stipend_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'stipend_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'stipend_reset',
            ),
        ));
    }
}
?>