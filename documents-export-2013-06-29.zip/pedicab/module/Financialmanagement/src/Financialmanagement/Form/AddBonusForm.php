<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddBonusForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_bonus_form');
		$this->setAttribute('id', 'pc_add_bonus_form');
		
		$this->add(array(
            'name' => 'manager_bonus_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'manager_bonus_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_location_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_location_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'bonus_type',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'bonus_type'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'manager_bonus_date_hidden',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'manager_bonus_date_hidden'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'manager_bonus_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'manager_bonus_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '2',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Bonus Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'manager_bonus_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'manager_bonus_amount',
				'class'								=> 'amt-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Bonus amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'install_bonus_location_manager',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'install_bonus_location_manager',
				'class'								=> 'amt-txbox',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Install Bonus amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
		
		$this->add(array(
            'name'		 => 'manager_bonus_description',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'manager_bonus_description',
				'class'								=> '',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Bonus description is required!',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'bonus_save',
            'attributes'=> array(
				'id'	=> 'bonus_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'bonus_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'bonus_reset',
            ),
        ));
    }
}
?>