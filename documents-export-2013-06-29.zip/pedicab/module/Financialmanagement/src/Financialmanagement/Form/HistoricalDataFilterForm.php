<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class HistoricalDataFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('Financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'historical_data_filter_form');
		$this->setAttribute('name', 'historical_data_filter_form');
		
		$this->add(array(
            'name' => 'historical_data_from_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'historical_data_from_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'From Month',
				'data-validation-engine' 			=> 'validate[optional,custom[dateNew]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'historical_data_to_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'historical_data_to_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'To Month',
				'data-validation-engine' 			=> 'validate[optional,custom[dateNew]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-YYYY format',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' 		 => 'historical_data_search_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'historical_data_search_submit',
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'historical_data_search_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'historical_data_search_reset',
            ),
        ));
    }
}
?>