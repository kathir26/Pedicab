<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class BonusFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('Financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'bonus_filter_form');
		$this->setAttribute('name', 'bonus_filter_form');
		
		$this->add(array(
            'name' => 'bonus_from_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bonus_from_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'From Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'bonus_to_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bonus_to_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'To Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'bonus_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'bonus_amount',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Bonus Amount',
				'data-validation-engine' 			=> 'validate[optional,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Bonus amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Amount',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		 => 'bonus_search_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'bonus_search_submit',
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'bonus_search_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'bonus_search_reset',
            ),
        ));
    }
}
?>