<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class AddEventCommissionForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_event_commission_form');
		$this->setAttribute('id', 'pc_add_event_commission_form');
		
		$this->add(array(
            'name' => 'event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' 		 => 'event_commission_percentage',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_commission_percentage',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Event Commission Percentage is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Percentage',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'event_commission_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_commission_amount',
				'class'								=> 'wid141',
				'tabindex'							=> '',
				'readonly'							=> 'readonly',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Event Commission Amount is required!',
				'data-errormessage' 			 	=> 'Please enter a valid amount',
            ),
            'options' => array(
            ),
        ));
		
        $this->add(array(
            'name' 		=> 'event_commission_save',
            'attributes'=> array(
				'id'	=> 'event_commission_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'event_commission_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'event_commission_reset',
            ),
        ));
    }
}
?>