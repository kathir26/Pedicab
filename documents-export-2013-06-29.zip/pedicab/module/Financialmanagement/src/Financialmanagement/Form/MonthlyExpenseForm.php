<?php
namespace Financialmanagement\Form;

use Zend\Form\Form;

class MonthlyExpenseForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('financialmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_monthly_expense_form');
		$this->setAttribute('id', 'pc_monthly_expense_form');
		
		$this->add(array(
            'name' => 'user_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'user_id'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'expense_reimber_hid',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'expense_reimber_hid'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'expense_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'expense_id'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' 		 => 'expense_report',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'expense_report',
				'class'								=> 'tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Purpose is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'reinbursement_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'reinbursement_date',
				'class'								=> 'calc-txbox datepicker',
				'tabindex'							=> '3',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Checkbox',
            'name' => 'generate_report',
            'options' => array(
                'value_options' => array(
                   
                ),
            ),
            'attributes' => array(
				'id'   								=> 'generate_report',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'expense_save',
            'attributes'=> array(
				'id'	=> 'expense_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'expense_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'expense_reset',
            ),
        ));
    }
}
?>