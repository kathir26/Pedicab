<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Financialmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Financialmanagement\Form\StipendFilterForm,
	Financialmanagement\Form\AddStipendForm,
	Financialmanagement\Form\EventCommissionFilterForm;

//	Models
use Schedulemanagement\Model\Shift;

use Usermanagement\Model\MyAuthenticationAdapter;

class CompensationController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "EventTable" => "Event-Table", "LeasePaymentsTable" => "Lease-Payments-Table",  "UsersTable" => "Users-Table", "ShiftRequestTable" => "Shift-Request-Table", "StipendManagerTable" => "Stipend-Manager-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Manager Stipend listing
	*	Detail	:	Used to List the Manager Copensation details
	*/
	public function managerStipendListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Create Add Stipend from
		$addStipendForm 		= new AddStipendForm();
		
		// Create Filter form
		$stipendFilterForm 			 =  new StipendFilterForm();					//	Stipend Filter form
		$eventCommissionFilterForm 	 =  new EventCommissionFilterForm();			//	Event Commission Filter form
		$revenueCommissionFilterForm =  new RevenueCommissionFilterForm();			//	Revenue Commission Filter form
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('stipendListing'));
		}
		
		$listingSession 	  	= new Container('stipendListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$stipendFilterForm->setData($request->getPost());
			if(isset($formData['stipend_from_date']) && !empty($formData['stipend_from_date']))
				$listingSession->stipend_from_date = $formData['stipend_from_date'];
			else
				$listingSession->stipend_from_date = '';
			
			if(isset($formData['stipend_to_date']) && !empty($formData['stipend_to_date']))
				$listingSession->stipend_to_date   = $formData['stipend_to_date'];
			else
				$listingSession->stipend_to_date   = '';
			
			if(isset($formData['stipend_amount']) && !empty($formData['stipend_amount']))
				$listingSession->stipend_amount    = $formData['stipend_amount'];
			else
				$listingSession->stipend_amount    = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Set Default values For Add Stipend Forms
		// Date
		$datetime		  	= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$stipendDate		= $datetime->getDates(time(), 0, 'n-j-Y');
		$addStipendForm->get('stipend_date')->setValue($stipendDate);
		$location_id		= $this->pcUser->location_id;
		$addStipendForm->get('fk_location_id')->setValue($location_id);
		
		
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('StipendManagerTable')->getStipendList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'addStipendForm'			=> $addStipendForm,
			'stipendFilterForm'			=> $stipendFilterForm,
			'eventCommissionFilterForm'		=> $eventCommissionFilterForm,
			'revenueCommissionFilterForm'	=> $revenueCommissionFilterForm,
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		
    }
	
	/*	Action	: 	Ajax Manager Stipend List, Ajax action
	*	Detail	:	Used to list the Manager Stipend details via Ajax
	*/
	public function managerStipendListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('stipendListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('StipendManagerTable')->getStipendList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Stipend Manager
	*	Detail	:	Add the Stipend Manager
	*/
	public function ajaxStipendManagerAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray		=  array();
		$addStipendForm	=  new AddStipendForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				if(strpos($formData['stipend_date'], '-') !== false ) {
				  $formData['stipend_date']	=  str_replace('-', '/', $formData['stipend_date']);
				  $stipend_date =  $datetime->getDates(strtotime($formData['stipend_date']), 0, 'Y-m-d H:i:s');
				} else {
				  $stipend_date =  '0000-00-00 00:00:00';
				}
				
				$stipend_id		= (isset($formData["stipend_id"])) ? $formData["stipend_id"] : 0;
				$stipendDetails = array(
					'stipend_id'			=> $stipend_id,
					'stipend_date'		  	=> $stipend_date,
					'stipend_amount'	  	=> $formData["stipend_amount"],
					'stipend_created_date'	=> $createdDate,
					'stipend_updated_date'	=> $createdDate,
					'fk_location_id'	  	=> $formData['fk_location_id'],
					'stipend_isdelete'		=> 0
				);
				$stipendId  =  $this->getTable("StipendManagerTable")->saveStipend($stipendDetails);		//	Save Stipend Details
				
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Stipend amount, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Stipend amount, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	View Stipend Manager
	*	Detail	:	To View the StipendManager details
	*/
	public function viewStipendManagerAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$auth   = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 		=  $this->getRequest();
			$message		=  '';
			$stipendId 		= (int) $this->params()->fromRoute('id', 0);
			$stipendDetail	= '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
			if ($stipendId) {
				$results	= $this->getTable("StipendManagerTable")->getStipendDetail($stipendId);
				if($results) {
					foreach($results as $stipend) {
						$stipendDetail = $stipend;
					}
					$stipendDate	  				= $datetime->getDates(strtotime($stipendDetail['stipend_date']), 0, 'n-j-Y');
					$stipendDetail['stipend_date']	= $stipendDate;
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'stipendDetail'	 	 	 => $stipendDetail,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Stipend Manager details, Ajax action
	*	Detail	:	Used to Delete the Stipend Manager details
	*/
	public function deleteStipendManagerAction()
    {
		$stipendId = (int) $this->params()->fromRoute('id', 0);
        if ($stipendId) {
			$this->getTable("StipendManagerTable")->deleteStipend($stipendId);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Financial Event listing
	*	Detail	:	Used to List the Events details
	*/
	public function financialEventListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$eventFilterForm 	  	= new EventFilterForm();
		$request 				= $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('openEventListing', 'closedEventListing'));
		}
		$openEventSession  	  	= new Container('openEventListing');
		$closedEventSession     = new Container('closedEventListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$eventFilterForm->setData($request->getPost());
			if(isset($formData['event_pay_status']) && $formData['event_pay_status'] == 1) {							// Open Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$openEventSession->event_date	 	 = $formData['event_date'];
				else
					$openEventSession->event_date	 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$openEventSession->event_title	 = $formData['event_title'];
				else
					$openEventSession->event_title	 = '';
			} else if(isset($formData['event_pay_status']) && $formData['event_pay_status'] == 2) {						// Closed Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$closedEventSession->event_date   = $formData['event_date'];
				else
					$closedEventSession->event_date 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$closedEventSession->event_title	 = $formData['event_title'];
				else
					$closedEventSession->event_title	 = '';
			}
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Confirmed Events Listing
		$perPage					= $this->defaultPerPage;
		$payStatus					= 1;		//		1 = Open; 2 = Closed
		$iteratorAdapter_confirmed	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getPaymentEventList($payStatus));
		$paginator_open				= new \Zend\Paginator\Paginator($iteratorAdapter_confirmed);
		$paginator_open->setCurrentPageNumber($page);
		$paginator_open->setItemCountPerPage($perPage);
		
		$paginator_closed			= '';
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'eventFilterForm'		=> $eventFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_open'		=> $paginator_open,
			'paginator_closed'		=> $paginator_closed,
			'perPage'				=> $perPage,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Financial Event list, Ajax action
	*	Detail	:	Used to list the Events details via Ajax
	*/
	public function financialEventListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$payStatus	= $matches->getParam('payStatus', '');
		
		//	Session for Role listing
		$sessionsContainer	= (isset($payStatus) && $payStatus == 1) ? 'openEventListing' : 'closedEventListing';
		$eventsSession 		= new Container($sessionsContainer);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($eventsSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$eventsSession->sortBy	= $sortBy;
		} else if($eventsSession->offsetExists('sortBy')) {
			$sortBy	= $eventsSession->sortBy;
		}
		if($sortType != '') {
			if($eventsSession->sortType == $sortType && $columnFlag == 1)
				$eventsSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$eventsSession->sortType	= $sortType;
		} else if($eventsSession->offsetExists('sortType')) {
			$sortType	= $eventsSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$eventsSession->perPage	= $perPage;
		} else if($eventsSession->offsetExists('perPage')) {
			$perPage		= $eventsSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$payStatus			= (isset($payStatus) && !empty($payStatus)) ? $payStatus : 1;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getPaymentEventList($payStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		if(isset($payStatus) && $payStatus == 1) {
			$paginator_closed	= '';
			$paginator_open		= $paginator;
		} else {
			$paginator_closed	= $paginator;
			$paginator_open		= '';
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_closed'		=> $paginator_closed,
			'paginator_open'		=> $paginator_open,
			'perPage'				=> $perPage,
			'payStatus'				=> $payStatus,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Event
	*	Detail	:	To View the Accident details
	*/
	public function viewEventAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			=  $this->getRequest();
			$message			=  '';
			$eventId 			= (int) $this->params()->fromRoute('id', 0);
			$eventDetails		= '';
			
			if ($eventId) {
				$results		= $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails = $event;
					}
					
					// Date
					$datetime	=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
						$eventDetails['event_date']	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
					} else {
						$eventDetails['event_date']	= '-';
					}
					
					// Start : Drivers assignment process
					$requestedDrivers		=  $allocatedDrivers =  array();
					$shiftManagers			=  array();
					
					// Get Requested Drivers for the shift
					$shiftId 				=  $eventDetails['shift_id'];
					$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
					if($requestResults) {
						$requestedToArray	=  $requestResults->toArray();
						if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
							foreach($requestedToArray as $keys => $values) {
								$requestedDrivers[$values['fk_user_id']]		=  $values;
								if($values['shift_request_status'] == 2) {
									$allocatedDrivers[$values['fk_user_id']]	=  $values;
									if($eventDetails['shift_manager_id'] == $values['fk_user_id']) {
										$shiftManagers[$values['fk_user_id']]	=  $values['user_firstname'].' '.$values['user_lastname'];
									}
								}
							}
						}
					}
					
					// Get All Bikes for the particulat locations
					$allocatedBikes  	= array();
					if (isset($eventDetails['bike_reserved_type']) && !empty($eventDetails['bike_reserved_type']) && $eventDetails['bike_reserved_type'] == 2) {
						$bikesIds			= $eventDetails['bike_reserved_ids'];
						$allBikesResults	= $this->getTable("BikeTable")->GetSelectedBikes($bikesIds);
						if($allBikesResults) {
							foreach($allBikesResults as $key => $value) {
								$bikeId					 = $value['bike_id'];
								$allocatedBikes[$bikeId] = $value;
							}
						}
					}
					
					// Other Costa label
					$other_costs_labels	 	 =  $other_costs_values	 =  array();
					if(isset($eventDetails['other_costs_labels']) && !empty($eventDetails['other_costs_labels'])) {
						$other_costs_labels	 =  explode(',', $eventDetails['other_costs_labels']);
					}
					
					// Other Costa value
					if(isset($eventDetails['other_costs_values']) && !empty($eventDetails['other_costs_values'])) {
						$other_costs_values	 =  explode(',', $eventDetails['other_costs_values']);
					}
					
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'balanceDueArrray'	 	 => $this->balanceDueArrray,
					'quotedStatusArrray' 	 => $this->quotedStatusArrray,
					'eventDetails'	 	 	 => $eventDetails,
					'allocatedDrivers'		 => $allocatedDrivers,
					'allocatedBikes'		 => $allocatedBikes,
					'other_costs_labels'	 => $other_costs_labels,
					'other_costs_values'	 => $other_costs_values,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'eventCategoryArray'	 => $this->eventCategoryArray,
					'quotedStatusArrray'	 => $this->quotedStatusArrray,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Financial Event Payments
	*	Detail	:	Used to add the event payment historys
	*/
	public function financialEventPaymentsAction()
    {
		$result 				 =  new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  			 =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity 			 =  $auth->getIdentity();
			$request 			 =  $this->getRequest();
			$message			 =  '';
			$errorFlag			 =	true;
			$eventId 			 =  (int) $this->params()->fromRoute('id', 0);
			$datetime 		     =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$addEventPaymentForm =  new AddEventPaymentForm();
			$eventDetails		 =  '';
			if ($eventId) {
				$results		 =  $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails   = $event;
					}
					
					$addEventPaymentForm->get('fk_event_id')->setValue($eventDetails['event_id']);
					$addEventPaymentForm->get('event_title')->setValue($eventDetails['event_title']);
					$addEventPaymentForm->get('payment_method')->setValueOptions($this->paymentMethodArray);
					$addEventPaymentForm->get('balance_owed')->setValue($eventDetails['balance_owed']);
					
					$result->setVariables(array(
						'userObject'			=> $identity,
						'addEventPaymentForm'	=> $addEventPaymentForm,
						'pc_users'				=> $this->pcUser,
						'message'				=> $message,
						'datetime'				=> $datetime,
						'errorFlag'				=> false,
						'paymentMethodArray'	=> $this->paymentMethodArray,
						'perPageArray'			=> $this->perPageArray,
						'controller'			=> $this->params('controller'),
						'commonData'			=> $this->getCommonDataObj()
					));
				}
			}
		}
		return $result;
    }
	
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	private function sendShiftAllocationNote($driversArray = false, $identity, $notifications)
    {
        if($driversArray && is_array($driversArray) && count($driversArray)) {
			foreach($driversArray as $driver_key => $driver_value) {
				$insert_array[]		 = "'".$notifications['shift_id']."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifications['subject'])."','".addslashes($notifications['notify_date'])."','".addslashes($notifications['notify_type'])."'";
			}
			if(is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
			}
		}
    }
	
	public function testAction()
	{
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==get_magic_quotes_gpc==>".get_magic_quotes_gpc()."<==";
		
		$inputArray		= array("test's array 1", "test's array 2", "test's array 3", "test's array 4");
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==inputArray==><pre>"; print_r($inputArray); echo "</pre><==";
		
		$addSlashes		= $this->getCommonDataObj()->customizedAddSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==addSlashes==><pre>"; print_r($addSlashes); echo "</pre><==";
		
		$stripSlashes	= $this->getCommonDataObj()->customizedStripSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==stripSlashes==><pre>"; print_r($stripSlashes); echo "</pre><==";
		
//		phpinfo();
		
		return $this->getResponse();
		
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
