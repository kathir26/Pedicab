<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Financialmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Financialmanagement\Form\StipendFilterForm,
	Financialmanagement\Form\AddStipendForm,
	Financialmanagement\Form\AddEventCommissionForm,
	Financialmanagement\Form\EventCommissionFilterForm,
	Financialmanagement\Form\AddRevenueCommissionForm,
	Financialmanagement\Form\RevenueCommissionFilterForm,
	Financialmanagement\Form\AddBonusForm,
	Financialmanagement\Form\BonusFilterForm;

//	Models
use Schedulemanagement\Model\Shift;

use Usermanagement\Model\MyAuthenticationAdapter;

class CompensationController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $bonusTypeArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->bonusTypeArray		=  array(1 => 'Bonus added by Owner', 2 => 'Install Bonuses on Event');
		
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "EventTable" => "Event-Table", "LeasePaymentsTable" => "Lease-Payments-Table",  "UsersTable" => "Users-Table", "ShiftRequestTable" => "Shift-Request-Table", "StipendManagerTable" => "Stipend-Manager-Table", "ManagerBonusTable" => "Manager-Bonus-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Manager Stipend listing
	*	Detail	:	Used to List the Manager Copensation details
	*/
	public function managerStipendListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Create Add Stipend from
		$addStipendForm 			 =  new AddStipendForm();						//	Stipend Add form
		$addBonusForm 			 	 =  new AddBonusForm();							//	Bonus Add form
		$addEventCommissionForm 	 =  new AddEventCommissionForm();				//	Event Commission Add form
		$addRevenueCommissionForm 	 =  new AddRevenueCommissionForm();				//	RevenueC ommission Add form
		
		// Create Filter form
		$stipendFilterForm 			 =  new StipendFilterForm();					//	Stipend Filter form
		$eventCommissionFilterForm 	 =  new EventCommissionFilterForm();			//	Event Commission Filter form
		$revenueCommissionFilterForm =  new RevenueCommissionFilterForm();			//	Revenue Commission Filter form
		$bonusFilterForm 			 =  new BonusFilterForm();						//	Bonus Filter form
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates();
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			=  $this->getCommonDataObj()->destroySessionVariables(array('stipendListing', 'eventCommissionListing', 'revenueCommissionListing', 'bonusListing'));
		}
		
		$listingSession 	  	= new Container('stipendListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$stipendFilterForm->setData($request->getPost());
			if(isset($formData['stipend_from_date']) && !empty($formData['stipend_from_date']))
				$listingSession->stipend_from_date = $formData['stipend_from_date'];
			else
				$listingSession->stipend_from_date = '';
			
			if(isset($formData['stipend_to_date']) && !empty($formData['stipend_to_date']))
				$listingSession->stipend_to_date   = $formData['stipend_to_date'];
			else
				$listingSession->stipend_to_date   = '';
			
			if(isset($formData['stipend_amount']) && !empty($formData['stipend_amount']))
				$listingSession->stipend_amount    = $formData['stipend_amount'];
			else
				$listingSession->stipend_amount    = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->stipend_from_date = $currentMonthStartDate;
			$listingSession->stipend_to_date   = $currentMonthEntDate;
		}
		
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// Set Default values For Add Stipend Forms
		$stipendDate		= $datetime->getDates(time(), 0, 'n-j-Y');
		$addStipendForm->get('stipend_date')->setValue($stipendDate);
		$addStipendForm->get('stipend_date_hidden')->setValue($stipendDate);
		$location_id		= $this->pcUser->location_id;
		$addStipendForm->get('fk_location_id')->setValue($location_id);
		
		//	Stipend Filter Forms
		$stipendFilterForm->get('stipend_from_date')->setValue($currentMonthStartDate);
		$stipendFilterForm->get('stipend_to_date')->setValue($currentMonthEntDate);
		
		//	Events Commission Filter Forms and Session Values
		$eventCommissionFilterForm->get('event_from_date')->setValue($currentMonthStartDate);
		$eventCommissionFilterForm->get('event_to_date')->setValue($currentMonthEntDate);
		/*
		$eventCommissionListingSession 	 					= new Container('eventCommissionListing');
		$eventCommissionListingSession->event_from_date	 	= $currentMonthStartDate;
		$eventCommissionListingSession->event_to_date	 	= $currentMonthEntDate;
		*/
		
		//	Driver's Revenue Commission Filter Forms and Session Values
		$revenueCommissionFilterForm->get('search_revenue_from_date')->setValue($currentMonthStartDate);
		$revenueCommissionFilterForm->get('search_revenue_to_date')->setValue($currentMonthEntDate);
		/*
		$revenueCommissionListingSession 					= new Container('revenueCommissionListing');
		$revenueCommissionListingSession->revenue_from_date	= $currentMonthStartDate;
		$revenueCommissionListingSession->revenue_to_date	= $currentMonthEntDate;
		*/
		
		//	Manager's Bonus Filter Forms and Session Values
		$bonusFilterForm->get('bonus_from_date')->setValue($currentMonthStartDate);
		$bonusFilterForm->get('bonus_to_date')->setValue($currentMonthEntDate);
		
		// Set Default values For Add Bonus Forms
		$bonusDate			= $datetime->getDates(time(), 0, 'n-j-Y');
		$addBonusForm->get('manager_bonus_date')->setValue($bonusDate);
		$addBonusForm->get('manager_bonus_date_hidden')->setValue($bonusDate);
		$location_id		= $this->pcUser->location_id;
		$addBonusForm->get('fk_location_id')->setValue($location_id);
		$addBonusForm->get('bonus_type')->setValue(1);			//	1	-	 Owners add one,	2	-	Install bonuses via Event
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('StipendManagerTable')->getStipendList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		return new ViewModel(array(
			'userObject'					=> $identity,
			'addStipendForm'				=> $addStipendForm,
			'stipendFilterForm'				=> $stipendFilterForm,
			'eventCommissionFilterForm'		=> $eventCommissionFilterForm,
			'addEventCommissionForm'		=> $addEventCommissionForm,
			'revenueCommissionFilterForm'	=> $revenueCommissionFilterForm,
			'addRevenueCommissionForm'		=> $addRevenueCommissionForm,
			'addBonusForm'					=> $addBonusForm,
			'bonusFilterForm'				=> $bonusFilterForm,
			'pc_users'						=> $this->pcUser,
			'message'						=> $message,
			'page'							=> $page,
			'sortBy'						=> $sortBy,
			'paginator'						=> $paginator,
			'perPage'						=> $perPage,
			'datetime'						=> $datetime,
			'perPageArray'					=> $this->perPageArray,
			'controller'					=> $this->params('controller'),
			'commonData'					=> $this->getCommonDataObj()
		));
		
    }
	
	/*	Action	: 	Ajax Manager Stipend List, Ajax action
	*	Detail	:	Used to list the Manager Stipend details via Ajax
	*/
	public function managerStipendListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('stipendListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('StipendManagerTable')->getStipendList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Stipend Manager
	*	Detail	:	Add the Stipend Manager
	*/
	public function ajaxStipendManagerAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray		=  array();
		$addStipendForm	=  new AddStipendForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				if(strpos($formData['stipend_date'], '-') !== false ) {
				  $formData['stipend_date']	=  str_replace('-', '/', $formData['stipend_date']);
				  $stipend_date =  $datetime->getDates(strtotime($formData['stipend_date']), 0, 'Y-m-d H:i:s');
				} else {
				  $stipend_date =  '0000-00-00 00:00:00';
				}
				
				$stipend_id		= (isset($formData["stipend_id"])) ? $formData["stipend_id"] : 0;
				$stipendDetails = array(
					'stipend_id'			=> $stipend_id,
					'stipend_date'		  	=> $stipend_date,
					'stipend_amount'	  	=> $formData["stipend_amount"],
					'stipend_created_date'	=> $createdDate,
					'stipend_updated_date'	=> $createdDate,
					'fk_location_id'	  	=> $formData['fk_location_id'],
					'stipend_isdelete'		=> 0
				);
				$stipendId  =  $this->getTable("StipendManagerTable")->saveStipend($stipendDetails);		//	Save Stipend Details
				
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Stipend amount, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Stipend amount, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	View Stipend Manager
	*	Detail	:	To View the StipendManager details
	*/
	public function viewStipendManagerAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$auth   = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 		=  $this->getRequest();
			$message		=  '';
			$stipendId 		= (int) $this->params()->fromRoute('id', 0);
			$stipendDetail	= '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
			if ($stipendId) {
				$results	= $this->getTable("StipendManagerTable")->getStipendDetail($stipendId);
				if($results) {
					foreach($results as $stipend) {
						$stipendDetail = $stipend;
					}
					$stipendDate	  				= $datetime->getDates(strtotime($stipendDetail['stipend_date']), 0, 'n-j-Y');
					$stipendDetail['stipend_date']	= $stipendDate;
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'stipendDetail'	 	 	 => $stipendDetail,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Stipend Manager details, Ajax action
	*	Detail	:	Used to Delete the Stipend Manager details
	*/
	public function deleteStipendManagerAction()
    {
		$stipendId = (int) $this->params()->fromRoute('id', 0);
        if ($stipendId) {
			$this->getTable("StipendManagerTable")->deleteStipend($stipendId);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Event Commission listing
	*	Detail	:	Used to List the Manager Copensation details
	*/
	public function eventCommissionListingAction() {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates();
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		$listingSession 	  	= new Container('eventCommissionListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$stipendFilterForm->setData($request->getPost());
			if(isset($formData['event_from_date']) && !empty($formData['event_from_date']))
				$listingSession->event_from_date = $formData['event_from_date'];
			else
				$listingSession->event_from_date = '';
			
			if(isset($formData['event_to_date']) && !empty($formData['event_to_date']))
				$listingSession->event_to_date   = $formData['event_to_date'];
			else
				$listingSession->event_to_date   = '';
			
			if(isset($formData['event_title']) && !empty($formData['event_title']))
				$listingSession->event_title    = $formData['event_title'];
			else
				$listingSession->event_title    = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->event_from_date = $currentMonthStartDate;
			$listingSession->event_to_date   = $currentMonthEntDate;
		}
		
		if($ajax == '') {
			$listingSession->event_from_date = $currentMonthStartDate;
			$listingSession->event_to_date   = $currentMonthEntDate;
		}
		
		// Set Default values For Add Stipend Forms
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventCommissionList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$result->setVariables(array(
			'userObject'				=> '',
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Event Commission List, Ajax action
	*	Detail	:	Used to list the Event Commission details via Ajax
	*/
	public function eventCommissionListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('eventCommissionListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getEventCommissionList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Event Commission
	*	Detail	:	Save the Event Commission Persentage
	*/
	public function ajaxEventCommissionAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray				=  array();
		$addEventCommissionForm	=  new AddEventCommissionForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				
				$event_id		=  (isset($formData['event_id']) && !empty($formData['event_id'])) ? $formData['event_id'] : 0;
				if($event_id) {
					$eventArray 	=  array(
						'event_id'					  => $event_id,
						'event_commission_percentage' => $formData['event_commission_percentage']
			        );
					$eventId  		=  $this->getTable("EventTable")->saveEvent($eventArray);								//	Save Event Percentagedetails
				}
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Event Commission Percentage, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Event Commission Percentage, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	Revenue Commission listing
	*	Detail	:	Used to List the Revenue Commission details
	*/
	public function revenueCommissionListingAction() {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates();
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		$listingSession 	  	=  new Container('revenueCommissionListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
			if(isset($formData['search_revenue_from_date']) && !empty($formData['search_revenue_from_date']))
				$listingSession->revenue_from_date = $formData['search_revenue_from_date'];
			else
				$listingSession->revenue_from_date = '';
			
			if(isset($formData['search_revenue_to_date']) && !empty($formData['search_revenue_to_date']))
				$listingSession->revenue_to_date   = $formData['search_revenue_to_date'];
			else
				$listingSession->revenue_to_date   = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->revenue_from_date = $currentMonthStartDate;
			$listingSession->revenue_to_date   = $currentMonthEntDate;
		}
		
		if($ajax == '') {
			$listingSession->revenue_from_date = $currentMonthStartDate;
			$listingSession->revenue_to_date   = $currentMonthEntDate;
		}
		
		// Set Default values For Add Stipend Forms
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getRevenueCommissionList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$result->setVariables(array(
			'userObject'				=> '',
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Revenue Commission List, Ajax action
	*	Detail	:	Used to list the Revenue Commission details via Ajax
	*/
	public function revenueCommissionListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('revenueCommissionListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getRevenueCommissionList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Revenue Commission
	*	Detail	:	Save the Revenue Commission Persentage
	*/
	public function ajaxRevenueCommissionAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray				=  array();
		$addEventCommissionForm	=  new AddEventCommissionForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				
				$mrc_id		=  (isset($formData['mrc_id']) && !empty($formData['mrc_id'])) ? $formData['mrc_id'] : 0;
				if($mrc_id) {
					$mrcArray 	=  array(
						'mrc_id'		   => $mrc_id,
						'mrc_percentage'   => $formData['mrc_percentage'],
						'mrc_updated_date' => $createdDate
			        );
					$mrcIdId  	=  $this->getTable("LeasePaymentsTable")->saveManagerRevenueCommissions($mrcArray);								//	Save Manager Revenue Commissions
				}
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Event Commission Percentage, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Event Commission Percentage, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	Manager Bonus listing
	*	Detail	:	Used to List the Manager Bonus details
	*/
	public function managerBonusListingAction() {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates();
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		$listingSession 	  	= new Container('bonusListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
			if(isset($formData['bonus_from_date']) && !empty($formData['bonus_from_date']))
				$listingSession->bonus_from_date = $formData['bonus_from_date'];
			else
				$listingSession->bonus_from_date = '';
			
			if(isset($formData['bonus_to_date']) && !empty($formData['bonus_to_date']))
				$listingSession->bonus_to_date   = $formData['bonus_to_date'];
			else
				$listingSession->bonus_to_date   = '';
			
			if(isset($formData['bonus_amount']) && !empty($formData['bonus_amount']))
				$listingSession->bonus_amount    = $formData['bonus_amount'];
			else
				$listingSession->bonus_amount    = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->bonus_from_date = $currentMonthStartDate;
			$listingSession->bonus_to_date   = $currentMonthEntDate;
		}
		
		if($ajax == '') {
			$listingSession->bonus_from_date = $currentMonthStartDate;
			$listingSession->bonus_to_date   = $currentMonthEntDate;
		}
		
		// Set Default values For Add Stipend Forms
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerBonusTable')->getManagerBonusList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$result->setVariables(array(
			'userObject'				=> '',
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'perPageArray'				=> $this->perPageArray,
			'bonusTypeArray'			=> $this->bonusTypeArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Manager Bonus List, Ajax action
	*	Detail	:	Used to list the Manager Bonus details via Ajax
	*/
	public function managerBonusListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('bonusListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerBonusTable')->getManagerBonusList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'bonusTypeArray'		=> $this->bonusTypeArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Bonus Manager
	*	Detail	:	Add the Bonus Manager
	*/
	public function ajaxBonusManagerAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray		=  array();
		$addBonusForm	=  new AddBonusForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	= $datetime(time(), 0, 'Y-m-d H:i:s');
				$bonusType		=  $formData["bonus_type"];
				if($bonusType == 2) {
					$fk_event_id	  = (isset($formData["fk_event_id"])) ? $formData["fk_event_id"] : 0;
					$eventDetails  	  = array(
						'event_id'						=> $fk_event_id,
						'install_bonus_location_manager'=> $formData["install_bonus_location_manager"],
						'event_updated_date'			=> $createdDate
					);
					$eventId   = $this->getTable("EventTable")->saveEvent($eventDetails);		//	Save Install Bonus Details in Events
					
				} else {
					
					if(strpos($formData['manager_bonus_date'], '-') !== false ) {
					  $formData['manager_bonus_date']	=  str_replace('-', '/', $formData['manager_bonus_date']);
					  $managerBonusDate   = $datetime->getDates(strtotime($formData['manager_bonus_date']), 0, 'Y-m-d');
					} else {
					  $managerBonusDate   = '0000-00-00';
					}
					
					$manager_bonus_id	  = (isset($formData["manager_bonus_id"])) ? $formData["manager_bonus_id"] : 0;
					$managerBonusDetails  = array(
						'manager_bonus_id'				=> $manager_bonus_id,
						'manager_bonus_date'			=> $managerBonusDate,
						'manager_bonus_amount'			=> $formData["manager_bonus_amount"],
						'manager_bonus_description'		=> $formData["manager_bonus_description"],
						'manager_bonus_created_date'	=> $createdDate,
						'manager_bonus_updated_date'	=> $createdDate,
						'fk_location_id'	  			=> $formData['fk_location_id'],
						'manager_bonus_isdelete'		=> 0
					);
					$managerBonusId   = $this->getTable("ManagerBonusTable")->saveManagerBonus($managerBonusDetails);		//	Save Bonus Details
					
				}
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Bonus amount, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Bonus amount, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	Delete Manager Bonus, Ajax action
	*	Detail	:	Used to Delete the Manager Bonus details
	*/
	public function deleteManagerBonusAction()
    {
		$bonusId = (int) $this->params()->fromRoute('id', 0);
        if ($bonusId) {
			$this->getTable("ManagerBonusTable")->deleteManagerBonus($bonusId);
		}
        return $this->getResponse();
    }
	
	public function testAction()
	{
		/*
		//	n-j-Y
		$date1		=  date("n-t-Y", strtotime("now"));
		$date2		=  date("n-1-Y", strtotime("now"));
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date1==>".$date1."<==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date2==>".$date2."<==";
		*/
		$currentMonth				 =  $this->getCommonDataObj()->getStartAndEndDates();
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==currentMonth==><pre>"; print_r($currentMonth); echo "</pre><==";
		
		return $this->getResponse();
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==get_magic_quotes_gpc==>".get_magic_quotes_gpc()."<==";
		
		$inputArray		= array("test's array 1", "test's array 2", "test's array 3", "test's array 4");
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==inputArray==><pre>"; print_r($inputArray); echo "</pre><==";
		
		$addSlashes		= $this->getCommonDataObj()->customizedAddSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==addSlashes==><pre>"; print_r($addSlashes); echo "</pre><==";
		
		$stripSlashes	= $this->getCommonDataObj()->customizedStripSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==stripSlashes==><pre>"; print_r($stripSlashes); echo "</pre><==";
		
//		phpinfo();
		
		return $this->getResponse();
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
