<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Financialmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Financialmanagement\Form\GoalsFilterForm,
	Financialmanagement\Form\AddGoalsForm,
	Financialmanagement\Form\HistoricalDataFilterForm;

//	Models
use Schedulemanagement\Model\Shift;

use Usermanagement\Model\MyAuthenticationAdapter;

class GoalsController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $bonusTypeArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->bonusTypeArray		=  array(1 => 'Bonus added by Owner', 2 => 'Install Bonuses on Event');
		
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "EventTable" => "Event-Table", "LeasePaymentsTable" => "Lease-Payments-Table",  "UsersTable" => "Users-Table", "ShiftRequestTable" => "Shift-Request-Table", "ManagerGoalsTable" => "Manager-Goals-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Goals listing
	*	Detail	:	Used to List the Manager Copensation details
	*/
	public function goalsListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Create Add Stipend from
		$addGoalsForm 			=  new AddGoalsForm();							//	Goals Add form
		
		// Create Filter form
		$goalsFilterForm 			=  new GoalsFilterForm();					//	Goals Filter form
		$historicalDataFilterForm 	=  new HistoricalDataFilterForm();			//	Historical Data Filter form
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates(2);
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			=  $this->getCommonDataObj()->destroySessionVariables(array('goalsListing', 'historicalDataListing'));
		}
		
		$listingSession 	  	= new Container('goalsListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$stipendFilterForm->setData($request->getPost());
			if(isset($formData['goals_from_date']) && !empty($formData['goals_from_date']))
				$listingSession->goals_from_date = $formData['goals_from_date'];
			else
				$listingSession->goals_from_date = '';
			
			if(isset($formData['goals_to_date']) && !empty($formData['goals_to_date']))
				$listingSession->goals_to_date   = $formData['goals_to_date'];
			else
				$listingSession->goals_to_date   = '';
			
			if(isset($formData['goals_amount']) && !empty($formData['goals_amount']))
				$listingSession->goals_amount    = $formData['goals_amount'];
			else
				$listingSession->goals_amount    = '';
			
			if(isset($formData['goals_target_drivers']) && !empty($formData['goals_target_drivers']))
				$listingSession->goals_target_drivers  = $formData['goals_target_drivers'];
			else
				$listingSession->goals_target_drivers  = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->goals_from_date = $currentMonthStartDate;
			$listingSession->goals_to_date   = $currentMonthEntDate;
		}
		
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// Set Default values For Add Goals Forms
		$goalsDate			= $currentMonthStartDate;						//	$datetime->getDates(time(), 0, 'n-j-Y');
		$addGoalsForm->get('manager_goals_date')->setValue($goalsDate);
		$addGoalsForm->get('manager_goals_date_hidden')->setValue($goalsDate);
		$location_id		= $this->pcUser->location_id;
		$addGoalsForm->get('fk_location_id')->setValue($location_id);
		
		//	Goals Filter Forms
		$goalsFilterForm->get('goals_from_date')->setValue($currentMonthStartDate);
		$goalsFilterForm->get('goals_to_date')->setValue($currentMonthEntDate);
		
		//	Historical Data Filter Forms and Session Values
		$historicalDataFilterForm->get('historical_data_from_date')->setValue($currentMonthStartDate);
		$historicalDataFilterForm->get('historical_data_to_date')->setValue($currentMonthEntDate);
		
		// Goals listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerGoalsTable')->getManagerGoalsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		return new ViewModel(array(
			'userObject'					=> $identity,
			'addGoalsForm'					=> $addGoalsForm,
			'goalsFilterForm'				=> $goalsFilterForm,
			'historicalDataFilterForm'		=> $historicalDataFilterForm,
			'pc_users'						=> $this->pcUser,
			'message'						=> $message,
			'page'							=> $page,
			'sortBy'						=> $sortBy,
			'paginator'						=> $paginator,
			'perPage'						=> $perPage,
			'datetime'						=> $datetime,
			'perPageArray'					=> $this->perPageArray,
			'controller'					=> $this->params('controller'),
			'commonData'					=> $this->getCommonDataObj()
		));
		
    }
	
	/*	Action	: 	Ajax Goals List, Ajax action
	*	Detail	:	Used to list the Manager Goals details via Ajax
	*/
	public function goalsListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('goalsListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerGoalsTable')->getManagerGoalsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Manager Goals
	*	Detail	:	Add the Stipend Manager
	*/
	public function ajaxManagerGoalsAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$jsonArray		=  array();
		$addGoalsForm	=  new AddGoalsForm();
	 	$request 		=  $this->getRequest();
		$message		=  '';
		$jsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				if(strpos($formData['manager_goals_date'], '-') !== false ) {
				  //$formData['manager_goals_date']	=  str_replace('-', '/', '1'.$formData['manager_goals_date']);
				  list($month, $year)				=  explode('-', $formData['manager_goals_date']);
				  $formData['manager_goals_date']	=  $month.'/1/'.$year;
				  $goalsDate 	=  $datetime->getDates(strtotime($formData['manager_goals_date']), 0, 'Y-m-d');
				} else {
				  $goalsDate 	=  '0000-00-00';
				}
				
				$goals_id		= (isset($formData["manager_goals_id"])) ? $formData["manager_goals_id"] : 0;
				$goalsDetails 	= array(
					'manager_goals_id'				=> $goals_id,
					'manager_goals_date'		  	=> $goalsDate,
					'manager_goals_amount'	  		=> $formData["manager_goals_amount"],
					'manager_goals_target_drivers'	=> $formData["manager_goals_target_drivers"],
					'manager_goals_created_date'	=> $createdDate,
					'manager_goals_updated_date'	=> $createdDate,
					'fk_location_id'	  			=> $formData['fk_location_id'],
					'manager_goals_isdelete'		=> 0
				);
				$golesId  =  $this->getTable("ManagerGoalsTable")->saveManagerGoals($goalsDetails);		//	Save Manager Goals Details
				
				$jsonArray['status_flag'] 	= true;
				$jsonArray['err_msg']		= "";
			} else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Goals amount, It's required";
			}
        } else {
				$jsonArray['status_flag'] 	= false;
				$jsonArray['err_msg']		= "Enter Goals amount, It's required";
		}
		
		echo json_encode($jsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	View Manager Goals
	*	Detail	:	To View the Manager Goals details
	*/
	public function viewManagerGoalsAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$auth   = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 		=  $this->getRequest();
			$message		=  '';
			$goalsId 		= (int) $this->params()->fromRoute('id', 0);
			$goalsDetail	= '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
			if ($goalsId) {
				$results	= $this->getTable("ManagerGoalsTable")->getManagerGoalsDetails($goalsId);
				if($results) {
					foreach($results as $goals) {
						$goalsDetail = $goals;
					}
					$goalsDate	  						= $datetime->getDates(strtotime($goalsDetail['manager_goals_date']), 0, 'F Y');
					$goalsDetail['manager_goals_date']	= $goalsDate;
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'goalsDetail'	 	 	 => $goalsDetail,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Manager Goals details, Ajax action
	*	Detail	:	Used to Delete the Manager Goals details
	*/
	public function deleteManagerGoalsAction()
    {
		$goalsId = (int) $this->params()->fromRoute('id', 0);
        if ($goalsId) {
			$this->getTable("ManagerGoalsTable")->deleteManagerGoals($goalsId);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Historical Data listing
	*	Detail	:	Used to List the Historical Data details
	*/
	public function historicalDataListingAction() {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		$request 	= $this->getRequest();
		
		// Get Start and End Date for the Current Month
		$currentMonth			=  $this->getCommonDataObj()->getStartAndEndDates(2);
		$currentMonthStartDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["start_date"] : false;
		$currentMonthEntDate	=  (isset($currentMonth["start_date"])) ? $currentMonth["end_date"] : false;
		
		$listingSession 	  	=  new Container('historicalDataListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
			if(isset($formData['historical_data_from_date']) && !empty($formData['historical_data_from_date']))
				$listingSession->from_date = $formData['historical_data_from_date'];
			else
				$listingSession->from_date = '';
			
			if(isset($formData['historical_data_to_date']) && !empty($formData['historical_data_to_date']))
				$listingSession->to_date   = $formData['historical_data_to_date'];
			else
				$listingSession->to_date   = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		} else {
			$listingSession->from_date = $currentMonthStartDate;
			$listingSession->to_date   = $currentMonthEntDate;
		}
		
		if($ajax == '') {
			$listingSession->from_date = $currentMonthStartDate;
			$listingSession->to_date   = $currentMonthEntDate;
		}
		
		// Date
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		// Get Historuical Data for Revenue and Drivers Shoft Counts.
		$revenueDetails		= $this->getCommonDataObj()->getRevenueHistoricalDataDetails();
		
		// Historical Data listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerGoalsTable')->getHistoricalDataList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$result->setVariables(array(
			'userObject'				=> '',
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'revenueDetails'			=> $revenueDetails,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Historical Data List, Ajax action
	*	Detail	:	Used to list the Historical Data details via Ajax
	*/
	public function historicalDataListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('historicalDataListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		// Get Historuical Data for Revenue and Drivers Shoft Counts.
		$revenueDetails		= $this->getCommonDataObj()->getRevenueHistoricalDataDetails();
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ManagerGoalsTable')->getHistoricalDataList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'revenueDetails'		=> $revenueDetails,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Historical Data
	*	Detail	:	To View the HistoricalData details
	*/
	public function viewHistoricalDataAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$auth   = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 		=  $this->getRequest();
			$message		=  '';
			$goalsId 		= (int) $this->params()->fromRoute('id', 0);
			$goalsDetail	=  $revenueDetails	=  '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
			if ($goalsId) {
				$results	= $this->getTable("ManagerGoalsTable")->getManagerGoalsDetails($goalsId);
				if($results) {
					foreach($results as $goals) {
						$goalsDetail = $goals;
					}
//					$goalsDate	  						= $datetime->getDates(strtotime($goalsDetail['manager_goals_date']), 0, 'n-j-Y');
					
					// Get Historuical Data for Revenue and Drivers Shoft Counts.
					$revenueDate		= $datetime->getDates(strtotime($goalsDetail['manager_goals_date']), 0, 'Y-n');
					$dateDetails		=  array(
						'from_date'	 	=> $revenueDate,
						'to_date'	 	=> $revenueDate,
					);
					$revenueDetails		= $this->getCommonDataObj()->getRevenueHistoricalDataDetails(2, $dateDetails);
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'goalsDetail'	 	 	 => $goalsDetail,
					'revenueDetails'	 	 => $revenueDetails,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	public function testAction()
	{
		$fromDate	= '2013-2-9';		//	2011-12-12
		$toDate		= '2013-4-12';		//	2012-02-01
		$startTime 	= strtotime($fromDate);
		$endTime 	= strtotime($toDate);
		
		$weeks 		= array();
		$days 		= array();
		$date 		= array();
		
		while ($startTime < $endTime) {
		    $weeks[] 	= date('W', $startTime);
			$day 	 	= date('w', $startTime);
			$days[] 	= $day;
			$date[]  	= date('d-m-Y', $startTime);
			$addNums	= ($day == 1) ? '+1 week' : '+'.(7-$day).' days';
			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==day==>".$day."<==diff==>".(7-$day)."<==addNums==>".$addNums."<==";
		    $startTime += strtotime($addNums, 0);	//	+7 days
		}
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==fromDate==>".$fromDate."<==toDate==>".$toDate."<==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==days==><pre>"; print_r($days); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date==><pre>"; print_r($date); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==weeks==><pre>"; print_r($weeks); echo "</pre><==";
		
		return $this->getResponse();
		
		
		/*
		//	n-j-Y
		$date1		=  date("n-t-Y", strtotime("now"));
		$date2		=  date("n-1-Y", strtotime("now"));
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date1==>".$date1."<==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date2==>".$date2."<==";
		*/
		$currentMonth				 =  $this->getCommonDataObj()->getStartAndEndDates(2);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==currentMonth==><pre>"; print_r($currentMonth); echo "</pre><==";
		
		return $this->getResponse();
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==get_magic_quotes_gpc==>".get_magic_quotes_gpc()."<==";
		
		$inputArray		= array("test's array 1", "test's array 2", "test's array 3", "test's array 4");
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==inputArray==><pre>"; print_r($inputArray); echo "</pre><==";
		
		$addSlashes		= $this->getCommonDataObj()->customizedAddSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==addSlashes==><pre>"; print_r($addSlashes); echo "</pre><==";
		
		$stripSlashes	= $this->getCommonDataObj()->customizedStripSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==stripSlashes==><pre>"; print_r($stripSlashes); echo "</pre><==";
		
//		phpinfo();
		
		return $this->getResponse();
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
