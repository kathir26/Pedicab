<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Financialmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use PHPExcel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Financialmanagement\Form\DepositLeaseFeesFilterForm,
	Financialmanagement\Form\EventFilterForm,
	Financialmanagement\Form\AddEventPaymentForm,
	Financialmanagement\Form\AddDepositLeaseFeesForm,
	Financialmanagement\Form\MonthlyExpenseForm,
	Financialmanagement\Form\ExpenseFilterForm;

//	Models
use Schedulemanagement\Model\Shift;

use Usermanagement\Model\MyAuthenticationAdapter;

class FinancialController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $shiftIconArray;
	protected $shiftArray;
	protected $eventCategoryArray;
	protected $balanceDueArrray;
	protected $quotedStatusArrray;
	protected $editCategoryArray;
	protected $paymentMethodArray;
	protected $leasePaymentTypes;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->shiftIconArray		=  array('1' => 'icon-day','2' => 'icon-nite', '3' => 'icon-double','4' => 'icon-special');
		$this->shiftArray			=  array('' => 'All Shifts', '1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$this->eventCategoryArray	=  array('' => 'Select Event Category', '1' => 'Ad Install', '2' => 'Dedicated Ad Event', '3' => 'Ride Request (not prepaid)', '4' => 'Tour', '5' => 'Wedding', 
											 '6' => 'Pre-paid Ride', '7' => 'Birthday', '8' => 'Bachelorette/Bachelor Party', '9' => 'Corporate', '10' => 'Group', '11' => 'Other');
		$this->editCategoryArray	=  array('4' => 'Tour', '5' => 'Wedding', '6' => 'Pre-paid Ride', '7' => 'Birthday', '8' => 'Bachelorette/Bachelor Party', '9' => 'Corporate', '10' => 'Group', '11' => 'Other');
		$this->balanceDueArrray		=  array('' => '-', '1' => 'Fully Paid', '2' => 'Not Paid');
		$this->quotedStatusArrray	=  array('1' => 'Quoted','2' => 'Confirmed');
		$this->paymentMethodArray	=  array('' => 'Select Payment', '1' => 'Cash', '2' => 'Cheque', '4' => 'Master Card', '3' => 'Visa');
		$this->leasePaymentTypes	=  array('' => 'Select Payment Type', '1' => 'Exactly the amount', '2' => 'Overpay amount', '3' => 'Underpay amount');
		
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "EventTable" => "Event-Table", "LeasePaymentsTable" => "Lease-Payments-Table",  "UsersTable" => "Users-Table", "ShiftRequestTable" => "Shift-Request-Table", "BikeTable" => "Bike-Table", "locationTable" => "location-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Deposit Lease Fees listing
	*	Detail	:	Used to List the Deposit Lease Fees details
	*/
	public function depositLeaseFeesListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Driver deposite lease fees form
		$addDepositLeasFeesForm = new AddDepositLeaseFeesForm();
		
		// Create Filter form
		$depositLeaseFilterForm = new DepositLeaseFeesFilterForm();
		$request 				= $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('leasePaymentsListing'));
		}
		
		$listingSession 	  	= new Container('leasePaymentsListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$depositLeaseFilterForm->setData($request->getPost());
			if(isset($formData['shift_date']) && !empty($formData['shift_date']))
				$listingSession->shift_date = $formData['shift_date'];
			else
				$listingSession->shift_date = '';
			
			if(isset($formData['user_name']) && !empty($formData['user_name']))
				$listingSession->user_name  = $formData['user_name'];
			else
				$listingSession->user_name  = '';
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Get All Lease Payments Details
		$allLeasePayments	= $this->getTable('LeasePaymentsTable')->getAllLeasePayments();
		$addDepositLeasFeesForm->get('pay_amount_type[]')->setValueOptions($this->leasePaymentTypes);
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getLeasePaymentsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  	= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'				=> $identity,
			'addDepositLeasFeesForm'	=> $addDepositLeasFeesForm,
			'depositLeaseFilterForm'	=> $depositLeaseFilterForm,
			'allLeasePayments'			=> $allLeasePayments,
			'pc_users'					=> $this->pcUser,
			'message'					=> $message,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'datetime'					=> $datetime,
			'leasePaymentTypes'			=> $this->leasePaymentTypes,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
		
    }
	
	/*	Action	: 	Ajax Deposit Lease Fees List, Ajax action
	*	Detail	:	Used to list the Deposit Lease Fees details via Ajax
	*/
	public function depositLeaseFeesListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('leasePaymentsListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getLeasePaymentsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'leasePaymentTypes'		=> $this->leasePaymentTypes,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Ajax Deposite Lease Payment
	*	Detail	:	Add the Deposite Lease Payment
	*/
	public function ajaxDepositeLeasePaymentAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$driverLeasePayArray	=  array();
		$addDepositLeaseForm	=  new AddDepositLeaseFeesForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$driverLeasePayArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				
				// Payment details
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==formData==><pre>"; print_r($formData); echo "</pre><==";
				
				$payAmountType		=  $formData['pay_amount_type'];
				$leasePayAmount		=  $formData['lease_pay_amount'];			//	ie : Driver need to payme the lease payment
				$leasePaymentAmount	=  $formData['lease_payment_amount'];		//	ie : Driver paied the lease payment
				$mechanicalIssue	=  $formData['discount_mechanical_issue'];
				$badWeather			=  $formData['discount_bad_weather'];
				$otherReason		=  $formData['discount_other_reason'];
				$paymentAmount		=  $formData['payment_amount'];
				$usersArrays		=  $formData['user_id'];
				$leaseArrays		=  $formData['lease_id'];
				
				foreach($leaseArrays as $key => $leaseId) {
					$payAmountTypeValue		 =  (isset($payAmountType[$key])) ? $payAmountType[$key] : '';
					$leasePayAmountValue 	 =  (isset($leasePayAmount[$key])) ? $leasePayAmount[$key] : '';
					$leasePaymentAmountValue =  (isset($leasePaymentAmount[$key])) ? $leasePaymentAmount[$key] : '';
					$mechanicalIssueValue	 =  (isset($mechanicalIssue[$key])) ? $mechanicalIssue[$key] : '';
					$badWeatherValue		 =  (isset($badWeather[$key])) ? $badWeather[$key] : '';
					$otherReasonValue		 =  (isset($otherReason[$key])) ? $otherReason[$key] : '';
					$paymentAmountValue		 =  (isset($paymentAmount[$key])) ? $paymentAmount[$key] : '';
					$userId		 			 =  (isset($usersArrays[$key])) ? $usersArrays[$key] : '';
					
					/*
					*	Condition handling for User Balance
					*/
					$creditFlag		=	false;
					$discountFlag	=	(!empty($mechanicalIssueValue) || !empty($badWeatherValue) || !empty($otherReasonValue)) ? true : false;
					$discountAmount	=   0;
					//	'1' => 'Exactly the amount', '2' => 'Overpay amount', '3' => 'Underpay amount'
					if($payAmountTypeValue == 1) {
						if($discountFlag) {
							$creditType			=  1;
							$discountAmount		=  (int) ($paymentAmountValue - $leasePaymentAmountValue);
							$userAmountBalance	=  $discountAmount;
							$creditFlag			=  true;
						}
					} else if($payAmountTypeValue == 2) {
						if($discountFlag) {
							$creditType			=  1;
							$discountAmount		=  (int) ($paymentAmountValue - $leasePaymentAmountValue);
							$userAmountBalance	=  (int) ( $discountAmount + ($paymentAmountValue - $leasePayAmountValue));
							$creditFlag			=  true;
						} else {
							$creditType			=  1;
							$userAmountBalance	=  (int) ($paymentAmountValue - $leasePayAmountValue);
							$creditFlag			=  true;
						}
					} else if($payAmountTypeValue == 3) {
						if($discountFlag) {
							$discountAmount		=  ($paymentAmountValue - $leasePaymentAmountValue);
							$needToPay			=  ($leasePayAmountValue - $discountAmount);
							if($needToPay > $paymentAmountValue) {
								$creditType			=  2;
								$userAmountBalance	=  (int) ($needToPay - $paymentAmountValue);
							} else {
								$creditType			=  1;
								$userAmountBalance	=  (int) ($paymentAmountValue - $needToPay);
							}
							$creditFlag			=  true;
						} else {
							$creditType			=  2;
							$userAmountBalance	=  (int) ($leasePayAmountValue - $paymentAmountValue);
							$creditFlag			=  true;
						}
					}
					
					$leasePayment 			 		=  array(
						'lease_id'			  	  	=> $leaseId,
						'pay_amount_type'		  	=> $payAmountTypeValue,
						'lease_payment_amount'	  	=> $leasePaymentAmountValue,
						'discount_amount'	  		=> $discountAmount,
						'discount_mechanical_issue'	=> $mechanicalIssueValue,
						'discount_bad_weather'		=> $badWeatherValue,
						'discount_other_reason'		=> $otherReasonValue,
						'lease_status'			  	=> 2,
						'lease_updated_date'	  	=> $createdDate
					);
					$leasePaymentId  =  $this->getTable("LeasePaymentsTable")->saveLeasePayments($leasePayment);	//	Update Driver Lease payments
					
					if($creditFlag) {
						$userDetails 					=  array(
							'user_id'			  	  	=> $userId,
							'credit_type'	  			=> $creditType,			//	1 - credit ( + ), 2 - debite (-)
							'user_amount_balance'	  	=> $userAmountBalance
						);
						$this->getTable("UsersTable")->saveUserAccountBalances($userDetails);					//	Update the User Account Balance
					}
					// End Condition handling for User Balance
				}
				
				$driverLeasePayArray['status_flag'] 	= true;
				$driverLeasePayArray['err_msg']			= "";
			} else {
				$driverLeasePayArray['status_flag'] 	= false;
				$driverLeasePayArray['err_msg']			= "Enter Payment amount, It's required";
			}
        } else {
				$driverLeasePayArray['status_flag'] 	= false;
				$driverLeasePayArray['err_msg']			= "Enter Payment amount, It's required";
		}
		
		echo json_encode($driverLeasePayArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	View Deposite Lease Fees
	*	Detail	:	To View the Deposit lease fees details
	*/
	public function viewDepositLeaseFeesAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$auth   = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 		=  $this->getRequest();
			$message		=  '';
			$leaseId 		= (int) $this->params()->fromRoute('id', 0);
			$depositeLeases	= '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
			if ($leaseId) {
				$results	= $this->getTable("LeasePaymentsTable")->viewLeasePaymentsDetails($leaseId);
				if($results) {
					foreach($results as $lease) {
						$depositeLeases = $lease;
					}
					
					$shiftStartDate					= ($depositeLeases['shift_occurs'] == 1) ? $depositeLeases['shift_dt_start_date'] : $depositeLeases['event_date'];
					$shiftDate	  					= $datetime->getDates(strtotime($shiftStartDate), 0, 'n-j-Y');
					$depositeLeases['shift_date']	= $shiftDate;
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'depositeLeases'	 	 	 => $depositeLeases,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'leasePaymentTypes'		 => $this->leasePaymentTypes,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Delete Deposit Lease Fees details, Ajax action
	*	Detail	:	Used to Delete the Deposit Lease Fees details
	*/
	public function deleteDepositLeaseFeesAction()
    {
		$lease_id = (int) $this->params()->fromRoute('id', 0);
        if ($lease_id) {
			$this->getTable("LeasePaymentsTable")->deleteLeasePayments($lease_id);
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Financial Event listing
	*	Detail	:	Used to List the Events details
	*/
	public function financialEventListingAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$message	= '';
		$matches	= $this->getEvent()->getRouteMatch();
		
		// ajax
		$ajax		= $matches->getParam('id', '');
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$eventFilterForm 	  	= new EventFilterForm();
		$request 				= $this->getRequest();
		
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('openEventListing', 'closedEventListing'));
		}
		$openEventSession  	  	= new Container('openEventListing');
		$closedEventSession     = new Container('closedEventListing');
		
		if ($request->isPost()) {
			$formData			=  $request->getPost();
//			$eventFilterForm->setData($request->getPost());
			if(isset($formData['event_pay_status']) && $formData['event_pay_status'] == 1) {							// Open Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$openEventSession->event_date	 	 = $formData['event_date'];
				else
					$openEventSession->event_date	 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$openEventSession->event_title	 = $formData['event_title'];
				else
					$openEventSession->event_title	 = '';
			} else if(isset($formData['event_pay_status']) && $formData['event_pay_status'] == 2) {						// Closed Event Listing
				
				if(isset($formData['event_date']) && !empty($formData['event_date']))
					$closedEventSession->event_date   = $formData['event_date'];
				else
					$closedEventSession->event_date 	 = '';
				
				if(isset($formData['event_title']) && !empty($formData['event_title']))
					$closedEventSession->event_title	 = $formData['event_title'];
				else
					$closedEventSession->event_title	 = '';
			}
			
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		
		// Confirmed Events Listing
		$perPage					= $this->defaultPerPage;
		$payStatus					= 1;		//		1 = Open; 2 = Closed
		$iteratorAdapter_confirmed	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getPaymentEventList($payStatus));
		$paginator_open				= new \Zend\Paginator\Paginator($iteratorAdapter_confirmed);
		$paginator_open->setCurrentPageNumber($page);
		$paginator_open->setItemCountPerPage($perPage);
		
		$paginator_closed			= '';
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'eventFilterForm'		=> $eventFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_open'		=> $paginator_open,
			'paginator_closed'		=> $paginator_closed,
			'perPage'				=> $perPage,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Financial Event list, Ajax action
	*	Detail	:	Used to list the Events details via Ajax
	*/
	public function financialEventListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('pageid', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$payStatus	= $matches->getParam('payStatus', '');
		
		//	Session for Role listing
		$sessionsContainer	= (isset($payStatus) && $payStatus == 1) ? 'openEventListing' : 'closedEventListing';
		$eventsSession 		= new Container($sessionsContainer);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($eventsSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$eventsSession->sortBy	= $sortBy;
		} else if($eventsSession->offsetExists('sortBy')) {
			$sortBy	= $eventsSession->sortBy;
		}
		if($sortType != '') {
			if($eventsSession->sortType == $sortType && $columnFlag == 1)
				$eventsSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$eventsSession->sortType	= $sortType;
		} else if($eventsSession->offsetExists('sortType')) {
			$sortType	= $eventsSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$eventsSession->perPage	= $perPage;
		} else if($eventsSession->offsetExists('perPage')) {
			$perPage		= $eventsSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$payStatus			= (isset($payStatus) && !empty($payStatus)) ? $payStatus : 1;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('EventTable')->getPaymentEventList($payStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		if(isset($payStatus) && $payStatus == 1) {
			$paginator_closed	= '';
			$paginator_open		= $paginator;
		} else {
			$paginator_closed	= $paginator;
			$paginator_open		= '';
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator_closed'		=> $paginator_closed,
			'paginator_open'		=> $paginator_open,
			'perPage'				=> $perPage,
			'payStatus'				=> $payStatus,
			'balanceDueArrray'		=> $this->balanceDueArrray,
			'eventCategoryArray'	=> $this->eventCategoryArray,
			'perPageArray'			=> $this->perPageArray,
			'datetime'				=> $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Event
	*	Detail	:	To View the Accident details
	*/
	public function viewEventAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			=  $this->getRequest();
			$message			=  '';
			$eventId 			= (int) $this->params()->fromRoute('id', 0);
			$eventDetails		= '';
			
			if ($eventId) {
				$results		= $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails = $event;
					}
					
					// Date
					$datetime	=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					if(isset($eventDetails['event_date']) && $eventDetails['event_date'] != "0000-00-00 00:00:00") {
						$eventDetails['event_date']	= $datetime->getDates(strtotime($eventDetails['event_date']), 0, 'n-j-Y');
					} else {
						$eventDetails['event_date']	= '-';
					}
					
					// Start : Drivers assignment process
					$requestedDrivers		=  $allocatedDrivers =  array();
					$shiftManagers			=  array();
					
					// Get Requested Drivers for the shift
					$shiftId 				=  $eventDetails['shift_id'];
					$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
					if($requestResults) {
						$requestedToArray	=  $requestResults->toArray();
						if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
							foreach($requestedToArray as $keys => $values) {
								$requestedDrivers[$values['fk_user_id']]		=  $values;
								if($values['shift_request_status'] == 2) {
									$allocatedDrivers[$values['fk_user_id']]	=  $values;
									if($eventDetails['shift_manager_id'] == $values['fk_user_id']) {
										$shiftManagers[$values['fk_user_id']]	=  $values['user_firstname'].' '.$values['user_lastname'];
									}
								}
							}
						}
					}
					
					// Get All Bikes for the particulat locations
					$allocatedBikes  	= array();
					if (isset($eventDetails['bike_reserved_type']) && !empty($eventDetails['bike_reserved_type']) && $eventDetails['bike_reserved_type'] == 2) {
						$bikesIds			= $eventDetails['bike_reserved_ids'];
						$allBikesResults	= $this->getTable("BikeTable")->GetSelectedBikes($bikesIds);
						if($allBikesResults) {
							foreach($allBikesResults as $key => $value) {
								$bikeId					 = $value['bike_id'];
								$allocatedBikes[$bikeId] = $value;
							}
						}
					}
					
					// Other Costa label
					$other_costs_labels	 	 =  $other_costs_values	 =  array();
					if(isset($eventDetails['other_costs_labels']) && !empty($eventDetails['other_costs_labels'])) {
						$other_costs_labels	 =  explode(',', $eventDetails['other_costs_labels']);
					}
					
					// Other Costa value
					if(isset($eventDetails['other_costs_values']) && !empty($eventDetails['other_costs_values'])) {
						$other_costs_values	 =  explode(',', $eventDetails['other_costs_values']);
					}
					
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'balanceDueArrray'	 	 => $this->balanceDueArrray,
					'quotedStatusArrray' 	 => $this->quotedStatusArrray,
					'eventDetails'	 	 	 => $eventDetails,
					'allocatedDrivers'		 => $allocatedDrivers,
					'allocatedBikes'		 => $allocatedBikes,
					'other_costs_labels'	 => $other_costs_labels,
					'other_costs_values'	 => $other_costs_values,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'sitePath'	 			 => $this->sitePath,
					'siteImagePath'	 		 => $this->siteImagePath,
					'siteImageUploadPath'	 => $this->siteImageUploadPath,
					'eventCategoryArray'	 => $this->eventCategoryArray,
					'quotedStatusArrray'	 => $this->quotedStatusArrray,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	/*	Action	: 	Financial Event Payments
	*	Detail	:	Used to add the event payment historys
	*/
	public function financialEventPaymentsAction()
    {
		$result 				 =  new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  			 =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity 			 =  $auth->getIdentity();
			$request 			 =  $this->getRequest();
			$message			 =  '';
			$errorFlag			 =	true;
			$eventId 			 =  (int) $this->params()->fromRoute('id', 0);
			$datetime 		     =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$addEventPaymentForm =  new AddEventPaymentForm();
			$eventDetails		 =  '';
			if ($eventId) {
				$results		 =  $this->getTable("EventTable")->getViewEventDetail($eventId);
				if($results) {
					foreach($results as $event) {
						$eventDetails   = $event;
					}
					
					$addEventPaymentForm->get('fk_event_id')->setValue($eventDetails['event_id']);
					$addEventPaymentForm->get('event_title')->setValue($eventDetails['event_title']);
					$addEventPaymentForm->get('payment_method')->setValueOptions($this->paymentMethodArray);
					$addEventPaymentForm->get('balance_owed')->setValue($eventDetails['balance_owed']);
					
					$result->setVariables(array(
						'userObject'			=> $identity,
						'addEventPaymentForm'	=> $addEventPaymentForm,
						'pc_users'				=> $this->pcUser,
						'message'				=> $message,
						'datetime'				=> $datetime,
						'errorFlag'				=> false,
						'paymentMethodArray'	=> $this->paymentMethodArray,
						'perPageArray'			=> $this->perPageArray,
						'controller'			=> $this->params('controller'),
						'commonData'			=> $this->getCommonDataObj()
					));
				}
			}
		}
		return $result;
    }
	
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	private function sendShiftAllocationNote($driversArray = false, $identity, $notifications)
    {
        if($driversArray && is_array($driversArray) && count($driversArray)) {
			foreach($driversArray as $driver_key => $driver_value) {
				$insert_array[]		 = "'".$notifications['shift_id']."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifications['subject'])."','".addslashes($notifications['notify_date'])."','".addslashes($notifications['notify_type'])."'";
			}
			if(is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
			}
		}
    }
	public function monthlyExpenseAction()
	{
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$paginator					= '';
		// assign default values
		$matches					= $this->getEvent()->getRouteMatch();
		$page						= $matches->getParam('id', 1);
		$sortBy						= $matches->getParam('sortBy', '');
		$sortType					= $matches->getParam('sortType', '');
		$perPage					= $matches->getParam('perPage', '');
		$getCurrentMonthReport		= '';
		$currentReport				= $currentMonthReport = array();
		$MonthlyExpenseForm			= new MonthlyExpenseForm();
		$ExpenseFilterForm			= new ExpenseFilterForm();
		$MonthlyExpenseForm->get('user_id')->setValue($identity->user_id);
		if(isset($identity->user_role_id) && $identity->user_role_id == 5)
		{
			$currentMonthDetails	= $this->getTable('LeasePaymentsTable')->getExpenseCurrentMonthList();
			if(is_object($currentMonthDetails) && count($currentMonthDetails) > 0)
			{
				foreach($currentMonthDetails as $Key => $Value)
				{
					$currentMonthReport[]		= $Value;
				}
			}
		}
		else
		{
			$getCurrentMonthReport	= $this->getTable('LeasePaymentsTable')->getMonthlyExpenseDetails();
			if(is_object($getCurrentMonthReport) && count($getCurrentMonthReport) > 0)
			{
				$e = 0;
				foreach($getCurrentMonthReport as $Key => $Value)
				{
					if($e == 0)
					{
						$MonthlyExpenseForm->get('expense_report')->setValue(stripslashes($Value['expense_purpose']));
						$MonthlyExpenseForm->get('expense_id')->setValue(stripslashes($Value['expense_id']));
						$MonthlyExpenseForm->get('generate_report')->setValue(stripslashes($Value['expense_report_generate']));
						if(isset($Value['expense_reinbursement_date']) && $Value['expense_reinbursement_date'] != '0000-00-00')
						{
							$MonthlyExpenseForm->get('expense_reimber_hid')->setValue(stripslashes(date('n-j-Y',strtotime($Value['expense_reinbursement_date']))));
						}
						if(isset($identity->user_role_id) && $identity->user_role_id == 5)
						{
							if(isset($Value['expense_reinbursement_date']) && $Value['expense_reinbursement_date'] != '0000-00-00')
							{
								$MonthlyExpenseForm->get('reinbursement_date')->setValue(stripslashes(date('n-j-Y',strtotime($Value['expense_reinbursement_date']))));
							}
						}
					}
					$currentReport[]	= $Value;
					$e++;
				}
			}
		}
		
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('expenseReportListing'));
		$expenseReportListing  		=  new Container('expenseReportListing');
		if($request->isPost()) {
			$ExpenseFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['expense_date']) && !empty($formData['expense_date']))
				$expenseReportListing->se_expense_date	= $formData['expense_date'];
			else
				$expenseReportListing->se_expense_date	= '';
			
			if(isset($formData['expense_title']) && $formData['expense_title'] != '')
				$expenseReportListing->ses_expense_title	= $formData['expense_title'];
			else
				$expenseReportListing->ses_expense_title	= '';
		}
		
		if($expenseReportListing->offsetExists('se_expense_date') && $expenseReportListing->se_expense_date != '' ) {
			$ExpenseFilterForm->get('expense_date')->setValue($expenseReportListing->se_expense_date);
		}
		if($expenseReportListing->offsetExists('ses_expense_title') && $expenseReportListing->ses_expense_title != '' ) {
			$ExpenseFilterForm->get('expense_title')->setValue($expenseReportListing->ses_expense_title);
		}
		
		// listing
		$perPage					= $this->defaultPerPage;
		$iteratorAdapter			= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getExpensereportList());
		$paginator					= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'pc_users'				=> $this->pcUser,
			'currentReport'			=> $currentReport,
			'MonthlyExpenseForm'	=> $MonthlyExpenseForm,
			'ExpenseFilterForm'		=> $ExpenseFilterForm,
			'currentMonthReport'	=> $currentMonthReport,
			'paginator'				=> $paginator,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
	}
	public function monthlyExpenseListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$expenseReportListing  	=  new Container('expenseReportListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($expenseReportListing->sortBy == $sortBy)
				$columnFlag	= 1;
			$expenseReportListing->sortBy	= $sortBy;
		} else if($expenseReportListing->offsetExists('sortBy')) {
			$sortBy	= $expenseReportListing->sortBy;
		}
		if($sortType != '') {
			if($expenseReportListing->sortType == $sortType && $columnFlag == 1)
				$expenseReportListing->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$expenseReportListing->sortType	= $sortType;
		} else if($expenseReportListing->offsetExists('sortType')) {
			$sortType	= $expenseReportListing->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$expenseReportListing->perPage	= $perPage;
		} else if($expenseReportListing->offsetExists('perPage')) {
			$perPage		= $expenseReportListing->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('LeasePaymentsTable')->getExpensereportList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function saveMonthlyExpenseAction()
	{
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$reimbDate					= $expenseId = $getlocationDetails = $locationValue = $userName = $purpose = '';
		$priceCalculation 			= $totalDriver = $totalTransport = $totalParts = $totalSupplies = $totalOthers = $expenceCount = $countDate = 0;
		if($request->isPost())
		{
			$expenseDate			= $descriptionArr = $driverMeeting = $transport = $bikeParts = $officeSupplies = $othersPrice = $priceInsertArray = $expenceIdArray = $expenceImageArr = array();
			$getAdminDetails		= '';
			$formData				= $request->getPost();
			$expenseDate			= $formData['expense_date'];
			$descriptionArr			= $formData['expense_desc'];
			$countDate				= count($expenseDate);
			$driverMeeting			= $formData['expense_lodging'];
			$transport				= $formData['expense_transport'];
			$bikeParts				= $formData['expense_meals'];
			$officeSupplies			= $formData['expense_others_supplies'];
			$othersPriceArr			= $formData['expense_others'];
			$expenceIdArray			= $formData['expense_price_id'];
			$expenceImageArr		= $formData['expense_image'];
			$expenceCount			= count($expenceIdArray);
			
			$fileTransfer 			= new \Zend\File\Transfer\Adapter\Http();
			$fileInfo 	  			= $fileTransfer->getFileInfo();
			if(isset($identity->user_role_id) && $identity->user_role_id == 5)
			{
				$tempDate			= str_replace('-', '/', $formData['reinbursement_date']);
				$reimbDate			= date('Y-m-d', strtotime($tempDate));
			}
			if(isset($formData['expense_id']) && $formData['expense_id'] != '')
			{
				$expenseId			= $formData['expense_id'];
				$updateString1		= " expense_purpose = '".addslashes($formData['expense_report'])."', expense_percent = '2', expense_owed_amount = '150'";
				if(isset($reimbDate) && ($reimbDate != '' && $reimbDate != '0000-00-00'))
				{
					$updateString1	.= ", expense_reinbursement_date = '".addslashes($reimbDate)."'";
				}
				$this->getTable('LeasePaymentsTable')->updateMonthlyExpense($updateString1,$expenseId);
			}
			else
			{
				//Insert Monthly Expense
				$insertString		= " ('".addslashes($identity->user_id)."', '".addslashes($identity->user_role_id)."', '".addslashes($identity->location_id)."', '".addslashes($formData['expense_report'])."', '2', '150', '".addslashes($reimbDate)."', now())";
				$expenseId			= $this->getTable('LeasePaymentsTable')->insertMonthlyExpense($insertString);
			}
			for($e = 0; $e < $countDate; $e++)
			{
				$driverPrice		= $transportPrice = $partsPrice = $suppliesPrice = $othersPrice = $totalRow = 0;
				$expenseImage		= '';
				$tempDate		  	= str_replace('-', '/', $expenseDate[$e]);
				$newDate		 	= date('Y-m-d', strtotime($tempDate));
				$driverPrice		= $this->checkNumericValue($driverMeeting[$e]);
				$transportPrice		= $this->checkNumericValue($transport[$e]);
				$partsPrice			= $this->checkNumericValue($bikeParts[$e]);
				$suppliesPrice		= $this->checkNumericValue($officeSupplies[$e]);
				$othersPrice		= $this->checkNumericValue($othersPriceArr[$e]);
				$priceCalculation	= $priceCalculation + $driverPrice + $transportPrice + $partsPrice + $suppliesPrice + $othersPrice;
				$totalDriver		= $totalDriver + $driverPrice;
				$totalTransport		= $totalTransport + $transportPrice;
				$totalParts			= $totalParts + $partsPrice;
				$totalSupplies		= $totalSupplies + $suppliesPrice;
				$totalOthers		= $totalOthers + $othersPrice;
				$totalRow			= $driverPrice + $transportPrice + $partsPrice + $suppliesPrice + $othersPrice;
				if(isset($fileInfo['expense_upload_'.$e.'_']['name']) && $fileInfo['expense_upload_'.$e.'_']['name'] != '')
				{
					$myFileUpload   			= $this->MyFileUpload();
					$myFileUpload->fileTypes	= $this->imageTypes;
					$myFileUpload->fileSizes	= $this->imageSizes;
					$fileNameArray				= array("expense_upload");
					$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
					$myFileUpload->uploadPath	= $this->siteImageUploadPath."/monthly_expense";
					if(isset($expenceImageArr[$e]) && $expenceImageArr[$e] != '')
					{
						$myFileUpload->unlinkFile($this->siteImageUploadPath."/monthly_expense/".$expenceImageArr[$e]);
					}
					$expenseImage				= $myFileUpload->uploadMultipleFiles($expenseId.'_'.$e, $fileNameArray, $fileInfo['expense_upload_'.$e.'_']);
				}
				if($expenceCount > $e && is_array($expenceIdArray))
				{
					$updateArray				= "	price_date = '".addslashes($newDate)."', price_desc = '".addslashes($descriptionArr[$e])."', price_driver = '".addslashes($driverPrice)."', price_transport = '".addslashes($transportPrice)."', price_bike_parts = '".addslashes($partsPrice)."',
													price_office_supplies = '".addslashes($suppliesPrice)."', price_others = '".addslashes($othersPrice)."', price_total = '".addslashes($totalRow)."'";
					if(isset($expenseImage) && $expenseImage != '')
					{
						$updateArray			.= " ,price_image = '".addslashes($expenseImage)."'";
					}
					$this->getTable('LeasePaymentsTable')->updateMonthlyExpensePrice($updateArray,$expenceIdArray[$e]);
				}
				else
				{
					$priceInsertArray[]			= "'".addslashes($expenseId)."', '".addslashes($newDate)."', '".addslashes($descriptionArr[$e])."', '".addslashes($driverPrice)."', '".addslashes($transportPrice)."', '".addslashes($partsPrice)."', '".addslashes($suppliesPrice)."', '".addslashes($othersPrice)."', '".addslashes($totalRow)."', '".addslashes($expenseImage)."', 1";
				}
			}
			if(is_array($priceInsertArray) && count($priceInsertArray) > 0)
			{
				$insertPriceString				= "(".implode("),(",$priceInsertArray).")";
				$this->getTable('LeasePaymentsTable')->insertMonthlyExpensePrice($insertPriceString);
			}
			//Update Monthly expense table for total price
			$updateString						= " expense_driver_total = '".addslashes($totalDriver)."', expense_transport_total = '".addslashes($totalTransport)."', expense_bike_parts_total = '".addslashes($totalParts)."', expense_office_total = '".addslashes($totalSupplies)."', expense_others_total = '".addslashes($totalOthers)."', expense_overall_total = '".addslashes($priceCalculation)."'";
			if($expenceCount > 0)
			{
				$updateString					.= " ,expense_isupdated_date = now()";
			}
			if(isset($formData['generate_report']) && $formData['generate_report'] == 1)
			{
				$updateString					.= " ,expense_report_generate = 1";
			}
			$this->getTable('LeasePaymentsTable')->updateMonthlyExpense($updateString,$expenseId);
			//Generate report and send notification
			if(isset($formData['generate_report']) && $formData['generate_report'] == 1)
			{
				$where				= " and user_role_id in (5)";
				$getAdminDetails	= $this->getTable('ShiftTable')->getuserDetails($where);
				if(is_object($getAdminDetails) && count($getAdminDetails) > 0)
				{
					foreach($getAdminDetails as $userKey => $userValue)
					{
						$notifySubject			= "Monthly Expense Report for the month of ".date('F, Y')." has been created and waiting for your approval";
						$notifyDate				= date('n-j-Y');
						$notifyType				= "13";
						$insertNotifyArray[]	= "'".$expenseId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
					}
					if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
					{
						$insertMultiString		= "(".implode("),(",$insertNotifyArray).")";
					}
					if(isset($insertMultiString) && $insertMultiString != '')
					{
						$this->getTable('LeasePaymentsTable')->insertManagerNotification($insertMultiString);
					}
				}
				//Get location Details
				$tempDate							= str_replace('-', '/', $formData['expense_reimber_hid']);
				$reimbDate							= date('Y-m-d', strtotime($tempDate));
				$formData['expense_reinbursement']	= $reimbDate;
				$this->generateMonthlyExcelReport($identity, $formData);
			}
		}
		return $this->redirect()->toRoute('financialmanagement', array('controller' => 'financial', 'action' => 'monthly-expense'));
	}
	public function generateMonthlyExcelReport($identity, $formData)
	{
		$getlocationDetails 	= $locationValue = $userName = $purpose = '';
		$expenseDate			= $formData['expense_date'];
		$descriptionArr			= $formData['expense_desc'];
		$countDate				= count($expenseDate);
		$driverMeeting			= $formData['expense_lodging'];
		$transport				= $formData['expense_transport'];
		$bikeParts				= $formData['expense_meals'];
		$officeSupplies			= $formData['expense_others_supplies'];
		$othersPriceArr			= $formData['expense_others'];
		$getlocationDetails		= $this->getTable('LeasePaymentsTable')->getUserDetailById($identity->user_id);
		if(is_object($getlocationDetails) && count($getlocationDetails) > 0)
		{
			foreach($getlocationDetails as $locKey => $locValue)
			{
				$locationValue	= stripslashes($locValue['loc_title']);
				$userName 		= stripslashes($locValue['user_firstname'])." ".stripslashes($locValue['user_lastname'])." (".stripslashes($locValue['role_name']).")";
			}
		}
		if(is_array($expenseDate) && count($expenseDate) > 0)
		{
			$objReader 			= \PHPExcel_IOFactory::createReader('Excel5');
			$excelPath			= $this->siteImageUploadPath."/monthly_expense_report/";
			$objPHPExcel 		= $objReader->load($excelPath."pedicab.xls");
			$objWorksheet 		= $objPHPExcel->getActiveSheet();
			$objRichText 		= new \PHPExcel_RichText();
			$text1 				= $objRichText->createTextRun('EXPENSE REPORT           ');
			$text1->getFont()->setName('Trebuchet MS')->setSize(24)->setBold(true)->setColor( new \PHPExcel_Style_Color( \PHPExcel_Style_Color::COLOR_PC_BLUE ) );
			$text2 				= $objRichText->createTextRun('(attach receipts)');
			$text2->getFont()->setName('Trebuchet MS')->setSize(12)->setBold(true)->setColor( new \PHPExcel_Style_Color( \PHPExcel_Style_Color::COLOR_RED ) );
			$objWorksheet->setCellValue("A1", $objRichText);
			$purpose			= $formData['expense_report'];
			$el 				= 0;
			$insertRow			= $startRow = 7;
			$AddCount			= $countDate;
			//Insert new rows
			$objWorksheet->insertNewRowBefore($insertRow,$AddCount - 1);
			//formatting the cells
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('A'.$insertRow),'A'.($insertRow + 1).':A'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('B'.$insertRow),'B'.($insertRow + 1).':B'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('C'.$insertRow),'C'.($insertRow + 1).':C'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('D'.$insertRow),'D'.($insertRow + 1).':D'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('E'.$insertRow),'E'.($insertRow + 1).':E'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('F'.$insertRow),'F'.($insertRow + 1).':F'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('G'.$insertRow),'G'.($insertRow + 1).':G'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('H'.$insertRow),'H'.($insertRow + 1).':H'.($insertRow + $AddCount - 1));
			$objWorksheet->duplicateStyle($objWorksheet->getStyle('I'.$insertRow),'I'.($insertRow + 1).':I'.($insertRow + $AddCount - 1));
			for($n = 0; $n < $AddCount; $n++)
			{
				if($el == 0)
				{
					$objWorksheet->setCellValue('G1',$locationValue)->getStyle("G1")->getFont()->setSize(14);
					$objWorksheet->setCellValue('G2',$userName)->getStyle("G2")->getFont()->setSize(10);
					$objWorksheet->setCellValue('G3',$purpose)->getStyle("G3")->getFont()->setSize(10);
					$startMonthDate		= date('n-1-Y',strtotime('this month'));
					$endMonthDate		= date('n-t-Y',strtotime('this month'));
					$monthDate			= $startMonthDate." to ".$endMonthDate;
					$objWorksheet->setCellValue('G4',$monthDate)->getStyle("G4")->getFont()->setSize(10);
				}
				//Set the value of cells 
				$objWorksheet->setCellValue('A'.($insertRow - 1),$expenseDate[$n])->getStyle("A".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('B'.($insertRow - 1),$descriptionArr[$n])->getStyle("B".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('D'.($insertRow - 1),$this->checkNumericValue($driverMeeting[$n]))->getStyle("D".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('E'.($insertRow - 1),$this->checkNumericValue($transport[$n]))->getStyle("E".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('F'.($insertRow - 1),$this->checkNumericValue($bikeParts[$n]))->getStyle("F".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('G'.($insertRow - 1),$this->checkNumericValue($officeSupplies[$n]))->getStyle("G".($insertRow - 1))->getFont()->setSize(8);
				$objWorksheet->setCellValue('H'.($insertRow - 1),$this->checkNumericValue($othersPriceArr[$n]))->getStyle("H".($insertRow - 1))->getFont()->setSize(8);
				//Sum the cells
				$objWorksheet->setCellValue("I".($insertRow - 1), "=SUM(D".($insertRow - 1).":H".($insertRow - 1).")");
				//Combine two cells
				$objWorksheet->mergeCells('B'.$insertRow.':C'.$insertRow);
				$insertRow++;
			}
			$objWorksheet->setCellValue("B".($insertRow - 1),'Total')->getStyle("B".($insertRow - 1))->getFont()->setSize(10)->setBold(true);
			$objWorksheet->setCellValue("B".($insertRow - 1),'Total')->getStyle("B".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			//Calculate Overall Total
			$objWorksheet->setCellValue("D".($insertRow - 1), "=SUM(D".($startRow - 1).":D".($insertRow - 2).")")->getStyle("D".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			$objWorksheet->setCellValue("E".($insertRow - 1), "=SUM(E".($startRow - 1).":E".($insertRow - 2).")")->getStyle("E".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			$objWorksheet->setCellValue("F".($insertRow - 1), "=SUM(F".($startRow - 1).":F".($insertRow - 2).")")->getStyle("F".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			$objWorksheet->setCellValue("G".($insertRow - 1), "=SUM(G".($startRow - 1).":G".($insertRow - 2).")")->getStyle("G".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			$objWorksheet->setCellValue("H".($insertRow - 1), "=SUM(H".($startRow - 1).":H".($insertRow - 2).")")->getStyle("H".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			$objWorksheet->setCellValue("I".($insertRow - 1), "=SUM(I".($startRow - 1).":I".($insertRow - 2).")")->getStyle("I".($insertRow - 1))->applyFromArray(array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99ccff'))));
			if(isset($formData['expense_reinbursement']) && $formData['expense_reinbursement'] != '0000-00-00')
			{
				$reimbursementDate	= date('n-j-Y',strtotime($formData['expense_reinbursement']));
				$objWorksheet->setCellValue("D".($insertRow + 2),$reimbursementDate)->getStyle("D".($insertRow + 2))->getFont()->setSize(10);
			}
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
			$objWriter->save($excelPath.'Monthly_Expense_Report_'.date('n-Y').".xls");
		}
	}
	public function deleteExpensePriceAction()
	{
		$request 		 				= $this->getRequest();
		if ($request->isPost())
		{
			$matches					= $this->getEvent()->getRouteMatch();
			$priceId					= $matches->getParam('id', '');
			$priceCalculation 			= $totalDriver = $totalTransport = $totalParts = $totalSupplies = $totalOthers = $expenceCount = $countDate = 0;
			if($priceId)
			{
				$formData				= $request->getPost();
				$expenseId				= $formData['expense_id'];
				$countDate				= count($formData['expense_date']);
				$driverMeeting			= $formData['expense_lodging'];
				$transport				= $formData['expense_transport'];
				$bikeParts				= $formData['expense_meals'];
				$officeSupplies			= $formData['expense_others_supplies'];
				$othersPriceArr			= $formData['expense_others'];
				for($e = 0; $e < $countDate; $e++)
				{
					$driverPrice		= $transportPrice = $partsPrice = $suppliesPrice = $othersPrice = $totalRow = 0;
					$driverPrice		= $this->checkNumericValue($driverMeeting[$e]);
					$transportPrice		= $this->checkNumericValue($transport[$e]);
					$partsPrice			= $this->checkNumericValue($bikeParts[$e]);
					$suppliesPrice		= $this->checkNumericValue($officeSupplies[$e]);
					$othersPrice		= $this->checkNumericValue($othersPriceArr[$e]);
					$priceCalculation	= $priceCalculation + $driverPrice + $transportPrice + $partsPrice + $suppliesPrice + $othersPrice;
					$totalDriver		= $totalDriver + $driverPrice;
					$totalTransport		= $totalTransport + $transportPrice;
					$totalParts			= $totalParts + $partsPrice;
					$totalSupplies		= $totalSupplies + $suppliesPrice;
					$totalOthers		= $totalOthers + $othersPrice;
					$totalRow			= $driverPrice + $transportPrice + $partsPrice + $suppliesPrice + $othersPrice;
				}
				$updateString			= " expense_driver_total = '".addslashes($totalDriver)."', expense_transport_total = '".addslashes($totalTransport)."', expense_bike_parts_total = '".addslashes($totalParts)."', expense_office_total = '".addslashes($totalSupplies)."', expense_others_total = '".addslashes($totalOthers)."', expense_overall_total = '".addslashes($priceCalculation)."'";
				$updateArray			= " price_status = 0";
				$this->getTable('LeasePaymentsTable')->updateMonthlyExpense($updateString,$expenseId);
				$this->getTable('LeasePaymentsTable')->updateMonthlyExpensePrice($updateArray,$priceId);
			}
		}
		echo 1;die();
	}
	public function viewExpenseReportAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 					= new ViewModel();
	    $result->setTerminal(true);
		$expenseId 					= (int) $this->params()->fromRoute('id', 0);
		$datetime					= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$expenseReportDetails		= '';
		if($expenseId)
		{
			$expenseReportDetails	= $this->getTable('LeasePaymentsTable')->getMonthlyExpenseDetails($expenseId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'expenseReportDetails'	=> $expenseReportDetails,
				'pc_users'				=> $this->pcUser,
				'fileUrl'				=> $this->siteImageUploadPath."/monthly_expense",
				'siteUrl'				=> $this->siteImagePath,
				'datetime'				=> $datetime,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function editExpenseReportAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 					= new ViewModel();
	    $result->setTerminal(true);
		$expenseId 					= (int) $this->params()->fromRoute('id', 0);
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'expenseId'				=> $expenseId,
				'pc_users'				=> $this->pcUser,
				'sitePath'				=> $this->sitePath,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function changeExpenseAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		if($request->isPost())
		{
			$formData			= $request->getPost();
			$expenseId			= $formData['expense_id'];
			if($expenseId)
			{
				$tempDate		= str_replace('-', '/', $formData['expense_date']);
				$reimbDate		= date('Y-m-d', strtotime($tempDate));
				$updateString	= " expense_reinbursement_date = '".addslashes($reimbDate)."'";
				$this->getTable('LeasePaymentsTable')->updateMonthlyExpense($updateString,$expenseId);
			}
		}
		echo 1;
		die();
	}
	public function approveExpenseAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$expenseId 				= (int) $this->params()->fromRoute('id', 0);
		$getExpenseDetails		= $insertNotifyArray = $insertMultiString = '';
		$formData				= array();
		if($expenseId)
		{
			$getExpenseDetails		= $this->getTable('LeasePaymentsTable')->getMonthlyExpenseDetails($expenseId);
			if(is_object($getExpenseDetails) && count($getExpenseDetails) > 0)
			{
				$nk	= 0;
				foreach($getExpenseDetails as $expKey => $expValue)
				{
					if($nk == 0)
					{
						if(isset($expValue['fk_user_id']) && $expValue['fk_user_id'] != '')
						{
							$notifySubject					= "Monthly Expense Report for the month of ".date('F, Y')." has been approved";
							$notifyDate						= date('n-j-Y',strtotime($expValue['expense_iscreated_date']));
							$notifyType						= "13";
							$insertNotifyArray[]			= "'".$expenseId."','".$identity->user_id."','".$expValue['fk_user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
						}
					}
					$formData['expense_date'][]				= $expValue['price_date'];
					$formData['expense_desc'][]				= $expValue['price_desc'];
					$formData['expense_lodging'][]			= $expValue['price_driver'];
					$formData['expense_transport'][]		= $expValue['price_transport'];
					$formData['expense_meals'][]			= $expValue['price_bike_parts'];
					$formData['expense_others_supplies'][]	= $expValue['price_office_supplies'];
					$formData['expense_others'][]			= $expValue['price_others'];
					$formData['expense_report']				= $expValue['expense_purpose'];
					$formData['expense_reinbursement']		= $expValue['expense_reinbursement_date'];
					$nk++;
				}
				if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
				{
					$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
				}
				if(isset($insertMultiString) && $insertMultiString != '')
				{
					$this->getTable('LeasePaymentsTable')->insertManagerNotification($insertMultiString);
				}
			}
			$updateString	= " expense_status = 1";
			$this->getTable('LeasePaymentsTable')->updateMonthlyExpense($updateString,$expenseId);
			$this->generateMonthlyExcelReport($identity, $formData);
		}
		return $this->redirect()->toRoute('financialmanagement', array('controller' => 'financial', 'action' => 'monthly-expense'));
	}
	private function checkNumericValue($value)
	{
		$numeric		= 0;
		if(is_numeric($value))
		{
			$numeric	= $value;
		}
		return $numeric;
	}
	public function testAction()
	{
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==get_magic_quotes_gpc==>".get_magic_quotes_gpc()."<==";
		
		$inputArray		= array("test's array 1", "test's array 2", "test's array 3", "test's array 4");
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==inputArray==><pre>"; print_r($inputArray); echo "</pre><==";
		
		$addSlashes		= $this->getCommonDataObj()->customizedAddSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==addSlashes==><pre>"; print_r($addSlashes); echo "</pre><==";
		
		$stripSlashes	= $this->getCommonDataObj()->customizedStripSlashes($inputArray);
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==stripSlashes==><pre>"; print_r($stripSlashes); echo "</pre><==";
		
//		phpinfo();
		
		return $this->getResponse();
		
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
