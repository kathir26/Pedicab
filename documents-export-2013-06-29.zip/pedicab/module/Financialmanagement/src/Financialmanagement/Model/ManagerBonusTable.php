<?php
namespace Financialmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class ManagerBonusTable extends AbstractTableGateway
{
    protected $table = 'manager_bonus';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new ManagerBonus());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getManagerBonus($manager_bonus_id)
    {
        $id  	= (int) $manager_bonus_id;
        $rowset = $this->select(array('manager_bonus_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveManagerBonus($managerBonusDetails)
    {
		$data = array();
		foreach($managerBonusDetails as $key => $value) {
			if($key != 'manager_bonus_id') {
				$data[$key]	= $managerBonusDetails[$key];
			}
		}
		
        $manager_bonus_id = (int)$managerBonusDetails["manager_bonus_id"];
        if (!$manager_bonus_id) {
			$data['manager_bonus_created_date']  =  $managerBonusDetails["manager_bonus_created_date"];
			/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Insert==><pre>"; print_r($data); echo "</pre><==";
			return true;*/
            $this->insert($data);
			$lastInsertId  				 =  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getManagerBonus($manager_bonus_id)) {
				/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
				return true;*/
                $this->update($data, array('manager_bonus_id' => $manager_bonus_id));
				return $manager_bonus_id;
            } else {
                throw new \Exception('Form event_id does not exist');
            }
        }
    }
	
	/*
	*	Get the Manager Bonus details listing
	*/
	public function getManagerBonusList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			  =  $pcUser->location_id;
		$whereClause1   	  = ' WHERE 1 And manager_bonus.manager_bonus_isdelete = 0 And manager_bonus.fk_location_id = "'.$locationId.'" ';
		$whereClause2   	  = ' WHERE 1 And event.event_type = 2 And event.event_quote_type = 2 And event.event_category = 2 And event.install_bonus_location_manager != 0 And shift.fk_location_id = "'.$locationId.'" ';
		
		$listingSession 	  = new Container('bonusListing');
		
		if($listingSession->offsetExists('bonus_from_date') && $listingSession->bonus_from_date != '') {
			$tempDate		  = str_replace('-', '/', $listingSession->bonus_from_date);
			$bonusFromDate 	  = date('Y-m-d', strtotime($tempDate));
			$whereClause1	 .= ' AND manager_bonus.manager_bonus_date >= "' . $bonusFromDate . '"';
			$whereClause2	 .= ' AND event.event_date >= "' . $bonusFromDate . '"';
		}
		
		if($listingSession->offsetExists('bonus_to_date') && $listingSession->bonus_to_date != '') {
			$tempDate		  = str_replace('-', '/', $listingSession->bonus_to_date);
			$bonusToDate 	  = date('Y-m-d', strtotime($tempDate));
			$whereClause1	 .= ' AND manager_bonus.manager_bonus_date <= "' . $bonusToDate . '"';
			$whereClause2	 .= ' AND event.event_date <= "' . $bonusToDate . '"';
		}
		
		if($listingSession->offsetExists('bonus_amount') && $listingSession->bonus_amount != '') {
			$whereClause1	 .= ' AND manager_bonus.manager_bonus_amount = ' . $listingSession->bonus_amount;
			$whereClause2	 .= ' AND event.install_bonus_location_manager = ' . $listingSession->bonus_amount;
		}
		/*
		$orderClause		  = '';
		if($listingSession->offsetExists('sortBy') && $listingSession->sortBy != '') {
			if($listingSession->sortBy == "shift_date") {
				$sortBy		  = ($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) ? ' DESC' : ' ';
				$orderClause  = ' ORDER BY sdt.shift_dt_start_date'.$sortBy.', event.event_date ';
			} else if($listingSession->sortBy == "user_name") {
				$sortBy		  = ($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) ? ' DESC' : ' ';
				$orderClause  = ' ORDER BY user.user_lastname'.$sortBy.', user.user_firstname ';
			} else {
				$joinPrefix	  = "lease_payments";
				$orderClause .= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
			}
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY lease_payments.lease_id DESC';
		}
		*/
		$sql	= '(SELECT manager_bonus_id, manager_bonus_date, manager_bonus_amount, manager_bonus_description, fk_location_id as location_id,
					1111 as event_id, 2222 as event_date, 3333 as event_title, 4444 as event_type, 5555 as install_bonus_location_manager, 1 as bonus_type
					FROM manager_bonus '.$whereClause1.')
					UNION
					(SELECT 1111 as manager_bonus_id, 2222 as manager_bonus_date, 3333 as manager_bonus_amount, 4444 as manager_bonus_description, shift.fk_location_id as location_id,
					event.event_id, event.event_date, event.event_title, event.event_type, event.install_bonus_location_manager, 2 as bonus_type
					FROM event as event 
					left join shift as shift on (shift.shift_id = event.fk_shift_id) '.$whereClause2.'
					);';
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	/*
	*	Get the Manager Bonus Details details
	*/
	public function viewManagerBonusDetails($bonusId)
	{
		$whereClause = ' WHERE 1 and manager_bonus_id = "'.$bonusId.'" ';
		$sql	= 'SELECT manager_bonus_id, manager_bonus_date, manager_bonus_amount, manager_bonus_description, fk_location_id as location_id
				   FROM manager_bonus';
		$sql   .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==viewManagerBonusDetails==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Delete the Manager Bonus details
	*/
	public function deleteManagerBonus($manager_bonus_id)
    {
        $data = array(
			'manager_bonus_isdelete' => '1'
        );
		$this->update($data, array('manager_bonus_id' => $manager_bonus_id));
    }
}