<?php
namespace Financialmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class LeasePaymentsTable extends AbstractTableGateway
{
    protected $table = 'lease_payments';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new LeasePayments());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getLeasePayments($lease_id)
    {
        $id  	= (int) $lease_id;
        $rowset = $this->select(array('lease_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveLeasePayments($leasePaymentsDetails)
    {
		$data = array();
		foreach($leasePaymentsDetails as $key => $value) {
			if($key != 'lease_id') {
				$data[$key]	= $leasePaymentsDetails[$key];
			}
		}
		
        $lease_id = (int)$leasePaymentsDetails["lease_id"];
        if (!$lease_id) {
			$data['lease_created_date']  =  $leasePaymentsDetails["lease_created_date"];
			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Insert==><pre>"; print_r($data); echo "</pre><==";
			return true;
            $this->insert($data);
			$lastInsertId  				 =  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getLeasePayments($lease_id)) {
				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
				return true;
                $this->update($data, array('lease_id' => $lease_id));
				return $lease_id;
            } else {
                throw new \Exception('Form event_id does not exist');
            }
        }
    }
	
	/*
	*	Get the Lease Payment Details details
	*/
	public function getAllLeasePayments()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	 = $pcUser->location_id;
		$whereClause = ' WHERE 1 And lease_payments.lease_isdelete = 0 and lease_payments.lease_status = 1 and lease_payments.fk_location_id = "'.$locationId.'" ';
		
		// TODO : Need To handle conditions
		/*
		$leaseDate	  = date('Y-m-d');		//	lease_created_date,	lease_updated_date
		$whereClause .= ' AND (lease_payments.lease_created_date >= "'.$leaseDate.'" || lease_payments.lease_created_date <= "'.$leaseDate.'")';
		*/
		
		$sql	= 'SELECT lease_payments.lease_id, lease_payments.fk_user_id, lease_payments.fk_shift_request_id, lease_payments.lease_pay_type, lease_payments.pay_amount_type, 
				   lease_payments.lease_pay_amount, lease_payments.payment_amount, lease_payments.discount_mechanical_issue,lease_payments.discount_bad_weather,
				   lease_payments.discount_other_reason, lease_payments.lease_status, lease_payments.fk_location_id,
				   shift.shift_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, sdt.shift_dt_bike_rental,shift.shift_occurs,
				   CONCAT(user.user_firstname," ",user.user_lastname) as user_name, user.user_firstname, user.user_lastname, user.user_amount_balance,
				   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date,
				   event.event_id, event.event_date, event.shift_bike_rental,
				   shift_request.shift_request_status, shift_request.shift_request_id
				   FROM lease_payments as lease_payments
				   left join shift_request as shift_request on (shift_request.shift_request_id = lease_payments.fk_shift_request_id)
				   left join shift as shift on (shift.shift_id = shift_request.fk_shift_id)
				   left join shift_date_timing as sdt on (shift_request.fk_shift_dt_id = sdt.shift_dt_id)
				   left join event as event on (shift_request.fk_shift_id = event.fk_shift_id)
				   left join user as user on (user.user_id = lease_payments.fk_user_id)';
		$sql   .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getAllLeasePayments==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Get the Lease Payments details listing
	*/
	public function getLeasePaymentsList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			  = $pcUser->location_id;
		$whereClause   	  	  = ' WHERE 1 And lease_payments.lease_isdelete = 0 and lease_payments.lease_status = 2 and lease_payments.fk_location_id = "'.$locationId.'" ';
		
		$listingSession 	  = new Container('leasePaymentsListing');
		if($listingSession->offsetExists('shift_date') && $listingSession->shift_date != '') {
			$tempDate		  = str_replace('-', '/', $listingSession->shift_date);
			$shift_date		  = date('Y-m-d', strtotime($tempDate));
			$whereClause	 .= ' AND (sdt.shift_dt_start_date = "'.addslashes($shift_date).'" || event.event_date = "'.addslashes($shift_date).'")';
		}
		
		if($listingSession->offsetExists('user_name') && $listingSession->user_name != '') {
			$whereClause	 .= ' AND (user.user_firstname like "%' . addslashes($listingSession->user_name) . '%" || user.user_lastname like "%' . addslashes($listingSession->user_name) . '%" )';
		}
		
		$orderClause		  = '';
		if($listingSession->offsetExists('sortBy') && $listingSession->sortBy != '') {
			if($listingSession->sortBy == "shift_date") {
				$sortBy		  = ($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) ? ' DESC' : ' ';
				$orderClause  = ' ORDER BY sdt.shift_dt_start_date'.$sortBy.', event.event_date ';
			} else if($listingSession->sortBy == "user_name") {
				$sortBy		  = ($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) ? ' DESC' : ' ';
				$orderClause  = ' ORDER BY user.user_lastname'.$sortBy.', user.user_firstname ';
			} else {
				$joinPrefix	  = "lease_payments";
				$orderClause .= ' ORDER BY '.$joinPrefix.'.'.$listingSession->sortBy;
			}
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY lease_payments.lease_id DESC';
		}
		
		$sql	= 'SELECT lease_payments.lease_id, lease_payments.fk_user_id, lease_payments.fk_shift_request_id, lease_payments.lease_pay_type, lease_payments.lease_pay_amount, 
				   lease_payments.payment_amount,lease_payments.discount_mechanical_issue,lease_payments.discount_bad_weather,lease_payments.discount_other_reason, 
				   lease_payments.lease_status, lease_payments.fk_location_id, lease_payments.pay_amount_type,
				   shift.shift_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, sdt.shift_dt_bike_rental,shift.shift_occurs,
				   CONCAT(user.user_firstname," ",user.user_lastname) as user_name, user.user_firstname, user.user_lastname, user.user_amount_balance,
				   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date,
				   event.event_id, event.event_date, event.shift_bike_rental,
				   shift_request.shift_request_status, shift_request.shift_request_id
				   FROM lease_payments as lease_payments
				   left join shift_request as shift_request on (shift_request.shift_request_id = lease_payments.fk_shift_request_id)
				   left join shift as shift on (shift.shift_id = shift_request.fk_shift_id)
				   left join shift_date_timing as sdt on (shift_request.fk_shift_dt_id = sdt.shift_dt_id)
				   left join event as event on (shift_request.fk_shift_id = event.fk_shift_id)
				   left join user as user on (user.user_id = lease_payments.fk_user_id)';
		$sql   .=  $whereClause . ' ' . $orderClause;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		
		return $result;
	}
	
	/*
	*	Delete the Event details
	*/
	public function deleteLeasePayments($lease_id)
    {
        $data = array(
			'lease_isdelete' => '1'
        );
		$this->update($data, array('lease_id' => $lease_id));
    }
}