<?php
namespace Financialmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class LeasePayments implements InputFilterAwareInterface
{
    public $lease_id;
    public $fk_user_id;
    public $fk_shift_request_id;
	public $shifts_date;
	public $lease_pay_type;
	public $lease_pay_amount;
	public $payment_amount;
	public $discount_mechanical_issue;
	public $discount_bad_weather;
	public $discount_other_reason;
	public $lease_status;
	public $lease_created_date;
	public $lease_updated_date;
	public $lease_isdelete;
	
    public function exchangeArray($data)
    {
		$this->lease_id						= (isset($data['lease_id'])) ? $data['lease_id'] : null;
		$this->fk_user_id					= (isset($data['fk_user_id'])) ? $data['fk_user_id'] : null;
        $this->fk_shift_request_id			= (isset($data['fk_shift_request_id'])) ? $data['fk_shift_request_id'] : null;
		$this->shifts_date					= (isset($data['shifts_date'])) ? $data['shifts_date'] : null;
        $this->lease_pay_type				= (isset($data['lease_pay_type'])) ? $data['lease_pay_type'] : null;
		$this->lease_pay_amount				= (isset($data['lease_pay_amount'])) ? $data['lease_pay_amount'] : null;
		$this->payment_amount				= (isset($data['payment_amount'])) ? $data['payment_amount'] : null;
		$this->discount_mechanical_issue	= (isset($data['discount_mechanical_issue'])) ? $data['discount_mechanical_issue'] : null;
		$this->discount_bad_weather			= (isset($data['discount_bad_weather'])) ? $data['discount_bad_weather'] : null;
		$this->discount_other_reason		= (isset($data['discount_other_reason'])) ? $data['discount_other_reason'] : null;
		$this->lease_status					= (isset($data['lease_status'])) ? $data['lease_status'] : null;
		$this->lease_created_date			= (isset($data['lease_created_date'])) ? $data['lease_created_date'] : null;
		$this->lease_updated_date			= (isset($data['lease_updated_date'])) ? $data['lease_updated_date'] : null;
		$this->lease_isdelete				= (isset($data['lease_isdelete'])) ? $data['lease_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
