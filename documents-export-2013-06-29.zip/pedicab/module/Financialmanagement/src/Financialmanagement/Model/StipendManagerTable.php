<?php
namespace Financialmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class StipendManagerTable extends AbstractTableGateway
{
    protected $table = 'stipend_manager';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new LeasePayments());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getStipend($stipend_id)
    {
        $id  	= (int) $stipend_id;
        $rowset = $this->select(array('stipend_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveStipend($stipendDetails)
    {
		$data = array();
		foreach($stipendDetails as $key => $value) {
			if($key != 'stipend_id' && $key != 'stipend_created_date' ) {
				$data[$key]	= $stipendDetails[$key];
			}
		}
		
        $stipend_id = (int)$stipendDetails["stipend_id"];
        if (!$stipend_id) {
			$data['stipend_created_date']  =  $stipendDetails["stipend_created_date"];
			/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Insert==><pre>"; print_r($data); echo "</pre><==";
			return true;*/
            $this->insert($data);
			$lastInsertId  				 =  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getStipend($stipend_id)) {
				/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
				return true;*/
                $this->update($data, array('stipend_id' => $stipend_id));
				return $stipend_id;
            } else {
                throw new \Exception('Form event_id does not exist');
            }
        }
    }
	
	/*
	*	Get the Lease Payments details listing
	*/
	public function getStipendList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			  = $pcUser->location_id;
		$whereClause   	  	  = ' WHERE 1 And stipend_isdelete = 0 and fk_location_id = "'.$locationId.'" ';
		
		$listingSession 	  = new Container('stipendListing');
		if($listingSession->offsetExists('stipend_from_date') && $listingSession->stipend_from_date != '') {
			$tempDate		  = str_replace('-', '/', $listingSession->stipend_from_date);
			$from_date		  = date('Y-m-d', strtotime($tempDate));
			$whereClause	 .= ' AND stipend_date >= "'.$from_date.'" ';
		}
		
		if($listingSession->offsetExists('stipend_to_date') && $listingSession->stipend_to_date != '') {
			$tempDate		  = str_replace('-', '/', $listingSession->stipend_to_date);
			$to_date		  = date('Y-m-d', strtotime($tempDate));
			$whereClause	 .= ' AND stipend_date <= "'.$to_date.'" ';
		}
		
		if($listingSession->offsetExists('stipend_amount') && $listingSession->stipend_amount != '') {
			$whereClause	 .= ' AND stipend_amount = ' . $listingSession->stipend_amount . ' ';
		}
		
		$orderClause		  = '';
		if($listingSession->offsetExists('sortBy') && $listingSession->sortBy != '') {
			$orderClause .= ' ORDER BY '.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY stipend_id DESC';
		}
		
		$sql	= 'SELECT stipend_id, stipend_date, stipend_amount, stipend_created_date, stipend_updated_date, fk_location_id, stipend_isdelete
				   FROM stipend_manager';
		$sql   .=  $whereClause . ' ' . $orderClause;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	/*
	*	Get the Stipend Details details
	*/
	public function getStipendDetail($stipendId)
	{
		$whereClause = ' WHERE 1 and stipend_id = "'.$stipendId.'" ';
		$sql	= 'SELECT stipend_id, stipend_date, stipend_amount, stipend_created_date, stipend_updated_date, fk_location_id, stipend_isdelete
				   FROM stipend_manager';
		$sql   .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==viewStipendDetails==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Delete the Event details
	*/
	public function deleteStipend($stipendId)
    {
        $data = array(
			'stipend_isdelete' => '1'
        );
		$this->update($data, array('stipend_id' => $stipendId));
    }
}