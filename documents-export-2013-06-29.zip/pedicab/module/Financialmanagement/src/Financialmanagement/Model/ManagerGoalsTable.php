<?php
namespace Financialmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class ManagerGoalsTable extends AbstractTableGateway
{
    protected $table = 'manager_goals';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new ManagerGoals());
        $this->initialize();
    }
	
	private function getSqlStrings($select) {
		if($select) {
			return $select->getSqlString();
		} else {
			return false;
		}
	}
	
    public function getManagerGoals($goalsId)
    {
        $id  	= (int) $goalsId;
        $rowset = $this->select(array('manager_goals_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveManagerGoals($goalsDetails)
    {
		$data = array();
		foreach($goalsDetails as $key => $value) {
			if($key != 'manager_goals_id' && $key != 'manager_goals_created_date') {
				$data[$key]	= $goalsDetails[$key];
			}
		}
		
        $goalsId = (int)$goalsDetails["manager_goals_id"];
        if (!$goalsId) {
			$data['manager_goals_created_date']  =  $goalsDetails["manager_goals_created_date"];
			/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Insert==><pre>"; print_r($data); echo "</pre><==";
			return true;*/
            $this->insert($data);
			$lastInsertId  				 =  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        } else {
            if ($this->getManagerGoals($goalsId)) {
				/*echo "<br/>==Line==".__LINE__."==File==".__FILE__."==Update==><pre>"; print_r($data); echo "</pre><==";
				return true;*/
                $this->update($data, array('manager_goals_id' => $goalsId));
				return $goalsId;
            } else {
                throw new \Exception('Form event_id does not exist');
            }
        }
    }
	
	/*
	*	Get the Manager Goals details listing
	*/
	public function getManagerGoalsList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			  = $pcUser->location_id;
		$whereClause   	  	  = ' WHERE 1 And manager_goals_isdelete = 0 and fk_location_id = "'.$locationId.'" ';
		
		$listingSession 	  = new Container('goalsListing');
		if($listingSession->offsetExists('goals_from_date') && $listingSession->goals_from_date != '') {
			$tempDate		  = explode('-', $listingSession->goals_from_date);
			$tempDate		  = array_reverse($tempDate);
			$from_date		  = implode('-',$tempDate);
			$whereClause	 .= ' AND DATE_FORMAT(manager_goals_date, "%Y-%c") >= "'.$from_date.'" ';
		}
		
		if($listingSession->offsetExists('goals_to_date') && $listingSession->goals_to_date != '') {
			$tempDate		  = explode('-', $listingSession->goals_to_date);
			$tempDate		  = array_reverse($tempDate);
			$to_date		  = implode('-',$tempDate);
			$whereClause	 .= ' AND DATE_FORMAT(manager_goals_date, "%Y-%c") <= "'.$to_date.'" ';
		}
		
		if($listingSession->offsetExists('goals_amount') && $listingSession->goals_amount != '') {
			$whereClause	 .= ' AND manager_goals_amount = ' . $listingSession->goals_amount . ' ';
		}
		
		if($listingSession->offsetExists('goals_target_drivers') && $listingSession->goals_target_drivers != '') {
			$whereClause	 .= ' AND manager_goals_target_drivers = ' . $listingSession->goals_target_drivers . ' ';
		}
		
		$orderClause		  = '';
		if($listingSession->offsetExists('sortBy') && $listingSession->sortBy != '') {
			$orderClause .= ' ORDER BY '.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY manager_goals_id DESC';
		}
		
		$sql	= 'SELECT manager_goals_id, manager_goals_date, manager_goals_amount, manager_goals_target_drivers, manager_goals_created_date, manager_goals_updated_date, 
				   fk_location_id, manager_goals_isdelete
				   FROM manager_goals';
		$sql   .=  $whereClause . ' ' . $orderClause;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	/*
	*	Get the Historical Data listing
	*/
	public function getHistoricalDataList()
	{
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId			  = $pcUser->location_id;
		$whereClause   	  	  = ' WHERE 1 And manager_goals_isdelete = 0 and fk_location_id = "'.$locationId.'" ';
		
		$listingSession 	  = new Container('historicalDataListing');
		if($listingSession->offsetExists('from_date') && $listingSession->from_date != '') {
			/*$tempDate		  = str_replace('-', '/', $listingSession->from_date);
			$from_date		  = date('Y-m', strtotime($tempDate));
			*/
			$tempDate		  = explode('-', $listingSession->from_date);
			$tempDate		  = array_reverse($tempDate);
			$from_date		  = implode('-',$tempDate);
			$whereClause	 .= ' AND DATE_FORMAT(manager_goals_date, "%Y-%c") >= "'.$from_date.'" ';
		}
		
		if($listingSession->offsetExists('to_date') && $listingSession->to_date != '') {
			/*
			$tempDate		  = str_replace('-', '/', $listingSession->to_date);
			$to_date		  = date('Y-m', strtotime($tempDate));
			*/
			$tempDate		  = explode('-', $listingSession->to_date);
			$tempDate		  = array_reverse($tempDate);
			$to_date		  = implode('-',$tempDate);
			$whereClause	 .= ' AND DATE_FORMAT(manager_goals_date, "%Y-%c") <= "'.$to_date.'" ';
		}
		
		$orderClause		  = '';
		if($listingSession->offsetExists('sortBy') && $listingSession->sortBy != '') {
			$orderClause .= ' ORDER BY '.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	 = ' ORDER BY manager_goals_id DESC';
		}
		
		$sql	= 'SELECT manager_goals_id, manager_goals_date, manager_goals_amount, manager_goals_target_drivers, manager_goals_created_date, manager_goals_updated_date, 
				   fk_location_id, manager_goals_isdelete
				   FROM manager_goals';
		$sql   .=  $whereClause . ' ' . $orderClause;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	/*
	*	Get the Manager Goals Details details
	*/
	public function getManagerGoalsDetails($goalsId)
	{
		$whereClause = ' WHERE 1 and manager_goals_id = "'.$goalsId.'" ';
		$sql	= 'SELECT manager_goals_id, manager_goals_date, manager_goals_amount, manager_goals_target_drivers, manager_goals_created_date, manager_goals_updated_date, 
				   fk_location_id, manager_goals_isdelete
				   FROM manager_goals';
		$sql   .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getManagerGoalsDetails==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		return $result;
	}
	
	/*
	*	Delete the Manager Goals details
	*/
	public function deleteManagerGoals($goalsId)
    {
        $data = array(
			'manager_goals_isdelete' => '1'
        );
		$this->update($data, array('manager_goals_id' => $goalsId));
    }
}