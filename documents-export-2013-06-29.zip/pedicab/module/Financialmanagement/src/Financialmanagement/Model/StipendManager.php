<?php
namespace Financialmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class StipendManager implements InputFilterAwareInterface
{
    public $stipend_id;
    public $stipend_date;
	public $stipend_amount;
	public $stipend_created_date;
	public $stipend_updated_date;
	public $fk_location_id;
	public $stipend_isdelete;
	
    public function exchangeArray($data)
    {
		$this->stipend_id			= (isset($data['stipend_id'])) ? $data['stipend_id'] : null;
        $this->stipend_date			= (isset($data['stipend_date'])) ? $data['stipend_date'] : null;
        $this->stipend_amount		= (isset($data['stipend_amount'])) ? $data['stipend_amount'] : null;
		$this->stipend_created_date	= (isset($data['stipend_created_date'])) ? $data['stipend_created_date'] : null;
		$this->stipend_updated_date	= (isset($data['stipend_updated_date'])) ? $data['stipend_updated_date'] : null;
		$this->fk_location_id		= (isset($data['fk_location_id'])) ? $data['fk_location_id'] : null;
		$this->stipend_isdelete		= (isset($data['stipend_isdelete'])) ? $data['stipend_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
