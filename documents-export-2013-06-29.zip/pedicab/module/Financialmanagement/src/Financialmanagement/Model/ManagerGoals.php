<?php
namespace Financialmanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class ManagerGoals implements InputFilterAwareInterface
{
    public $manager_bonus_id;
    public $manager_bonus_date;
    public $manager_bonus_amount;
	public $manager_bonus_description;
	public $manager_bonus_created_date;
	public $manager_bonus_updated_date;
	public $fk_location_id;
	public $manager_bonus_isdelete;
	
    public function exchangeArray($data)
    {
		$this->manager_bonus_id				= (isset($data['manager_bonus_id'])) ? $data['manager_bonus_id'] : null;
		$this->manager_bonus_date			= (isset($data['manager_bonus_date'])) ? $data['manager_bonus_date'] : null;
        $this->manager_bonus_amount			= (isset($data['manager_bonus_amount'])) ? $data['manager_bonus_amount'] : null;
		$this->manager_bonus_description	= (isset($data['manager_bonus_description'])) ? $data['manager_bonus_description'] : null;
        $this->manager_bonus_created_date	= (isset($data['manager_bonus_created_date'])) ? $data['manager_bonus_created_date'] : null;
		$this->manager_bonus_updated_date	= (isset($data['manager_bonus_updated_date'])) ? $data['manager_bonus_updated_date'] : null;
		$this->fk_location_id				= (isset($data['fk_location_id'])) ? $data['fk_location_id'] : null;
		$this->manager_bonus_isdelete		= (isset($data['manager_bonus_isdelete'])) ? $data['manager_bonus_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
