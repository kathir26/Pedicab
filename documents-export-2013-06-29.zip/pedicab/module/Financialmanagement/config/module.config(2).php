<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Financialmanagement\Controller\Financial',
                        'action'     => 'deposit-lease-fees',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'financialmanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/financialmanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'    => 'Financial',
                        'action'        => 'deposit-lease-fees',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/financialmanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'financial-event-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/financial-event-page[/[:payStatus[/[:pageid]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'    => 'Financial',
                        'action'        => 'financial-event-list',
						'payStatus' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'financial-event-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/financial-event-list[/[:payStatus[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'    => 'Financial',
                        'action'        => 'financial-event-list',
						'payStatus' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'financial-event-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/financial-event-listcount[/[:payStatus[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'   => 'Financial',
                        'action'       => 'financial-event-list',
						'payStatus'    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'deposit-lease-fees-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/deposit-lease-fees-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'    => 'Financial',
                        'action'        => 'deposit-lease-fees-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'deposit-lease-fees-list-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/deposit-lease-fees-list-page[/[:pageid]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'    => 'Financial',
                        'action'        => 'deposit-lease-fees-list',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'deposit-lease-fees-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/deposit-lease-fees-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Financialmanagement\Controller',
                        'controller'   => 'Financial',
                        'action'       => 'deposit-lease-fees-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'Financialmanagement\Controller\Financial' 			=> 'Financialmanagement\Controller\FinancialController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
