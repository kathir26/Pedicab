<?php
namespace Schedulemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class ShiftRequestTable extends AbstractTableGateway
{
    protected $table = 'shift_request';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new ShiftRequest());
        $this->initialize();
    }
	
	public function insertConfirmedDrivers($shiftRequests, $confirmdDrivers)
    {
		$dt_id	   = ($shiftRequests['shift_occurs'] == 1) ? $shiftRequests['fk_shift_dt_id'] : 0;
		$sql	   = '';
		foreach($confirmdDrivers as $key => $userId) {
			$sql  .= "(NULL, '".$shiftRequests['fk_shift_id']."', '".$userId."', '".$shiftRequests['shift_request_status']."', '2', '".$dt_id."', '".$shiftRequests['shift_occurs']."', '".$shiftRequests['shift_request_created_date']."', '".$shiftRequests['shift_request_updated_date']."', '".$shiftRequests['shift_request_isdelete']."'), ";
		}
		if($sql) {
			if(!empty($sql)) $sql =	substr($sql, 0, -2);
			$sqlInsert 	   = "Insert into shift_request (`shift_request_id`, `fk_shift_id`, `fk_user_id`, `shift_request_status`, `shift_request_concat_status`, `fk_shift_dt_id`, `shift_occurs`, `shift_request_created_date`, `shift_request_updated_date`, `shift_request_isdelete`) VALUES ".$sql;
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==insertConfirmedDrivers==>".$sqlInsert."<==";
//			return false;
			$statement = $this->adapter->query($sqlInsert);
			$results   = $statement->execute();
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		}
    }
	
	public function updateConfirmedDrivers($shiftRequests, $confirmdDrivers)
    {
		$sql	   = '';
		$impValue  = implode(', ', $confirmdDrivers);
		if($shiftRequests['shift_occurs'] == 1) {
			$where = "where fk_shift_id = '".$shiftRequests['fk_shift_id']."' and shift_occurs = '".$shiftRequests['shift_occurs']."' and fk_shift_dt_id = '".$shiftRequests['fk_shift_dt_id']."' and fk_user_id in (".$impValue.") ";
		} else {
			$where = "where fk_shift_id = '".$shiftRequests['fk_shift_id']."' and shift_occurs = '".$shiftRequests['shift_occurs']."' and fk_user_id in (".$impValue.") ";
		}
		$updateSql = "update shift_request set shift_request_concat_status = CONCAT(shift_request_concat_status, ',', shift_request_status), shift_request_status = '".$shiftRequests['shift_request_status']."', shift_request_updated_date='".$shiftRequests["shift_request_updated_date"]."' ".$where;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==updateConfirmedDrivers==>".$updateSql."<==";
//		return false;
		$statement = $this->adapter->query($updateSql);
		$results   = $statement->execute();
    }
	
	public function getRequestedDriver($shiftId, $shiftDtId = '')
    {
		$sql		= 'SELECT shift_request.shift_request_id, shift_request.fk_shift_id, shift_request.fk_user_id, shift_request.shift_request_status, shift_request.fk_shift_dt_id, shift_request.shift_occurs,
					   user.user_firstname, user.user_lastname, user.user_id, user.user_role_id, user.user_email, user.user_telephone_number, user.user_mailing_address, 
					   user.user_text_address, user.location_id, CONCAT(user.user_firstname," ",user.user_lastname) as user_full_name
					   FROM shift_request as shift_request
					   left join user as user on (shift_request.fk_user_id = user.user_id)
					   WHERE 1 and shift_request.fk_shift_id = '.$shiftId;
		if($shiftDtId) {
			$sql   .= ' and shift_request.fk_shift_dt_id = '.$shiftDtId;
		}
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==count==>".$count."<==";
		$result->buffer();
		$result->next();
        if($count) {
             return $result;
        } else {
			 return false;
		}
    }
	
	/*
	*	Get the Shift details for Driver lease fees
	*/
	public function getShiftsDetailForDriverLeasefees($shiftRequestId)
	{
		$sql	= "SELECT shift.shift_id, shift.shift_type, shift.shift_occurs, 
				   sdt.shift_dt_id, sdt.shift_dt_bike_rental, 
				   event.event_id, event.event_type, event.shift_bike_rental, 
				   user.user_firstname, user.user_lastname, CONCAT(user.user_firstname,' ',user.user_lastname) as users_name, user_amount_balance
				   FROM shift_request as shift_request
				   left join shift as shift on (shift.shift_id = shift_request.fk_shift_id)
				   left join shift_date_timing as sdt on (sdt.shift_dt_id = shift_request.fk_shift_dt_id)
				   left join event as event on (shift.shift_id = event.fk_shift_id)
				   left join user as user on (user.user_id = shift_request.fk_user_id)
				   WHERE 1 and shift_request.shift_request_id = ".$shiftRequestId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
		$result->buffer();
		$result->next();
		if($count) {
			return $result;
		} else {
			return false;
		}
		
	}
	
	public function updateShiftManager($shiftRequests)
    {
	    if(isset($shiftRequests['shift_occurs']) && $shiftRequests['shift_occurs'] == 1) {
			$sql	= " update shift_date_timing set shift_dt_manager_id = '".$shiftRequests['shift_manager']."' where fk_shift_id = ".$shiftRequests['fk_shift_id']." and shift_dt_id = ".$shiftRequests['fk_shift_dt_id'];
		} else {
			$sql	= " update event set shift_manager_id = '".$shiftRequests['shift_manager']."' where fk_shift_id = ".$shiftRequests['fk_shift_id']." and event_id = ".$shiftRequests['event_id'];
		}
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==updateShiftManager==>".$sql."<==";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	
	public function updateShiftBikes($shiftRequests)
    {
	    if(isset($shiftRequests['shift_occurs']) && $shiftRequests['shift_occurs'] == 1) {
			$sql	= " update shift_date_timing set shift_dt_bike_available = shift_dt_bike_available - ".$shiftRequests['shift_bike_available']." where fk_shift_id = ".$shiftRequests['fk_shift_id']." and shift_dt_id = ".$shiftRequests['fk_shift_dt_id'];
		} else {
			$sql	= " update event set shift_bike_available = shift_bike_available - ".$shiftRequests['shift_bike_available']." where fk_shift_id = ".$shiftRequests['fk_shift_id']." and event_id = ".$shiftRequests['event_id'];
		}
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==updateShiftBikes==>".$sql."<==";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        return $result;
    }
	
	public function driverShiftRequest($shiftRequests)
    {
        $shiftId = (int)$shiftRequests["shiftId"];
		$userId  = (int)$shiftRequests["user_id"];
		//if($this->checkDriverRequest($shiftId, $userId)) {
			$fields  	    =  "fk_shift_id ='".$shiftRequests["shiftId"]."', fk_user_id='".$shiftRequests["user_id"]."', fk_shift_dt_id='".$shiftRequests["shift_dt_id"]."', ";
			$fields  	   .=  "shift_occurs ='".$shiftRequests["shift_occurs"]."', shift_request_status='".$shiftRequests["request_status"]."', ";
			$fields  	   .=  "shift_request_created_date ='".$shiftRequests["created_date"]."', shift_request_updated_date='".$shiftRequests["updated_date"]."', ";
			$fields  	   .=  "shift_request_concat_status ='".$shiftRequests["requ_new_status"]."'";
			$sqlInsert 	   	=  "Insert into shift_request set ".$fields;
			$statement 		=  $this->adapter->query($sqlInsert);
			$results   		=  $statement->execute();
			$lastInsertId  	=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
		/*} else {
			return false;
		}*/
    }
	
	public function checkDriverRequest($shiftId, $userId)
    {
        $sql 		= "Select count(shift_request_id ) as requestCount, shift_request_status from shift_request where fk_shift_id = ".$shiftId." and fk_user_id = ".$userId." group by shift_request_status";
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$count		= $result->count();
		$result->buffer();
		$result->next();
        if($count) {
             return false;
        } else {
			 return true;
		}
    }
	
	public function getDriverRequestDetails($shiftIds = false)
    {
        $whereClause = ' WHERE 1 and shift_request_isdelete = 0';
		if($shiftIds && is_array($shiftIds) && count($shiftIds)) {
			$idsImps 	  = implode(", ", $shiftIds);
			$whereClause .= " and shift_request.fk_shift_id in (".$idsImps.")";
		}
		$sql 		 = "Select shift_request.shift_request_id, shift_request.fk_shift_id, shift_request.fk_user_id, shift_request.shift_request_status, shift_request.fk_shift_dt_id,
		                shift_request.shift_occurs, shift_request.shift_request_created_date, shift_request.shift_request_updated_date, shift_request.shift_request_isdelete ,
					    user.user_firstname, user.user_lastname
					    from shift_request as shift_request
					    left join user as user on (shift_request.fk_user_id = user.user_id)";
		$sql        .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$count		= $result->count();
		$result->buffer();
//		$result->next();
        if($count) {
             return $result;
        } else {
			 return false;
		}
    }
	
	public function getDriverRequestDetailsForLogin($shiftIds = false)
    {
        // Todo : Location based search
		$userSession 	  = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 	  = $userSession->pc_users;
		}
		
		$locationId	 	  = $pcUser->location_id;
		$userId	 		  = $pcUser->user_id;
//		$whereClause   	  = ' WHERE 1 and shift_request.shift_request_isdelete = 0 and  shift.fk_location_id='.$locationId;
		$whereClause   	  = ' WHERE 1 and shift_request.shift_request_isdelete = 0 and  shift_request.fk_user_id='.$userId;
		$event_date   	  = date('Y-m-d', time());
		$whereClause	 .= ' AND (sdt.shift_dt_start_date = "' . $event_date . '" || event.event_date = "' . $event_date . '")';
		if($shiftIds && is_array($shiftIds) && count($shiftIds)) {
			$idsImps 	  = implode(", ", $shiftIds);
			$whereClause .= " and shift_request.fk_shift_id in (".$idsImps.")";
		}
		
		$sql 		 = "Select shift_request.shift_request_id, shift_request.fk_shift_id, shift_request.fk_user_id, shift_request.shift_request_status, shift_request.fk_shift_dt_id,
		                shift_request.shift_occurs, shift_request.shift_request_created_date, shift_request.shift_request_updated_date, shift_request.shift_request_isdelete ,
					    user.user_firstname, user.user_lastname, logtime.logtime_id, logtime.fk_user_id as fk_user_id_logtime, logtime.fk_user_role_id, logtime.fk_shift_request_id,
						logtime.logtime_intime, logtime.logtime_outtime, logtime.logtime_status
					    from shift_request as shift_request
						left join logtime as logtime on (shift_request.shift_request_id = logtime.fk_shift_request_id)
						left join shift_date_timing as sdt on (shift_request.fk_shift_id = sdt.fk_shift_id)
						left join event as event on (shift_request.fk_shift_id = event.fk_shift_id)
						left join user as user on (shift_request.fk_user_id = user.user_id)";
		$sql        .=  $whereClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$count		= $result->count();
		$result->buffer();
//		$result->next();
        if($count) {
             return $result;
        } else {
			 return false;
		}
    }
	
	/*
	*	Get the Available bikes for all shifts in a particulat day.
	*/
	public function getAllShiftAvailableBikes($shiftDetails)
    {
        // Todo : Location based search
		$userSession  = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	  = $userSession->pc_users;
		}
		$locationId	  = $pcUser->location_id;
		
		$whereClause  = ' WHERE 1 and shift.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || event.event_isdelete = 0) and shift.fk_location_id ='.$locationId;
		$whereClause .= ' AND (sdt.shift_dt_start_date = "' . $shiftDetails['shift_date'] . '" || event.event_date = "' . $shiftDetails['shift_date'] . '")';
		$whereClause .= ' AND ( (("' . $shiftDetails['start_time'] . '" <= shift.shift_start_time) AND ("' . $shiftDetails['end_time'] . '" > shift.shift_start_time)) OR (("' . $shiftDetails['start_time'] . '" >= shift.shift_start_time) AND ("' . $shiftDetails['start_time'] . '" < shift.shift_end_time)))';
		
		$sql 		  = "SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, event.event_total_bikes, event.shift_bike_available, sdt.shift_dt_start_date, event.event_date, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, sdt.shift_dt_bike_rental,
					   	 shift.shift_occurs, sdt.shift_dt_id, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, event.event_id, event.event_category, event.event_type
					   	 FROM shift as shift
					   	 left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id && sdt.shift_dt_total_bikes != 0 )
	   					 left join event as event on (shift.shift_id = event.fk_shift_id && event.event_total_bikes != 0)
					   	 left join user as user on (sdt.shift_dt_manager_id = user.user_id || event.shift_manager_id = user.user_id)";
		$sql         .=  $whereClause;
		if(in_array($_SERVER["REMOTE_ADDR"], array('192.168.1.130', '103.20.100.122', '115.248.201.61'))) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql."<==";
		}
		
		/*
		SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, sdt.shift_dt_bike_available, event.shift_bike_available, sdt.shift_dt_start_date, event.event_date, 
		shift.shift_start_time, shift.shift_end_time, shift.shift_bike_rental, shift.shift_occurs, sdt.shift_dt_id, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, 
		event.event_id, event.event_category, event.event_type FROM shift as shift left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id && sdt.shift_dt_bike_available != 0 )
		left join event as event on (shift.shift_id = event.fk_shift_id && event.shift_bike_available != 0) left join user as user on (sdt.shift_dt_manager_id = user.user_id || 
		event.shift_manager_id = user.user_id) WHERE 1 and shift.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || event.event_isdelete = 0) and shift.fk_location_id =1 AND 
		(sdt.shift_dt_start_date = "2013-03-13" || event.event_date = "2013-03-13") 
		AND ( (('10:00:00' <= shift.shift_start_time)AND('17:00:00' > shift.shift_start_time)) OR (('10:00:00' >= shift.shift_start_time)AND('10:00:00' < shift.shift_end_time)))
		*/
		//		$whereClause .= ' AND (shift.shift_start_time BETWEEN "' . $shiftDetails['start_time'] . '"  AND "' . $shiftDetails['end_time'] . '"  || shift.shift_end_time BETWEEN "' . $shiftDetails['start_time'] . '"  AND "' . $shiftDetails['end_time'] . '")';
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
//		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
//		$result->buffer();
//		$result->next();
        if($count) {
             return $result;
        } else {
			 return false;
		}
    }
	
	/*
	*	Get the Total Available bikes in locations
	*/
	public function getBikesAvailable($todayDate)
    {
        // Todo : Location based search
		$userSession  =  new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	  =  $userSession->pc_users;
		}
		$locationId	  =  $pcUser->location_id;
		$whereClause  = ' WHERE 1 and fk_location_id ='.$locationId.' and date = "' . $todayDate . '" ';
		$sql 		  = "SELECT bikes_available_id, fk_location_id, date, total_bikes, available_bikes
					   	 FROM bikes_available";
		$sql         .=  $whereClause;
		
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$count		= $result->count();
        if($count) {
             return $result;
        } else {
			 $data	= array(
			 	'location_id'	=>	$locationId,
				'date'			=>	$todayDate,
			 );
			 return $this->checkBikeAvailability($data);
		}
    }
	
	/*
	*	Check the Over all Bike Availability for an location
	*/
    public function checkBikeAvailability($data)
    {
		$sqlInsert = "Insert into bikes_available set total_bikes = (SELECT count(bike_id) FROM `bike` where fk_location_id = ".$data['location_id']." and bike_status = 1 and bike_isdelete = 0), 
					  available_bikes  =  total_bikes, date = '".$data['date']."', fk_location_id = ".$data['location_id'];
		
		$statement 	  = $this->adapter->query($sqlInsert);
		$results   	  = $statement->execute();
		$lastInsertId = $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		
		// Condition handling to get the newly added data
		if($lastInsertId) {
			$whereClause  = ' WHERE 1 and bikes_available_id ='.$lastInsertId;
			$sql 		  = "SELECT bikes_available_id, fk_location_id, date, total_bikes, available_bikes
						   	 FROM bikes_available";
			$sql         .=  $whereClause;
			
			$statement 	= $this->adapter->query($sql);
			$result		= $statement->execute();
			$count		= $result->count();
	        if($count) {
	             return $result;
	        } else {
				 return false;
			}
		} else {
			 return false;
		}
    }
	
	/*
	*	Update the Bike availability from Tables (bikes_available, shift_date_timing, shift_bike_available)
	*/
	public function updateBikesAvailable($bikeAvailability, $type = 1)
    {
	    if($type == 1) {
			$sql		= " update bikes_available set available_bikes = available_bikes - ".$bikeAvailability['bike_available']." where bikes_available_id = ".$bikeAvailability['bikes_available_id'];
		} else {
			if(isset($bikeAvailability['shift_occurs']) && $bikeAvailability['shift_occurs'] == 1) {
				$impVal = $bikeAvailability['shift_dt_id']; // total_bike
				$sql	= " update shift_date_timing set shift_dt_total_bikes = ".$bikeAvailability['total_bike'].", shift_dt_bike_available = ".$bikeAvailability['bike_available']." where shift_dt_id in (".$impVal.") ";
			} else {
				$impVal = $bikeAvailability['event_id'];
				$sql	= " update event set event_total_bikes = ".$bikeAvailability['total_bike'].", shift_bike_available = ".$bikeAvailability['bike_available']." where event_id in (".$impVal.") ";
			}
		}
		// bike_available, bikes_available_id, fk_shift_dt_id, event_id, shift_occurs
		// shift_dt_total_bikes = shift_dt_total_bikes - newcount, shift_dt_bike_available = shift_dt_bike_available - (newcount - (shift_dt_total_bikes - shift_dt_bike_available))
		//echo "<br/>==Line==".__LINE__."==updateBikesAvailable==>".$sql."<==<br/>";
//		return false;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        return $result;
    }
	
	/*
	*	Update Shift Bike Details
	*/
	public function updateShiftBikesDetails($bikeDetails)
    {
		$data = array();
		foreach($bikeDetails as $key => $value) {
			if($key != 'shift_request_id') {
				$data[$key]	= $bikeDetails[$key];
			}
		}
        $shift_request_id = (int)$bikeDetails["shift_request_id"];
        if ($shift_request_id) {
            $this->update($data, array('shift_request_id' => $shift_request_id));
			return $shift_request_id;
        }
    }
	
}