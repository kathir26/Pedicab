<?php
namespace Schedulemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class ShiftTable extends AbstractTableGateway
{
    protected $table = 'shift';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Shift());
        $this->initialize();
    }
	
	public function insertShift($shift)
    {
		$data = array(
            'fk_location_id'		=> $shift->shift_location,
			'shift_type'			=> $shift->shift_type,
            'shift_start_time'		=> $shift->shift_start_time,
			'shift_end_time' 		=> $shift->shift_end_time,
			'shift_occurs'			=> $shift->shift_occurs,
			'shift_weather' 		=> $shift->shift_weather,
			'shift_driver_note'		=> $shift->shift_driver_note,
            'shift_manager_note'	=> $shift->shift_manager_note,
			'shift_isdelete' 		=> 0,
			'shift_status' 			=> 1,
			'shift_created_date'	=> date('Y-m-d H:i:s')
        );
        $this->insert($data);
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertshiftDateTime($insert_string)
    {
		$sql 				= " INSERT INTO shift_date_timing (fk_shift_id,shift_dt_start_date,shift_dt_end_date,shift_dt_day,shift_dt_allDay,shift_dt_total_bikes,shift_dt_bike_available,shift_dt_status,shift_dt_start_date_repeat,shift_dt_end_date_repeat,shift_dt_sel_date,shift_dt_bike_rental,shift_dt_st_time,shift_dt_ed_time) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertshiftEvent($shift)
    {
		$data = " fk_shift_id 			= '".addslashes($shift['shift_id'])."' ,
				  event_title			= '".addslashes($shift['shift_event_title'])."',
            	  event_category		= '".addslashes($shift['shift_event_cat'])."',
				  shift_bike_available	= '".addslashes($shift['shift_bike_available'])."',
				  shift_bike_rental		= '".addslashes($shift['shift_bike_rental'])."',
				  event_total_bikes		= '".addslashes($shift['event_total_bikes'])."',
				  event_date			= '".$shift['shift_event_date']."',
				  event_status 			= 1,
				  event_isdelete		= 0,
            	  event_creation_date	= '".date('Y-m-d H:i:s')."',
				  event_description		= '".addslashes($shift['shift_event_des'])."'";
        $sql 				= "insert into event set ".$data;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	
	public function getshiftDetails()
	{
		$sql 		= "Select * from ".$this->table." where shift_isdelete = 0 order by shift_type asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getshiftDateTimeDetails($start_date,$end_date,$calendar_month,$pc_user_details)
	{
		$where		= '';
		if(isset($start_date) && $start_date != '' && isset($end_date) && $end_date != '')
		{
			//$where	.= " and ((sdt.shift_dt_start_date >= '".$start_date."' and sdt.shift_dt_start_date <= '".$end_date."') or (sdt.shift_dt_start_date <= '".$start_date."' and sdt.shift_dt_end_date >= '".$end_date."') or (MONTH(sdt.shift_dt_end_date) = ".$calendar_month."))";
			$where	.= " and MONTH(sdt.shift_dt_end_date) = ".$calendar_month;
		}
		$where		.= " and s.fk_location_id = ".$pc_user_details->location_id;
		$sql 		= " Select s.shift_type,s.shift_id,s.shift_occurs,sdt.shift_dt_bike_available,sdt.* from shift as s 
						left join shift_date_timing as sdt on(sdt.fk_shift_id = s.shift_id) 
						where sdt.shift_dt_status = 1 and s.shift_isdelete = 0 and s.shift_occurs = 1 ".$where." order by s.shift_type asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getshiftEventDetails($start_date,$end_date,$pc_user_details)
	{
		$where		= '';
		if(isset($start_date) && $start_date != '' && isset($end_date) && $end_date != '')
		{
			$where	.= " and (e.event_date >= '".$start_date."' and e.event_date <= '".$end_date."')";
		}
		$where		.= " and s.fk_location_id = ".$pc_user_details->location_id;
		$sql 		= " Select s.shift_type,s.shift_id,s.shift_occurs,e.shift_bike_available,e.* from shift as s 
						left join event as e on(e.fk_shift_id = s.shift_id) 
						where s.shift_isdelete = 0 and e.event_isdelete = 0 and s.shift_occurs = 2 ".$where." order by s.shift_type asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function checkShiftDateTime($shift_chk_array)
	{
		$where = '';
		if(isset($shift_chk_array['start']) && $shift_chk_array['start'] != '' && isset($shift_chk_array['end']) && $shift_chk_array['end'] != '')
		{
			$where		.= " and (sdt.shift_dt_start_date <= '".$shift_chk_array['end']."' and sdt.shift_dt_end_date >= '".$shift_chk_array['start']."') and s.shift_isdelete = 0 and s.shift_type = '".$shift_chk_array['type']."'";
		}
		if(isset($shift_chk_array['location']) && $shift_chk_array['location'] != '')
		{
			$where		.= " and s.fk_location_id = ".$shift_chk_array['location'];
		}
		if(isset($shift_chk_array['chk_dat']) && $shift_chk_array['chk_dat'] != '')
		{
			$where		.= " and sdt.shift_dt_day in (".$shift_chk_array['chk_dat'].")";
		}
		if(isset($shift_chk_array['shift_id']) && $shift_chk_array['shift_id'] != '')
		{
			$where		.= " and s.shift_id != ".$shift_chk_array['shift_id'];
		}
		$sql 			= " Select sdt.*,s.shift_type,s.shift_start_time,s.shift_end_time from shift as s 
							left join shift_date_timing as sdt on(sdt.fk_shift_id = s.shift_id) where 1 and sdt.shift_dt_status = 1 and s.shift_isdelete = 0 ".$where;
		$statement 		= $this->adapter->query($sql);
		$result			= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	
	public function getShiftsList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$todaysDate					= date('Y-m-d');
		$whereClause   	  	 		= ' WHERE 1 and shift.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || event.event_isdelete = 0) AND (sdt.shift_dt_start_date >= "' . $todaysDate . '" || event.event_date >= "' . $todaysDate . '")';
		$driverShiftListingSession 	= new Container('driverShiftListing');
		
		if($driverShiftListingSession->offsetExists('shift_date') && $driverShiftListingSession->shift_date != '') {
			$tempDate		 = str_replace('-', '/', $driverShiftListingSession->shift_date);
			$event_date   	 = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND (sdt.shift_dt_start_date = "' . $event_date . '" || event.event_date = "' . $event_date . '")';
		}
		
		if($driverShiftListingSession->offsetExists('shift_name') && $driverShiftListingSession->shift_name != '') {
			$whereClause	.= ' AND shift.shift_type = "' . $driverShiftListingSession->shift_name . '"';
		}
		
		$orderClause		 = '';
		if($driverShiftListingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($driverShiftListingSession->sortBy == "user_firstname") ? "user" : "shift";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$driverShiftListingSession->sortBy;
		}
		
		if($driverShiftListingSession->offsetExists('sortType') && $driverShiftListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, sdt.shift_dt_bike_rental,
				   shift.shift_occurs, shift.shift_created_date, shift.shift_updated_date, shift.shift_assign_status, user.user_firstname, user.user_lastname, 
				   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, sdt.shift_dt_status, sdt.shift_dt_manager_id,
				   event.event_id, event.event_title, event.event_date, event.event_category, event.event_description, event.event_status, event.shift_bike_available, event.event_total_bikes,
				   event.shift_manager_id, event.event_type,sdt.shift_dt_ed_time, sdt.shift_dt_st_time 
				   FROM shift as shift
				   left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id)
				   left join event as event on (shift.shift_id = event.fk_shift_id)
				   left join user as user on (sdt.shift_dt_manager_id = user.user_id || event.shift_manager_id = user.user_id)';
		$sql   .=  $whereClause . ' ' . $orderClause;				//	 || event.fk_shift_id is null
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function getConfirmedShiftsList($requestStatus = 2)
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 			= $userSession->pc_users;
			$userId				= $pcUser->user_id;
			$whereClause   	  	= ' WHERE 1 and shift.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || event.event_isdelete = 0) and shift_request.fk_user_id ='.$userId;
			if($requestStatus == 2) {
				$whereClause   .= ' and shift_request.shift_request_status ='.$requestStatus;
			} else {
				$whereClause   .= ' and (shift_request.shift_request_status = 1 || shift_request.shift_request_status = 3 || shift_request.shift_request_status = 4)';
			}
			
			$containerSession	= ($requestStatus == 2) ? "driverConfirmedShiftListing" : "driverRequestedShiftListing";
			$driverShiftListingSession 	= new Container($containerSession);
			
			if($driverShiftListingSession->offsetExists('shift_date') && $driverShiftListingSession->shift_date != '') {
				$tempDate		 = str_replace('-', '/', $driverShiftListingSession->shift_date);
				$event_date   	 = date('Y-m-d', strtotime($tempDate));
				$whereClause	.= ' AND (sdt.shift_dt_start_date = "' . $event_date . '" || event.event_date = "' . $event_date . '")';
			}
			
			if($driverShiftListingSession->offsetExists('shift_name') && $driverShiftListingSession->shift_name != '') {
				$whereClause	.= ' AND shift.shift_type = "' . $driverShiftListingSession->shift_name . '"';
			}
			
			$orderClause		 = '';
			if($driverShiftListingSession->offsetExists('sortBy')) {
				$joinPrefix		 = ($driverShiftListingSession->sortBy == "user_firstname") ? "user" : "shift";
				$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$driverShiftListingSession->sortBy;
			}
			
			if($driverShiftListingSession->offsetExists('sortType') && $driverShiftListingSession->sortType == 1) {
				$orderClause	.= ' DESC';
			}
			
			if($orderClause == '') {
				$orderClause	.= ' ORDER BY shift_request.shift_request_id DESC';
			}
			
			$sql	= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, sdt.shift_dt_bike_rental,
					   shift.shift_occurs, shift.shift_created_date, shift.shift_updated_date, shift.shift_assign_status, user.user_firstname, user.user_lastname, 
					   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, sdt.shift_dt_status, sdt.shift_dt_manager_id,
					   event.event_id, event.event_title, event.event_date, event.event_category, event.event_description, event.event_status, event.shift_bike_available, event.event_total_bikes,
					   event.shift_manager_id, event.event_type, shift_request.shift_request_status,shift_request.shift_request_id, sdt.shift_dt_st_time, sdt.shift_dt_ed_time 
					   FROM shift_request as shift_request
					   left join shift as shift on (shift_request.fk_shift_id = shift.shift_id)
					   left join shift_date_timing as sdt on (shift_request.fk_shift_dt_id = sdt.shift_dt_id)
					   left join event as event on (shift_request.fk_shift_id = event.fk_shift_id)
					   left join user as user on (sdt.shift_dt_manager_id = user.user_id || event.shift_manager_id = user.user_id)';
			$sql   .=  $whereClause . ' ' . $orderClause;					//	 || event.fk_shift_id is null
			
			$statement	= $this->adapter->query($sql);
			$result		= $statement->execute();
			$result		= $this->resultSetPrototype->initialize($result);
			$result->buffer();
			$result->next();
			return $result;
		} else {
			return false;
		}
	}
	
	public function getManageShiftList($ShiftDetail = '')
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$sessionKey		 		= ($ShiftDetail == 2) ? "oldmanageShiftListing" : "manageShiftListing";
		$whereClause   	  	 	= ' WHERE 1 and s.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || e.event_isdelete = 0) and s.fk_location_id = '.$pcUser->location_id;
		$shiftListingSession 	= new Container($sessionKey);
		if(isset($ShiftDetail) && $ShiftDetail == 1)
		{
			$whereClause		.= ' AND (sdt.shift_dt_start_date >= "'.date('Y-m-d').'" || e.event_date >= "'.date('Y-m-d').'")';
		}
		else if(isset($ShiftDetail) && $ShiftDetail == 2)
		{
			$whereClause		.= ' AND (sdt.shift_dt_start_date < "'.date('Y-m-d').'" || e.event_date < "'.date('Y-m-d').'")';
		}
		if($shiftListingSession->offsetExists('shift_date') && $shiftListingSession->shift_date != '') {
			$tempDate		 	= str_replace('-', '/', $shiftListingSession->shift_date);
			$shift_date			= date('Y-m-d', strtotime($tempDate));
			$whereClause		.= ' AND (sdt.shift_dt_start_date = "'.addslashes($shift_date).'" || e.event_date = "'.addslashes($shift_date).'")';
		}
		
		
		if($shiftListingSession->offsetExists('shift_type') && $shiftListingSession->shift_type != '') {
			$whereClause	.= ' AND s.shift_type = "' . $shiftListingSession->shift_type . '"';
		}
		
		$orderClause		 = $sortClause = '';
		if($shiftListingSession->offsetExists('sortBy')) {
			if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "shift_dt_bike_rental")
			{
				if($shiftListingSession->offsetExists('sortType') && $shiftListingSession->sortType == 1) {
					$sortClause	.= ' DESC';
				}
				$orderClause	= ' ORDER BY sdt.'.$shiftListingSession->sortBy.' '.$sortClause.',e.shift_bike_rental ';
			}
			else if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "shift_dt_st_time")
			{
				if($shiftListingSession->offsetExists('sortType') && $shiftListingSession->sortType == 1) {
					$sortClause	.= ' DESC';
				}
				$orderClause	= ' ORDER BY sdt.'.$shiftListingSession->sortBy.' '.$sortClause.',s.shift_start_time ';
			}
			else if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "shift_dt_ed_time")
			{
				if($shiftListingSession->offsetExists('sortType') && $shiftListingSession->sortType == 1) {
					$sortClause	.= ' DESC';
				}
				$orderClause	= ' ORDER BY sdt.'.$shiftListingSession->sortBy.' '.$sortClause.',s.shift_end_time ';
			}
			else if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "shift_dt_start_date")
			{
				if($shiftListingSession->offsetExists('sortType') && $shiftListingSession->sortType == 1) {
					$sortClause	.= ' DESC';
				}
				$orderClause	= ' ORDER BY sdt.'.$shiftListingSession->sortBy.' '.$sortClause.',e.event_date ';
			}
			else
			{
				if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "shift_dt_bike_available")
				{
					$joinPrefix	 = "sdt.";
				}
				else if(isset($shiftListingSession->sortBy) && $shiftListingSession->sortBy == "name")
				{
					$joinPrefix	 = "";
				}
				else
				{
					$joinPrefix	 = "s.";
				}
				$orderClause	.= ' ORDER BY '.$joinPrefix.$shiftListingSession->sortBy;
			}
		}
		
		if($shiftListingSession->offsetExists('sortType') && $shiftListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT s.shift_id, s.fk_location_id, s.shift_type, s.shift_start_time, s.shift_end_time, e.shift_bike_rental,sdt.shift_dt_bike_rental,
				   e.shift_bike_available, e.event_total_bikes, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, CONCAT(u.user_firstname," ",u.user_lastname) as name ,
				   s.shift_created_date, s.shift_assign_status,s.shift_occurs,s.shift_status,e.event_id,e.event_date,
				   sdt.shift_dt_id,sdt.shift_dt_start_date,sdt.shift_dt_end_date,e.event_type, sdt.shift_dt_st_time, sdt.shift_dt_ed_time
				   FROM shift as s 
				   left join shift_date_timing as sdt on (s.shift_id = sdt.fk_shift_id) 
				   left join event as e on (s.shift_id = e.fk_shift_id) 
				   left join user as u on (sdt.shift_dt_manager_id = u.user_id || e.shift_manager_id = u.user_id ) ' . $whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function getShiftsDetail($shiftId, $shiftOrEventId = 0, $shiftOccurs)
	{
		$condition	= ($shiftOccurs == 1) ? '(sdt.shift_dt_manager_id = user.user_id)' : '(event.shift_manager_id = user.user_id)';
		$sql		= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental,sdt.shift_dt_bike_rental, shift.shift_occurs, 
					   shift.shift_created_date, shift.shift_updated_date, shift.shift_assign_status, user.user_firstname, user.user_lastname, 
					   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, sdt.shift_dt_status, sdt.shift_dt_manager_id,
					   event.event_id, event.event_title, event.event_date, event.event_category, event.event_description, event.event_status, event.shift_bike_available, event.event_total_bikes,
					   event.shift_manager_id, event.event_type
					   FROM shift as shift
					   left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id)
					   left join event as event on (shift.shift_id = event.fk_shift_id)
					   left join user as user on '.$condition.'
					   WHERE 1 and shift.shift_id = '.$shiftId;
		
		if($shiftOrEventId) {
			$ids	= ($shiftOccurs == 1) ? 'sdt.shift_dt_id' : 'event.event_id';
			$sql   .= ' and '.$ids.' = '.$shiftOrEventId;
		}
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
		$result->buffer();
		$result->next();
		return $result;
	}
	
	/*
	*	Get the shift details by Id
	*/
	public function getShiftsDetailById($shiftId)
	{
		$sql	= "SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental,sdt.shift_dt_bike_rental, shift.shift_occurs,
				   shift.shift_driver_note, sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, sdt.shift_dt_status, 
				   sdt.shift_dt_manager_id, event.event_id, event.event_title, event.event_date, event.event_category, event.event_description, event.event_status, event.event_type,
				   event.shift_bike_available, event.event_total_bikes, event.shift_manager_id, event.event_type, event.special_instructions, event.special_notes, 
				   event.pickup_location, event.dropoff_location, event_payment.pay_per_driver,
				   user.user_firstname, user.user_lastname, CONCAT(user.user_firstname,' ',user.user_lastname) as users_name
				   FROM shift as shift
				   left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id)
				   left join event as event on (shift.shift_id = event.fk_shift_id)
				   left join event_payment as event_payment on (event.event_id = event_payment.fk_event_id)
				   left join user as user on (sdt.shift_dt_manager_id = user.user_id || event.shift_manager_id = user.user_id)
				   WHERE 1 and shift.shift_id = ".$shiftId;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
		$result->buffer();
		$result->next();
		if($count) {
			return $result;
		} else {
			return false;
		}
	}
	
	public function getparticularShiftDetails($shift_id)
	{
		$sql 		= "Select * from ".$this->table." where shift_id = ".$shift_id." and shift_isdelete = 0";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getparticularShiftDateTime($shift_id)
	{
		$sql 		= " Select s.shift_id,s.fk_location_id,s.shift_type,s.shift_start_time,s.shift_end_time,sdt.shift_dt_bike_rental,s.shift_weather,
						s.shift_driver_note,sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, s.shift_manager_note,s.shift_occurs,sdt.shift_dt_st_time,
						sdt.shift_dt_ed_time,sdt.shift_dt_allDay,sdt.shift_dt_sel_date,sdt.shift_dt_start_date_repeat,sdt.shift_dt_end_date_repeat,sdt.shift_dt_start_date
						from shift as s 
						left join shift_date_timing as sdt on (sdt.fk_shift_id = s.shift_id) where shift_dt_id = ".$shift_id." and sdt.shift_dt_status = 1 and s.shift_isdelete = 0";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getparticularEventDetails($shift_id)
	{
		$sql 		= " Select s.shift_id,s.fk_location_id,s.shift_type,s.shift_start_time,s.shift_end_time,e.shift_bike_rental,s.shift_weather,s.shift_driver_note,e.shift_bike_available, e.event_total_bikes,
						s.shift_manager_note,s.shift_occurs,e.event_title,e.event_date,e.event_type,e.event_category,e.event_description from shift as s 
						left join event as e on(e.fk_shift_id = s.shift_id) where event_id = ".$shift_id." and event_isdelete = 0 and s.shift_isdelete = 0";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateShift($data,$shift_id)
    {
	    $sql		= " update shift set ".$data." where shift_id = ".$shift_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function updateEvent($data,$event_id)
    {
	    $sql		= " update event set ".$data." where event_id = ".$event_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	
	public function updateShiftManager($data, $shift_id)
    {
	    $sql		= " update shift set ".$data." where shift_id = ".$shift_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function updateShiftEvent($data,$shift_id)
    {
	    $sql		= " update event set ".$data." where fk_shift_id = ".$shift_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getshiftDateTimeList($fields,$where)
	{
		$sql 		= "Select ".$fields." from shift_date_timing where ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateShiftDateTime($data,$shift_dt_id)
    {
	    $sql		= " update shift_date_timing set ".$data." where shift_dt_id = ".$shift_dt_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getParticularShift($fields,$where)
	{
		$sql 		= " Select ".$fields." from shift_date_timing as sdt 
						left join shift as s on(sdt.fk_shift_id = s.shift_id) 
						where sdt.shift_dt_status = 1 and s.shift_isdelete = 0 and s.shift_occurs = 1".$where." order by s.shift_type asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getParticularEvent($fields,$where)
	{
		$sql 		= " Select ".$fields." from shift as s 
						left join event as e on(e.fk_shift_id = s.shift_id) 
						where s.shift_isdelete = 0 and s.shift_occurs = 2 and e.event_isdelete = 0 ".$where." order by s.shift_type asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getCurrentShiftDetails($identity)
	{
		$where		= '';
		if(isset($identity->user_id) && $identity->user_id != '')
		{
			$where	.= " and sr.fk_user_id = ".$identity->user_id." and (sdt.shift_dt_start_date >= '".date('Y-m-d')."' || e.event_date >= '".date('Y-m-d')."')";
		}
		$limit	 	= '';
		$sql 		= " Select s.shift_id,s.shift_type,s.shift_start_time,s.shift_end_time,s.shift_occurs,
						sdt.shift_dt_id,sdt.shift_dt_start_date,sdt.shift_dt_end_date,
						sr.shift_request_id,sr.fk_user_id,sr.shift_request_status,
						e.event_date,e.event_id 
						from shift as s 
						left join shift_date_timing as sdt on(sdt.fk_shift_id = s.shift_id) 
						left join event as e on(e.fk_shift_id = s.shift_id)
						left join shift_request as sr on ((sr.fk_shift_dt_id = sdt.shift_dt_id and sr.shift_occurs = 1) || (sr.fk_shift_id = e.fk_shift_id and sr.shift_occurs = 2)) 
						where (sdt.shift_dt_status = 1 || e.event_isdelete = 0) and s.shift_isdelete = 0  and 
						sr.shift_request_status = 2 and sr.shift_request_isdelete = 0 ".$where." order by (sdt.shift_dt_start_date || e.event_date )asc,s.shift_start_time asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getParticularShiftRequest($where)
	{
		$sql 		= " Select * from shift_request where shift_request_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertManagerNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_shift_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertAccidentNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_accident_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getuserDetails($where)
	{
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	
	/*
	*	Get the drivers shifts to view the details.
	*/
	public function getDriversShiftsList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	 		 = $pcUser->location_id;
		$whereClause   	  	 = ' WHERE 1 and shift.shift_isdelete = 0 and (sdt.shift_dt_status = 1 || event.event_isdelete = 0) and shift.fk_location_id='.$locationId;
		$event_date   		 = date('Y-m-d', time());
		$whereClause	    .= ' AND (sdt.shift_dt_start_date = "' . $event_date . '" || event.event_date = "' . $event_date . '")';
		
		$driversLoginShiftListingSession = new Container('driversLoginShiftListing');
		$orderClause		 = $sortClause = '';
		if($driversLoginShiftListingSession->offsetExists('sortBy')) {
			if(isset($driversLoginShiftListingSession->sortBy) && $driversLoginShiftListingSession->sortBy == "shift_dt_bike_rental")
			{
				if($driversLoginShiftListingSession->offsetExists('sortType') && $driversLoginShiftListingSession->sortType == 1) {
					$sortClause	.= ' DESC';
				}
				$orderClause	= ' ORDER BY sdt.'.$driversLoginShiftListingSession->sortBy.' '.$sortClause.',event.shift_bike_rental ';
			}
			else
			{
				$joinPrefix		 = ($driversLoginShiftListingSession->sortBy == "user_firstname") ? "user" : "shift";
				$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$driversLoginShiftListingSession->sortBy;
			}
		}
		
		if($driversLoginShiftListingSession->offsetExists('sortType') && $driversLoginShiftListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	.= ' ORDER BY shift.shift_start_time, sdt.shift_dt_st_time';
		}
		
		$sql	= 'SELECT shift.shift_id, shift.fk_location_id, shift.shift_type, shift.shift_start_time, shift.shift_end_time, event.shift_bike_rental, sdt.shift_dt_bike_rental,
				   shift.shift_occurs, shift.shift_created_date, shift.shift_updated_date, shift.shift_assign_status, user.user_firstname, user.user_lastname, 
				   sdt.shift_dt_id, sdt.shift_dt_start_date, sdt.shift_dt_end_date, sdt.shift_dt_allDay, sdt.shift_dt_day, sdt.shift_dt_bike_available, sdt.shift_dt_total_bikes, sdt.shift_dt_status, 
				   sdt.shift_dt_manager_id, sdt.shift_dt_st_time, sdt.shift_dt_ed_time, 
				   event.event_id, event.event_title, event.event_date, event.event_category, event.event_description, event.event_status, event.shift_bike_available, event.event_total_bikes,
				   event.shift_manager_id, event.event_type
				   FROM shift as shift
				   left join shift_date_timing as sdt on (shift.shift_id = sdt.fk_shift_id)
				   left join event as event on (shift.shift_id = event.fk_shift_id)
				   left join user as user on (sdt.shift_dt_manager_id = user.user_id || event.shift_manager_id = user.user_id)';
		$sql   .=  $whereClause . ' ' . $orderClause;				//	 || event.fk_shift_id is null
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getshiftBikeAvailableDetails($where)
	{
		$sql 		= "Select * from bikes_available where 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertshiftBikeAvailable($insert_string)
    {
		$sql 				= " INSERT INTO bikes_available (date,fk_location_id,total_bikes,available_bikes) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getAllBikeDetails($field,$where)
	{
		$sql 		= "Select ".$field." from bike where 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateShiftRequest($data,$shift_req_id)
    {
	    $sql		= " update shift_request set ".$data." where shift_request_id = ".$shift_req_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getparticularShiftRequestDetails($fields,$where)
	{
		$sql 		= "  Select ".$fields." from shift_request as sr 
						 Left join shift_date_timing as sdt on(sdt.shift_dt_id = sr.fk_shift_dt_id)
						 where 1 and sdt.shift_dt_status = 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getarticularEventRequestDetails($fields,$where)
	{
		$sql 		= "  Select ".$fields." from shift_request as sr 
						 Left join event as e on(e.fk_shift_id = sr.fk_shift_id)
						 where 1 and e.event_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	
    public function getShift($shift_id)
    {
        $id  	= (int) $shift_id;
        $rowset = $this->select(array('shift_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
    public function saveShift($shiftDetails)
    {
		$data = array();
		foreach($shiftDetails as $key => $value) {
			if($key != 'shift_id') {
				$data[$key]	= $shiftDetails[$key];
			}
		}
		
        $shift_id = (int)$shiftDetails["shift_id"];
        if (!$shift_id) {
			$data['shift_created_date'] = $shiftDetails["shift_created_date"];
            $this->insert($data);
			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getShift($shift_id)) {
                $this->update($data, array('shift_id' => $shift_id));
				return $shift_id;
            } else {
                throw new \Exception('Form shift_id does not exist');
            }
        }
    }
	public function getEventRequestDetails($event_id)
	{
		$sql 		= " Select s.shift_id,s.fk_location_id,s.shift_type,s.shift_start_time,s.shift_end_time,event.shift_bike_rental,s.shift_weather,s.shift_driver_note,e.shift_bike_available, e.event_total_bikes,
						s.shift_manager_note,s.shift_occurs,e.event_title,e.event_date,e.event_category,e.event_description,sr.shift_request_id,sr.shift_request_status from shift as s 
						left join event as e on(e.fk_shift_id = s.shift_id) 
						left join shift_request as sr on(s.shift_id = sr.fk_shift_id) where event_id = ".$event_id." and event_isdelete = 0 and s.shift_isdelete = 0";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getParticularJobSheet($where)
	{
		$sql 		= "Select * from job_sheet where 1 and job_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getMeetingList($fields,$where)
	{
		$sql 		= "Select ".$fields." from meeting where ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
}