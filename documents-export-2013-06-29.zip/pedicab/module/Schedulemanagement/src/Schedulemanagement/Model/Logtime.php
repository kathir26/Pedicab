<?php
namespace Schedulemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Logtime implements InputFilterAwareInterface
{
    public $logtime_id;
    public $fk_user_id;
    public $fk_user_role_id;
	public $fk_shift_request_id;
	public $logtime_intime;
	public $logtime_outtime;
	public $logtime_created_date;
	public $logtime_updated_date;
	public $logtime_status;
	public $logtime_isdeleted;
	
    public function exchangeArray($data)
    {
		$this->logtime_id			= (isset($data['logtime_id'])) ? $data['logtime_id'] : null;
		$this->fk_user_id			= (isset($data['fk_user_id'])) ? $data['fk_user_id'] : null;
        $this->fk_user_role_id		= (isset($data['fk_user_role_id'])) ? $data['fk_user_role_id'] : null;
        $this->fk_shift_request_id	= (isset($data['fk_shift_request_id'])) ? $data['fk_shift_request_id'] : null;
		$this->logtime_intime		= (isset($data['logtime_intime'])) ? $data['logtime_intime'] : null;
		$this->logtime_outtime		= (isset($data['logtime_outtime'])) ? $data['logtime_outtime'] : null;
		$this->logtime_created_date	= (isset($data['logtime_created_date'])) ? $data['logtime_created_date'] : null;
		$this->logtime_updated_date	= (isset($data['logtime_updated_date'])) ? $data['logtime_updated_date'] : null;
		$this->logtime_status		= (isset($data['logtime_status'])) ? $data['logtime_status'] : null;
		$this->logtime_isdeleted	= (isset($data['logtime_isdeleted'])) ? $data['logtime_isdeleted'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
