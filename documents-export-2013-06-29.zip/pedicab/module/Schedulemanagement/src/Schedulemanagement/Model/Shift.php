<?php
namespace Schedulemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Shift implements InputFilterAwareInterface
{
    public $shift_id;
    public $shift_location;
    public $shift_type;
	public $shift_start_time;
	public $shift_end_time;
	public $shift_bike_rental;
	public $shift_bike_avail;
	public $shift_occurs;
	public $shift_weather;
	public $shift_driver_note;
	public $shift_manager_note;
	public $shift_manager_id;
	public $shift_assign_status;
	
    public function exchangeArray($data)
    {
		$this->shift_id					= (isset($data['shift_id'])) ? $data['shift_id'] : null;
		$this->shift_location			= (isset($data['shift_location'])) ? $data['shift_location'] : null;
        $this->shift_type				= (isset($data['shift_type'])) ? $data['shift_type'] : null;
        $this->shift_start_time			= (isset($data['shift_start_time'])) ? $data['shift_start_time'] : null;
		$this->shift_end_time			= (isset($data['shift_end_time'])) ? $data['shift_end_time'] : 0;
		$this->shift_bike_rental		= (isset($data['shift_bike_rental'])) ? $data['shift_bike_rental'] : null;
		$this->shift_bike_avail			= (isset($data['shift_bike_avail'])) ? $data['shift_bike_avail'] : null;
		$this->shift_occurs				= (isset($data['shift_occurs'])) ? $data['shift_occurs'] : null;
		$this->shift_weather			= (isset($data['shift_weather'])) ? $data['shift_weather'] : null;
		$this->shift_driver_note		= (isset($data['shift_driver_note'])) ? $data['shift_driver_note'] : null;
		$this->shift_manager_note		= (isset($data['shift_manager_note'])) ? $data['shift_manager_note'] : null;
		$this->shift_manager_id			= (isset($data['shift_manager_id'])) ? $data['shift_manager_id'] : null;
		$this->shift_assign_status		= (isset($data['shift_assign_status'])) ? $data['shift_assign_status'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
