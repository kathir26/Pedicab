<?php
namespace Schedulemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class LogtimeTable extends AbstractTableGateway
{
    protected $table = 'logtime';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new PartsPurchase());
        $this->initialize();
    }
	
	public function getLogtime($logtimeId)
    {
        $id  	= (int) $logtimeId;
        $rowset = $this->select(array('logtime_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
			return false;
            //throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	public function saveLogtime($formData)
    {
        $logtime_id = (int)$formData["logtime_id"];
		$fields   = '';
		foreach ($formData as $key => $value) {
			if($key == "logtime_outtime_all" || $key == "logtime_intime_all") {
				$fields .= $key . " = " . $value . ", ";
			} else if($key != "logtime_id") {
				$fields .= $key . " = '" . $value . "', ";
//				$fields .= $key . " = '" . addslashes($value) . "', ";
			}
		}
		$fields = substr($fields, 0, -2);
		
        if (!$logtime_id) {
            $sql 	   = " insert into ".$this->table." set ".$fields;
			$statement = $this->adapter->query($sql);
			$results   = $statement->execute();
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getLogtime($logtime_id)) {
				$sql 	   = "update ".$this->table." set " . $fields . " where logtime_id  = " . $logtime_id;
				$statement = $this->adapter->query($sql);
				$results   = $statement->execute();
				return $logtime_id;
            } else {
                //throw new \Exception('Form id does not exist');
				return false;
            }
        }
    }
	
	public function checkLogInOutTime($logtimes)
    {
		$whereClause = ' WHERE 1 and fk_user_id = '.$logtimes['user_id'].' and logtime_intime >= "' . $logtimes['date'] . '"';
		$sql	 	 = 'SELECT logtime_id, fk_user_id, fk_user_role_id, fk_shift_request_id, logtime_intime, logtime_outtime, logtime_created_date, logtime_updated_date,
					    logtime_status, logtime_isdeleted
					    FROM logtime';
		$sql   	 	.=  $whereClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
		if($count) {
			return $result;
		} else {
			return false;
		}
		/*$result->buffer();
		$result->next();*/
		
    }
	
	/*
	*	Check the Driver Log In and Out times
	*/
	public function checkDriversLogInOutTime($logtimes)
    {
		$whereClause = ' WHERE 1 and fk_user_id = '.$logtimes['user_id'].' and fk_shift_request_id = '.$logtimes['fk_shift_request_id'].' and logtime_intime >= "' . $logtimes['date'] . '"';
		$sql	 	 = 'SELECT logtime_id, fk_user_id, fk_user_role_id, fk_shift_request_id, logtime_intime, logtime_outtime, logtime_created_date, logtime_updated_date,
					    logtime_status, logtime_isdeleted
					    FROM logtime';
		$sql   	 	.=  $whereClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$count		= $result->count();
		if($count) {
			return $result;
		} else {
			return false;
		}
    }
	
	public function deleteLogtime($logtimeId)
    {
        $data = array(
				'logtime_isdeleted'	=> '1'
        );
		$this->update($data, array('logtime_id' => $logtimeId));
    }
	
}