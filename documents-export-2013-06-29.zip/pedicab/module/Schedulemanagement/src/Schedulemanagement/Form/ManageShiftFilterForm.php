<?php
namespace Schedulemanagement\Form;

use Zend\Form\Form;

class ManageShiftFilterForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('schedulemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_manage_shift_form');
		$this->setAttribute('id', 'pc_manage_shift_form');
		
		$this->add(array(
            'name' => 'shift_type_chk',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'shift_type_chk'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'shift_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_date',
				'class'								=> 'calc-txbox',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_type',
            'options' => array(
                'value_options' => array(
					
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid150',
				'id'   								=> 'shift_type',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'shift_save',
            'attributes'=> array(
				'id'	=> 'shift_save',
                'type'  => 'submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'shift_reset',
            'attributes' => array(
				'id'	=> 'shift_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>