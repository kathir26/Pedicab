<?php
namespace Schedulemanagement\Form;

use Zend\Form\Form;

class DriversLogtimeForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('schedulemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_drivers_logtime_form');
		$this->setAttribute('id', 'pc_drivers_logtime_form');
		
		$this->add(array(
            'name' => 'logtimeType',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'logtimeType'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'logtimeId',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'logtimeId'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_shift_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_shift_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'lease_pay_amount',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'lease_pay_amount'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'user_available_balance',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'user_available_balance'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_shift_request_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_shift_request_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'fk_bike_id',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid150',
				'id'   								=> 'fk_bike_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'payment_type',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid150',
				'id'   								=> 'payment_type',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Payment type is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'payment_amount',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'payment_amount',
				'class'								=> 'wid71',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Lease Payment is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Lease Payment',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'bike_issues',
            'options'   => array(
                'value_options' => array(
                    '1' => 'No',
                    '2' => 'Yes',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'bike_issues',
				'tabindex'	=> '5',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
        $this->add(array(
            'name' 		=> 'drivers_logtime_save',
            'attributes'=> array(
				'id'	=> 'drivers_logtime_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> 'fnone',
            ),
        ));
		
		$this->add(array(
            'name' 		=> 'drivers_logtime_save_yes',
            'attributes'=> array(
				'id'	=> 'drivers_logtime_save_yes',
                'type'  => 'submit',
                'value' => 'Save & Continue',
				'class'	=> 'fnone',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'drivers_logtime_reset',
            'attributes' => array(
				'id'	=> 'drivers_logtime_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'fnone',
            ),
        ));
    }
}
?>