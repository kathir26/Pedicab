<?php
namespace Schedulemanagement\Form;

use Zend\Form\Form;

class AssignDriversForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('schedulemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_assign_drivers_form');
		$this->setAttribute('id', 'pc_assign_drivers_form');
		
		$this->add(array(
            'name' => 'event_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'event_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_bike_available',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'shift_bike_available'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_shift_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_shift_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_shift_dt_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_shift_dt_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_occurs',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'shift_occurs'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_date_hidden',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'shift_date_hidden'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_type',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid150',
				'disabled'							=> 'disabled',
				'id'   								=> 'shift_type',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift is required!',
            )
        ));
		
        $this->add(array(
            'name' => 'shift_start_time',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_start_time',
				'class'								=> 'clock-txbox fleft',
				'readonly'							=> 'readonly',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift Start Time is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_end_time',
            'attributes' => array(
				'type' 								=> 'text',
				'class'								=> 'clock-txbox fleft',
                'value' 							=> '',
				'readonly'							=> 'readonly',
				'id'  								=> 'shift_end_time',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift End Time is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'shift_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_date',
				'class'								=> 'calc-txbox',
				'autofocus'							=> '',
				'readonly'							=> 'readonly',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Start Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'requested_drivers',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Assign Requested Drivers',
                    '2' => 'Assign Non-Requested Drivers',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'requested_drivers',
				'tabindex'	=> '5',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_manager',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid230',
				'id'   								=> 'shift_manager',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift manager is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'shift_save',
            'attributes'=> array(
				'id'	=> 'shift_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'shift_reset',
            'attributes' => array(
				'id'	=> 'shift_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>