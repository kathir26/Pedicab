<?php
namespace Schedulemanagement\Form;

use Zend\Form\Form;

class AddShiftForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('schedulemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_shift_form');
		$this->setAttribute('id', 'pc_add_shift_form');
		
		$this->add(array(
            'name' => 'shift_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'shift_id'
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'shift_location',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'shift_location'
            ),
            'options' => array(
            )
        ));
		/*$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_location',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Location',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'   								=> 'shift_location',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Location is required!',
            )
        ));*/
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_type',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'wid150',
				'id'   								=> 'shift_type',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Shift is required!',
            )
        ));
        $this->add(array(
            'name' => 'shift_start_time',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_start_time',
				'class'								=> 'clock-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[time]]',
				'data-errormessage-value-missing' 	=> 'Shift Start Time is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_end_time',
            'attributes' => array(
				'type' 								=> 'text',
				'class'								=> 'clock-txbox datepicker',
                'value' 							=> '',
				'id'  								=> 'shift_end_time',
				'data-validation-engine' 			=> 'validate[required,custom[time]]',
				'data-errormessage-value-missing' 	=> 'Shift End Time is required!',
            )
        ));
		$this->add(array(
            'name' => 'shift_bike_rental',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_bike_rental',
				'class'								=> 'dollar-txbox',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Rental Rate is required!',
            ),
            'options' => array(
            )
        ));
		$this->add(array(
            'name' => 'shift_bike_avail',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_bike_avail',
				'class'								=> 'wid138',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bikes Available is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'shift_occurs',
            'options' => array(
                'value_options' => array(
                    '1' => 'Floating / Repeating',
                    '2' => 'Events',
                ),
            ),
            'attributes' => array(
                'value' 							=> '1',
				'id'   								=> 'shift_occurs',
				'class'								=> 'check_radio_select',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Occurs is required!',
            )
        ));
		$this->add(array(
            'name' 		 => 'shift_weather',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_weather',
				'class'								=> 'wid138',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'readonly'							=> 'readonly',
				'data-validation-engine' 			=> 'validate[required]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Weather is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' 		 => 'shift_driver_note',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'shift_driver_note',
				'class'								=> 'wid138',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
//				'data-validation-engine' 			=> 'validate[required]',		//	custom[fileupload],
//				'data-errormessage-value-missing' 	=> 'Note for Drivers is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' 		 => 'shift_manager_note',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'shift_manager_note',
				'class'								=> 'wid138',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
//				'data-validation-engine' 			=> 'validate[required]',		//	custom[fileupload],
//				'data-errormessage-value-missing' 	=> 'Manager\'s Note is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' 		 => 'shift_st_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_st_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',		//	,custom[date],custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Start Date is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' 		 => 'shift_end_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_end_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',		//	,custom[date],custom[fileupload],
				'data-errormessage-value-missing' 	=> 'End Date is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'type' => 'Zend\Form\Element\MultiCheckbox',
            'name' => 'select_days',
            'options' => array(
                'value_options' => array(
                    '7' => 'All',
					'0' => 'Sunday',
					'1' => 'Monday',
					'2' => 'Tuesday',
					'3' => 'Wednesday',
					'4' => 'Thursday',
					'5' => 'Friday',
					'6' => 'Saturday'
                ),
            ),
            'attributes' => array(
				'id'   								=> 'select_all',
				'class'								=> 'select_day',
				'data-validation-engine' 			=> 'validate[required,minCheckbox[1]]',
				'data-errormessage-value-missing' 	=> 'Select atleast one option!',
            )
        ));
		$this->add(array(
            'name' 		 => 'shift_event_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_event_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Event Date is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'name' 		 => 'shift_event_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_event_title',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Event Title is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'shift_event_cat',
            'options' => array(
                'value_options' => array(
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'class'								=> 'EC281',
				'id'   								=> 'shift_event_cat',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Event Category is required!',
            )
        ));
		$this->add(array(
            'name' 		 => 'shift_event_des',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'shift_event_des',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				//'data-validation-engine' 			=> 'validate[required]',		//	custom[fileupload],
				//'data-errormessage-value-missing' 	=> 'Description is required!',
            ),
            'options' => array(
            ),
        ));
        $this->add(array(
            'name' 		=> 'shift_save',
            'attributes'=> array(
				'id'	=> 'shift_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'shift_reset',
            'attributes' => array(
				'id'	=> 'shift_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>