<?php
namespace Schedulemanagement\Form;

use Zend\Form\Form;

class DriverShiftFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('schedulemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'drive_shift_filter_form');
		$this->setAttribute('name', 'drive_shift_filter_form');
		
		$this->add(array(
            'name' => 'search_shift_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_shift_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Shift Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Shift date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'search_shift_name',
            'options' => array(
                'value_options' 	=> array(
                   ''  				=> 'Name',
				   'user_firstname' => 'First Name',
				   'user_lastname' 	=> 'Last Name',
				   'role_name' 		=> 'Role',
				   'user_email' 	=> 'Email',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'  								=> 'search_shift_name',
				'class'								=> 'wid150',
//				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Shift is required!',
            )
        ));
		
        $this->add(array(
            'name' => 'search_driver_shift_submit',
            'attributes' => array(
				'id'     => 'search_driver_shift_submit',
                'type'   => 'submit',
                'value'  => 'Search',
				'class'	 => '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_driver_shift_reset',
            'attributes' => array(
			    'id'     => 'search_driver_shift_reset',
                'type'   => 'reset',
                'value'  => 'Reset',
				'class'	 => '',
            ),
        ));
    }
}
?>