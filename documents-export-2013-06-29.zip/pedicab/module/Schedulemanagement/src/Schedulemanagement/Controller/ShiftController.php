<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Schedulemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;
//	Forms
use Schedulemanagement\Form\AddShiftForm,
	Schedulemanagement\Form\ManageShiftFilterForm,
	Schedulemanagement\Form\DriverShiftFilterForm;

//	Models
use Usermanagement\Model\Aclresources,
	Schedulemanagement\Model\Shift;
use Usermanagement\Model\MyAuthenticationAdapter;

class ShiftController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $shiftIconArray;
	protected $shiftArray;
	protected $shiftRequestStatusArray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->shiftIconArray		=  array('1' => 'icon-day','2' => 'icon-nite', '3' => 'icon-double','4' => 'icon-special');
		$this->shiftArray			=  array('' => 'All Shifts', '1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$this->shiftRequestStatusArray	=  array('1' => 'Not Allocated', '2' => 'Confirmed', '3' => 'On-call Waiting list','4' => 'Cancelled');
		$this->eventCategoryArray	=  array('' => 'Select Event Category', '1' => 'Ad Install', '2' => 'Dedicated Ad Event', '3' => 'Ride Request (not prepaid)', '4' => 'Tour', '5' => 'Wedding', 
											 '6' => 'Pre-paid Ride', '7' => 'Birthday', '8' => 'Bachelorette/Bachelor Party', '9' => 'Corporate', '10' => 'Group', '11' => 'Other');
		$this->repairUrgency		=  array('1' => 'Not Urgent: Bike is rideable but should be looked at in the next 2-4 days','2'	=> 'Somewhat Urgent: Bike should be looked at very soon, but is still safe to ride','3' => 'URGENT: Bike cannot be ridden until fixed');
		$this->requestBy			=  array('1' => 'Driver','2' => 'Mechanic','3' => 'Manager');
		$this->jobBikeStatus		=  array('0' => 'Not yet started','1' => 'Inprogress','2' => 'Completed');
		
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "LocationTable" => "Location-Table", "ShiftRequestTable" => "Shift-Request-Table", "LogtimeTable" => "Logtime-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	public function shiftCalendarAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'controller'	 	=> $this->params('controller')
		));
    }
	public function addShiftAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$addShiftForm		= new AddShiftForm;
		$get_bike_location	= $weather_details = $temp_string = $weather_detail = $temp_icon = $temp_status = '';
		/*$get_bike_location	= $this->getTable('LocationTable')->getAllLocationDetails();
		$bike_loc_array		= array('' => 'Select Location');
		foreach($get_bike_location as $loc_key => $loc_value)
		{
			$bike_loc_array[$loc_value->loc_id]		= $loc_value->loc_title;
		}*/
		$weather_key		= $this->getCommonDataObj()->getWeatherKey();
		if($weather_key != '' && $identity->location_postal_code != '')
		{
			$url			= "https://api.wunderground.com/api/".$weather_key."/forecast/geolookup/conditions/q/".$identity->location_postal_code.".json"; //default Zipcode Boston(02118)
			$weather_detail = file_get_contents($url);
			$weather_detail	= json_decode($weather_detail);
			if(is_object($weather_detail) && count($weather_detail) > 0)
			{
				$location 			= $weather_detail->location->city;
				$temp_string		= $weather_detail->current_observation->temperature_string;
				$temp_icon			= $weather_detail->current_observation->icon_url;
				$temp_status		= ucfirst($weather_detail->current_observation->icon);
			}
		}
		$addShiftForm->get('shift_weather')->setValue($temp_string);
		/*$addShiftForm->get('shift_location')->setValueOptions($bike_loc_array);
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
			$addShiftForm->get('shift_location')->setValue($this->pcUser->location_id);
		}*/
		$addShiftForm->get('shift_location')->setValue($this->pcUser->location_id);
		$addShiftForm->get('shift_event_cat')->setValueOptions($this->eventCategoryArray);
		$shift_array		= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$addShiftForm->get('shift_type')->setValueOptions($shift_array);
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'addShiftForm'		=> $addShiftForm,
			'temp_icon'			=> $temp_icon,
			'temp_status'		=> $temp_status,
			'controller'	 	=> $this->params('controller')
		));
    }
	public function editShiftAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$editShiftForm		= new AddShiftForm;
		$get_bike_location	= $weather_details = $get_shift_details = $shift_occurs = $shift_dt_details = $shift_events_details = $temp_string = $weather_detail = $temp_icon = $temp_status = '';
		/*$get_bike_location	= $this->getTable('LocationTable')->getAllLocationDetails();
		$bike_loc_array		= array('' => 'Select Location');
		foreach($get_bike_location as $loc_key => $loc_value)
		{
			$bike_loc_array[$loc_value->loc_id]		= $loc_value->loc_title;
		}*/
		$weather_key		= $this->getCommonDataObj()->getWeatherKey();
		if($weather_key != '' && $identity->location_postal_code != '')
		{
			$url			= "http://api.wunderground.com/api/".$weather_key."/forecast/geolookup/conditions/q/".$identity->location_postal_code.".json"; //default Zipcode Boston(02118)
			$weather_detail = file_get_contents($url);
			
			$weather_detail	= json_decode($weather_detail);
			if(is_object($weather_detail) && count($weather_detail) > 0)
			{
				$location 			= $weather_detail->location->city;
				$temp_string		= $weather_detail->current_observation->temperature_string;
				$temp_icon			= $weather_detail->current_observation->icon_url;
				$temp_status		= ucfirst($weather_detail->current_observation->icon);
			}
		}
		//$editShiftForm->get('shift_location')->setValueOptions($bike_loc_array);
		$editShiftForm->get('shift_event_cat')->setValueOptions($this->eventCategoryArray);
		$shift_array		= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$editShiftForm->get('shift_type')->setValueOptions($shift_array);
		$shift_occurs		= (int) $this->params()->fromRoute('shiftOccurs', 0);
		$shift_id			= (int) $this->params()->fromRoute('shiftId', 0);
		$bike_available = 0;
		if(isset($shift_occurs) && $shift_occurs == 1)
		{
			$shift_dt_details	= $this->getTable('ShiftTable')->getparticularShiftDateTime($shift_id);
			if(is_object($shift_dt_details) && count($shift_dt_details) > 0)
			{
				foreach($shift_dt_details as $sh_key => $sh_value)
				{
					$editShiftForm->get('shift_id')->setValue($sh_value['shift_id']);
					$editShiftForm->get('shift_location')->setValue($sh_value['fk_location_id']);
					$editShiftForm->get('shift_type')->setValue($sh_value['shift_type']);
					$editShiftForm->get('shift_start_time')->setValue($this->getCommonDataObj()->convertTimeFormat($sh_value['shift_dt_st_time'],''));
					$editShiftForm->get('shift_end_time')->setValue($this->getCommonDataObj()->convertTimeFormat($sh_value['shift_dt_ed_time'],''));
					$editShiftForm->get('shift_bike_rental')->setValue($sh_value['shift_dt_bike_rental']);
					$editShiftForm->get('shift_weather')->setValue(stripslashes($sh_value['shift_weather']));
					$editShiftForm->get('shift_driver_note')->setValue(stripslashes($sh_value['shift_driver_note']));
					$editShiftForm->get('shift_manager_note')->setValue(stripslashes($sh_value['shift_manager_note']));
					$editShiftForm->get('shift_occurs')->setValue($sh_value['shift_occurs']);
					$editShiftForm->get('shift_bike_avail')->setValue($sh_value['shift_dt_total_bikes']);
					$editShiftForm->get('shift_st_date')->setValue(date('n-j-Y',strtotime($sh_value['shift_dt_start_date_repeat'])));
					$editShiftForm->get('shift_end_date')->setValue(date('n-j-Y',strtotime($sh_value['shift_dt_end_date_repeat'])));
					if($sh_value['shift_dt_allDay'] == 1)
					{
						$selected_days	= array('0','1','2','3','4','5','6','7');
					}
					else
					{
						$selected_days	= explode(",",$sh_value['shift_dt_sel_date']);
					}
					$editShiftForm->get('select_days')->setValue($selected_days);
				}
			}
		}
		else if(isset($shift_occurs) && $shift_occurs == 2)
		{
			$shift_events_details	= $this->getTable('ShiftTable')->getparticularEventDetails($shift_id);
			if(is_object($shift_events_details) && count($shift_events_details) > 0)
			{
				foreach($shift_events_details as $se_key => $se_value)
				{
					$editShiftForm->get('shift_id')->setValue($se_value['shift_id']);
					$editShiftForm->get('shift_location')->setValue($se_value['fk_location_id']);
					$editShiftForm->get('shift_type')->setValue($se_value['shift_type']);
					$editShiftForm->get('shift_start_time')->setValue($this->getCommonDataObj()->convertTimeFormat($se_value['shift_start_time'],''));
					$editShiftForm->get('shift_end_time')->setValue($this->getCommonDataObj()->convertTimeFormat($se_value['shift_end_time'],''));
					$editShiftForm->get('shift_bike_rental')->setValue($se_value['shift_bike_rental']);
					$editShiftForm->get('shift_weather')->setValue(stripslashes($se_value['shift_weather']));
					$editShiftForm->get('shift_driver_note')->setValue(stripslashes($se_value['shift_driver_note']));
					$editShiftForm->get('shift_manager_note')->setValue(stripslashes($se_value['shift_manager_note']));
					$editShiftForm->get('shift_occurs')->setValue($se_value['shift_occurs']);
					$editShiftForm->get('shift_bike_avail')->setValue($se_value['event_total_bikes']);
					$editShiftForm->get('shift_event_date')->setValue(date('n-j-Y',strtotime($se_value['event_date'])));
					$editShiftForm->get('shift_event_title')->setValue($se_value['event_title']);
					$editShiftForm->get('shift_event_cat')->setValue($se_value['event_category']);
					$editShiftForm->get('shift_event_des')->setValue($se_value['event_description']);
				}
			}
		}
		$editShiftForm->get('shift_weather')->setValue($temp_string);
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'editShiftForm'		=> $editShiftForm,
			'shift_occurs'		=> $shift_occurs,
			'temp_icon'			=> $temp_icon,
			'temp_status'		=> $temp_status,
			'controller'	 	=> $this->params('controller')
		));
    }
	public function saveShiftAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$addShiftForm		= new AddShiftForm;
		$request 			= $this->getRequest();
		$json_array	= array();
		if($request->isPost())
		{
			$shift_id = $check_shift_details = $shift_date_array = $shift_days = $shift_date_tm_details = $shift_dt_array = $user_details_array = $shift_days_array = '';
			$notification_subject = $get_bike_avail_details = $get_active_bikes = $notify_bike_avail = '';
			$shift_days_array = $bike_date_avail = $new_date_avail_insert = $shift_allocate_bike = $shift_date_notify = $driver_array = array();
			$location_manager_array = $notification_send_array = array();
			$error_flag = $active_bike_count = 0;
			$shiftModel			= new Shift();
			$pc_user_details	= $this->pcUser;
			$formData  = $getData	= $request->getPost();
			$shiftModel->exchangeArray($formData);
			$shift_array			= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
			$bikfield				= " count(bike_id) as bike_count";
			$bikwhere				= " and bike_isdelete = 0 and bike_status = 1 and bike_operation = 1 and fk_location_id = ".$identity->location_id;
			$get_active_bikes		= $this->getTable('ShiftTable')->getAllBikeDetails($bikfield,$bikwhere);
			$convertStartTime		= $this->getCommonDataObj()->convertTimeFormat($formData->shift_start_time,1);
			$convertEndTime			= $this->getCommonDataObj()->convertTimeFormat($formData->shift_end_time,1);
			if(is_object($get_active_bikes) && count($get_active_bikes) > 0)
			{
				foreach($get_active_bikes as $bi_key => $bi_value)
				{
					$active_bike_count		= $bi_value['bike_count'];
				}
			}
			$where_user			= "  and location_id = '".$identity->location_id."' and user_role_id in (1,3)";
			$user_details_array	= $this->getTable('ShiftTable')->getuserDetails($where_user);
			if(is_object($user_details_array) && count($user_details_array) > 0)
			{
				foreach($user_details_array as $user_key => $user_value)
				{
					if($user_value['user_role_id'] == 1)
					{
						$driver_array[]				= $user_value['user_id'];
					}
					else if($user_value['user_role_id'] == 3)
					{
						$location_manager_array[]	= $user_value['user_id'];
					}
				}
			}
			$days_array		= array('0' => 'sunday','1' => 'monday','2' => 'tuesday','3' => 'wednesday','4' => 'thursday','5' => 'friday','6' => 'saturday','7' => 'all');
			if(isset($getData['shift_occurs']) && $getData['shift_occurs'] == 1)
			{
				//check shift already exists starts
				if(isset($getData['shift_st_date']) && $getData['shift_st_date'] != '')
				{
					$location_date		= explode('-',$getData['shift_st_date']);
					if(is_array($location_date) && count($location_date) > 0)
					{
						$shift_dt_st	= $location_date[2]."-".$location_date[0]."-".$location_date[1];
					}
				}
				if(isset($getData['shift_end_date']) && $getData['shift_end_date'] != '')
				{
					$location_date		= explode('-',$getData['shift_end_date']);
					if(is_array($location_date) && count($location_date) > 0)
					{
						$shift_dt_end	= $location_date[2]."-".$location_date[0]."-".$location_date[1];
					}
				}
				$shift_dat_day	= $notification_days_all = '';
				$shift_all_dat  = 0;
				if(is_array($getData['select_days']) && count($getData['select_days']) > 0)
				{
					foreach($getData['select_days'] as $day_key => $day_value)
					{
						if($day_value == 7)
						{
							if(isset($getData['shift_id']) && $getData['shift_id'] != '')
							{
								$shift_dt_new_st		= date('Y-m-d');
							}
							else
							{
								$shift_dt_new_st		= $shift_dt_st;
							}
							$shift_allDays	= $this->getCommonDataObj()->getAllDates($shift_dt_new_st,$shift_dt_end,'P1D');
							foreach($shift_allDays as $all_key => $all_value)
							{
								$shift_days_array[]		= $all_value->format('Y-m-d');
							}
							$shift_days_array[]			= $shift_dt_end;
							$shift_all_dat				= 1;
							break;
						}
						else
						{
							if(isset($shift_dat_day) && $shift_dat_day == '')
							{
								$shift_dat_day			.= $day_value;
								$notification_days_all	.= ucfirst($days_array[$day_value]);
							}
							else
							{
								$shift_dat_day			.= ",".$day_value;
								$notification_days_all	.= ", ".ucfirst($days_array[$day_value]);
							}
						}
					}
				}
				if(isset($shift_all_dat) && $shift_all_dat == 1)
				{
					$shift_chk_array['chk_dat']	= "0,1,2,3,4,5,6";
					$notification_days_all		= "Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday";
				}
				else
				{
					$shift_chk_array['chk_dat']	= $shift_dat_day;
				}
				$shift_chk_array['start']		= $shift_dt_st;
				$shift_chk_array['end']			= $shift_dt_end;
				$shift_chk_array['type']		= $getData['shift_type'];
				$shift_chk_array['st_time']		= $convertStartTime;
				$shift_chk_array['ed_time']		= $convertEndTime;
				$shift_chk_array['location']	= $getData['shift_location'];
				if(isset($getData['shift_id']) && $getData['shift_id'] != '')
				{
					$shift_chk_array['shift_id']	= $getData['shift_id'];
				}
				$check_shift_details		= $this->getTable('ShiftTable')->checkShiftDateTime($shift_chk_array);
				if(is_object($check_shift_details) && count($check_shift_details) > 0)
				{
					$error_flag = 1;
				}
				if(isset($error_flag) && $error_flag == 1)
				{
					$json_array['err']		= 1;
				}
				else
				{
					$insert_array = '';
					//$shift_dt_array['shift_id']	= $shift_id;
					if(isset($shift_dat_day) && $shift_dat_day != '')
					{
						$shift_d_arr				= explode(",",$shift_dat_day);
						if(isset($getData['shift_id']) && $getData['shift_id'] != '')
						{
							$shift_dt_new_st		= date('Y-m-d');
						}
						else
						{
							$shift_dt_new_st		= $shift_dt_st;
						}
						$shift_partDays				= $this->getCommonDataObj()->getAllParticularDates($shift_dt_new_st,$shift_dt_end,$shift_d_arr);
						foreach($shift_partDays as $par_key => $par_value)
						{
							$shift_days_array[]		= date('Y-m-d',strtotime($par_value->format('Y-m-d')));
						}
					}
					if(is_array($shift_days_array) && count($shift_days_array) == 0)
					{
						$json_array['err']		= 2;
					}
					else
					{
						$bike_where						= " and date >= '".$shift_dt_st."' and date <= '".$shift_dt_end."' and fk_location_id = ".$identity->location_id;
						$get_bike_avail_details 		= $this->getTable('ShiftTable')->getshiftBikeAvailableDetails($bike_where);
						if(is_object($get_bike_avail_details) && count($get_bike_avail_details) > 0)
						{
							foreach($get_bike_avail_details as $bike_key => $bike_value)
							{
								$bike_date_avail[]	= $bike_value['date'];
							}
						}
						if(isset($getData['shift_id']) && $getData['shift_id'] != '')
						{
							$data = " fk_location_id		= '".$formData->shift_location."',
									  shift_type			= '".$formData->shift_type."',
									  shift_start_time		= '".$convertStartTime."',
									  shift_end_time		= '".$convertEndTime."',
									  shift_occurs			= '".$formData->shift_occurs."',
									  shift_weather			= '".$formData->shift_weather."',
									  shift_driver_note		= '".addslashes($formData->shift_driver_note)."',
									  shift_manager_note	= '".addslashes($formData->shift_manager_note)."',
									  shift_updated_date	= now()";
							$shift_id					= $getData['shift_id'];
							$this->getTable('ShiftTable')->updateShift($data,$shift_id);
						}
						else
						{
							$shift_id					= $this->getTable('ShiftTable')->insertshift($formData);
						}
						if(isset($getData['shift_id']) && $getData['shift_id'] != '')
						{
							$fields			= "*";
							$where			= " shift_dt_status = 1 and shift_dt_start_date >= '".$shift_dt_new_st."' and fk_shift_id = ".$getData['shift_id'];
							$shift_date_tm_details	= $this->getTable('ShiftTable')->getshiftDateTimeList($fields,$where);
							if(is_object($shift_date_tm_details) && count($shift_date_tm_details) > 0)
							{
								foreach($shift_date_tm_details as $sdt_key => $sdt_value)
								{
									$shift_dt_array[]									= $sdt_value['shift_dt_id'];
									$shift_allocate_bike[$sdt_value['shift_dt_id']]		= $sdt_value['shift_dt_total_bikes'] - $sdt_value['shift_dt_bike_available'];
									$shift_date_notify[$sdt_value['shift_dt_id']]		= $sdt_value['shift_dt_start_date'];
								}
							}
							$count_shi_dt		= count($shift_days_array);
							$count_sdt_array	= count($shift_dt_array);
							for($e = 0;$e < $count_shi_dt;$e++)
							{
								$date  		= '';
								$date		= date("w",strtotime($shift_days_array[$e]));
								if(!in_array($shift_days_array[$e],$bike_date_avail))
								{
									$new_date_avail_insert[]	= "'".$shift_days_array[$e]."','".$identity->location_id."','".addslashes($active_bike_count)."','".addslashes($active_bike_count)."'";
								}
								$bike_count_new		= $getData['shift_bike_avail'];
								if($count_sdt_array > $e && is_array($shift_dt_array))
								{
									if(isset($shift_allocate_bike[$shift_dt_array[$e]]) && $getData['shift_bike_avail'] >= $shift_allocate_bike[$shift_dt_array[$e]])
									{
										$bike_count_new		= $getData['shift_bike_avail'] - $shift_allocate_bike[$shift_dt_array[$e]];
										$bike_total			= $getData['shift_bike_avail'];
									}
									else //Notification Todo change the driver to on call list
									{
										$bike_count_new		= $getData['shift_bike_avail'];
										$bike_total			= $getData['shift_bike_avail'];
										if(is_array($location_manager_array) && count($location_manager_array) > 0)
										{
											foreach($location_manager_array as $loc_key => $loc_value)
											{
												$notification_subject	= "Assigned driver is greater than bike available(".abs($getData['shift_bike_avail'] - $shift_allocate_bike[$shift_dt_array[$e]])." bike needed).So assigned driver status has been changed to on call list";
												$notification_send_array[]	= "'".$shift_dt_array[$e]."','".$identity->user_id."','".$loc_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($shift_days_array[$e])."','1'";
											}
										}
									}
									$data		= " shift_dt_start_date = '".$shift_days_array[$e]."',shift_dt_end_date = '".$shift_days_array[$e]."',shift_dt_bike_available = '".addslashes($getData['shift_bike_avail'])."',shift_dt_total_bikes = '".addslashes($getData['shift_bike_avail'])."',shift_dt_allDay = '".$shift_all_dat."',shift_dt_day = '".addslashes($date)."',
													shift_dt_start_date_repeat = '".$shift_dt_st."',shift_dt_end_date_repeat = '".$shift_dt_end."',shift_dt_sel_date = '".$shift_chk_array['chk_dat']."',shift_dt_bike_rental = '".addslashes($getData['shift_bike_rental'])."',
													shift_dt_st_time = '".$convertStartTime."',shift_dt_ed_time = '".$convertEndTime."'";
									$this->getTable('ShiftTable')->updateShiftDateTime($data,$shift_dt_array[$e]);
								}
								else
								{
									$insert_array[]			= " '".$getData['shift_id']."','".$shift_days_array[$e]."','".$shift_days_array[$e]."','".addslashes($date)."','".$shift_all_dat."','".addslashes($getData['shift_bike_avail'])."','".addslashes($getData['shift_bike_avail'])."',1,'".$shift_dt_st."','".$shift_dt_end."','".$shift_chk_array['chk_dat']."','".addslashes($getData['shift_bike_rental'])."','".addslashes($convertStartTime)."','".addslashes($convertEndTime)."'";
								}
							}
							if(is_array($notification_send_array) && count($notification_send_array) > 0)
							{
								$notify_bike_avail			= "(".implode("),(",$notification_send_array).")";
								if(isset($notify_bike_avail) && $notify_bike_avail != '')
								{
									$this->getTable('ShiftTable')->insertManagerNotification($notify_bike_avail);
								}
							}
							if(is_array($new_date_avail_insert) && count($new_date_avail_insert) > 0)
							{
								$insert_string_multi		= "(".implode("),(",$new_date_avail_insert).")";
								if(isset($insert_string_multi) && $insert_string_multi != '')
								{
									$this->getTable('ShiftTable')->insertshiftBikeAvailable($insert_string_multi);
								}
							}
							if($count_sdt_array > $count_shi_dt)
							{
								for($k = $count_shi_dt;$k < $count_sdt_array;$k++)
								{
									$data		= " shift_dt_status = 0";
									$this->getTable('ShiftTable')->updateShiftDateTime($data,$shift_dt_array[$k]);
								}
							}
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_string		= "(".implode("),(",$insert_array).")";
								$this->getTable('ShiftTable')->insertshiftDateTime($insert_string);
							}
						}
						else
						{
							if(is_array($shift_days_array) && count($shift_days_array) > 0)
							{
								foreach($shift_days_array as $shift_key => $shift_value)
								{
									$date  		= '';
									if(!in_array($shift_value,$bike_date_avail))
									{
										$new_date_avail_insert[]	= "'".$shift_value."','".$identity->location_id."','".addslashes($active_bike_count)."','".addslashes($active_bike_count)."'";
									}
									$date		= date("w",strtotime($shift_value));
									$insert_array[]			= " '".addslashes($shift_id)."','".addslashes($shift_value)."','".addslashes($shift_value)."','".addslashes($date)."','".$shift_all_dat."','".addslashes($getData['shift_bike_avail'])."','".addslashes($getData['shift_bike_avail'])."',1,'".$shift_dt_st."','".$shift_dt_end."','".$shift_chk_array['chk_dat']."','".addslashes($getData['shift_bike_rental'])."','".addslashes($convertStartTime)."','".addslashes($convertEndTime)."'";
								}
							}
							if(is_array($new_date_avail_insert) && count($new_date_avail_insert) > 0)
							{
								$insert_string_multi		= "(".implode("),(",$new_date_avail_insert).")";
								if(isset($insert_string_multi) && $insert_string_multi != '')
								{
									$this->getTable('ShiftTable')->insertshiftBikeAvailable($insert_string_multi);
								}
							}
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_string		= "(".implode("),(",$insert_array).")";
								$this->getTable('ShiftTable')->insertshiftDateTime($insert_string);
							}
						}
						$json_array['err']		= 0;
						$json_array['redirect']	= '/schedulemanagement/shift/manage-shift';
					}
				}
			}
			else
			{
				if(isset($getData['shift_event_date']) && $getData['shift_event_date'] != '')
				{
					$location_date				= explode('-',$getData['shift_event_date']);
					if(is_array($location_date) && count($location_date) > 0)
					{
						$shift_event_array['shift_event_date']	= $location_date[2]."-".$location_date[0]."-".$location_date[1];
					}
				}
				$bike_where						= " and date = '".$shift_event_array['shift_event_date']."' and fk_location_id = ".$identity->location_id;
				$get_bike_avail_details 		= $this->getTable('ShiftTable')->getshiftBikeAvailableDetails($bike_where);
				if(is_object($get_bike_avail_details) && count($get_bike_avail_details) > 0)
				{
					foreach($get_bike_avail_details as $bike_key => $bike_value)
					{
						$bike_date_avail[]	= $bike_value['date'];
					}
				}
				if(!in_array($shift_event_array['shift_event_date'],$bike_date_avail))
				{
					$new_date_avail_insert[]	= "'".$shift_event_array['shift_event_date']."','".$identity->location_id."','".addslashes($active_bike_count)."','".addslashes($active_bike_count)."'";
					$insert_string_multi		= "(".implode("),(",$new_date_avail_insert).")";
					if(isset($insert_string_multi) && $insert_string_multi != '')
					{
						$this->getTable('ShiftTable')->insertshiftBikeAvailable($insert_string_multi);
					}
				}
				
				if(isset($getData['shift_id']) && $getData['shift_id'] != '')
				{
					$data = " fk_location_id		= '".$formData->shift_location."',
							  shift_type			= '4',
							  shift_start_time		= '".$convertStartTime."',
							  shift_end_time		= '".$convertEndTime."',
							  shift_occurs			= '".$formData->shift_occurs."',
							  shift_weather			= '".$formData->shift_weather."',
							  shift_driver_note		= '".addslashes($formData->shift_driver_note)."',
							  shift_manager_note	= '".addslashes($formData->shift_manager_note)."',
							  shift_updated_date	= now()";
					$shift_id					= $getData['shift_id'];
					$this->getTable('ShiftTable')->updateShift($data,$shift_id);
				}
				else
				{
					$formData->shift_type	= 4;
					$shift_id		= $this->getTable('ShiftTable')->insertshift($formData);
				}
				$shift_event_array['shift_id']					= $shift_id;
				$shift_event_array['shift_event_title']			= $getData['shift_event_title'];
				$shift_event_array['shift_event_cat']			= $getData['shift_event_cat'];
				$shift_event_array['shift_event_des']			= $getData['shift_event_des'];
				$shift_event_array['shift_bike_available']		= $getData['shift_bike_avail'];
				$shift_event_array['event_total_bikes']			= $getData['shift_bike_avail'];
				$shift_event_array['shift_bike_rental']			= $getData['shift_bike_rental'];
				if(isset($getData['shift_id']) && $getData['shift_id'] != '')
				{
					$where_event			= " and s.shift_id = ".$shift_id;
					$get_event_details		= $this->getTable('ShiftTable')->getParticularEvent("*",$where_event);
					if(is_object($get_event_details) && count($get_event_details) > 0)
					{
						foreach($get_event_details as $eve_key => $eve_value)
						{
							$new_event_bike_count	= $eve_value['event_total_bikes'] - $eve_value['shift_bike_available'];
							if(isset($new_event_bike_count) && $getData['shift_bike_avail'] >= $new_event_bike_count)
							{
								$bike_count_new		= $getData['shift_bike_avail'] - $new_event_bike_count;
								$bike_total			= $getData['shift_bike_avail'];
							}
							else //Notification Todo change the driver to on call list
							{
								$bike_count_new		= $getData['shift_bike_avail'];
								$bike_total			= $getData['shift_bike_avail'];
								if(is_array($location_manager_array) && count($location_manager_array) > 0)
								{
									foreach($location_manager_array as $loc_key => $loc_value)
									{
										$notification_subject	= "Assigned driver is greater than bike available(".abs($getData['shift_bike_avail'] - $new_event_bike_count)." bike needed).So assigned driver status has been changed to on call list";
										$notification_send_array[]	= "'".$shift_id."','".$identity->user_id."','".$loc_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($eve_value['event_date'])."','2'";
									}
								}
							}
						}
					}
					if(is_array($notification_send_array) && count($notification_send_array) > 0)
					{
						$notify_bike_avail			= "(".implode("),(",$notification_send_array).")";
						if(isset($notify_bike_avail) && $notify_bike_avail != '')
						{
							$this->getTable('ShiftTable')->insertManagerNotification($notify_bike_avail);
						}
					}
					$data = " event_title			= '".addslashes($shift_event_array['shift_event_title'])."',
			            	  event_category		= '".addslashes($shift_event_array['shift_event_cat'])."',
							  shift_bike_available	= '".addslashes($bike_count_new)."',
							  shift_bike_rental		= '".addslashes($shift_event_array['shift_bike_rental'])."',
							  event_total_bikes		= '".addslashes($bike_total)."',
							  event_date			= '".$shift_event_array['shift_event_date']."',
			            	  event_creation_date	= '".date('Y-m-d H:i:s')."',
							  event_description		= '".addslashes($shift_event_array['shift_event_des'])."',
							  event_updated_date	= now()";
					$shift_id					= $getData['shift_id'];
					$this->getTable('ShiftTable')->updateShiftEvent($data,$shift_id);
				}
				else
				{
					$this->getTable('ShiftTable')->insertshiftEvent($shift_event_array);
				}
				$json_array['err']		= 0;
				$json_array['redirect']	= '/schedulemanagement/shift/manage-shift';
			}
			if(isset($json_array['err']) && $json_array['err'] == 0)
			{
				//Notification
				$insert_array = array();
				if(is_array($driver_array) && count($driver_array) > 0)
				{
					if(isset($getData['shift_occurs']) && $getData['shift_occurs'] == 1)
					{
						if(isset($getData['shift_id']) && $getData['shift_id'] != '')
						{
							$notification_subject	= $shift_array[$getData['shift_type']]." Shift Updated ";
						}
						else
						{
							$notification_subject	= $shift_array[$getData['shift_type']]." Shift Created ";
						}
						$notify_date				= $shift_dt_st." to ".$shift_dt_end.'<br>'.$notification_days_all;
						$notify_type				= 1;
					}
					else
					{
						if(isset($getData['shift_id']) && $getData['shift_id'] != '')
						{
							$notification_subject	= $getData['shift_event_title']." Updated ";
						}
						else
						{
							$notification_subject	= $getData['shift_event_title']." Created ";
						}
						$notify_date				= $shift_event_array['shift_event_date'];
						$notify_type				= 2;
					}
					foreach($driver_array as $driver_key => $driver_value)
					{
						$insert_array[]		= "'".$shift_id."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($notify_date)."','".addslashes($notify_type)."'";
					}
					if(is_array($insert_array) && count($insert_array) > 0)
					{
						$insert_multi_string	= "(".implode("),(",$insert_array).")";
					}
					if(isset($insert_multi_string) && $insert_multi_string != '')
					{
						$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
					}
				}
			}
		}
		echo json_encode($json_array);
		return $this->getResponse();
    }
	public function shiftCalendarDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$shift_date_array = $shift_date_time_array = $shift_event_array = $shift_array = $implode_shift_dt_ids = $implode_shift_event_ids = '';
		$shift_event_details = $shift_type_array = $bike_avail_array = $event_title = $event_cat = $event_des = '';
		$shift_calendar_array = array();
		$request 				= $this->getRequest();
		if($request->isPost())
		{
			$pc_user_details	= $this->pcUser;
			$get_ajax_data		= $request->getPost();
			$calendar_st_date	= date("Y-m-d",$get_ajax_data['start']);
			$calendar_end_date	= date("Y-m-d",$get_ajax_data['end']);
			$calendar_month		= $get_ajax_data['month'];
			$shift_dt_details	= $this->getTable('ShiftTable')->getshiftDateTimeDetails($calendar_st_date,$calendar_end_date,$calendar_month,$pc_user_details);
			$e = 0;
			$todays_date		= strtotime(date('Y-m-d'));
			$user_role_id		= $identity->user_role_id;
			if($calendar_month == date('m'))
			{
				$weather_key		= $this->getCommonDataObj()->getWeatherKey();
				if($weather_key != '' && $identity->location_postal_code != '')
				{
					$url			= "http://api.wunderground.com/api/".$weather_key."/forecast/geolookup/conditions/q/".$identity->location_postal_code.".json"; //default Zipcode Boston(02118)
					$weather_detail = file_get_contents($url);
					
					$weather_detail	= json_decode($weather_detail);
					if(is_object($weather_detail) && count($weather_detail) > 0)
					{
						$shift_calendar_array[$e]['shift_id']			= 0;
						$shift_calendar_array[$e]['start']				= date('Y-m-d',$weather_detail->current_observation->observation_epoch);
						$shift_calendar_array[$e]['end']				= date('Y-m-d',$weather_detail->current_observation->observation_epoch);
						$shift_calendar_array[$e]['normal']				= $weather_detail->current_observation->temp_f." F (".$weather_detail->current_observation->temp_c." C)";
						$shift_calendar_array[$e]['shift_event']		= 3;
						$shift_calendar_array[$e]['conditions']			= ucfirst($weather_detail->current_observation->weather);
						$shift_calendar_array[$e]['icon']				= ucfirst($weather_detail->current_observation->icon);
						$shift_calendar_array[$e]['icon_url']			= $weather_detail->current_observation->icon_url;
						$shift_calendar_array[$e]['date_check']			= 1;
						$shift_calendar_array[$e]['user_role']			= $user_role_id;
						$e = $e+1;
						foreach($weather_detail->forecast->simpleforecast->forecastday as $weather_key => $weather_value)
						{
							$st_dat		= date('Y-m-d',$weather_value->date->epoch);
							$end_dat	= date('Y-m-d',$weather_value->date->epoch);
							if(date('Y-m-d') != $st_dat)
							{
								$shift_calendar_array[$e]['shift_id']			= 0;
								$shift_calendar_array[$e]['start']				= $st_dat;
								$shift_calendar_array[$e]['end']				= $end_dat;
								$shift_calendar_array[$e]['high']				= $weather_value->high->fahrenheit." F (".$weather_value->high->celsius." C)";
								$shift_calendar_array[$e]['low']				= $weather_value->low->fahrenheit." F (".$weather_value->low->celsius." C)";
								$shift_calendar_array[$e]['shift_event']		= 3;
								$shift_calendar_array[$e]['conditions']			= ucfirst($weather_value->conditions);
								$shift_calendar_array[$e]['icon']				= ucfirst($weather_value->icon);
								$shift_calendar_array[$e]['icon_url']			= $weather_value->icon_url;
								$shift_calendar_array[$e]['date_check']			= 1;
								$shift_calendar_array[$e]['user_role']			= $user_role_id;
								$e++;
							}
						}
					}
				}
			}
			if(is_object($shift_dt_details) && count($shift_dt_details) > 0)
			{
				foreach($shift_dt_details as $shift_dt_key => $shift_dt_value)
				{
					$st_dat_str			= strtotime($shift_dt_value['shift_dt_start_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					else
					{
						$chk_greater	= 0;
					}
					$shift_calendar_array[$e]['shift_id']			= $shift_dt_value['fk_shift_id'];
					$shift_calendar_array[$e]['start']				= $shift_dt_value['shift_dt_start_date'];
					$shift_calendar_array[$e]['end']				= $shift_dt_value['shift_dt_end_date'];
					$shift_calendar_array[$e]['bike_avail']			= $shift_dt_value['shift_dt_bike_available'];
					$shift_calendar_array[$e]['bike_rent']			= $shift_dt_value['shift_dt_bike_rental'];
					$shift_calendar_array[$e]['shift_type']			= $shift_dt_value['shift_type'];
					$shift_calendar_array[$e]['shift_dt_id']		= $shift_dt_value['shift_dt_id'];
					$shift_calendar_array[$e]['shift_event']		= 2;
					$shift_calendar_array[$e]['event_title']		= '';
					$shift_calendar_array[$e]['event_cat']			= '';
					$shift_calendar_array[$e]['event_des']			= '';
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
			$shift_event_details		= $this->getTable('ShiftTable')->getshiftEventDetails($calendar_st_date,$calendar_end_date,$pc_user_details);
			if(is_object($shift_event_details) && count($shift_event_details) > 0)
			{
				foreach($shift_event_details as $event_key => $event_value)
				{
					$st_dat_str			= strtotime($event_value['event_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					else
					{
						$chk_greater	= 0;
					}
					$shift_calendar_array[$e]['shift_id']			= $event_value['fk_shift_id'];
					$shift_calendar_array[$e]['start']				= $event_value['event_date'];
					$shift_calendar_array[$e]['end']				= $event_value['event_date'];
					$shift_calendar_array[$e]['bike_avail']			= $event_value['shift_bike_available'];
					$shift_calendar_array[$e]['bike_rent']			= $event_value['shift_bike_rental'];
					$shift_calendar_array[$e]['shift_type']			= $event_value['shift_type'];
					$shift_calendar_array[$e]['event_id']			= $event_value['event_id'];
					$shift_calendar_array[$e]['shift_event']		= 1;
					$shift_calendar_array[$e]['event_title']		= $this->getCommonDataObj()->displayShortText($event_value['event_title'], '20');
					$shift_calendar_array[$e]['event_cat']			= isset($this->eventCategoryArray[$event_value['event_category']])?$this->eventCategoryArray[$event_value['event_category']]:'';
					$shift_calendar_array[$e]['event_des']			= $event_value['event_description'];
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
			$meetingFields		= "*";
			$meetingWhere		= " meeting_status = 2 and meeting_location = ".$identity->location_id;//meeting_to = ".$identity->user_role_id
			$meetingDetails		= $this->getTable('ShiftTable')->getMeetingList($meetingFields,$meetingWhere);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $meetKey => $meetValue)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($meetValue['meeting_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					$shift_calendar_array[$e]['shift_id']			= 0;
					$shift_calendar_array[$e]['meet_id']			= $meetValue['meeting_id'];
					$shift_calendar_array[$e]['start']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['end']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['meet_time']			= $this->getCommonDataObj()->convertTimeFormat($meetValue['meeting_time'],'');
					$shift_calendar_array[$e]['meeting_to']			= $meetValue['meeting_to'];
					$shift_calendar_array[$e]['price']				= $meetValue['meeting_budget_request'];
					$shift_calendar_array[$e]['shift_event']		= 4;
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
		}
		echo json_encode($shift_calendar_array);die();
		return $this->getResponse();
	}
	
	/*	Action	: 	Driver View Shift
	*	Detail	:	Used to view the shifts
	*	TODO	:	Ajax actions inprocess
	*/
	public function driverViewShiftAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		
		// Create Filter form
		$driverShiftFilterForm		=  new DriverShiftFilterForm();
		
		//	Destroy listing Session Vars
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('driverShiftListing'));
		$driverShiftListingSession  =  new Container('driverShiftListing');
		
		if ($request->isPost()) {
			$driverShiftFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_shift_date']) && !empty($formData['search_shift_date']))
				$driverShiftListingSession->shift_date	= $formData['search_shift_date'];
			else
				$driverShiftListingSession->shift_date	= '';
			
			if(isset($formData['search_shift_name']) && $formData['search_shift_name'] != '')
				$driverShiftListingSession->shift_name	= $formData['search_shift_name'];
			else
				$driverShiftListingSession->shift_name	= '';
		}
		
		$driverShiftFilterForm->get('search_shift_name')->setValueOptions($this->shiftArray);
		
		if($driverShiftListingSession->offsetExists('shift_date') && $driverShiftListingSession->shift_date != '' ) {
			$driverShiftFilterForm->get('search_shift_date')->setValue($driverShiftListingSession->shift_date);
		}
		if($driverShiftListingSession->offsetExists('shift_name') && $driverShiftListingSession->shift_name != '' ) {
			$driverShiftFilterForm->get('search_shift_name')->setValue($driverShiftListingSession->shift_name);
		}
		
		// Get Drivers request details
		$driversRequestsResults	= $this->getTable('ShiftRequestTable')->getDriverRequestDetails();
		$driversRequests		= array();
		$driversAllocated		= array();
		
		if($driversRequestsResults) {
//			$driversRequests		= $driversRequestsResults->toArray();
			foreach($driversRequestsResults as $key => $requests) {
				if(isset($requests["shift_occurs"]) && !empty($requests["shift_occurs"]) && $requests["shift_occurs"] == 1) {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]]	=  $requests;
					$driversAllocated[$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]][]  = $requests["user_firstname"].' '.$requests["user_lastname"];
				} else {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]]	=  $requests;
					$driversAllocated[$requests["fk_shift_id"]][$requests["shift_occurs"]][]  = $requests["user_firstname"].' '.$requests["user_lastname"];
				}
			}
		}
		// listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getShiftsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'driverShiftFilterForm'	=> $driverShiftFilterForm,
			'driversRequests'		=> $driversRequests,
			'driversAllocated'		=> $driversAllocated,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'shiftIconArray'		=> $this->shiftIconArray,
			'shiftArray'			=> $this->shiftArray,
			'shiftRequestStatusArray' => $this->shiftRequestStatusArray,
			'datetime'			    => $datetime,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax User list, Ajax action
	*	Detail	:	Used to list the shifts details via Ajax
	*/
	public function driverViewShiftListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$driverShiftListingSession  =  new Container('driverShiftListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($driverShiftListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$driverShiftListingSession->sortBy	= $sortBy;
		} else if($driverShiftListingSession->offsetExists('sortBy')) {
			$sortBy	= $driverShiftListingSession->sortBy;
		}
		if($sortType != '') {
			if($driverShiftListingSession->sortType == $sortType && $columnFlag == 1)
				$driverShiftListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$driverShiftListingSession->sortType	= $sortType;
		} else if($driverShiftListingSession->offsetExists('sortType')) {
			$sortType	= $driverShiftListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$driverShiftListingSession->perPage	= $perPage;
		} else if($driverShiftListingSession->offsetExists('perPage')) {
			$perPage		= $driverShiftListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		// Get Drivers request details
		$driversRequestsResults	= $this->getTable('ShiftRequestTable')->getDriverRequestDetails();
		$driversRequests		= array();
		$driversAllocated		= array();
		
		if($driversRequestsResults) {
//			$driversRequests		= $driversRequestsResults->toArray();
			foreach($driversRequestsResults as $key => $requests) {
				if(isset($requests["shift_occurs"]) && !empty($requests["shift_occurs"]) && $requests["shift_occurs"] == 1) {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]]	=  $requests;
					$driversAllocated[$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]][]  = $requests["user_firstname"].' '.$requests["user_lastname"];
				} else {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]]	=  $requests;
					$driversAllocated[$requests["fk_shift_id"]][$requests["shift_occurs"]][]  = $requests["user_firstname"].' '.$requests["user_lastname"];
				}
			}
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getShiftsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'message'			=> $message,
			'driversRequests'	=> $driversRequests,
			'driversAllocated'	=> $driversAllocated,
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'shiftIconArray'	=> $this->shiftIconArray,
			'shiftArray'		=> $this->shiftArray,
			'shiftRequestStatusArray' => $this->shiftRequestStatusArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	
	/*	Action	: 	Driver View Shift
	*	Detail	:	Used to view the shifts
	*	TODO	:	Ajax actions inprocess
	*/
	public function driverConfirmedShiftAction()
    {
		$request 	  =  $this->getRequest();
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$requestStatus	= $matches->getParam('id', 2);
		$page			= $matches->getParam('pageid', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		
		// Create Filter form
		$driverShiftFilterForm		=  new DriverShiftFilterForm();
		
		//	Destroy listing Session Vars
		$containerSession			= ($requestStatus == 2) ? "driverConfirmedShiftListing" : "driverRequestedShiftListing";
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array($containerSession));
		$driverShiftListingSession 	=  new Container($containerSession);
		
		if ($request->isPost()) {
			$driverShiftFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_shift_date']) && !empty($formData['search_shift_date']))
				$driverShiftListingSession->shift_date	= $formData['search_shift_date'];
			else
				$driverShiftListingSession->shift_date	= '';
			
			if(isset($formData['search_shift_name']) && $formData['search_shift_name'] != '')
				$driverShiftListingSession->shift_name	= $formData['search_shift_name'];
			else
				$driverShiftListingSession->shift_name	= '';
		}
		
		$driverShiftFilterForm->get('search_shift_name')->setValueOptions($this->shiftArray);
		
		if($driverShiftListingSession->offsetExists('shift_date') && $driverShiftListingSession->shift_date != '' ) {
			$driverShiftFilterForm->get('search_shift_date')->setValue($driverShiftListingSession->shift_date);
		}
		if($driverShiftListingSession->offsetExists('shift_name') && $driverShiftListingSession->shift_name != '' ) {
			$driverShiftFilterForm->get('search_shift_name')->setValue($driverShiftListingSession->shift_name);
		}
		
		// listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getConfirmedShiftsList($requestStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'driverShiftFilterForm'	=> $driverShiftFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'shiftIconArray'		=> $this->shiftIconArray,
			'shiftArray'			=> $this->shiftArray,
			'shiftRequestStatusArray' => $this->shiftRequestStatusArray,
			'datetime'			    => $datetime,
			'requestStatus'			=> $requestStatus,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax drivers Confirmed shift list, Ajax action
	*	Detail	:	Used to list the shifts details via Ajax
	*/
	public function driverConfirmedShiftListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$ajax			= $matches->getParam('id', 1);
		$page			= $matches->getParam('pageid', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		$requestStatus 	= $matches->getParam('requestStatus', 2);
		
		//	Session for Role listing
		$containerSession			= ($requestStatus == 2) ? "driverConfirmedShiftListing" : "driverRequestedShiftListing";
		$driverShiftListingSession  =  new Container($containerSession);
		$columnFlag		= 0;
		if($sortBy != '') {
			if($driverShiftListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$driverShiftListingSession->sortBy	= $sortBy;
		} else if($driverShiftListingSession->offsetExists('sortBy')) {
			$sortBy	= $driverShiftListingSession->sortBy;
		}
		if($sortType != '') {
			if($driverShiftListingSession->sortType == $sortType && $columnFlag == 1)
				$driverShiftListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$driverShiftListingSession->sortType	= $sortType;
		} else if($driverShiftListingSession->offsetExists('sortType')) {
			$sortType	= $driverShiftListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$driverShiftListingSession->perPage	= $perPage;
		} else if($driverShiftListingSession->offsetExists('perPage')) {
			$perPage		= $driverShiftListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getConfirmedShiftsList($requestStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'message'			=> $message,
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'shiftIconArray'	=> $this->shiftIconArray,
			'shiftArray'		=> $this->shiftArray,
			'shiftRequestStatusArray' => $this->shiftRequestStatusArray,
			'datetime'			=> $datetime,
			'requestStatus'		=> $requestStatus,
			'pc_users'			=> $this->pcUser,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Shift Event
	*	Detail	:	To View the Shift And Event details
	*/
	public function viewShiftEventAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			
			$request 			=  $this->getRequest();
			$message			=  '';
			$shiftId 			= (int) $this->params()->fromRoute('id', 0);
			$shiftEventDetails	= '';
			
			if ($shiftId) {
				$results		= $this->getTable("ShiftTable")->getShiftsDetailById($shiftId);
				if($results) {
					foreach($results as $event) {
						$shiftEventDetails = (array)$event;
					}
					
					// Date
					$datetime			=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$requestedDrivers	=  $allocatedDrivers =  array();
					$allocatedBikes  	=  array();
					$shiftManagers		=  array();
					
					$eventType			=  (isset($shiftEventDetails['event_type']) && !empty($shiftEventDetails['event_type'])) ? $shiftEventDetails['event_type'] : 1;		//	1 - Event via Shift, 2 - Event
					if($eventType == 1) {
						$shiftStartDate					 = ($shiftEventDetails['shift_occurs'] == 1) ? $shiftEventDetails['shift_dt_start_date'] : $shiftEventDetails['event_date'];
						$shiftEventDetails['shift_date'] = $datetime->getDates(strtotime($shiftStartDate), 0, 'n-j-Y');
					} else {
						if(isset($shiftEventDetails['event_date']) && $shiftEventDetails['event_date'] != "0000-00-00 00:00:00") {
							$shiftEventDetails['event_date']	= $datetime->getDates(strtotime($shiftEventDetails['event_date']), 0, 'n-j-Y');
						} else {
							$shiftEventDetails['event_date']	= '-';
						}
						
						// Get All Bikes for the particulat locations
						/*
						if (isset($shiftEventDetails['bike_reserved_type']) && !empty($shiftEventDetails['bike_reserved_type']) && $shiftEventDetails['bike_reserved_type'] == 2) {
							$bikesIds			= $shiftEventDetails['bike_reserved_ids'];
							$allBikesResults	= $this->getTable("BikeTable")->GetSelectedBikes($bikesIds);
							if($allBikesResults) {
								foreach($allBikesResults as $key => $value) {
									$bikeId					 = $value['bike_id'];
									$allocatedBikes[$bikeId] = $value;
								}
							}
						}
						*/
					} 	// End event type
					
					// Get Requested Drivers for the shift
					$shiftId 				=  $shiftEventDetails['shift_id'];
					$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId);
					if($requestResults) {
						$requestedToArray	=  $requestResults->toArray();
						if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
							foreach($requestedToArray as $keys => $values) {
								$requestedDrivers[$values['fk_user_id']]		=  $values;
								if($values['shift_request_status'] == 2) {
									$allocatedDrivers[$values['fk_user_id']]	=  $values;
									if($shiftEventDetails['shift_manager_id'] == $values['fk_user_id']) {
										$shiftManagers[$values['fk_user_id']]	=  $values['user_firstname'].' '.$values['user_lastname'];
									}
								}
							}
						}
					}
					
				}
			}
			
			$result->setVariables(array(
					'controller'	 		 => $this->params('controller'),
					'shiftEventDetails'	 	 => $shiftEventDetails,
					'allocatedDrivers'		 => $allocatedDrivers,
					'allocatedBikes'		 => $allocatedBikes,
					'pc_users'			 	 => $this->pcUser,
					'datetime'			     => $datetime,
					'eventType'			     => $eventType,
					'sitePath'	 			 => $this->sitePath,
					'eventCategoryArray'	 => $this->eventCategoryArray,
					'shiftArray'	 		 => $this->shiftArray,
					'shiftIconArray'	 	 => $this->shiftIconArray,
					'controller'			 => $this->params('controller'),
					'commonData'			 => $this->getCommonDataObj()
			));
			return $result;
		} else {
			die();
		}
    }
	
	public function manageShiftAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// assign default
		// ajax
		$matches				= $this->getEvent()->getRouteMatch();
		$ajax					= $matches->getParam('id', '');
		$page					= $matches->getParam('pageid', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		
		// Create Filter form
		$manageShiftFilterForm 	= new ManageShiftFilterForm();
		$shift_array			= array(''	=> 'All Shifts','1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$manageShiftFilterForm->get('shift_type')->setValueOptions($shift_array);
		$request 				= $this->getRequest();
		//	Destroy listing Session Vars
		if($ajax == '') {
			$status	 			= $this->getCommonDataObj()->destroySessionVariables(array('manageShiftListing', 'oldmanageShiftListing'));
		}
		$shiftListingSession 	= new Container('manageShiftListing');
		$OldshiftListingSession = new Container('oldmanageShiftListing');
		if ($request->isPost()) {
			$formData			=  $request->getPost();
			if(isset($formData['shift_type_chk']) && $formData['shift_type_chk'] == 1)
			{
				if(isset($formData['shift_date']) && !empty($formData['shift_date']))
					$shiftListingSession->shift_date	= $formData['shift_date'];
				else
					$shiftListingSession->shift_date	= '';
				if(isset($formData['shift_type']) && !empty($formData['shift_type']))
					$shiftListingSession->shift_type	= $formData['shift_type'];
				else
					$shiftListingSession->shift_type	= '';
			}
			else if(isset($formData['shift_type_chk']) && $formData['shift_type_chk'] == 2)
			{
				if(isset($formData['shift_date']) && !empty($formData['shift_date']))
					$OldshiftListingSession->shift_date	= $formData['shift_date'];
				else
					$OldshiftListingSession->shift_date	= '';
				if(isset($formData['shift_type']) && !empty($formData['shift_type']))
					$OldshiftListingSession->shift_type	= $formData['shift_type'];
				else
					$OldshiftListingSession->shift_type	= '';
			}
			if($ajax != '') {
				$jsonArray   		 = array();
				$jsonArray['status'] = true;
				echo json_encode($jsonArray);
				return $this->getResponse();
			}
		}
		$perPage				= $this->defaultPerPage;
		$shiftDate  			= 1; //2:Old data 1:New Data
		$iteratorAdapter_New	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getManageShiftList($shiftDate));
		$paginator_New			= new \Zend\Paginator\Paginator($iteratorAdapter_New);
		$paginator_New->setCurrentPageNumber($page);
		$paginator_New->setItemCountPerPage($perPage);
		$paginator_old			= '';
		$datetime				= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		return new ViewModel(array(
			'userObject'			=> $identity,
			'manageShiftFilterForm'	=> $manageShiftFilterForm,
			'pc_users'				=> $this->pcUser,
			'paginator_new'			=> $paginator_New,
			'paginator_old'			=> $paginator_old,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'perPage'		 		=> $perPage,
			'shiftDate'				=> $shiftDate,
			'datetime'				=> $datetime,
			'shiftArray'			=> $shift_array,
			'perPageArray'			=> $this->perPageArray,
			'shiftIconArray'		=> $this->shiftIconArray,
			'commonData'			=> $this->getCommonDataObj(),
			'controller'	 		=> $this->params('controller')
		));
    }
	
	public function manageShiftListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		// assign default
		$matches				= $this->getEvent()->getRouteMatch();
		$page					= $matches->getParam('pageid', 1);
		$sortBy					= $matches->getParam('sortBy', '');
		$sortType				= $matches->getParam('sortType', '');
		$perPage				= $matches->getParam('perPage', '');
		$shiftDate				= $matches->getParam('shiftDate', '');
		
		$shift_array			= array(''	=> 'All Shifts','1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$sessionsContainer		= (isset($shiftDate) && $shiftDate == 1) ? 'manageShiftListing' : 'oldmanageShiftListing';
		$shiftListingSession 	= new Container($sessionsContainer);
		$columnFlag		= 0;
		if($sortBy != '') {
			if($shiftListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$shiftListingSession->sortBy	= $sortBy;
		} else if($shiftListingSession->offsetExists('sortBy')) {
			$sortBy	= $shiftListingSession->sortBy;
		}
		if($sortType != '') {
			if($shiftListingSession->sortType == $sortType && $columnFlag == 1)
				$shiftListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$shiftListingSession->sortType	= $sortType;
		} else if($shiftListingSession->offsetExists('sortType')) {
			$sortType	= $shiftListingSession->sortType;
		}
		//	Perpage
		if($perPage != '') {
			$shiftListingSession->perPage	= $perPage;
		} else if($shiftListingSession->offsetExists('perPage')) {
			$perPage		= $shiftListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$message			= '';
		$shiftDate  		= (isset($shiftDate) && $shiftDate == 1) ? $shiftDate : 2;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getManageShiftList($shiftDate));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		if(isset($shiftDate) && $shiftDate == 2) {
			$paginator_New			= '';
			$paginator_old			= $paginator;
		} else {
			$paginator_New			= $paginator;
			$paginator_old			= '';
		}
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$result->setVariables(array(
			'pc_users'				=> $this->pcUser,
			'page'			 		=> $page,
			'sortBy'		 		=> $sortBy,
			'paginator_new'			=> $paginator_New,
			'paginator_old'			=> $paginator_old,
			'shiftDate'				=> $shiftDate,
			'perPage'		 		=> $perPage,
			'datetime'				=> $datetime,
			'shiftArray'			=> $shift_array,
			'perPageArray'			=> $this->perPageArray,
			'shiftIconArray'		=> $this->shiftIconArray,
			'commonData'			=> $this->getCommonDataObj(),
			'controller'	 		=> $this->params('controller')
		));
		return $result;
    }
	// 
	
	/*	Action	: 	Driver shift request, Ajax action
	*	Detail	:	Used to set the request for particular shifts by drivers.
	*/
	public function driverShiftRequestAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 		 = $this->getRequest();
		if ($request->isPost()) {
			// assign  values
			$matches		= $this->getEvent()->getRouteMatch();
			$shiftId		= $matches->getParam('shiftId', '');
			$shiftOccurs	= $matches->getParam('shiftOccurs', '');
			$shiftDtId		= $matches->getParam('shiftDtId', '');
			$todays_date	= date('Y-m-d');
			$check_shift_status = '';
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			
	        if ($shiftId) {
				$shift_status			= 1;
				$old_status				= 0;
				$fields					= "*";
				$where					= " shift_dt_id = ".$shiftDtId;
				$check_shift_status		= $this->getTable("ShiftTable")->getshiftDateTimeList($fields,$where);
				if(is_object($check_shift_status) && count($check_shift_status) > 0)
				{
					foreach($check_shift_status as $shift_key => $shift_value)
					{
						$check_count		= 0;
						if($shift_value['shift_dt_bike_available'] == 0)
						{
							$shift_status		= 3;
						}
						else if($shift_value['shift_dt_start_date'] == $todays_date)
						{
							$fields_shift		= " sr.shift_request_id";
							$where_shift		= " and sr.shift_request_status = 2 and sdt.shift_dt_start_date = '".$todays_date."' and sr.fk_user_id = '".$identity->user_id."'";
							$check_shift_timing	= $this->getTable("ShiftTable")->getparticularShiftRequestDetails($fields_shift,$where_shift);
							if(count($check_shift_timing) > 0)
							{
								$check_count	= 1;
							}
							else
							{
								$fields_event		= " sr.shift_request_id";
								$where_event		= " and sr.shift_request_status = 2 and e.event_date = '".$todays_date."' and sr.fk_user_id = '".$identity->user_id."'";
								$check_event_timing	= $this->getTable("ShiftTable")->getarticularEventRequestDetails($fields_event,$where_event);
								if(count($check_event_timing) > 0)
								{
									$check_count	= 1;
								}
							}
							if($check_count == 0)
							{
								$shift_status		= 2;
								$data				= " shift_dt_bike_available = shift_dt_bike_available - 1";
								$this->getTable("ShiftTable")->updateShiftDateTime($data,$shiftDtId);
							}
							else
							{
								$json_array['err']	= 2;
							}
						}
						else
						{
							$shift_status		= 1;
						}
						if($check_count == 0)
						{
							$requestedDate					 = $datetime(time(), 0, 'Y-m-d H:i:s');
							$shiftRequests["shiftId"]		 = $shiftId;
							$shiftRequests["user_id"]		 = $this->pcUser->user_id;
							$shiftRequests["request_status"] = $shift_status;
							$shiftRequests["requ_new_status"]= $old_status;
							$shiftRequests["shift_occurs"]   = $shiftOccurs;
							$shiftRequests["shift_dt_id"]    = $shiftDtId;
							$shiftRequests["created_date"]   = $requestedDate;
							$shiftRequests["updated_date"]   = $requestedDate;
							$request_id						 = $this->getTable("ShiftRequestTable")->driverShiftRequest($shiftRequests);
							$json_array['err']				 = 0;
							$json_array['req_id']			 = $request_id;
							$json_array['req_stat']			 = $shift_status;
							$notification_subject			 = 'Driver confirmed his shift';
							$notify_type					 = 1;
							$notify_date					 = $todays_date;
							/*$insert_array[]					 = "'".$shiftId."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($notify_date)."','".addslashes($notify_type)."'";
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_multi_string	= "(".implode("),(",$insert_array).")";
							}
							if(isset($insert_multi_string) && $insert_multi_string != '')
							{
								$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
							}*/
						}
						else
						{
							$shift_status	= 5;
						}
					}
				}
				echo $shift_status;
			}
		}
        return $this->getResponse();
    }
	
	public function eventDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 		 = $this->getRequest();
		$event_details = $shiftRequestDetail = '';
		$json_array = array();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$event_id		= $matches->getParam('id', '');
			if(isset($event_id) && $event_id != '')
			{
				$event_details		= $this->getTable("ShiftTable")->getparticularEventDetails($event_id);
				if(is_object($event_details) && count($event_details) > 0)
				{
					foreach($event_details as $eve_key => $eve_value)
					{
						$where				= " and fk_shift_id = ".$eve_value['shift_id']." and fk_user_id = ".$identity->user_id;
						$shiftRequestDetail = $this->getTable("ShiftTable")->getParticularShiftRequest($where);
						if(is_object($shiftRequestDetail) && count($shiftRequestDetail) > 0)
						{
							foreach($shiftRequestDetail as $sr_key => $sr_value)
							{
								$shiftRequestArray[$sr_value['fk_shift_id']]			= $sr_value['shift_request_id'];
								$shiftRequestStat[$sr_value['fk_shift_id']]				= $sr_value['shift_request_status'];
							}
						}
						$requestId	= $requestStat = '';
						if(isset($shiftRequestArray[$eve_value['shift_id']]) && $shiftRequestArray[$eve_value['shift_id']] != '')
						{
							$requestId		= $shiftRequestArray[$eve_value['shift_id']];
							$requestStat	= $shiftRequestStat[$eve_value['shift_id']];
						}
						$json_array['title']			= stripslashes($eve_value['event_title']);
						$json_array['category']			= isset($this->eventCategoryArray[$eve_value['event_category']])?$this->eventCategoryArray[$eve_value['event_category']]:'';
						$json_array['description']		= stripslashes($eve_value['event_description']);
						$json_array['st_time']			= $this->getCommonDataObj()->convertTimeFormat($eve_value['shift_start_time'],'');
						$json_array['ed_time']			= $this->getCommonDataObj()->convertTimeFormat($eve_value['shift_end_time'],'');
						$json_array['event_type']		= $eve_value['event_type'];
						$json_array['shift_id']			= $eve_value['shift_id'];
						$json_array['req_id']			= $requestId;
						$json_array['req_stat']			= $requestStat;
					}
				}
			}
		}
		echo json_encode($json_array);die();
	}
	public function deleteShiftAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$event_id		= $matches->getParam('eventId', '');
			$shift_id		= $matches->getParam('shiftId', '');
			if(isset($shift_id) && $shift_id != '')
			{
				$data		= " shift_isdelete = 1,shift_updated_date = now()";
				$this->getTable("ShiftTable")->updateShift($data,$shift_id);
			}
			if(isset($event_id) && $event_id != '')
			{
				$data		= " event_isdelete = 1,event_updated_date = now()";
				$this->getTable("ShiftTable")->updateEvent($data,$event_id);
			}
		}
		echo 1;die();
	}
	public function deleteShiftEventAction()
	{
		$request 		 = $this->getRequest();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$sh_ev_id		= $matches->getParam('sh_ev_id', '');
			$shift_id		= $matches->getParam('shiftId', '');
			$occurs			= $matches->getParam('occurs', '');
			$shift_count = 0;
			if($occurs == 1)
			{
				$fields				= " count(shift_dt_id) as num_count";
				$where				= " fk_shift_id	= ".$shift_id." and shift_dt_status = 1";
				$shift_date_details	= $this->getTable("ShiftTable")->getshiftDateTimeList($fields,$where);
				if(is_object($shift_date_details) && count($shift_date_details) > 0)
				{
					foreach($shift_date_details as $shift_key => $shift_value)
					{
						$shift_count	= $shift_value['num_count'];
					}
				}
				if($shift_count == 1)
				{
					if(isset($shift_id) && $shift_id != '')
					{
						$data		= " shift_isdelete = 1,shift_updated_date = now()";
						$this->getTable("ShiftTable")->updateShift($data,$shift_id);
					}
				}
				if(isset($sh_ev_id) && $sh_ev_id != '')
				{
					$data		= " shift_dt_status = 0";
					$this->getTable("ShiftTable")->updateShiftDateTime($data,$sh_ev_id);
				}
			}
			else
			{
				if(isset($shift_id) && $shift_id != '')
				{
					$data		= " shift_isdelete = 1,shift_updated_date = now()";
					$this->getTable("ShiftTable")->updateShift($data,$shift_id);
				}
				if(isset($sh_ev_id) && $sh_ev_id != '')
				{
					$data		= " event_isdelete = 1,event_updated_date = now()";
					$this->getTable("ShiftTable")->updateEvent($data,$sh_ev_id);
				}
			}
		}
		echo 1;die();
	}
	public function driverDashboardAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		//Get Today and next day shift details
		$shiftDateSession 		= new Container('shiftDateTime');
		$shift_date				= array();
		/*if($shiftDateSession->offsetExists('shiftDates') && $shiftDateSession->shiftDates != '' ) {
			$shift_date			= $shiftDateSession->shiftDates;
		} else {*/
		$shift_details		= $this->getTable('ShiftTable')->getCurrentShiftDetails($identity);
		if($shift_details) {
			foreach($shift_details as $shift) {
				if(isset($shift['shift_dt_id']) && $shift['shift_dt_id'] != '')
				{
					$shift_date[$shift['shift_dt_id']]  =  $shift;
				}
				else
				{
					$shift_date[$shift['event_id']]  	=  $shift;
				}
				
			}
		}
		$shiftDateSession->shiftDates  		   =  $shift_date;
		//}
		$todays_date	= date('Y-m-d');
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'shiftDateSession'	=> $shiftDateSession,
			'todays_date'		=> $todays_date,
			'controller'	 	=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj(),
			'datetime'			=> $datetime,
			'action'			=>$this->params('action')
		));
	}
	public function driverCalendarDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$shift_date_array = $shift_date_time_array = $shift_event_array = $shift_array = $implode_shift_dt_ids = $implode_shift_event_ids = '';
		$shift_event_details = $shift_type_array = $bike_avail_array = $event_title = $event_cat = $event_des = $shift_request_det = '';
		$shift_request_array = $shift_request_status = $weather_key = $meetingDetails = '';
		$shift_calendar_array = $event_request_array = $event_request_status = array();
		$request 				= $this->getRequest();
		if($request->isPost())
		{
			$where = '';
			$pc_user_details	= $this->pcUser;
			$get_ajax_data		= $request->getPost();
			$date_range			= date("Y-m-d",strtotime("+14 days"));
			$calendar_month		= $get_ajax_data['month'];
			$todays_date		= strtotime(date('Y-m-d'));
			$user_role_id		= $identity->user_role_id;
			$e = 0;
			if($calendar_month == date('m'))
			{
				$weather_key		= $this->getCommonDataObj()->getWeatherKey();
				if($weather_key != '' && $identity->location_postal_code != '')
				{
					$url			= "https://api.wunderground.com/api/".$weather_key."/forecast/geolookup/conditions/q/".$identity->location_postal_code.".json"; //default Zipcode Boston(02118)
					$weather_detail = file_get_contents($url);
					
					$weather_detail	= json_decode($weather_detail);
					if(is_object($weather_detail) && count($weather_detail) > 0)
					{
						$shift_calendar_array[$e]['shift_id']			= 0;
						$shift_calendar_array[$e]['start']				= date('Y-m-d',$weather_detail->current_observation->observation_epoch);
						$shift_calendar_array[$e]['end']				= date('Y-m-d',$weather_detail->current_observation->observation_epoch);
						$shift_calendar_array[$e]['normal']				= $weather_detail->current_observation->temp_f." F (".$weather_detail->current_observation->temp_c." C)";
						$shift_calendar_array[$e]['shift_event']		= 3;
						$shift_calendar_array[$e]['conditions']			= ucfirst($weather_detail->current_observation->weather);
						$shift_calendar_array[$e]['icon']				= ucfirst($weather_detail->current_observation->icon);
						$shift_calendar_array[$e]['icon_url']			= $weather_detail->current_observation->icon_url;
						$shift_calendar_array[$e]['date_check']			= 1;
						$shift_calendar_array[$e]['user_role']			= $user_role_id;
						$e = $e+1;
						foreach($weather_detail->forecast->simpleforecast->forecastday as $weather_key => $weather_value)
						{
							$st_dat		= date('Y-m-d',$weather_value->date->epoch);
							$end_dat	= date('Y-m-d',$weather_value->date->epoch);
							if(date('Y-m-d') != $st_dat)
							{
								$shift_calendar_array[$e]['shift_id']			= 0;
								$shift_calendar_array[$e]['start']				= $st_dat;
								$shift_calendar_array[$e]['end']				= $end_dat;
								$shift_calendar_array[$e]['high']				= $weather_value->high->fahrenheit." F (".$weather_value->high->celsius." C)";
								$shift_calendar_array[$e]['low']				= $weather_value->low->fahrenheit." F (".$weather_value->low->celsius." C)";
								$shift_calendar_array[$e]['shift_event']		= 3;
								$shift_calendar_array[$e]['conditions']			= ucfirst($weather_value->conditions);
								$shift_calendar_array[$e]['icon']				= ucfirst($weather_value->icon);
								$shift_calendar_array[$e]['icon_url']			= $weather_value->icon_url;
								$shift_calendar_array[$e]['date_check']			= 1;
								$shift_calendar_array[$e]['user_role']			= $user_role_id;
								$e++;
							}
						}
					}
				}
			}
			$where_new = '';
			if(isset($calendar_month) && $calendar_month != '')
			{
				$where		.= " and MONTH(sdt.shift_dt_end_date) = ".$calendar_month." and sdt.shift_dt_start_date <= '".$date_range."'";
			}
			if(isset($pc_user_details->user_role_id) && $pc_user_details->user_role_id == 1)
			{
				$where		.= " and s.fk_location_id = ".$pc_user_details->location_id." ";//
				$where_new	.= " and fk_user_id = '".$pc_user_details->user_id."'";
			}
			$fields				= "s.shift_type,s.shift_id,s.shift_occurs,sdt.shift_dt_bike_available,sdt.shift_dt_start_date,sdt.shift_dt_end_date,sdt.fk_shift_id,sdt.shift_dt_id,sdt.shift_dt_bike_rental";
			$shift_dt_details	= $this->getTable('ShiftTable')->getParticularShift($fields,$where);
			$shift_request_det	= $this->getTable('ShiftTable')->getParticularShiftRequest($where_new);
			if(is_object($shift_request_det) && count($shift_request_det) > 0)
			{
				foreach($shift_request_det as $shre_key => $shre_value)
				{
					if($shre_value['shift_occurs'] == 1)
					{
						$shift_request_array[$shre_value['fk_shift_dt_id']]		= $shre_value['shift_request_id'];
						$shift_request_status[$shre_value['fk_shift_dt_id']]	= $shre_value['shift_request_status'];
					}
					else
					{
						$event_request_array[$shre_value['fk_shift_id']]		= $shre_value['shift_request_id'];
						$event_request_status[$shre_value['fk_shift_id']]		= $shre_value['shift_request_status'];
					}
				}
			}
			if(is_object($shift_dt_details) && count($shift_dt_details) > 0)
			{
				foreach($shift_dt_details as $sdt_key => $sdt_value)
				{
					$request_id = $req_status = '';
					$chk_greater = 0;
					$st_dat_str			= strtotime($sdt_value['shift_dt_start_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					if(isset($shift_request_array[$sdt_value['shift_dt_id']]) && $shift_request_array[$sdt_value['shift_dt_id']] != '')
					{
						$request_id		= $shift_request_array[$sdt_value['shift_dt_id']];
						$req_status		= $shift_request_status[$sdt_value['shift_dt_id']];
					}
					$shift_calendar_array[$e]['shift_id']			= $sdt_value['fk_shift_id'];
					$shift_calendar_array[$e]['start']				= $sdt_value['shift_dt_start_date'];
					$shift_calendar_array[$e]['end']				= $sdt_value['shift_dt_end_date'];
					$shift_calendar_array[$e]['bike_avail']			= $sdt_value['shift_dt_bike_available'];
					$shift_calendar_array[$e]['bike_rent']			= $sdt_value['shift_dt_bike_rental'];
					$shift_calendar_array[$e]['shift_type']			= $sdt_value['shift_type'];
					$shift_calendar_array[$e]['shift_dt_id']		= $sdt_value['shift_dt_id'];
					$shift_calendar_array[$e]['request_id']			= $request_id;
					$shift_calendar_array[$e]['req_status']			= $req_status;
					$shift_calendar_array[$e]['shift_event']		= 2;
					$shift_calendar_array[$e]['event_title']		= '';
					$shift_calendar_array[$e]['event_cat']			= '';
					$shift_calendar_array[$e]['event_des']			= '';
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
			$where		= '';
			if(isset($date_range) && $date_range != '')
			{
				$where	.= " and e.event_date <= '".$date_range."'";
			}
			if(isset($pc_user_details->user_role_id) && $pc_user_details->user_role_id == 1)
			{
				$where	.= " and s.fk_location_id = ".$pc_user_details->location_id;//and (sr.fk_user_id = '".$pc_user_details->user_id."' or sr.fk_user_id is null) 
			}
			$fields		 = "s.shift_type,s.shift_id,s.shift_occurs,e.shift_bike_available,e.fk_shift_id,e.event_date,e.event_id,e.event_title,e.event_category,e.event_description,e.shift_bike_rental";
			$shift_event_details		= $this->getTable('ShiftTable')->getParticularEvent($fields,$where);
			if(is_object($shift_event_details) && count($shift_event_details) > 0)
			{
				foreach($shift_event_details as $event_key => $event_value)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($event_value['event_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					if(isset($event_request_array[$event_value['fk_shift_id']]) && $event_request_array[$event_value['fk_shift_id']] != '')
					{
						$request_id		= $event_request_array[$event_value['fk_shift_id']];
						$req_status		= $event_request_status[$event_value['fk_shift_id']];
					}
					$shift_calendar_array[$e]['shift_id']			= $event_value['fk_shift_id'];
					$shift_calendar_array[$e]['start']				= $event_value['event_date'];
					$shift_calendar_array[$e]['end']				= $event_value['event_date'];
					$shift_calendar_array[$e]['bike_avail']			= $event_value['shift_bike_available'];
					$shift_calendar_array[$e]['bike_rent']			= $event_value['shift_bike_rental'];
					$shift_calendar_array[$e]['shift_type']			= $event_value['shift_type'];
					$shift_calendar_array[$e]['event_id']			= $event_value['event_id'];
					$shift_calendar_array[$e]['request_id']			= $request_id;
					$shift_calendar_array[$e]['req_status']			= $req_status;
					$shift_calendar_array[$e]['shift_event']		= 1;
					$shift_calendar_array[$e]['event_title']		= $this->getCommonDataObj()->displayShortText($event_value['event_title'], '20');
					$shift_calendar_array[$e]['event_cat']			= isset($this->eventCategoryArray[$event_value['event_category']])?$this->eventCategoryArray[$event_value['event_category']]:'';
					$shift_calendar_array[$e]['event_des']			= $event_value['event_description'];
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
			$meetingFields		= "*";
			$meetingWhere		= " meeting_status = 2 and meeting_to = ".$identity->user_role_id;
			$meetingDetails		= $this->getTable('ShiftTable')->getMeetingList($meetingFields,$meetingWhere);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $meetKey => $meetValue)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($meetValue['meeting_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					$shift_calendar_array[$e]['shift_id']			= 0;
					$shift_calendar_array[$e]['meet_id']			= $meetValue['meeting_id'];
					$shift_calendar_array[$e]['start']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['end']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['meet_time']			= $this->getCommonDataObj()->convertTimeFormat($meetValue['meeting_time'],'');
					$shift_calendar_array[$e]['meeting_to']			= $meetValue['meeting_to'];
					$shift_calendar_array[$e]['price']				= $meetValue['meeting_budget_request'];
					$shift_calendar_array[$e]['shift_event']		= 4;
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
		}
		echo json_encode($shift_calendar_array);die();
	}
	public function driverShiftReqCalAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 		 = $this->getRequest();
		if ($request->isPost()) {
			// assign  values
			$matches		= $this->getEvent()->getRouteMatch();
			$shiftId		= $matches->getParam('shiftId', '');
			$shiftOccurs	= $matches->getParam('shiftOccurs', '');
			$shiftDtId		= $matches->getParam('shiftDtId', '');
			$json_array		= array();
			$todays_date	= date('Y-m-d');
			$check_shift_status = $check_shift_timing = $check_event_timing = '';
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
	        if($shiftId)
			{
				$shift_status			= 1;
				$old_status				= 0;
				$fields					= "*";
				$where					= " shift_dt_id = ".$shiftDtId;
				$check_shift_status		= $this->getTable("ShiftTable")->getshiftDateTimeList($fields,$where);
				if(is_object($check_shift_status) && count($check_shift_status) > 0)
				{
					foreach($check_shift_status as $shift_key => $shift_value)
					{
						$check_count		= 0;
						if($shift_value['shift_dt_bike_available'] == 0)
						{
							$shift_status		= 3;
						}
						else if($shift_value['shift_dt_start_date'] == $todays_date)
						{
							$fields_shift		= " sr.shift_request_id";
							$where_shift		= " and sr.shift_request_status = 2 and sdt.shift_dt_start_date = '".$todays_date."' and sr.fk_user_id = '".$identity->user_id."'";
							$check_shift_timing	= $this->getTable("ShiftTable")->getparticularShiftRequestDetails($fields_shift,$where_shift);
							if(count($check_shift_timing) > 0)
							{
								$check_count	= 1;
							}
							else
							{
								$fields_event		= " sr.shift_request_id";
								$where_event		= " and sr.shift_request_status = 2 and e.event_date = '".$todays_date."' and sr.fk_user_id = '".$identity->user_id."'";
								$check_event_timing	= $this->getTable("ShiftTable")->getarticularEventRequestDetails($fields_event,$where_event);
								if(count($check_event_timing) > 0)
								{
									$check_count	= 1;
								}
							}
							if($check_count == 0)
							{
								$shift_status		= 2;
								$data				= " shift_dt_bike_available = shift_dt_bike_available - 1";
								$this->getTable("ShiftTable")->updateShiftDateTime($data,$shiftDtId);
							}
							else
							{
								$json_array['err']	= 2;
							}
						}
						else
						{
							$shift_status		= 1;
						}
						if($check_count == 0)
						{
							$requestedDate					 = $datetime(time(), 0, 'Y-m-d H:i:s');
							$shiftRequests["shiftId"]		 = $shiftId;
							$shiftRequests["user_id"]		 = $this->pcUser->user_id;
							$shiftRequests["request_status"] = $shift_status;
							$shiftRequests["requ_new_status"]= $old_status;
							$shiftRequests["shift_occurs"]   = $shiftOccurs;
							$shiftRequests["shift_dt_id"]    = $shiftDtId;
							$shiftRequests["created_date"]   = $requestedDate;
							$shiftRequests["updated_date"]   = $requestedDate;
							$request_id						 = $this->getTable("ShiftRequestTable")->driverShiftRequest($shiftRequests);
							$json_array['err']				 = 0;
							$json_array['req_id']			 = $request_id;
							$json_array['req_stat']			 = $shift_status;
							$notification_subject			 = 'Driver confirmed his shift';
							$notify_type					 = 1;
							$notify_date					 = $todays_date;
							/*$insert_array[]					 = "'".$shiftId."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($notify_date)."','".addslashes($notify_type)."'";
							if(is_array($insert_array) && count($insert_array) > 0)
							{
								$insert_multi_string	= "(".implode("),(",$insert_array).")";
							}
							if(isset($insert_multi_string) && $insert_multi_string != '')
							{
								$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
							}*/
						}
					}
				}
			}
			else
			{
				$json_array['err']				 = 1;
			}
		}
		echo json_encode($json_array);die();
    }
	public function mechanicDashboardAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// Condition handling for Mechanic login
		$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$date			=  $datetime(time(), 0, 'Y-m-d');
		$logtimeDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
		$checkLogin  	=  array(
			'user_id'	=> $this->pcUser->user_id,
			'user_role_id'	=> $this->pcUser->user_role_id,
			'date'		=> $date
		);
		$loginStatus	=  $this->getTable("LogtimeTable")->checkLogInOutTime($checkLogin);
		$logs			=  array();
		if($loginStatus) {
			foreach($loginStatus as $value) {
				$logs	= (array) $value;
			}
			$status		= ($logs['logtime_status'] == 1) ? 1 : 2;			//	1 - 'Second In - Time',  2	-	'Out - Time'
			/*if($logs['logtime_status'] == 1) {
				$status	= 1;		//	'Second In - Time'
			} else {
				$status	= 2;		//	'Out - Time'
			}*/
		} else {
				$status	= 1;			//	'First In - Time'
		}
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'controller'	 	=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj(),
			'datetime'			=> $datetime,
			'loginStatus'		=> $status,
			'action'			=>$this->params('action')
		));
	}
	public function clientDashboardAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'controller'	 	=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj(),
			'datetime'			=> $datetime,
			'action'			=>$this->params('action')
		));
	}
	public function driverShiftCancelAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 		 = $this->getRequest();
		if ($request->isPost()) {
			// assign  values
			$matches		= $this->getEvent()->getRouteMatch();
			$shiftId		= $matches->getParam('shiftId', '');
			$shiftOccurs	= $matches->getParam('shiftOccurs', '');
			$shiftDtId		= $matches->getParam('shiftDtId', '');
			$reqId			= $matches->getParam('reqId', '');
			$reqSt			= $matches->getParam('reqSt', '');
			$json_array		= array();
			$shift_array	= array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
			$check_shift_status = $hour_format = $hour = $get_particular_shift = $current_shift_time = $previous_time = $current_date_time = $user_details_array = '';
			$driver_name_new = $get_user_name_details = $reason_driver = '';
			$get_post_data	= $request->getPost();
			$location_manager_array = $driver_details_array = $insert_array = array();
			if($shiftId > 0)
			{
				$reason_driver		= $get_post_data['reason'];
				if($reqSt == 2) // Condition to cancel confirm shift
				{
					$assign_shift_other	= 0;
					if($shiftOccurs == 1)
					{
						$fields					= "sdt.shift_dt_st_time as shift_start_time,s.shift_end_time,sdt.shift_dt_start_date,s.shift_type";
						$where					= " and sdt.shift_dt_id = ".$shiftDtId;
						$get_particular_shift	= $this->getTable('ShiftTable')->getParticularShift($fields,$where);
					}
					else if($shiftOccurs == 2)
					{
						$fields					= "s.shift_start_time,s.shift_end_time,e.event_date,s.shift_type,e.event_title";
						$where					= " and e.fk_shift_id = ".$shiftId;
						$get_particular_shift	= $this->getTable('ShiftTable')->getParticularEvent($fields,$where);
					}
					if(is_object($get_particular_shift) && count($get_particular_shift) > 0)
					{
						foreach($get_particular_shift as $par_key => $par_value)
						{
							$shift_time			= $par_value['shift_start_time'];
							$time_sub			= "6:00:00"; // Cut off time
							$hour_format		= explode(":",$time_sub);
							if($shiftOccurs == 1)
							{
								$date				= $par_value['shift_dt_start_date']." ".$shift_time;
							}
							else if($shiftOccurs == 2)
							{
								$date				= $par_value['event_date']." ".$shift_time;
							}
							if(is_array($hour_format) && count($hour_format) > 0)
							{
								$hour	= "PT".$hour_format[0]."H".$hour_format[1]."M";
							}
							$check_confirm_status	= $this->getCommonDataObj()->getPreviousDateTime($hour,$date);
							if(isset($check_confirm_status) && $check_confirm_status != '')
							{
								$previous_time			= strtotime($check_confirm_status);
								$current_shift_time		= strtotime($date);
								$current_date_time		= strtotime(date('Y-m-d H:i:s'));
								if($previous_time - $current_date_time < 0 && $current_date_time - $current_shift_time < 0)
								{
									$json_array['req_st']	= 4;
									$json_array['err']		= 0;
									//Get Location Managers
									$where_user			= "  and location_id = '".$identity->location_id."' and user_role_id in (3)";
									$user_details_array	= $this->getTable('ShiftTable')->getuserDetails($where_user);
									if(is_object($user_details_array) && count($user_details_array) > 0)
									{
										foreach($user_details_array as $user_key => $user_value)
										{
											$location_manager_array[]	= $user_value['user_id'];
										}
									}
									$par_value['shift_start_time']	= $this->getCommonDataObj()->convertTimeFormat($par_value['shift_start_time'],'');
									$par_value['shift_end_time']	= $this->getCommonDataObj()->convertTimeFormat($par_value['shift_end_time'],'');
									//Get Next oncall list driver Info
									if($shiftOccurs == 1)
									{
										$where_next				= " and fk_shift_dt_id = ".$shiftDtId." and shift_request_status = 3 and fk_user_id != '".$identity->user_id."' order by shift_request_id asc Limit 1";
									}
									else if($shiftOccurs == 2)
									{
										$where_next				= " and fk_shift_id = ".$shiftId." and shift_request_status = 3 and fk_user_id != '".$identity->user_id."' order by shift_request_id asc Limit 1";
									}
									$driver_details_array	= $this->getTable('ShiftTable')->getParticularShiftRequest($where_next);
									if(is_object($driver_details_array) && count($driver_details_array) > 0)
									{
										foreach($driver_details_array as $driver_ke => $driver_val)
										{
											$assign_shift_other		= 1;
											$json_array['assign']	= 1;
											$driv_up_data	= " shift_request_concat_status = concat(shift_request_concat_status,',',shift_request_status),shift_request_status = 2 ";
											$this->getTable('ShiftTable')->updateShiftRequest($driv_up_data,$driver_val['shift_request_id']);
											$whr_usr				= " and user_id = ".$driver_val['fk_user_id'];
											$get_user_name_details	= $this->getTable('ShiftTable')->getuserDetails($whr_usr);
											if(is_object($get_user_name_details) && count($get_user_name_details) > 0)
											{
												foreach($get_user_name_details as $user_key => $user_value)
												{
													$driver_name_new		= $user_value['user_firstname']." ".$user_value['user_lastname'];
												}
											}
											if($shiftOccurs == 1)
											{
												$notification_subj			= $shift_array[$par_value['shift_type']]." Shift has been cancelled by me and i am assigning my shift to you.<br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time'];
												$notification_subj_loc		= $shift_array[$par_value['shift_type']]." Shift has been cancelled by me and i am assigning my shift to ".$driver_name_new."<br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time']."<br>Reason : ".$reason_driver;
												$notify_dat					= $par_value['shift_dt_start_date'];
												$notify_typ					= 1;
											}
											else if($shiftOccurs == 2)
											{
												$notification_subj			= $par_value['event_title']." has been cancelled by me and i am assigning my shift to you <br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time'];
												$notification_subj_loc		= $par_value['event_title']." has been cancelled by me and i am assigning my shift to ".$driver_name_new."<br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time']."<br>Reason : ".$reason_driver;
												$notify_dat					= $par_value['event_date'];
												$notify_typ					= 2;
											}
											$insert_array[]		= "'".$shiftId."','".$identity->user_id."','".$driver_val['fk_user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subj)."','".addslashes($notify_dat)."','".addslashes($notify_typ)."'";
											if(is_array($location_manager_array) && count($location_manager_array) > 0)
											{
												foreach($location_manager_array as $l_key => $l_value)
												{
													$insert_array[]		= "'".$shiftId."','".$identity->user_id."','".$l_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subj_loc)."','".addslashes($notify_dat)."','".addslashes($notify_typ)."'";
												}
											}
										}
									}
									else
									{
										$json_array['assign']	= 0;
										if($shiftOccurs == 1)
										{
											$data		= " shift_dt_bike_available = shift_dt_bike_available + 1";
											$this->getTable('ShiftTable')->updateShiftDateTime($data,$shiftDtId);
										}
										else if($shiftOccurs == 2)
										{
											$data		= " shift_bike_available = shift_bike_available + 1";
											$this->getTable('ShiftTable')->updateShiftEvent($data,$shiftId);
										}
									}
									//Update shift request table to cancel state
									$update_data		= " shift_request_concat_status = concat(shift_request_concat_status,',',shift_request_status),shift_request_status = 4 ";
									$this->getTable('ShiftTable')->updateShiftRequest($update_data,$reqId);
									if(is_array($location_manager_array) && count($location_manager_array) > 0 && $assign_shift_other == 0) // Notification Without assigning the driver from oncall list
									{
										if($shiftOccurs == 1)
										{
											$notification_subject		= $shift_array[$par_value['shift_type']]." Shift has been cancelled by driver <br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time']."<br>Reason : ".$reason_driver;
											$notify_date				= $par_value['shift_dt_start_date'];
											$notify_type				= 1;
										}
										else if($shiftOccurs == 2)
										{
											$notification_subject		= $par_value['event_title']." has been cancelled by driver <br>Timing : ".$par_value['shift_start_time']." to ".$par_value['shift_end_time']."<br>Reason : ".$reason_driver;
											$notify_date				= $par_value['event_date'];
											$notify_type				= 2;
										}
										foreach($location_manager_array as $driver_key => $driver_value)
										{
											$insert_array[]		= "'".$shiftId."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($notify_date)."','".addslashes($notify_type)."'";
										}
									}
									if(is_array($insert_array) && count($insert_array) > 0)
									{
										$insert_multi_string	= "(".implode("),(",$insert_array).")";
									}
									if(isset($insert_multi_string) && $insert_multi_string != '')
									{
										$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
									}
								}
								else
								{
									$json_array['err']	= 2;
								}
							}
						}
					}
				}
				else if($reqSt == 3)
				{
					if($reqId != '')
					{
						$json_array['err']	= 0;
						$update_data		= " shift_request_concat_status = concat(shift_request_concat_status,',',shift_request_status),shift_request_status = 4 ";
						$this->getTable('ShiftTable')->updateShiftRequest($update_data,$reqId);
					}
				}
			}
			else
			{
				$json_array['err']	 = 1;
			}
		}
		echo json_encode($json_array);die();
    }
	/*	Action	: 	send NewShiftMails
	*	Detail	:	Send the mails
	*/
	private function sendNewShiftMails()
    {
		/*
		// Get All Active drivers
		$allDriversSession 		= new Container('allDrivers');
		$allDrivers				= array();
		if($allDriversSession->offsetExists('allDriver') && $allDriversSession->allDriver != '' ) {
			$allDrivers			= $allDriversSession->allDriver;
		} else {
			$drivers			= $this->getTable("UsersTable")->getAllUsersDetail(1);
			if($drivers) {
				foreach($drivers as $driver) {
					$allDrivers[$driver->user_id]  =  $driver->user_firstname.' '.$driver->user_lastname;
				}
			}
			$allDriversSession->allDriver  =  $allDrivers;
		}
		
		if(isset($allDrivers) && is_array($allDrivers) && count($allDrivers)) {
			foreach($allDrivers as $driver_key => $driver) {
				$mail_title				= 'Hello '.strtolower(ucFirst($formData['user_firstname'])).' '.$formData['user_lastname'];
				$mail_descriptions		= 'Registration is successfully done!, Can you check your login details are below, <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
				
				$mailArray			    =  array(
					'subject'		  	=> 'Registration mail',
		            'from_email'	  	=> 'pajany@sdi.la',
					'from_name' 	  	=> 'Pajany',
					'to_email' 	  	  	=> $formData['user_email'],
					'mail_title' 	  	=> $mail_title,
					'mail_descriptions' => $mail_descriptions
		        );
				
				$allRoleSession 		= new Container('allRole');
				$role					= (isset($allRoleSession->allRoles[$formData['user_role_id']])) ? $allRoleSession->allRoles[$formData['user_role_id']] : '';
				$user			    	=  array(
					'Email'		  		=> $formData['user_email'],
					'Password'		  	=> $formData['user_password'],
					'First Name'		=> $formData['user_firstname'],
					'Last Name'		  	=> $formData['user_lastname'],
					'Role'		  		=> $role
		        );
				
				$this->siteMailSending($user, $mailArray);
			}
		}
		*/
		/*
		$mail_title				= 'Hello '.strtolower(ucFirst($formData['user_firstname'])).' '.$formData['user_lastname'];
		$mail_descriptions		= 'Registration is successfully done!, Can you check your login details are below, <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
		
		$mailArray			    =  array(
			'subject'		  	=> 'Registration mail',
            'from_email'	  	=> 'pajany@sdi.la',
			'from_name' 	  	=> 'Pajany',
			'to_email' 	  	  	=> $formData['user_email'],
			'mail_title' 	  	=> $mail_title,
			'mail_descriptions' => $mail_descriptions
        );
		
		$allRoleSession 		= new Container('allRole');
		$role					= (isset($allRoleSession->allRoles[$formData['user_role_id']])) ? $allRoleSession->allRoles[$formData['user_role_id']] : '';
		$user			    	=  array(
			'Email'		  		=> $formData['user_email'],
			'Password'		  	=> $formData['user_password'],
			'First Name'		=> $formData['user_firstname'],
			'Last Name'		  	=> $formData['user_lastname'],
			'Role'		  		=> $role
        );
		
		$this->siteMailSending($user, $mailArray);
		*/
	}
	
	/*	Action	: 	site Mail Sending
	*	Detail	:	Send the mails
	*/
	private function siteMailSending($user, $mailArray)
    {
		//	Get common data
		if (!isset($this->sendMail)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->sendMail 	=  $sm->get('viewhelpermanager')->get('sendMail');
        }
		$this->renderer 		= $this->getServiceLocator()->get('ViewRenderer');
		$content 				= $this->renderer->render('usermanagement/tpl/template', null);
		$mailArray['content']	= $content;
		
		// Send mails
		$this->sendMail->mailSend($mailArray, $user);
		return true;
    }
	
	/*	Action	: 	Testing
	*	Detail	:	Used to test something for development
	*/
	public function testAction()
	{
		$this->sendNewShiftMails();
		return $this->getResponse();
		
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	public function calendarAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// Create Filter form
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'pc_users'			=> $this->pcUser,
			'controller'	 	=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj(),
			'action'			=> $this->params('action')
		));
	}
	public function clientCalendarDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$shift_date_array = $shift_date_time_array = $shift_event_array = $shift_array = $implode_shift_dt_ids = $implode_shift_event_ids = '';
		$shift_event_details = $shift_type_array = $bike_avail_array = $event_title = $event_cat = $event_des = $shift_request_det = '';
		$shift_request_array = $shift_request_status = '';
		$shift_calendar_array = $event_request_array = $event_request_status = array();
		$request 				= $this->getRequest();
		if($request->isPost())
		{
			$where = '';
			$pc_user_details	= $this->pcUser;
			$get_ajax_data		= $request->getPost();
			$date_range			= date("Y-m-d",strtotime("+14 days"));
			$calendar_month		= $get_ajax_data['month'];
			$todays_date		= strtotime(date('Y-m-d'));
			$user_role_id		= $identity->user_role_id;
			$e = 0;
			$where		= '';
			if(isset($date_range) && $date_range != '')
			{
				$where	.= " and e.event_date <= '".$date_range."' and contact_client_id = ".$identity->user_id;
			}
			$fields		 = "s.shift_type,s.shift_id,s.shift_occurs,e.shift_bike_available,e.fk_shift_id,e.event_date,e.event_id,e.event_title,e.event_category,e.event_description,e.shift_bike_rental";
			$shift_event_details		= $this->getTable('ShiftTable')->getParticularEvent($fields,$where);
			if(is_object($shift_event_details) && count($shift_event_details) > 0)
			{
				foreach($shift_event_details as $event_key => $event_value)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($event_value['event_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					$shift_calendar_array[$e]['shift_id']			= $event_value['fk_shift_id'];
					$shift_calendar_array[$e]['start']				= $event_value['event_date'];
					$shift_calendar_array[$e]['end']				= $event_value['event_date'];
					$shift_calendar_array[$e]['bike_avail']			= $event_value['shift_bike_available'];
					$shift_calendar_array[$e]['bike_rent']			= $event_value['shift_bike_rental'];
					$shift_calendar_array[$e]['shift_type']			= $event_value['shift_type'];
					$shift_calendar_array[$e]['event_id']			= $event_value['event_id'];
					$shift_calendar_array[$e]['request_id']			= $request_id;
					$shift_calendar_array[$e]['req_status']			= $req_status;
					$shift_calendar_array[$e]['shift_event']		= 1;
					$shift_calendar_array[$e]['event_title']		= $this->getCommonDataObj()->displayShortText($event_value['event_title'], '20');
					$shift_calendar_array[$e]['event_cat']			= isset($this->eventCategoryArray[$event_value['event_category']])?$this->eventCategoryArray[$event_value['event_category']]:'';
					$shift_calendar_array[$e]['event_des']			= $event_value['event_description'];
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $user_role_id;
					$e++;
				}
			}
		}
		echo json_encode($shift_calendar_array);die();
	}
	public function mechanicCalendarDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$shift_event_details = '';
		$shift_calendar_array = array();
		$request 				= $this->getRequest();
		if($request->isPost())
		{
			$where = '';
			$pc_user_details			= $this->pcUser;
			$get_ajax_data				= $request->getPost();
			$todays_date				= strtotime(date('Y-m-d'));
			$where						= " and job_mechanic = ".$identity->user_id;
			$shift_event_details		= $this->getTable('ShiftTable')->getParticularJobSheet($where);
			$e = 0;
			if(is_object($shift_event_details) && count($shift_event_details) > 0)
			{
				foreach($shift_event_details as $event_key => $event_value)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($event_value['job_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					$shift_calendar_array[$e]['job_id']				= $event_value['job_id'];
					$shift_calendar_array[$e]['job_number']			= $event_value['job_number'];
					$shift_calendar_array[$e]['start']				= date('Y-m-d',strtotime($event_value['job_date']));
					$shift_calendar_array[$e]['end']				= date('Y-m-d',strtotime($event_value['job_date']));
					$shift_calendar_array[$e]['job_status']			= $event_value['job_status'];
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $identity->user_role_id;
					$e++;
				}
			}
			$meetingFields		= "*";
			$meetingWhere		= " meeting_status = 2 and meeting_to = ".$identity->user_role_id;
			$meetingDetails		= $this->getTable('ShiftTable')->getMeetingList($meetingFields,$meetingWhere);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $meetKey => $meetValue)
				{
					$chk_greater = 0;
					$request_id = $req_status = '';
					$st_dat_str			= strtotime($meetValue['meeting_date']);
					if($st_dat_str >= $todays_date)
					{
						$chk_greater	= 1;
					}
					$shift_calendar_array[$e]['shift_id']			= 0;
					$shift_calendar_array[$e]['meet_id']			= $meetValue['meeting_id'];
					$shift_calendar_array[$e]['start']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['end']				= $meetValue['meeting_date'];
					$shift_calendar_array[$e]['meet_time']			= $this->getCommonDataObj()->convertTimeFormat($meetValue['meeting_time'],'');
					$shift_calendar_array[$e]['meeting_to']			= $meetValue['meeting_to'];
					$shift_calendar_array[$e]['price']				= $meetValue['meeting_budget_request'];
					$shift_calendar_array[$e]['shift_event']		= 4;
					$shift_calendar_array[$e]['date_check']			= $chk_greater;
					$shift_calendar_array[$e]['user_role']			= $identity->user_role_id;
					$e++;
				}
			}
		}
		echo json_encode($shift_calendar_array);die();
	}
	public function jobSheetDetailsAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 		 = $this->getRequest();
		$job_details = '';
		$json_array = array();
		if ($request->isPost())
		{
			$matches		= $this->getEvent()->getRouteMatch();
			$job_id			= $matches->getParam('id', '');
			if(isset($job_id) && $job_id != '')
			{
				$where				= " and job_id = ".$job_id;
				$job_details		= $this->getTable('ShiftTable')->getParticularJobSheet($where);
				if(is_object($job_details) && count($job_details) > 0)
				{
					foreach($job_details as $job_key => $job_value)
					{
						$json_array['job_id']		= $job_value['job_id'];
						$json_array['number']		= $job_value['job_number'];
						$json_array['bike']			= $job_value['job_bike_number'];
						$json_array['minutes']		= $job_value['job_est_time'];
						$json_array['issue']		= stripslashes($job_value['job_issue']);
						$json_array['urgency']		= isset($this->repairUrgency[$job_value['job_repair_urgency']])?$this->repairUrgency[$job_value['job_repair_urgency']]:'-';
						$json_array['request']		= isset($this->requestBy[$job_value['job_request_by']])?$this->requestBy[$job_value['job_request_by']]:'-';
						$json_array['status']		= isset($this->jobBikeStatus[$job_value['job_status']])?$this->jobBikeStatus[$job_value['job_status']]:'-';
					}
				}
			}
		}
		echo json_encode($json_array);die();
	}
	
	/*	Action	: 	Mechanic logtime, Ajax action
	*	Detail	:	Used to Log the Mechanic In and Out time
	*/
	public function mechanicLogtimeAction()
    {
		$request 		 	= $this->getRequest();
		if ($request->isPost()) {
			// assign  values
			$matches		= $this->getEvent()->getRouteMatch();
			//$shiftRequestId	= $matches->getParam('shiftRequestId', 0);
			$logtimeId		= 0;
			$status			= '';
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$date			=  $datetime(time(), 0, 'Y-m-d');
			$logtimeDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
			
			$checkLogin  	=  array(
				'user_id'		=> $this->pcUser->user_id,
				'user_role_id'	=> $this->pcUser->user_role_id,
				'date'			=> $date
			);
			
			$loginStatus	=  $this->getTable("LogtimeTable")->checkLogInOutTime($checkLogin);
			$logs			=  array();
			if($loginStatus) {
				foreach($loginStatus as $value) {
					$logs	= (array) $value;
				}
				$logtimeId	= $logs['logtime_id'];
				if($logs['logtime_status'] == 1) {
					$logtimes					=  array(
						'logtime_id'			=> $logtimeId,
						'fk_user_id'			=> $this->pcUser->user_id,
						'fk_user_role_id'		=> $this->pcUser->user_role_id,
						//'logtime_intime'		=> $logtimeDate,
						'logtime_intime_all'	=> 'CONCAT(logtime_intime_all,",","'.$logtimeDate.'")',
						'logtime_updated_date'	=> $logtimeDate,
						'logtime_status'		=> 0
					);
					$status	= 1;		//	'Second In - Time'
				} else {
					if($logs['logtime_outtime'] != '0000-00-00 00:00:00') {
						$logtime_outtime_all	=  'CONCAT(logtime_outtime_all,",","'.$logtimeDate.'")';
					} else {
						$logtime_outtime_all	=  "'".$logtimeDate."'";
					}
					$logtimes					=  array(
						'logtime_id'			=> $logtimeId,
						'fk_user_id'			=> $this->pcUser->user_id,
						'fk_user_role_id'		=> $this->pcUser->user_role_id,
						'logtime_outtime'		=> $logtimeDate,
						'logtime_outtime_all'	=> $logtime_outtime_all,
						'logtime_updated_date'	=> $logtimeDate,
						'logtime_status'		=> 1
					);
					$status	= 2;		//	'Out - Time'
				}
			} else {
				$logtimes					=  array (
					'logtime_id'			=> $logtimeId,
					'fk_user_id'			=> $this->pcUser->user_id,
					'fk_user_role_id'		=> $this->pcUser->user_role_id,
					'logtime_intime'		=> $logtimeDate,
					'logtime_intime_all'	=> "'".$logtimeDate."'",
					'logtime_created_date'	=> $logtimeDate,
					'logtime_status'		=> 0,
					'logtime_isdeleted'		=> 0
				);
				$status	= 1;			//	'First In - Time'
			}
			
			$requestStatus	=  $this->getTable("LogtimeTable")->saveLogtime($logtimes);
			if($requestStatus) {
				echo $status;
			} else {
				echo false;
			}
		}
        return $this->getResponse();
    }
}
