<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Schedulemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Schedulemanagement\Form\AddShiftForm,
	Schedulemanagement\Form\AssignDriversForm,
	Schedulemanagement\Form\DriversLogtimeForm;

//	Models
use Usermanagement\Model\Aclresources,
	Schedulemanagement\Model\Shift;
use Usermanagement\Model\MyAuthenticationAdapter;

class ShiftallocationController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $shiftTypeArray;
	protected $requestClasses;
	protected $commonData;
	protected $driverPaymentTypes;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->shiftTypeArray		=  array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
		$this->requestClasses		=  array(1 => 'he-Requested', 2 => 'he-confirmed', 3 => 'he-Oncall');
		$this->driverPaymentTypes	=  array('' => 'Select Payment Type', '1' => 'Use an Open balance', '2' => 'Pay partially by account balance & partially by cash', '3' => 'Pay by cash');
		
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "LocationTable" => "Location-Table", "ShiftRequestTable" => "Shift-Request-Table", "UsersTable" => "Users-Table", "LogtimeTable" => "Logtime-Table", "LeasePaymentsTable" => "Lease-Payments-Table", "BikeTable" => "Bike-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Assign Drivers
	*	Detail	:	Used to assign the drivers
	*	TODO	:	Mail sending is inprocess
	*/
	public function assignDriversAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$assignDriversForm		=  new AssignDriversForm;
	 	$request 				=  $this->getRequest();
		$shiftId 				=  (int) $this->params()->fromRoute('shiftId', '');
		$shiftDtId 				=  (int) $this->params()->fromRoute('shiftDtId', '');
		$shiftOccurs 			=  (int) $this->params()->fromRoute('shiftOccurs', '');
		$shiftDetail			=  $message	 =  '';
		$requestedDrivers		=  $requestedDriversId	=  $allocatedDrivers =  $notAllocatedDrivers  =  $allDrivers  =  array();
		$shiftManagers			=  array('' => 'Select shift manager');
		
		if ($shiftId) {
			// Get Requested Drivers for the shift
			$requestResults			=  $this->getTable("ShiftRequestTable")->getRequestedDriver($shiftId, $shiftDtId);
			if($requestResults) {
				$requestedToArray	=  $requestResults->toArray();
				if($requestedToArray && is_array($requestedToArray) && count($requestedToArray)) {
					foreach($requestedToArray as $keys => $values) {
						$requestedDrivers[$values['fk_user_id']]		=  $values;
						if($values['shift_request_status'] == 2) {
							$allocatedDrivers[$values['fk_user_id']]	=  $values;
							$shiftManagers[$values['fk_user_id']]		=  $values['user_firstname'].' '.$values['user_lastname'];
						} else {
							$notAllocatedDrivers[$values['fk_user_id']]	=  $values;
						}
					}
				}
				$requestedDriversId	 =  (is_array($requestedDrivers) && count($requestedDrivers)) ? array_keys($requestedDrivers) : '';
			}
			
			// Get all drivers other than requested drivers.
			$allDriversResults		 =  $this->getTable("UsersTable")->getUserDetailsForShiftAssign($requestedDriversId);
			if($allDriversResults) {
				$allDriversToArray	 =  $allDriversResults->toArray();
				if($allDriversToArray && is_array($allDriversToArray) && count($allDriversToArray)) {
					foreach($allDriversToArray as $key => $value) {
						$allDrivers[$value['user_id']]	=  $value;
					}
				}
			}
			
			// Get the shift details for given Id
			$results			=  $this->getTable("ShiftTable")->getShiftsDetail($shiftId, $shiftDtId, $shiftOccurs);
			if($results) {
				$toArray		=  $results->toArray();
				$shiftDetail	=  (isset($toArray[0]) && count($toArray[0])) ? $toArray[0] : '';
			}
			
			// Date
			$datetime			=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$bike_available		=  0;
			if(isset($shiftDetail) && is_array($shiftDetail) && count($shiftDetail)) {
				$shiftStartDate		=  ($shiftDetail['shift_occurs'] == 1) ? $shiftDetail['shift_dt_start_date'] : $shiftDetail['event_date'];
				$shift_date_hidden	=  $shiftStartDate;
				$shiftStartDate		=  $datetime->getDates(strtotime($shiftStartDate), 0, 'n-j-Y');
				$assignDriversForm->get('shift_date')->setValue($shiftStartDate);
				$assignDriversForm->get('shift_date_hidden')->setValue($shift_date_hidden);
				
				// Condition handling for both Shift, Events and Repeated shifts
				$event_id			=  $shiftDetail['event_id'];
				$assignDriversForm->get('event_id')->setValue($event_id);
				$bike_available		= ($shiftDetail['shift_occurs'] == 1) ? $shiftDetail['shift_dt_bike_available'] : $shiftDetail['shift_bike_available'];
				$assignDriversForm->get('shift_bike_available')->setValue($bike_available);
				
				// Time
				$assignDriversForm->get('shift_start_time')->setValue($this->getCommonDataObj()->convertTimeFormat($shiftDetail['shift_start_time']));
				$assignDriversForm->get('shift_end_time')->setValue($this->getCommonDataObj()->convertTimeFormat($shiftDetail['shift_end_time']));
				
				// Shift types
				$shiftTypeArray		= $this->shiftTypeArray;
				$assignDriversForm->get('shift_type')->setValueOptions($shiftTypeArray);
				$assignDriversForm->get('shift_type')->setValue($shiftDetail['shift_type']);
				
				// Assign Shift Manager
				$assignDriversForm->get('shift_manager')->setValueOptions($shiftManagers);
				$shift_manager		= ($shiftDetail['shift_occurs'] == 1) ? $shiftDetail['shift_dt_manager_id'] : $shiftDetail['shift_manager_id'];
				$assignDriversForm->get('shift_manager')->setValue($shift_manager);
				
				/*
				// Testing process : Start
				$shiftStartDate		= ($shiftDetail['shift_occurs'] == 1) ? $shiftDetail['shift_dt_start_date'] : $shiftDetail['event_date'];
				$shiftDetails		=  array(
				   'shift_date' 	=> $shiftStartDate,
				   'start_time' 	=> $shiftDetail['shift_start_time'],
				   'end_time'		=> $shiftDetail['shift_end_time'],
				   'shift_id'		=> $shiftId,
				   'special_id'		=> $shiftDtId,
				   'shift_occurs'	=> $shiftOccurs,
				);
				
				$this->getCommonDataObj()->checkBikeAvailability($shiftDetails, 1, $this->pcUser);
				// Testing process : End
				*/
			}
			
			// Assign hidden values
			$assignDriversForm->get('fk_shift_id')->setValue($shiftId);
			$assignDriversForm->get('shift_occurs')->setValue($shiftOccurs);
			$assignDriversForm->get('fk_shift_dt_id')->setValue($shiftDtId);
			
			return new ViewModel(array(
				'userObject'		 	=> $identity,
				'assignDriversForm'	 	=> $assignDriversForm,
				'message'			 	=> $message,
				'shiftDetail'			=> $shiftDetail,
				'requestedDrivers'		=> $requestedDrivers,
				'allocatedDrivers'		=> $allocatedDrivers,
				'notAllocatedDrivers'	=> $notAllocatedDrivers,
				'allDrivers'			=> $allDrivers,
				'bike_available'		=> $bike_available,
				'pc_users'			 	=> $this->pcUser,
				'controller'	 		=> $this->params('controller')
			));
		} else {
			return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'manage-shift'));
			die();
		}
    }
	
	/*	Action	: 	Ajax Assign Drivers
	*	Detail	:	Used to assign the drivers via ajax
	*	TODO	:	Mail sending is inprocess
	*/
	public function ajaxAssignDriversAction() {
		$auth 		  		    = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$assignDriversJsonArray =  array();
		$notifications			=  array();
		$assignDriversForm		=  new AssignDriversForm;
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$assignDriversJsonArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData				= $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		 	=  $postData;
				$shiftId 			=  $formData['fk_shift_id'];
				$shiftDtId 			=  $formData['fk_shift_dt_id'];
				$shiftOccurs 		=  $formData['shift_occurs'];
				$requestedDrivers	=  (isset($formData['requested_drivers_hidden_ids']) && is_array($formData['requested_drivers_hidden_ids']) && count($formData['requested_drivers_hidden_ids'])) ? $formData['requested_drivers_hidden_ids'] : array();
//				$allDrivers			=  $formData['notRequested_drivers_hidden_ids'];
				$allDrivers			=  (isset($formData['notRequested_drivers_hidden_ids']) && is_array($formData['notRequested_drivers_hidden_ids']) && count($formData['notRequested_drivers_hidden_ids'])) ? $formData['notRequested_drivers_hidden_ids'] : array();
//				$preConfirmedDriver =  $formData['confirmed_drivers_hidden_ids'];
				$preConfirmedDriver	=  (isset($formData['confirmed_drivers_hidden_ids']) && is_array($formData['confirmed_drivers_hidden_ids']) && count($formData['confirmed_drivers_hidden_ids'])) ? $formData['confirmed_drivers_hidden_ids'] : array();
//				$confirmedDriver	=  $formData['confirmed_drivers_ids'];
				$confirmedDriver	=  (isset($formData['confirmed_drivers_ids']) && is_array($formData['confirmed_drivers_ids']) && count($formData['confirmed_drivers_ids'])) ? $formData['confirmed_drivers_ids'] : array();
				
				// Set the Notifications shift date and types
			    $notifications['notify_date']	= $formData['shift_date_hidden'];
			    $notifications['notify_type']	= 3;
				$notifications['shift_id']		= $formData['fk_shift_id'];
				
				// Condition handling for Drivers selections
				if(count($confirmedDriver)) {
					
					// Condition check for Available Bikes and Assigned drivers
					$totalBikeAvailable 	=  (int) (count($confirmedDriver) - count($preConfirmedDriver));
					if($totalBikeAvailable <= $formData['shift_bike_available']) {
						$datetime			=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate		=  $datetime(time(), 0, 'Y-m-d H:i:s');
						
						$shiftRequests 		=  array(
							'fk_shift_id'			  	 => $shiftId,
							'fk_shift_dt_id'			 => $shiftDtId,
				            'shift_occurs'			  	 => $shiftOccurs,
				            'shift_request_updated_date' => $createdDate,
							'shift_request_status'		 => 2,		//	Shift Confirmed
				            'shift_request_isdelete'     => 0
				        );
						
						// Findout the already requested drivers
						$updateDrivers		=  array_intersect($requestedDrivers, $confirmedDriver);
						// Update the status for Confirmed drivers as shift_request_status - 2 (Shift Confirmed)
						if(isset($updateDrivers) && is_array($updateDrivers) && count($updateDrivers)) {
						   $updateStatus	=  $this->getTable("ShiftRequestTable")->updateConfirmedDrivers($shiftRequests, $updateDrivers);
						   
						   // Send the Notifications for Confirmed Drivers
						   $notifications['subject'] = 'Shift Confirmed';
						   $this->sendShiftAllocationNote($updateDrivers, $identity, $notifications);
						}
						$onCallList1		=  array_diff($requestedDrivers, $confirmedDriver);
						$onCallList2		=  array_diff($preConfirmedDriver, $confirmedDriver);
						$onCallList			=  array_merge($onCallList1, $onCallList2);
						if(isset($onCallList) && is_array($onCallList) && count($onCallList)) {
						   $shiftRequests['shift_request_status']  =  3;		//	On-call list
						   $updateStatus	=  $this->getTable("ShiftRequestTable")->updateConfirmedDrivers($shiftRequests, $onCallList);
						   
						   // Send the Notifications for On-Call Drivers
						   $notifications['subject'] = 'Your request is on On-Call list for this shift';
						   $this->sendShiftAllocationNote($onCallList, $identity, $notifications);
						}
						
						// Findout the confirmed drivers
						if(isset($allDrivers) && is_array($allDrivers) && count($allDrivers)) {
							$shiftRequests['shift_request_created_date']  =  $createdDate;
							$shiftRequests['shift_request_status']  	  =  2;		//	Shift Confirmed
							$insertDrivers	=  array_intersect($allDrivers, $confirmedDriver);
							if(isset($insertDrivers) && is_array($insertDrivers) && count($insertDrivers)) {
							  $insertStatus =  $this->getTable("ShiftRequestTable")->insertConfirmedDrivers($shiftRequests, $insertDrivers);
							  
							  // Send the Notifications for Confirmed Drivers
							  $notifications['subject'] = 'Shift Confirmed';
							  $this->sendShiftAllocationNote($insertDrivers, $identity, $notifications);
							}
						}
						
						//  shift_bike_available, event_id
						$shiftRequests['event_id']  			=  (isset($formData['event_id'])) ? $formData['event_id'] : 0;		//	event id
						$shiftRequests['shift_bike_available']  =  (isset($totalBikeAvailable)) ? $totalBikeAvailable : 0;		//	Shift bike available
						// Update shift manager.
						$shiftRequests['shift_manager']  		=  (isset($formData['shift_manager'])) ? $formData['shift_manager'] : 0;		//	event id
						$shiftManagerStatus =  $this->getTable("ShiftRequestTable")->updateShiftManager($shiftRequests);
						
						// Update shift bike available status 
						$shiftBikesStatus 	=  $this->getTable("ShiftRequestTable")->updateShiftBikes($shiftRequests);
						
						/*
						*	Function to Check the Bike Availability
						*	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
						*/
						$shiftStartDate		=  str_replace('-', '/', $formData['shift_date']);
						$shiftStartDate		=  $datetime->getDates(strtotime($shiftStartDate), 0, 'Y-m-d');
						$shiftDetails		=  array(
						   'shift_date' 	=> $shiftStartDate,
						   'start_time' 	=> $this->getCommonDataObj()->convertTimeFormat($formData['shift_start_time'], 1),
						   'end_time'		=> $this->getCommonDataObj()->convertTimeFormat($formData['shift_end_time'], 1),
						   'shift_id'		=> $shiftId,
						   'special_id'		=> $shiftDtId,
						   'shift_occurs'	=> $shiftOccurs,
						);
						$this->getCommonDataObj()->checkBikeAvailability($shiftDetails, 1, $this->pcUser);
						// End
						
						$message			= 'Drivers Assign successfully !';
						$assignDriversJsonArray['redirect_url'] 		 = '/schedulemanagement/shift/manage-shift';
						$assignDriversJsonArray['confirmed_drivers_div'] = true;
						$assignDriversJsonArray['err_msg']	  			 = "";
					} else {
						$assignDriversJsonArray['requested_drivers'] 	 = false;
						$assignDriversJsonArray['err_msg']	  			 = "Available Drivers is exist, You want to select more drivers, <br/>Please remove the existing drivers and then select the required drivers, <br/> No. of Drivers Still Needed :".$formData['shift_bike_available']."!";
					}
				} else {
					// $errorMessages	= $addUserForm->getMessages();
					$assignDriversJsonArray['confirmed_drivers_div'] 	 = false;
					$assignDriversJsonArray['err_msg']				 	 = "Assign the drivers, It's required";
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$assignDriversJsonArray['confirmed_drivers_div'] = false;
				$assignDriversJsonArray['err_msg']				 = "Assign the drivers, It's required";
			}
        } else {
				$assignDriversJsonArray['confirmed_drivers_div'] = false;
				$assignDriversJsonArray['err_msg']				 = "Assign the drivers, It's required";
		}
		
		echo json_encode($assignDriversJsonArray);
		return $this->getResponse();
    }
	
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	private function sendShiftAllocationNote($driversArray = false, $identity, $notifications)
    {
        if($driversArray && is_array($driversArray) && count($driversArray)) {
			foreach($driversArray as $driver_key => $driver_value) {
				$insert_array[]		 = "'".$notifications['shift_id']."','".$identity->user_id."','".$driver_value."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notifications['subject'])."','".addslashes($notifications['notify_date'])."','".addslashes($notifications['notify_type'])."'";
			}
			if(is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable('ShiftTable')->insertManagerNotification($insert_multi_string);
			}
		}
    }
	
	/*	Action	:   Driver Login shifts listing
	*	Detail	:	Used to List the Driver shifts details
	*/
	public function driverLoginShiftsListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		
		//	Destroy listing Session Vars
		$status	 		=  $this->getCommonDataObj()->destroySessionVariables(array('driversLoginShiftListing'));
		$driversLoginShiftListingSession = new Container('driversLoginShiftListing');
		
		// Get Drivers request details
		$driversRequestsResults	= $this->getTable('ShiftRequestTable')->getDriverRequestDetailsForLogin();
		$driversRequests		= array();
		
		if($driversRequestsResults) {
			foreach($driversRequestsResults as $key => $requests) {
				if(isset($requests["shift_occurs"]) && !empty($requests["shift_occurs"]) && $requests["shift_occurs"] == 1) {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]]	=  $requests;
				} else {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]]	=  $requests;
				}
			}
		}
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getDriversShiftsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'driversRequests'		=> $driversRequests,
			'requestClasses'		=> $this->requestClasses,
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax drivers driverLoginShiftsListingAction shifts list, Ajax action
	*	Detail	:	Used to list the drivers shifts details via Ajax
	*/
	public function driverLoginShiftsListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$driversLoginShiftListingSession = new Container('driversLoginShiftListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($driversLoginShiftListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$driversLoginShiftListingSession->sortBy	= $sortBy;
		} else if($driversLoginShiftListingSession->offsetExists('sortBy')) {
			$sortBy	= $driversLoginShiftListingSession->sortBy;
		}
		if($sortType != '') {
			if($driversLoginShiftListingSession->sortType == $sortType && $columnFlag == 1)
				$driversLoginShiftListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$driversLoginShiftListingSession->sortType	= $sortType;
		} else if($driversLoginShiftListingSession->offsetExists('sortType')) {
			$sortType	= $driversLoginShiftListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$driversLoginShiftListingSession->perPage	= $perPage;
		} else if($driversLoginShiftListingSession->offsetExists('perPage')) {
			$perPage		= $driversLoginShiftListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		// Get Drivers request details
		$driversRequestsResults	= $this->getTable('ShiftRequestTable')->getDriverRequestDetailsForLogin();
		$driversRequests		= array();
		
		if($driversRequestsResults) {
			foreach($driversRequestsResults as $key => $requests) {
				if(isset($requests["shift_occurs"]) && !empty($requests["shift_occurs"]) && $requests["shift_occurs"] == 1) {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]][$requests["fk_shift_dt_id"]]	=  $requests;
				} else {
					$driversRequests[$requests["fk_user_id"]][$requests["fk_shift_id"]][$requests["shift_occurs"]]	=  $requests;
				}
			}
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ShiftTable')->getDriversShiftsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'message'			=> $message,
			'pc_users'			=> $this->pcUser,
			'driversRequests'	=> $driversRequests,
			'requestClasses'	=> $this->requestClasses,
			'datetime'			=> $datetime,
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Driver shift logtime, Ajax action
	*	Detail	:	Used to set Drivers In and Out time
	*/
	public function driverShiftLogtimeAction()
    {
		$request 		 = $this->getRequest();
		if ($request->isPost()) {
			// assign  values
			$matches		= $this->getEvent()->getRouteMatch();
			$shiftRequestId	= $matches->getParam('shiftRequestId', 0);
			$logtimeId		= $matches->getParam('logtimeId', 0);
			$logtimes		= array();
			
			// Date
			$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			$logtimeDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
			if(isset($logtimeId) && !empty($logtimeId)) {
				$logtimes					=  array(
					'logtime_id'			=> $logtimeId,
					'fk_user_id'			=> $this->pcUser->user_id,
					'fk_user_role_id'		=> $this->pcUser->user_role_id,
					'fk_shift_request_id'	=> $shiftRequestId,
					'logtime_outtime'		=> $logtimeDate,
					'logtime_outtime_all'	=> "'".$logtimeDate."'",
					'logtime_updated_date'	=> $logtimeDate,
					'logtime_status'		=> 1
				);
			} else {
				$logtimes					=  array (
					'logtime_id'			=> $logtimeId,
					'fk_user_id'			=> $this->pcUser->user_id,
					'fk_user_role_id'		=> $this->pcUser->user_role_id,
					'fk_shift_request_id'	=> $shiftRequestId,
					'logtime_intime'		=> $logtimeDate,
					'logtime_intime_all'	=> "'".$logtimeDate."'",
					'logtime_created_date'	=> $logtimeDate,
					'logtime_status'		=> 0,
					'logtime_isdeleted'		=> 0
				);
			}
			
			$requestStatus					 =  $this->getTable("LogtimeTable")->saveLogtime($logtimes);
			if($requestStatus) {
				$status		=	(isset($logtimeId) && !empty($logtimeId)) ? 'out' : $requestStatus;
				echo $status;
			} else {
				echo 0;
			}
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Driver login time, Ajax action
	*	Detail	:	Used to set Drivers In and Out time
	*/
	public function driverLoginTimeAction()
	{
		$auth 	 =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$result  = new ViewModel();
	    $result->setTerminal(true);
		
		$paramId = $this->params()->fromRoute('id', 0);
		if (strpos($paramId, '_') !== false) {
			list($loopKey, $shiftRequestId, $logtimeType)  =	explode('_', $paramId);
		} else {
			$logtimeType	=  1;
		}
		$datetime	  		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$driversLogtimeForm	=  new DriversLogtimeForm;
		
		// Get the Shift details
		$results			=  $this->getTable("ShiftRequestTable")->getShiftsDetailForDriverLeasefees($shiftRequestId);
		if($results) {
			$shiftDetails   =  array();
			foreach($results as $shifts) {
			  $shiftDetails = (array)$shifts;
			}
			$shiftId		=  $shiftDetails['shift_id'];
			
			if($logtimeType == 1) {
				
				/*	TODO : Need to work for find out the available bikes for a particular shifts.
				*	Get available bikes
				*/
				$allBikes			=  array(''  => 'Select Bike');
				$allBikesResults	=  $this->getTable("BikeTable")->GetAllBikes();
				if($allBikesResults) {
					foreach($allBikesResults as $key => $value) {
						$allBikes[$value['bike_id']] = $value['bike_name'];
					}
				}
				$driversLogtimeForm->get('fk_bike_id')->setValueOptions($allBikes);
			} else {
				$driversLogtimeForm->get('payment_type')->setValueOptions($this->driverPaymentTypes);
			}
			
			$driversLogtimeForm->get('logtimeType')->setValue($logtimeType);
			$driversLogtimeForm->get('fk_shift_request_id')->setValue($shiftRequestId);
			$driversLogtimeForm->get('fk_shift_id')->setValue($shiftId);
			
			$leasePayAmount			=  ($shiftDetails['shift_occurs'] == 1) ? $shiftDetails['shift_dt_bike_rental'] : $shiftDetails['shift_bike_rental'];
			$userAvailableBalance	=  $shiftDetails['user_amount_balance'];
			$driversLogtimeForm->get('lease_pay_amount')->setValue($leasePayAmount);
			
			$result->setVariables(array(
					'controller'	 		=> $this->params('controller'),
					'driversLogtimeForm'	=> $driversLogtimeForm,
					'leasePayAmount'		=> $leasePayAmount,
					'userAvailableBalance'	=> $userAvailableBalance,
					'loopKey'				=> $loopKey,
					'datetime'				=> $datetime,
					'logtimeType'			=> $logtimeType,
					'errorFlags'			=> 0,
					'commonData'			=> $this->getCommonDataObj()
			));
			return $result;
		} else {
			$result->setVariables(array(
					'controller'	 		=> $this->params('controller'),
					'errorFlags'			=> 1,
					'commonData'			=> $this->getCommonDataObj()
			));
			return $result;
		}
	}
	
	/*	Action	: 	Ajax Driver Lease Payment
	*	Detail	:	Add the Driver Lease Payment
	*/
	public function ajaxDriverLeasePaymentAction() {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$driverLeasePayArray	=  array();
		$DriversLogtimeForm		=  new DriversLogtimeForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		$driverLeasePayArray['redirect_url']	= '';
		if ($request->isPost()) {
			$postData			=  $request->getPost()->toArray();
            if (is_array($postData)) {
				$formData		=  $postData;
				$datetime		=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$createdDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
				
				if($formData['logtimeType'] == 1 || ($formData['logtimeType'] == 2 && $formData['payment_amount'] >= $formData['lease_pay_amount'])) {
					if($formData['logtimeType'] == 1) {
						$shift_request_id			  =  (isset($formData['fk_shift_request_id']) && !empty($formData['fk_shift_request_id'])) ? $formData['fk_shift_request_id'] : 0;
						$bikeDetails 				  =  array(
				            'shift_request_id'	  	  => $shift_request_id,
							'fk_bike_id'		  	  => $formData['fk_bike_id']
						);
						$shiftRequestId  			  =  $this->getTable("ShiftRequestTable")->updateShiftBikesDetails($bikeDetails);								//	Insert and Update Driver Lease payments
					} else {
						$lease_id					  =  (isset($formData['lease_id']) && !empty($formData['lease_id'])) ? $formData['lease_id'] : 0;
						$leasePayment 				  =  array(
							'lease_id'			  	  => $lease_id,
							'fk_user_id'		  	  => $this->pcUser->user_id,
				            'fk_shift_request_id'	  => $formData['fk_shift_request_id'],
							'lease_pay_type'		  => $formData['payment_type'],
							'payment_amount'		  => $formData['payment_amount'],
							'lease_pay_amount'		  => $formData['lease_pay_amount'],
							'lease_status'			  => 1,
							'lease_created_date'	  => $createdDate,
							'lease_updated_date'	  => $createdDate,
							'fk_location_id'		  => $this->pcUser->location_id,
							'lease_isdelete'		  => 0
						);
						$leasePaymentId  			  =  $this->getTable("LeasePaymentsTable")->saveLeasePayments($leasePayment);								//	Insert and Update Driver Lease payments
					}
					
					// Log Driver's In and Out times
					$shiftRequestId	=  (isset($formData['fk_shift_request_id']) && !empty($formData['fk_shift_request_id'])) ? $formData['fk_shift_request_id'] : 0;
					$logtimeId		=  0;
					$logtimes		=  array();
					$logtimeDate	=  $datetime(time(), 0, 'Y-m-d H:i:s');
					
					$date			=  $datetime(time(), 0, 'Y-m-d');
					
					// Condition handling for Driver's Log time.
					$checkLogin  	=  array(
						'user_id'				=> $this->pcUser->user_id,
						'user_role_id'			=> $this->pcUser->user_role_id,
						'fk_shift_request_id'	=> $shiftRequestId,
						'date'					=> $date
					);
					$loginStatus	=  $this->getTable("LogtimeTable")->checkDriversLogInOutTime($checkLogin);
					if($loginStatus) {
						$logs		=  array();
						foreach($loginStatus as $value) {
							$logs	= (array) $value;
						}
						$logtimeId					=  $logs['logtime_id'];
						$logtimes					=  array(
							'logtime_id'			=> $logtimeId,
							'fk_user_id'			=> $this->pcUser->user_id,
							'fk_user_role_id'		=> $this->pcUser->user_role_id,
							'fk_shift_request_id'	=> $shiftRequestId,
							'logtime_outtime'		=> $logtimeDate,
							'logtime_outtime_all'	=> "'".$logtimeDate."'",
							'logtime_updated_date'	=> $logtimeDate,
							'logtime_status'		=> 1
						);
					} else {
						$logtimes					=  array (
							'logtime_id'			=> $logtimeId,
							'fk_user_id'			=> $this->pcUser->user_id,
							'fk_user_role_id'		=> $this->pcUser->user_role_id,
							'fk_shift_request_id'	=> $shiftRequestId,
							'logtime_intime'		=> $logtimeDate,
							'logtime_intime_all'	=> "'".$logtimeDate."'",
							'logtime_created_date'	=> $logtimeDate,
							'logtime_status'		=> 0,
							'logtime_isdeleted'		=> 0
						);
					}
					$requestStatus	=  $this->getTable("LogtimeTable")->saveLogtime($logtimes);		//  Log In and Out time for Driver's.
					
					$driverLeasePayArray['status_flag'] = true;
					$driverLeasePayArray['loopKey'] 	= $formData['loopKey'];
					$driverLeasePayArray['logtimeType'] = $formData['logtimeType'];
					$driverLeasePayArray['err_msg']		= "";
				} else {
					// $errorMessages	= $addUserForm->getMessages();
					$driverLeasePayArray['status_flag'] = false;
					$driverLeasePayArray['err_msg']		= "Please check the Lease Payment, <br/>It's must match the Amount Due for shift";
				}
			} else {
				// $errorMessages	= $addUserForm->getMessages();
				$driverLeasePayArray['status_flag'] 	= false;
				$driverLeasePayArray['err_msg']			= "Enter Payment amount, It's required";
			}
        } else {
				$driverLeasePayArray['status_flag'] 	= false;
				$driverLeasePayArray['err_msg']			= "Enter Payment amount, It's required";
		}
		
		echo json_encode($driverLeasePayArray);
		return $this->getResponse();
    }
	
}
