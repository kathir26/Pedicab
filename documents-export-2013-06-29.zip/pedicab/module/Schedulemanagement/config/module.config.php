<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Schedulemanagement\Controller\Shift',
                        'action'     => 'bike-listing',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'schedulemanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/schedulemanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'bike-listing',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/schedulemanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'manage-shift-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-shift-list[/[:shiftDate[/[:pageid]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'manage-shift-list',
						'shiftDate' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-shift-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-shift-sort[/[:shiftDate[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'manage-shift-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftDate' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-shift-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-shift-page[/[:shiftDate[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' 	=> 'Schedulemanagement\Controller',
                        'controller'   	=> 'Shift',
                        'action'      	=> 'manage-shift-list',
						'shiftDate' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-view-shift-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-view-shift-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-view-shift-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-view-shift-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-view-shift-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'   => 'Shift',
                        'action'       => 'driver-view-shift-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-confirmed-shift-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-confirmed-shift-page[/[:requestStatus[/[:pageid]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-confirmed-shift-list',
						'requestStatus' => '[a-zA-Z][a-zA-Z0-9_-]*',
						'pageid' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-confirmed-shift-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-confirmed-shift-list[/[:requestStatus[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-confirmed-shift-list',
						'requestStatus' => '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-confirmed-shift-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-confirmed-shift-listcount[/[:requestStatus[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'   => 'Shift',
                        'action'       => 'driver-confirmed-shift-list',
						'requestStatus' => '[a-zA-Z][a-zA-Z0-9_-]*',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-shift-requests' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-shift-requests[/[:shiftId[/[:shiftOccurs[/[:shiftDtId]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-shift-request',
						'shiftId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftOccurs' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftDtId' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'assign-driver' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/assign-driver[/[:shiftId[/[:shiftOccurs[/[:shiftDtId]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shiftallocation',
                        'action'        => 'assign-drivers',
						'shiftId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftOccurs' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftDtId' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
				
            ),
			'schedulemanagement/shift/edit-shift' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/schedulemanagement/shift/edit-shift[/[:shiftId[/[:shiftOccurs]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'edit-shift',
						'shiftId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftOccurs' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'schedulemanagement/shift/delete-shift' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/schedulemanagement/shift/delete-shift[/[:eventId[/[:shiftId]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'delete-shift',
						'eventId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftId' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'schedulemanagement/shift/delete-shift-event' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/schedulemanagement/shift/delete-shift-event[/[:sh_ev_id[/[:shiftId[/[:occurs]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'delete-shift-event',
						'sh_ev_id' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftId' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'occurs' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-shift-req-cal' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-shift-req-cal[/[:shiftId[/[:shiftOccurs[/[:shiftDtId]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-shift-req-cal',
						'shiftId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftOccurs' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftDtId' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-login-shifts-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-login-shifts-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shiftallocation',
                        'action'        => 'driver-login-shifts-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-login-shifts-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-login-shifts-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'   => 'Shiftallocation',
                        'action'       => 'driver-login-shifts-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-shift-logtime' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-shift-logtime[/[:shiftRequestId[/[:logtimeId]]]]',
                    'defaults' => array(
                        '__NAMESPACE__'  => 'Schedulemanagement\Controller',
                        'controller'     => 'Shiftallocation',
                        'action'         => 'driver-shift-logtime',
						'shiftRequestId' => '[a-zA-Z][a-zA-Z0-9_-]*',
						'logtimeId' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'driver-shift-cancel' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/driver-shift-cancel[/[:shiftId[/[:shiftOccurs[/[:shiftDtId[/[:reqId[/[:reqSt]]]]]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Schedulemanagement\Controller',
                        'controller'    => 'Shift',
                        'action'        => 'driver-shift-cancel',
						'shiftId' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftOccurs' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'shiftDtId' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'reqId'			=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'reqSt'			=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'Schedulemanagement\Controller\Shift' 			=> 'Schedulemanagement\Controller\ShiftController',
			'Schedulemanagement\Controller\Shiftallocation' => 'Schedulemanagement\Controller\ShiftallocationController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
