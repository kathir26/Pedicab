<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Maintenancemanagement\Controller\Inventory',
                        'action'     => 'parts-listing',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'maintenancemanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/maintenancemanagement[/[:controller[/[:action[/[:id[/[:jobBack]]]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Inventory',
                        'action'        => 'parts-listing',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/maintenancemanagement[/[:controller[/[:action[/[:id[/[:jobBack]]]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
								'jobBack'	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'parts-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Inventory',
                        'action'        => 'parts-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'parts-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Inventory',
                        'action'       => 'parts-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'parts-purchase-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-purchase-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Inventory',
                        'action'        => 'parts-purchase-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'parts-purchase-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-purchase-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Inventory',
                        'action'       => 'parts-purchase-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'get-parts-purchase' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/maintenancemanagement/inventory/get-parts-purchase[/[:editId]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Inventory',
                        'action'       => 'get-parts-purchase',
						'editId' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'job-list-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/job-list-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Job',
                        'action'        => 'job-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'job-list-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/job-list-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Job',
                        'action'       => 'job-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-job-list-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-job-list-sort[/[:jobStatus[/[:sortBy[/[:sortType]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Job',
                        'action'        => 'mechanic-job-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'jobStatus'		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-job-list-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-job-list-page[/[:jobStatus[/[:perPage]]]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Job',
                        'action'       => 'mechanic-job-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
						'jobStatus'		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-job-listing-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-job-listing-page[/[:jobStatus[/[:id]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Job',
                        'action'        => 'mechanic-job-list',
						'jobStatus' 	=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'id' 			=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-request-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-request-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Job',
                        'action'        => 'mechanic-request-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'mechanic-request-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/mechanic-request-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Job',
                        'action'       => 'mechanic-request-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'parts-request-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-request-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'    => 'Inventory',
                        'action'        => 'parts-request-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'parts-request-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/parts-request-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Maintenancemanagement\Controller',
                        'controller'   => 'Inventory',
                        'action'       => 'parts-request-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
			),
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'Maintenancemanagement\Controller\Inventory' 	=> 'Maintenancemanagement\Controller\InventoryController',
			'Maintenancemanagement\Controller\Job' 			=> 'Maintenancemanagement\Controller\JobController',
			'Maintenancemanagement\Controller\Request' 		=> 'Maintenancemanagement\Controller\RequestController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
