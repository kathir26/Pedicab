<?php
namespace Maintenancemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class PartsTable extends AbstractTableGateway
{
    protected $table = 'parts';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Parts());
        $this->initialize();
    }
	
	public function getPart($partsId)
    {
        $id  	= (int) $partsId;
        $rowset = $this->select(array('parts_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	public function saveParts($formData)
    {
        $parts_id = (int)$formData["parts_id"];
		if ($parts_id) {
		 	unset($formData["parts_created_date"]);
		}
		$fields   = '';
		foreach ($formData as $key => $value) {
			if($key != "parts_id") {
				$fields .= $key . " = '" . addslashes($value) . "', ";
			}
		}
		$fields = substr($fields, 0, -2);
		
        if (!$parts_id) {
            $sql 	   = " insert into ".$this->table." set ".$fields;
			$statement = $this->adapter->query($sql);
			$results   = $statement->execute();
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getPart($parts_id)) {
				$sql 	   = "update ".$this->table." set " . $fields . " where parts_id  = " . $parts_id;
				$statement = $this->adapter->query($sql);
				$results   = $statement->execute();
				return $parts_id;
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	
	public function savePartsImages($partsImage)
    {
        $data = array(
			'parts_image'	=> $partsImage["parts_image"]
        );
        $parts_id = (int)$partsImage["parts_id"];
        if ($this->getPart($parts_id)) {
            $this->update($data, array('parts_id' => $parts_id));
        } else {
            throw new \Exception('Form id does not exist');
        }
    }
	
	public function getPartsDetails($partsId)
    {
		$sql		= "SELECT * FROM ".$this->table." WHERE 1 And parts_isdelete = 0 And parts_id ='" . $partsId ."'";
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	
	public function getPartsList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId					=  $pcUser->location_id;
		$whereClause   	  	 		= ' WHERE 1 and parts_isdelete = 0 and location_id='.$locationId;
		
		$partsListingSession 	= new Container('partsListing');
		
		if($partsListingSession->offsetExists('parts_name') && $partsListingSession->parts_name != '') {
			$whereClause	.= ' AND parts_name like "%' . $partsListingSession->parts_name . '%"';
		}
		
		if($partsListingSession->offsetExists('parts_jbno') && $partsListingSession->parts_jbno != '') {
			$whereClause	.= ' AND parts_jb like "%' . $partsListingSession->parts_jbno . '%"';
		}
		
		$orderClause		 = '';
		if($partsListingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$partsListingSession->sortBy;
		}
		
		if($partsListingSession->offsetExists('sortType') && $partsListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT parts_id, parts_name, parts_jb, parts_qbp, parts_min_quantity, parts_max_quantity, parts_in_stock, parts_to_order, parts_status, parts_created_date, 
				   parts_updated_date, location_id, parts_isdelete
				   FROM '.$this->table;
		$sql   .=  $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function deleteParts($partId)
    {
        $data = array(
				'parts_isdelete'	=> '1'
        );
		$this->update($data, array('parts_id' => $partId));
    }
	public function getPartsDetailsSearch($where)
    {
		$sql		= "SELECT * FROM ".$this->table." WHERE 1 ".$where;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	public function getPartsDetailsAll($where)
    {
		$sql		= "SELECT * FROM ".$this->table." WHERE 1 ".$where;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		//$result		= $this->resultSetPrototype->initialize($result);
		//$result->buffer();
		//$result->next();
		return $result;
    }
}