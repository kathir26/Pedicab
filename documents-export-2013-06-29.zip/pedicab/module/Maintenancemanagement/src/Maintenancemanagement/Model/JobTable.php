<?php
namespace Maintenancemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class JobTable extends AbstractTableGateway
{
    protected $table = 'job_sheet';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Parts());
        $this->initialize();
    }
	public function getJobDetails($where)
	{
		$sql 		= "Select * from job_sheet where job_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getPartsPurchaseDetails($location_id,$parts_id = '')
	{
		$where = '';
		if(isset($location_id) && $location_id != '')
		{
			$where	= " and location_id = ".$location_id;
		}
		if(isset($parts_id) && $parts_id != '')
		{
			$where	.= " and parts_id in (".$parts_id.")";
		}
		$sql 		= "  Select * from parts where parts_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getBikeDetails($where)
	{
		$sql 		= "Select * from bike where bike_isdelete = 0 and bike_status = 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getuserDetails($location_id,$role)
	{
		$where		= " and location_id = ".$location_id." and user_role_id in (".$role.")";
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getUniqueJobNumber($location_id)
	{
		$where		= " and location_id = ".$location_id;
		$sql 		= "Select max(job_id) as max_job from job_sheet where 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertJob($data)
    {
        $sql 				= "insert into job_sheet set ".$data;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertJobStock($insert_string)
    {
		$sql 				= " INSERT INTO job_sheet_stocks (fk_job_id,fk_parts_id,parts_stock,job_stock_status) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updatePartsStock($data,$parts_id)
    {
	   $sql		= " update parts set ".$data." where parts_id = ".$parts_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getJobSheetList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	 		 = $pcUser->location_id;
		$whereClause   	  	 = ' WHERE 1 and job_isdelete = 0 and job.location_id = '.$locationId;
		if(isset($pcUser->user_role_id) && ($pcUser->user_role_id == 1 || $pcUser->user_role_id == 2))
		{
			$whereClause	.= ' AND job.job_request_user_id = '.$pcUser->user_id;
		}
		$jobListingSession 	= new Container('JobListing');
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '') {
			$whereClause	.= ' AND job_number like "%' . $jobListingSession->job_sheet . '%"';
		}
		if($jobListingSession->offsetExists('bike_number') && $jobListingSession->bike_number != '') {
			$whereClause	.= ' AND job_bike_number like "%' . $jobListingSession->bike_number . '%"';
		}
		$orderClause		 = '';
		$orderClause		 = '';
		if($jobListingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$jobListingSession->sortBy;
		}
		
		if($jobListingSession->offsetExists('sortType') && $jobListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY job.job_repair_urgency DESC';
		}
		
		$sql	= ' SELECT job.*,concat(user.user_firstname," ",user.user_lastname) as mech_name  FROM job_sheet as job 
					Left join user as user on (job.job_mechanic = user.user_id) '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getJobStocksDetails($where)
	{
		$sql 		= "Select * from job_sheet_stocks where job_stock_status = 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateJobSheet($data,$job_id)
    {
	    $sql		= " update job_sheet set ".$data." where job_id = ".$job_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function updateJobSheetStock($data,$job_stock_id)
    {
	    $sql		= " update job_sheet_stocks set ".$data." where job_stock_id = ".$job_stock_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function insertManagerNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_job_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function viewJobSheet($job_id)
	{
		$whereClause = ' where job.job_id = '.$job_id;
		$sql	= ' SELECT job.*,concat(user.user_firstname," ",user.user_lastname) as mech_name  FROM job_sheet as job 
					Left join user as user on (job.job_mechanic = user.user_id) '.$whereClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		return $result;
	}
	public function getParticularUserDetails($user_id)
	{
		$where		= " and user_id in (".$user_id.")";
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getJobSheetViewList($job_view_id = '')
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	 		 = $pcUser->location_id;
		$whereClause   	  	 = ' WHERE 1 and job_isdelete = 0 and job.location_id = '.$locationId;
		if(isset($job_view_id) && $job_view_id == 2)
		{
			$whereClause	.= ' AND job.job_mechanic = '.$pcUser->user_id.' AND job.job_status = 2';
		}
		else
		{
			$whereClause	.= ' AND job.job_mechanic = '.$pcUser->user_id.' AND job.job_status != 2';
		}
		$session_container	= (isset($job_view_id) && $job_view_id == 2) ? 'mechanicCompletedJob' : 'mechanicViewJob';
		$jobListingSession 	= new Container($session_container);
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '') {
			$whereClause	.= ' AND job_number like "%' . $jobListingSession->job_sheet . '%"';
		}
		if($jobListingSession->offsetExists('bike_number') && $jobListingSession->bike_number != '') {
			$whereClause	.= ' AND job_bike_number like "%' . $jobListingSession->bike_number . '%"';
		}
		$orderClause		 = '';
		$orderClause		 = '';
		if($jobListingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$jobListingSession->sortBy;
		}
		
		if($jobListingSession->offsetExists('sortType') && $jobListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			if(isset($job_view_id) && $job_view_id == 2) {
				$orderClause	.= ' ORDER BY job_id DESC';
			} else {
				$orderClause	.= ' ORDER BY job_repair_urgency DESC';
			}
		}
		
		$sql	= ' SELECT job.*,concat(user.user_firstname," ",user.user_lastname) as mech_name  FROM job_sheet as job 
					Left join user as user on (job.job_mechanic = user.user_id) '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getJobSheetRequestList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	 		 = $pcUser->location_id;
		$whereClause   	  	 = ' WHERE 1 and job_isdelete = 0 and job.location_id = '.$locationId.' AND job.job_mechanic = 0';
		
		$session_container	= 'mechanicRequestedJob';
		$jobListingSession 	= new Container($session_container);
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '') {
			$whereClause	.= ' AND job_number like "%' . $jobListingSession->job_sheet . '%"';
		}
		if($jobListingSession->offsetExists('job_date') && $jobListingSession->job_date != '') {
			$tempDate		 = str_replace('-', '/', $jobListingSession->job_date);
			$job_date   	 = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND DATE(job_date) = "'.$job_date.'"';
		}
		$orderClause		 = '';
		$orderClause		 = '';
		if($jobListingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$jobListingSession->sortBy;
		}
		
		if($jobListingSession->offsetExists('sortType') && $jobListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY job_repair_urgency DESC';
		}
		
		$sql	= ' SELECT job.* FROM job_sheet as job '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
}