<?php
namespace Maintenancemanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class PartsPurchaseTable extends AbstractTableGateway
{
    protected $table = 'parts_purchase';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new PartsPurchase());
        $this->initialize();
    }
	
	public function getPurchase($partsId)
    {
        $id  	= (int) $partsId;
        $rowset = $this->select(array('parts_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	public function savePurchase($formData)
    {
        $purchase_id = (int)$formData["parts_purchase_id"];
		$fields   = '';
		foreach ($formData as $key => $value) {
			if($key != "parts_purchase_id") {
				$fields .= $key . " = '" . addslashes($value) . "', ";
			}
		}
		$fields = substr($fields, 0, -2);
		
        if (!$purchase_id) {
            $sql 	   = " insert into ".$this->table." set ".$fields;
			$statement = $this->adapter->query($sql);
			$results   = $statement->execute();
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
        } else {
            if ($this->getPart($purchase_id)) {
				$sql 	   = "update ".$this->table." set " . $fields . " where parts_purchase_id  = " . $purchase_id;
				$statement = $this->adapter->query($sql);
				$results   = $statement->execute();
				return $parts_id;
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	
	public function getPartsPurchaseDetails($purchaseId)
    {
		$sql	= 'SELECT parts.parts_id, parts.parts_name, parts.parts_jb, parts.parts_qbp,parts. parts_status, location_id,
				   purchase.parts_purchase_id, purchase.purchase_date, purchase.purchase_quantity, purchase.fk_parts_id
				   FROM '.$this->table.' as purchase
				   left join parts as parts on (purchase.fk_parts_id = parts.parts_id)
				   where 1 and purchase.parts_purchase_id ='.$purchaseId;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	
	public function getPartsPurchaseList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId				=  $pcUser->location_id;
		$whereClause   	  	 	= ' WHERE 1 and parts.parts_isdelete = 0 and purchase.purchase_isdelete = 0 and parts.location_id='.$locationId;
		
		$purchaseListingSession = new Container('partsPurchaseListing');
		
		if($purchaseListingSession->offsetExists('parts_name') && $purchaseListingSession->parts_name != '') {
			$whereClause	.= ' AND parts.parts_name like "%' . $purchaseListingSession->parts_name . '%"';
		}
		
		if($purchaseListingSession->offsetExists('purchase_date') && $purchaseListingSession->purchase_date != '') {
			$tempDate		 = str_replace('-', '/', $purchaseListingSession->purchase_date);
			$purchase_date   = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND purchase.purchase_date = "' . $purchase_date . '"';
		}
		
		$orderClause		 = '';
		if($purchaseListingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($purchaseListingSession->sortBy == "purchase_date" || $purchaseListingSession->sortBy == "purchase_quantity") ? "purchase" : "parts";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$purchaseListingSession->sortBy;
		}
		
		if($purchaseListingSession->offsetExists('sortType') && $purchaseListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	= ' ORDER BY purchase.parts_purchase_id DESC';
		}
		$sql	= 'SELECT parts.parts_id, parts.parts_name, parts.parts_jb, parts.parts_qbp,parts. parts_status, location_id,
				   purchase.parts_purchase_id, purchase.purchase_date, purchase.purchase_quantity, purchase.fk_parts_id
				   FROM '.$this->table.' as purchase
				   left join parts as parts on (purchase.fk_parts_id = parts.parts_id)';
		$sql   .=  $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
	public function deletePurchase($purchaseId)
    {
        $data = array(
				'purchase_isdelete'	=> '1'
        );
		$this->update($data, array('parts_purchase_id' => $purchaseId));
    }
	public function checkPartsPurchaseDetails($where)
	{
		$sql 		= "Select * from parts_purchase where purchase_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updatePartsPurchase($update_string,$purchase_id)
    {
	    $sql		= " update parts_purchase set ".$update_string." where parts_purchase_id = ".$purchase_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function insertPartsPurchase($insert_string)
    {
        $sql 				= "insert into parts_purchase set ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getAllPartsPurchaseDetails($where)
    {
		$sql	= 'SELECT parts.parts_id, parts.parts_name, parts.parts_jb, parts.parts_qbp,parts. parts_status,parts.parts_min_quantity, parts.parts_in_stock, location_id,
				   purchase.parts_purchase_id, purchase.purchase_date, purchase.purchase_quantity, purchase.fk_parts_id
				   FROM parts as parts 
				   left join '.$this->table.' as purchase on (purchase.fk_parts_id = parts.parts_id)
				   where 1 '.$where;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		//$result		= $this->resultSetPrototype->initialize($result);
		return $result;
    }
	public function updatePartsStock($data,$parts_id)
    {
	   $sql		= " update parts set ".$data." where parts_id = ".$parts_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function insertMutliPartsRequest($insert_string)
    {
        $sql 				= "insert into parts_request (fk_parts_id, fk_location_id, fk_user_id, request_date, request_quantity, request_isdelete, request_created_date ) values  ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function insertMultiPartsPurchase($insert_string)
    {
        $sql 				= "insert into parts_purchase(fk_parts_id, fk_location_id, fk_user_id, purchase_created_date, purchase_date, purchase_quantity, purchase_isdelete ) values  ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updatePartsRequest($update_string,$purchase_id)
    {
	    $sql		= " update parts_request set ".$update_string." where parts_request_id = ".$purchase_id;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getPartsRequestList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId				=  $pcUser->location_id;
		$whereClause   	  	 	= ' WHERE 1 and parts.parts_isdelete = 0 and request.request_isdelete = 0 and parts.location_id = '.$locationId;
		
		$purchaseListingSession = new Container('partsPurchaseRequestListing');
		
		if($purchaseListingSession->offsetExists('parts_name') && $purchaseListingSession->parts_name != '') {
			$whereClause	.= ' AND parts.parts_name like "%' . $purchaseListingSession->parts_name . '%"';
		}
		
		if($purchaseListingSession->offsetExists('purchase_date') && $purchaseListingSession->purchase_date != '') {
			$tempDate		 = str_replace('-', '/', $purchaseListingSession->purchase_date);
			$purchase_date   = date('Y-m-d', strtotime($tempDate));
			$whereClause	.= ' AND request.request_date = "' . $purchase_date . '"';
		}
		
		$orderClause		 = '';
		if($purchaseListingSession->offsetExists('sortBy')) {
			$joinPrefix		 = ($purchaseListingSession->sortBy == "request_date" || $purchaseListingSession->sortBy == "request_quantity") ? "request" : "parts";
			$orderClause	.= ' ORDER BY '.$joinPrefix.'.'.$purchaseListingSession->sortBy;
		}
		
		if($purchaseListingSession->offsetExists('sortType') && $purchaseListingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	= ' ORDER BY request.parts_request_id DESC';
		}
		$sql	= 'SELECT parts.parts_id, parts.parts_name, parts.parts_jb, parts.parts_qbp,parts. parts_status, location_id,
				   request.parts_request_id, request.request_date, request.request_quantity, request.fk_parts_id
				   FROM parts_request as request
				   left join parts as parts on (request.fk_parts_id = parts.parts_id)';
		$sql   .=  $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getPartsRequestDetails($purchaseId)
    {
		$sql	= 'SELECT parts.parts_id, parts.parts_name, parts.parts_jb, parts.parts_qbp,parts. parts_status, location_id,
				   request.parts_request_id, request.request_date, request.request_quantity, request.fk_parts_id
				   FROM parts_request as request
				   left join parts as parts on (request.fk_parts_id = parts.parts_id)
				   where 1 and request.parts_request_id ='.$purchaseId;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
    }
	public function deletePartsRequest($purchaseId)
    {
		 $sql		= " update parts_request set request_isdelete = 1 where parts_request_id = ".$purchaseId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function insertManagerNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
}