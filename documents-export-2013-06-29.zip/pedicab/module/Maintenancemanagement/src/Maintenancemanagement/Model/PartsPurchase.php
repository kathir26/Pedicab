<?php
namespace Maintenancemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class PartsPurchase implements InputFilterAwareInterface
{
    public $parts_purchase_id;
    public $fk_parts_id;
    public $purchase_date;
	public $purchase_quantity;
	public $purchase_isdelete;
	
    public function exchangeArray($data)
    {
		$this->parts_purchase_id	= (isset($data['parts_purchase_id'])) ? $data['parts_purchase_id'] : null;
		$this->fk_parts_id			= (isset($data['fk_parts_id'])) ? $data['fk_parts_id'] : null;
        $this->purchase_date		= (isset($data['purchase_date'])) ? $data['purchase_date'] : null;
        $this->purchase_quantity	= (isset($data['purchase_quantity'])) ? $data['purchase_quantity'] : null;
		$this->purchase_isdelete	= (isset($data['purchase_isdelete'])) ? $data['purchase_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
