<?php
namespace Maintenancemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Job implements InputFilterAwareInterface
{
	
    public function exchangeArray($data)
    {
		$this->job_id				= (isset($data['job_id'])) ? $data['job_id'] : null;
		$this->fk_bike_id			= (isset($data['fk_bike_id'])) ? $data['fk_bike_id'] : null;
		$this->location_id			= (isset($data['location_id'])) ? $data['location_id'] : null;
        $this->Job_number			= (isset($data['Job_number'])) ? $data['Job_number'] : null;
        $this->job_date				= (isset($data['job_date'])) ? $data['job_date'] : null;
		$this->job_bike_number		= (isset($data['job_bike_number'])) ? $data['job_bike_number'] : null;
		$this->job_mechanic			= (isset($data['job_mechanic'])) ? $data['job_mechanic'] : null;
		$this->job_est_time			= (isset($data['job_est_time'])) ? $data['job_est_time'] : null;
		$this->job_parts_used		= (isset($data['job_parts_used'])) ? $data['job_parts_used'] : null;
		$this->job_description		= (isset($data['job_description'])) ? $data['job_description'] : null;
		$this->job_created_date		= (isset($data['job_created_date'])) ? $data['job_created_date'] : null;
		$this->job_updated_date		= (isset($data['job_updated_date'])) ? $data['job_updated_date'] : null;
		$this->job_isdelete			= (isset($data['job_isdelete'])) ? $data['job_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
