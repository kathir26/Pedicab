<?php
namespace Maintenancemanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Parts implements InputFilterAwareInterface
{
    public $parts_id;
    public $parts_name;
    public $parts_jb;
	public $parts_qbp;
	public $parts_min_quantity;
	public $parts_max_quantity;
	public $parts_in_stock;
	public $parts_to_order;
	public $parts_description;
	public $parts_image;
	public $parts_status;
	public $parts_created_date;
	public $parts_updated_date;
	public $location_id;
	public $parts_isdelete;
	
    public function exchangeArray($data)
    {
		$this->parts_id				= (isset($data['parts_id'])) ? $data['parts_id'] : null;
		$this->parts_name			= (isset($data['parts_name'])) ? $data['parts_name'] : null;
        $this->parts_jb				= (isset($data['parts_jb'])) ? $data['parts_jb'] : null;
        $this->parts_qbp			= (isset($data['parts_qbp'])) ? $data['parts_qbp'] : null;
		$this->parts_min_quantity	= (isset($data['parts_min_quantity'])) ? $data['parts_min_quantity'] : null;
		$this->parts_max_quantity	= (isset($data['parts_max_quantity'])) ? $data['parts_max_quantity'] : null;
		$this->parts_in_stock		= (isset($data['parts_in_stock'])) ? $data['parts_in_stock'] : null;
		$this->parts_to_order		= (isset($data['parts_to_order'])) ? $data['parts_to_order'] : null;
		$this->parts_description	= (isset($data['parts_description'])) ? $data['parts_description'] : null;
		$this->parts_image			= (isset($data['parts_image'])) ? $data['parts_image'] : null;
		$this->parts_status			= (isset($data['parts_status'])) ? $data['parts_status'] : null;
		$this->parts_created_date	= (isset($data['parts_created_date'])) ? $data['parts_created_date'] : null;
		$this->parts_updated_date	= (isset($data['parts_updated_date'])) ? $data['parts_updated_date'] : null;
		$this->location_id			= (isset($data['location_id'])) ? $data['location_id'] : null;
		$this->parts_isdelete		= (isset($data['parts_isdelete'])) ? $data['parts_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
