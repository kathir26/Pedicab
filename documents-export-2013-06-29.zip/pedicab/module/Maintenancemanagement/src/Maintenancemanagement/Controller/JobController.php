<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Maintenancemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Maintenancemanagement\Form\AddJobForm,
	Maintenancemanagement\Form\JobFilterForm,
	Maintenancemanagement\Form\MechanicJobFilterForm,
	Maintenancemanagement\Form\MechanicRequestFilterForm;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter,
	Maintenancemanagement\Model\Job;

class JobController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->repairUrgency		=  array('1' => 'Not Urgent: Bike is rideable but should be looked at in the next 2-4 days','2'	=> 'Somewhat Urgent: Bike should be looked at very soon, but is still safe to ride','3' => 'URGENT: Bike cannot be ridden until fixed');
		$this->requestBy			=  array('1' => 'Driver','2' => 'Mechanic','3' => 'Manager');
		$this->jobBikeStatus		=  array('0' => 'Not yet started','1' => 'Inprogress','2' => 'Completed');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("JobTable" => "Job-Table", "LocationTable" => "Location-Table", "PartsTable" => "Parts-Table", "PartsPurchaseTable" => "Parts-Purchase-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	public function JobListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		// Create Filter form
		$AddJobForm 	= new AddJobForm();
		$JobFilterForm 	= new JobFilterForm();
		$fkjobId 		= $this->params()->fromRoute('id', '');
		$unique_job_number = $get_parts_details = $get_mechanic_details = $get_job_details = $parts_name_ids = $parts_ids_array = $jobDateTime = '';
		$job_unique_number = 1;
		$jobDateTime 	   = date('n-j-Y H:i');
		$parts_purchase_array = $mechanic_array = array();
		//	Destroy listing Session Vars
		if(isset($fkjobId) && $fkjobId == '')
		{
			$status	 		=  $this->getCommonDataObj()->destroySessionVariables(array('JobListing'));
		}
		$jobListingSession 	= new Container('JobListing');
		$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
		if(is_object($get_parts_details) && count($get_parts_details) > 0)
		{
			foreach($get_parts_details as $parts_key => $parts_value)
			{
				$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
			}
		}
		$get_mechanic_details = $this->getTable('JobTable')->getUserDetails($identity->location_id,2);
		$mechanic_array['']	  = 'Select';
		if(is_object($get_mechanic_details) && count($get_mechanic_details) > 0)
		{
			foreach($get_mechanic_details as $mech_key => $mech_value)
			{
				$mechanic_array[$mech_value['user_id']]	= $mech_value['user_firstname']." ".$mech_value['user_lastname'];
			}
		}
		if ($request->isPost()) {
			$JobFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_job_sheet']) && !empty($formData['search_job_sheet']))
				$jobListingSession->job_sheet	= $formData['search_job_sheet'];
			else
				$jobListingSession->job_sheet	= '';
			
			if(isset($formData['search_bike_number']) && $formData['search_bike_number'] != '')
				$jobListingSession->bike_number	= $formData['search_bike_number'];
			else
				$jobListingSession->bike_number	= '';
		}
		
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '' ) {
			$JobFilterForm->get('search_job_sheet')->setValue($jobListingSession->job_sheet);
		}
		if($jobListingSession->offsetExists('bike_number') && $jobListingSession->bike_number != '' ) {
			$JobFilterForm->get('search_bike_number')->setValue($jobListingSession->bike_number);
		}
		$AddJobForm->get('job_repair_urgency')->setValueOptions($this->repairUrgency);
		$AddJobForm->get('job_request_by')->setValueOptions($this->requestBy);
		$AddJobForm->get('job_used_parts')->setValueOptions($parts_purchase_array);
		$AddJobForm->get('job_mechanic')->setValueOptions($mechanic_array);
		$AddJobForm->get('job_bike_status')->setValueOptions($this->jobBikeStatus);
		if(isset($fkjobId) && $fkjobId > 0)
		{
			$where				= " and job_id = ".$fkjobId;
			$get_job_details	= $this->getTable('JobTable')->getJobDetails($where);
			if(is_object($get_job_details) && count($get_job_details) > 0)
			{
				$jobBack		= $matches->getParam('jobBack', '');
				$AddJobForm->get('job_back')->setValue($jobBack);
				foreach($get_job_details as $jo_key => $jo_value)
				{
					$AddJobForm->get('job_number')->setValue(stripslashes($jo_value['job_number']));
					$job_unique_number	= stripslashes($jo_value['job_number']);
					$AddJobForm->get('job_date')->setValue(date('n-j-Y H:i',strtotime($jo_value['job_date'])));
					$AddJobForm->get('job_bike')->setValue(stripslashes($jo_value['job_bike_number']));
					$AddJobForm->get('job_bike_id')->setValue(stripslashes($jo_value['fk_bike_id']));
					$AddJobForm->get('job_mechanic')->setValue(stripslashes($jo_value['job_mechanic']));
					if(isset($jo_value['job_est_time']) && $jo_value['job_est_time'] != '00:00:00')
					{
						$AddJobForm->get('job_est_time')->setValue(stripslashes($jo_value['job_est_time']));
					}
					$AddJobForm->get('job_additional_desc')->setValue(stripslashes($jo_value['job_additional_desc']));
					$AddJobForm->get('job_description')->setValue(stripslashes($jo_value['job_description']));
					$AddJobForm->get('job_id')->setValue(stripslashes($jo_value['job_id']));
					$AddJobForm->get('job_bike_status')->setValue(stripslashes($jo_value['job_status']));
					$parts_name_ids	= stripslashes($jo_value['job_parts_used']);
					if(isset($parts_name_ids) && $parts_name_ids != '')
					{
						$parts_ids_array	= explode(",",$parts_name_ids);
						$parts_ids_array	= array_flip($parts_ids_array);
					}
					$AddJobForm->get('job_issue')->setValue(stripslashes($jo_value['job_issue']));
					$AddJobForm->get('job_repair_urgency')->setValue(stripslashes($jo_value['job_repair_urgency']));
					$AddJobForm->get('job_request_id')->setValue(stripslashes($jo_value['job_request_user_id']));
					$AddJobForm->get('job_request_by')->setValue(stripslashes($jo_value['job_request_by']));
				}
			}
		}
		else
		{
			$unique_job_number	  = $this->getTable('JobTable')->getUniqueJobNumber($identity->location_id);
			if(is_object($unique_job_number) && count($unique_job_number) > 0)
			{
				foreach($unique_job_number as $job_key => $job_value)
				{
					if($job_value['max_job'] > 0)
					{
						$job_unique_number	= $job_value['max_job'] + 1;
					}
				}
			}
			$job_unique_number	= 'JB '.str_pad($job_unique_number,6,'0',STR_PAD_LEFT);
			$AddJobForm->get('job_number')->setValue($job_unique_number);
			$AddJobForm->get('job_date')->setValue($jobDateTime);
			$AddJobForm->get('job_request_id')->setValue($identity->user_id);
			$AddJobForm->get('job_request_by')->setValue($identity->user_role_id);
		}
		// User listing
		$perPage			= $this->defaultPerPage;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'JobFilterForm' 		=> $JobFilterForm,
			'AddJobForm'			=> $AddJobForm,
			'pc_users'				=> $this->pcUser,
			'fkjobId'				=> $fkjobId,
			'parts_ids_array'		=> $parts_ids_array,
			'datetime'				=> $datetime,
			'job_unique_number'		=> $job_unique_number,
			'parts_purchase_array'	=> $parts_purchase_array,
			'repairUrgency'			=> $this->repairUrgency,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function jobListAction()
    {
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$get_parts_details = $parts_purchase_array = '';
		//	Session for Role listing
		$jobListingSession 	= new Container('JobListing');
		$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
		if(is_object($get_parts_details) && count($get_parts_details) > 0)
		{
			foreach($get_parts_details as $parts_key => $parts_value)
			{
				$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
			}
		}
		$columnFlag		= 0;
		if($sortBy != '') {
			if($jobListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$jobListingSession->sortBy	= $sortBy;
		} else if($jobListingSession->offsetExists('sortBy')) {
			$sortBy	= $jobListingSession->sortBy;
		}
		if($sortType != '') {
			if($jobListingSession->sortType == $sortType && $columnFlag == 1)
				$jobListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$jobListingSession->sortType	= $sortType;
		} else if($jobListingSession->offsetExists('sortType')) {
			$sortType	= $jobListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$jobListingSession->perPage	= $perPage;
		} else if($jobListingSession->offsetExists('perPage')) {
			$perPage		= $jobListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'parts_purchase_array'	=> $parts_purchase_array,
			'repairUrgency'			=> $this->repairUrgency,
			'perPage'				=> $perPage,
			'activeArrray'			=> $this->activeArrray,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function getBikeDetailsAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		if($request->isPost())
		{
			$get_bike_details = '';
			$form_data		= $request->getPost();
			$json_array 	= array();
			if($form_data['search'] != '')
			{
				$where				= " and bike_name like '%".addslashes($form_data['search'])."%' and fk_location_id = '".$identity->location_id."'";
				$get_bike_details	= $this->getTable('JobTable')->getBikeDetails($where);
				if(is_object($get_bike_details) && count($get_bike_details) > 0)
				{
					foreach($get_bike_details as $bike_key => $bike_value)
					{
						$json_array[$bike_key]['name']		= $bike_value['bike_name'];
						$json_array[$bike_key]['model']		= $bike_value['bike_model'];
						$json_array[$bike_key]['serial']	= $bike_value['bike_name'];
						$json_array[$bike_key]['bId']		= $bike_value['bike_id'];
					}
				}
			}
			echo json_encode($json_array);die();
		}
	}
	public function saveJobSheetAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$job_sheet_id 			= $job_stock_id = $insert_job_sheet = $date_purchase = $job_parts_id = $insert_string_implode = $insert_string = $get_deleted_array = $sessDateTime = '';
		$insert_Notify_array 	= $get_location_manager = $loc_man_driv_ids = $email_ids_array = '';
		$partsInsuffArray		= array();
		if($request->isPost())
		{
			$form_data			= $request->getPost();
			$convertTime		= $form_data['job_est_time'];
			if(isset($form_data['job_date']) && $form_data['job_date'] != '')
			{
				$sessDateTime		= explode(' ',$form_data['job_date']);
				if(is_array($sessDateTime) && count($sessDateTime) > 0)
				{
					$sess_open_date		= explode('-',$sessDateTime[0]);
					if(is_array($sess_open_date) && count($sess_open_date) > 0)
					{
						$date_purchase	= $sess_open_date[2]."-".$sess_open_date[0]."-".$sess_open_date[1];
						$date_purchase  .= ' '.$sessDateTime[1];
					}
				}
			}
			if(is_array($form_data['job_used_parts']) && count($form_data['job_used_parts']) > 0)
			{
				$job_parts_id		= implode(',',$form_data['job_used_parts']);
			}
			if(isset($form_data['job_bike_id']) && $form_data['job_bike_id'] != '')
			{
				$insert_job_sheet	= " fk_bike_id 				= '".addslashes($form_data['job_bike_id'])."',
										location_id				= '".addslashes($identity->location_id)."',
										job_number				= '".addslashes($form_data['job_number'])."',
										job_date				= '".addslashes($date_purchase)."',
										job_bike_number			= '".addslashes($form_data['job_bike'])."',
										job_issue				= '".addslashes($form_data['job_issue'])."',
										job_additional_desc		= '".addslashes($form_data['job_additional_desc'])."',
										job_mechanic_status		= 0,
										job_isdelete			= 0";
				if(isset($form_data['job_request_by']) && $form_data['job_request_by'] != '')
				{
					$insert_job_sheet .= ", job_request_by			= '".addslashes($form_data['job_request_by'])."',
											job_request_user_id		= '".addslashes($form_data['job_request_id'])."'";
				}
				if(isset($form_data['job_repair_urgency']) && $form_data['job_repair_urgency'] != '')
				{
					$insert_job_sheet .= ", job_repair_urgency		= '".addslashes($form_data['job_repair_urgency'])."'";
				}
				if(isset($identity->user_role_id) && ($identity->user_role_id == 2 || $identity->user_role_id == 3 ))
				{
					$insert_job_sheet .= ", job_est_time		= '".addslashes($convertTime)."',
											job_parts_used		= '".addslashes($job_parts_id)."',
											job_description		= '".addslashes($form_data['job_description'])."',
											job_status			= '".addslashes($form_data['job_bike_status'])."'";
					if($identity->user_role_id == 3)
					{
						$insert_job_sheet .= ", job_mechanic	= '".addslashes($form_data['job_mechanic'])."'";
					}
				}
				if(isset($form_data['job_id']) && $form_data['job_id'] != '')
				{
					$insert_job_sheet .= ", job_updated_date = now()";
					$job_sheet_id		= $form_data['job_id'];
					$this->getTable("JobTable")->updateJobSheet($insert_job_sheet,$job_sheet_id);
					//Update all the job sheets
					if(isset($job_parts_id) && $job_parts_id != '')
					{
						$where				= " and fk_parts_id not in (".$job_parts_id.") and fk_job_id = ".$job_sheet_id;
						$get_deleted_array	= $this->getTable("JobTable")->getJobStocksDetails($where);
						if(is_object($get_deleted_array) && count($get_deleted_array) > 0)
						{
							foreach($get_deleted_array as $del_key => $del_value)
							{
								$data_upd		= " job_stock_status = 0";
								$this->getTable("JobTable")->updateJobSheetStock($data_upd,$del_value['job_stock_id']);
								if(isset($form_data['job_bike_status']) && $form_data['job_bike_status'] != 2)
								{
									$this->getTable("JobTable")->updatePartsStock("parts_in_stock = parts_in_stock + ".$del_value['parts_stock'],$del_value['fk_parts_id']);
								}
							}
						}
					}
					$notification_subject	= " Job Sheet (".$form_data['job_number'].") has been updated for bike number(".$form_data['job_bike'].")";
				}
				else
				{
					$insert_job_sheet .= ", job_created_date = now()";
					$job_sheet_id		= $this->getTable("JobTable")->insertJob($insert_job_sheet);
					$notification_subject	= " Job Sheet (".$form_data['job_number'].") has been created for bike number(".$form_data['job_bike'].").";
				}
				if(isset($identity->user_role_id) && $identity->user_role_id == 3)
				{
					if(isset($form_data['job_id']) && $form_data['job_id'] != '')
					{
						$notification_subject	= " Job Sheet (".$form_data['job_number'].") has been updated for bike number(".$form_data['job_bike'].")";
					}
					else
					{
						$notification_subject	= " Job Sheet (".$form_data['job_number'].") has been created for bike number(".$form_data['job_bike'].") and assigned to you.";
					}
					$get_location_manager		= $this->getTable('JobTable')->getParticularUserDetails($form_data['job_mechanic']);
					if(is_object($get_location_manager) && count($get_location_manager) > 0)
					{
						foreach($get_location_manager as $mech_key => $mech_value)
						{
							$email_ids_array[]			= $mech_value['user_email'];
						}
					}
					$insert_Notify_array[]		= "'".$job_sheet_id."','".$identity->user_id."','".$form_data['job_mechanic']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($date_purchase)."','8'";
				}
				else if(isset($identity->user_role_id) && $identity->user_role_id == 2)
				{
					$loc_man_driv_ids			= '3';//1
					$get_location_manager		= $this->getTable('JobTable')->getUserDetails($identity->location_id,$loc_man_driv_ids);
					if(is_object($get_location_manager) && count($get_location_manager) > 0)
					{
						foreach($get_location_manager as $mech_key => $mech_value)
						{
							$email_ids_array[]			= $mech_value['user_email'];
							$insert_Notify_array[]		= "'".$job_sheet_id."','".$identity->user_id."','".$mech_value['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($date_purchase)."','8'";
						}
					}
				}
				else if(isset($identity->user_role_id) && $identity->user_role_id == 1)
				{
					$loc_man_driv_ids			= '2,3';
					$get_location_manager		= $this->getTable('JobTable')->getUserDetails($identity->location_id,$loc_man_driv_ids);
					if(is_object($get_location_manager) && count($get_location_manager) > 0)
					{
						foreach($get_location_manager as $mech_key => $mech_value)
						{
							$email_ids_array[]			= $mech_value['user_email'];
							$insert_Notify_array[]		= "'".$job_sheet_id."','".$identity->user_id."','".$mech_value['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($date_purchase)."','8'";
						}
					}
				}
				
				if(is_array($insert_Notify_array) && count($insert_Notify_array) > 0)
				{
					$insert_multi_string	= "(".implode("),(",$insert_Notify_array).")";
				}
				if(isset($insert_multi_string) && $insert_multi_string != '')
				{
					$this->getTable('JobTable')->insertManagerNotification($insert_multi_string);
				}
				if(is_array($form_data['job_used_parts']) && count($form_data['job_used_parts']) > 0) //Minimum parts notification mail
				{
					$parts_id_count		= count($form_data['stocks_ids']);
					$parts_name_count	= count($form_data['job_used_parts']);
					
					for($e = 0; $e < $parts_name_count; $e++)
					{
						$update_string = '';
						if(isset($form_data['stocks_ids'][$e]) && $form_data['stocks_ids'][$e] != '')
						{
							$job_stock_id	= $form_data['stocks_ids'][$e];
							$new_stock_up	= 0;
							$new_stock_up	= $form_data['stocks'][$e] - $form_data['stocks_old'][$e];
							$update_string	= " fk_job_id = '".addslashes($job_sheet_id)."', fk_parts_id = '".addslashes($form_data['job_used_parts'][$e])."', parts_stock = '".addslashes($form_data['stocks'][$e])."'";
							$this->getTable("JobTable")->updateJobSheetStock($update_string,$job_stock_id);
							$this->getTable("JobTable")->updatePartsStock("parts_in_stock = parts_in_stock - ".$new_stock_up,$form_data['job_used_parts'][$e]);
							if(isset($form_data['stocks_min_qty'][$e]) && isset($form_data['stocks_available'][$e]))
							{
								$currentStock 				= 0;
								$currentStock 				= $form_data['stocks_available'][$e] - $new_stock_up;
								if($form_data['stocks_min_qty'][$e] >= $currentStock)
								{
									$partsInsuffArray[]		= $form_data['job_used_parts'][$e];
								}
							}
						}
						else
						{
							$insert_string[]			= "'".addslashes($job_sheet_id)."','".addslashes($form_data['job_used_parts'][$e])."', '".addslashes($form_data['stocks'][$e])."',1";
							$this->getTable("JobTable")->updatePartsStock("parts_in_stock = parts_in_stock - ".$form_data['stocks'][$e],$form_data['job_used_parts'][$e]);
							$currentStock 				= 0;
							$currentStock 				= $form_data['stocks_available'][$e] - $form_data['stocks'][$e];
							if($form_data['stocks_min_qty'][$e] >= $currentStock)
							{
								$partsInsuffArray[]		= $form_data['job_used_parts'][$e];
							}
						}
					}
					if(is_array($insert_string) && count($insert_string) > 0)
					{
						$insert_string_implode	= "(".implode("),(",$insert_string).")";
						$this->getTable("JobTable")->insertJobStock($insert_string_implode);
					}
				}
				//Minimum Parts mail sending
				if(is_array($partsInsuffArray) && count($partsInsuffArray) > 0)
				{
					$locationValue				= '';
					$partsIdsImplode			= implode(",",$partsInsuffArray);
					$gerLocationList			= $this->getTable("LocationTable")->getLocationDetails($identity->location_id);
					if(is_object($gerLocationList) && count($gerLocationList) > 0)
					{
						foreach($gerLocationList as $locKey => $locValue)
						{
							$locationValue		= $locValue['loc_title'];
						}
					}
					$where						= '';
					$where						= " and parts_isdelete = 0 and parts_in_stock <= parts_min_quantity and location_id = ".$identity->location_id;
					$getPartsList				= $this->getTable("PartsTable")->getPartsDetailsAll($where);
					if(is_object($getPartsList) && count($getPartsList) > 0)
					{
						$roleId					= '3,5'; //Admin and Manager
						$getUserDetails 		= $this->getTable("JobTable")->getuserDetails($identity->location_id, $roleId);
						if(is_object($getUserDetails) && count($getUserDetails) > 0)
						{
							foreach($getUserDetails as $userKey => $userValue)
							{
								$toMailAddr[]							= $userValue['user_email'];
							}
						}
						$partsHtmlContent		= '';
						$partsHtmlContent		.= '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr style="background:#2D4C05;color: #FFFFFF;font-size: 12px;font-weight: normal;font-family:Arial"><th style="width:25%; padding:10px 0px">Part Name</th><th style="width:25%">Part Number</th><th style="width:20%">No.should have in stock</th><th style="width:15%">No. on Hand</th><th style="width:15%">Parts to Order</th></tr>';
						foreach($getPartsList as $partsKey => $partsValue)
						{
							$partsHtmlContent	.= '<tr style="padding:10px 0px;background:#ECF1E6;color:#404040;font-size: 12px;font-family:Arial;text-align:center;">
														<td style="border:1px solid #2D4C05;border-top:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_name']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_jb']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_min_quantity']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_in_stock']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.abs($partsValue['parts_in_stock'] - $partsValue['parts_min_quantity']).'</td>
													</tr>';
						}
						$partsHtmlContent		.= '</table>';
						if(is_array($toMailAddr) && count($toMailAddr) > 0 && isset($partsHtmlContent) && $partsHtmlContent != '')
						{
							$mailArray			    =  array(
								'subject'		  	=> 'Minimum Parts Notification from '.ucfirst($locationValue),
					            'from_email'	  	=> '',
								'from_name' 	  	=> '',
								'to_email' 	  	  	=> $toMailAddr,//'kathiravan@sdi.la',//
								'mail_title' 	  	=> 'Parts to Order in '.ucfirst($locationValue),
								'mail_descriptions' => '',
								'mail_preview' 		=> 1, // Change to 0 for mail sending
								'template_path' 	=> 'usermanagement/mail_templates/parts_notification',
								//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
					        );
							$this->getCommonDataObj()->siteMailSending($partsHtmlContent, $mailArray);
						}
					}
				}
				//Mail Sending
				if(isset($form_data['job_repair_urgency']) && $form_data['job_repair_urgency'] != 3)
				{
					if(is_array($email_ids_array) && count($email_ids_array) > 0)
					{
						if(isset($form_data['job_id']) && $form_data['job_id'] != '')
						{
							$emailText			= 'Updated';
						}
						else
						{
							$emailText			= 'Created';
						}
						$mailArray			    =  array(
							'subject'		  	=> 'Job Sheet ('.$form_data['job_number'].') '.$emailText.' for bike('.$form_data['job_bike'].')',
				            'from_email'	  	=> '',
							'from_name' 	  	=> '',
							'to_email' 	  	  	=> $email_ids_array,
							'mail_title' 	  	=> 'Job Sheet ('.$form_data['job_number'].')',
							'mail_descriptions' => '',
							'mail_preview' 		=> 1, // Change to 0 for mail sending
							'template_path' 	=> 'usermanagement/mail_templates/job_sheet_template',
							//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
				        );
						$mailDetails			=  array(
							'Job Sheet'					=>	$form_data['job_number'],
							'Bike Number'				=>	$form_data['job_bike'],
							'Repair Urgency'			=>	$this->repairUrgency[$form_data['job_repair_urgency']],
							'Job Addition Description'	=>	$form_data['job_additional_desc'],
						);
						
						$this->getCommonDataObj()->siteMailSending($mailDetails, $mailArray);
					}
				}
				else
				{
					//Send Sms
				}
			}
			if(isset($form_data['job_back']) && $form_data['job_back'] == 1)
			{
				return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'job', 'action' => 'mechanic-job','id' => 1));
			}
			else
			{
				return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'job', 'action' => 'job-listing','id' => 0));
			}
		}
	}
	public function getPartsDetailsAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array = array();
		if($request->isPost())
		{
			$get_parts_details	= $get_job_stocks = $job_stock_array = $job_part_array = '';
			$form_data			= $request->getPost();
			$parts_ids_string	= $form_data['sel'];
			if(isset($parts_ids_string) && $parts_ids_string != '')
			{
				$json_array['err']	= 0;
				if(isset($form_data['job_id']) && $form_data['job_id'] != '')
				{
					$job_id			= $form_data['job_id'];
					$where			= " and fk_job_id = ".$job_id;
					$get_job_stocks	= $this->getTable('JobTable')->getJobStocksDetails($where);
					if(is_object($get_job_stocks) && count($get_job_stocks) > 0)
					{
						foreach($get_job_stocks as $job_key => $job_value)
						{
							$job_stock_array[$job_value['fk_parts_id']]		= $job_value['parts_stock'];
							$job_part_array[$job_value['fk_parts_id']]		= $job_value['job_stock_id'];
						}
					}
				}
				$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id,$parts_ids_string);
				if(is_object($get_parts_details) && count($get_parts_details) > 0)
				{
					$e = 0;
					foreach($get_parts_details as $parts_key => $parts_value)
					{
						$part_old_stock = $stock_id = '';
						if(isset($job_part_array[$parts_value['parts_id']]) && $job_part_array[$parts_value['parts_id']] != '')
						{
							$stock_id						= $job_part_array[$parts_value['parts_id']];
						}
						if(isset($job_stock_array[$parts_value['parts_id']]) && $job_stock_array[$parts_value['parts_id']] != '')
						{
							$part_old_stock					= $job_stock_array[$parts_value['parts_id']];
						}
						$json_array[$e]['id']				= $parts_value['parts_id'];
						$json_array[$e]['name']				= stripslashes($parts_value['parts_name']);
						$json_array[$e]['number']			= stripslashes($parts_value['parts_jb']);
						$json_array[$e]['stock']			= $parts_value['parts_in_stock'];
						$json_array[$e]['min_qty']			= $parts_value['parts_min_quantity'];
						$json_array[$e]['old_stock']		= $part_old_stock;
						$json_array[$e]['stock_ids']		= $stock_id;
						$e++;
					}
				}
			}
			else
			{
				$json_array['err']	= 1;
			}
		}
		echo json_encode($json_array);die();
	}
	public function viewJobAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$job_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$get_parts_details = $get_job_details = '';
		if($job_id)
		{
			$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
			if(is_object($get_parts_details) && count($get_parts_details) > 0)
			{
				foreach($get_parts_details as $parts_key => $parts_value)
				{
					$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
				}
			}
			$get_job_details	= $this->getTable('JobTable')->viewJobSheet($job_id);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $get_job_details,
				'parts_purchase_array'	=> $parts_purchase_array,
				'datetime'				=> $datetime,
				'repairUrgency'			=> $this->repairUrgency,
				'requestBy'				=> $this->requestBy,
				'jobBikeStatus'			=> $this->jobBikeStatus,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function deleteJobSheetAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$getJobDetails = '';
		if($request->isPost())
		{
			$formData	= $request->getPost();
			$jobId		= $formData['jobId'];
			$jobStat	= $formData['stat'];
			$mechId		= $formData['mech'];
			//Update all the job sheets
			$whereJob			= " and job_id = ".$jobId;
			$getJobDetails		= $this->getTable('JobTable')->getJobDetails($whereJob);
			if(is_object($getJobDetails) && count($getJobDetails) > 0)
			{
				foreach($getJobDetails as $jbkey => $jbvalue)
				{
					$where				= " and fk_job_id = ".$jobId;
					$getDeletedArray	= $this->getTable("JobTable")->getJobStocksDetails($where);
					if(is_object($getDeletedArray) && count($getDeletedArray) > 0)
					{
						foreach($getDeletedArray as $delKey => $delValue)
						{
							$dataUpd		= " job_stock_status = 0";
							$this->getTable("JobTable")->updateJobSheetStock($dataUpd,$delValue['job_stock_id']);
							if(isset($jbvalue['job_status']) && $jbvalue['job_status'] != 2)
							{
								$this->getTable("JobTable")->updatePartsStock("parts_in_stock = parts_in_stock + ".$delValue['parts_stock'],$delValue['fk_parts_id']);
							}
						}
					}
					$this->getTable("JobTable")->updateJobSheet("job_isdelete = 1",$jobId);
					if(isset($jbvalue['job_status']) && $jbvalue['job_status'] != 2)
					{
						$notification_subject		= " Job Sheet (".$jbvalue['job_number'].") has been deleted successfully by Location Manager";
						$insert_Notify_array[]		= "'".$jobId."','".$identity->user_id."','".$jbvalue['job_mechanic']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notification_subject)."','".addslashes($jbvalue['job_date'])."','8'";
						if(is_array($insert_Notify_array) && count($insert_Notify_array) > 0)
						{
							$insert_multi_string	= "(".implode("),(",$insert_Notify_array).")";
						}
						if(isset($insert_multi_string) && $insert_multi_string != '')
						{
							$this->getTable('JobTable')->insertManagerNotification($insert_multi_string);
						}
					}
				}
			}
			echo 1;
			die();
		}
	}
	public function mechanicJobAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$get_parts_details = '';
		$parts_purchase_array = array();
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		// Create Filter form
		$mechanicJobFilterForm 	= new MechanicJobFilterForm();
		$jobStatus 				= $this->params()->fromRoute('id', '');
		$session_container		= (isset($jobStatus) && $jobStatus == 2) ? 'mechanicCompletedJob' : 'mechanicViewJob';
		$jobListingSession 		= new Container($session_container);
		if(isset($jobStatus) && ($jobStatus == 1 || $jobStatus == 2))
		{
			$status	 		=  $this->getCommonDataObj()->destroySessionVariables(array($session_container));
		}
		if($jobStatus == '')
		{
			$jobStatus = 1;
		}
		$get_parts_details		= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
		if(is_object($get_parts_details) && count($get_parts_details) > 0)
		{
			foreach($get_parts_details as $parts_key => $parts_value)
			{
				$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
			}
		}
		if ($request->isPost()) {
			$mechanicJobFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_job_sheet']) && !empty($formData['search_job_sheet']))
				$jobListingSession->job_sheet	= $formData['search_job_sheet'];
			else
				$jobListingSession->job_sheet	= '';
			
			if(isset($formData['search_bike_number']) && $formData['search_bike_number'] != '')
				$jobListingSession->bike_number	= $formData['search_bike_number'];
			else
				$jobListingSession->bike_number	= '';
		}
		
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '' ) {
			$mechanicJobFilterForm->get('search_job_sheet')->setValue($jobListingSession->job_sheet);
		}
		if($jobListingSession->offsetExists('bike_number') && $jobListingSession->bike_number != '' ) {
			$mechanicJobFilterForm->get('search_bike_number')->setValue($jobListingSession->bike_number);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetViewList($jobStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'mechanicJobFilterForm' => $mechanicJobFilterForm,
			'pc_users'				=> $this->pcUser,
			'jobStatus'				=> $jobStatus,
			'datetime'				=> $datetime,
			'parts_purchase_array'	=> $parts_purchase_array,
			'repairUrgency'			=> $this->repairUrgency,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function mechanicJobListAction()
    {
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$get_parts_details = $parts_purchase_array = '';
		$jobStatus 				= $this->params()->fromRoute('jobStatus', '');
		if($jobStatus == '')
		{
			$jobStatus = 1;
		}
		$session_container		= (isset($jobStatus) && $jobStatus == 2) ? 'mechanicCompletedJob' : 'mechanicViewJob';
		$jobListingSession 		= new Container($session_container);
		$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
		if(is_object($get_parts_details) && count($get_parts_details) > 0)
		{
			foreach($get_parts_details as $parts_key => $parts_value)
			{
				$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
			}
		}
		$columnFlag		= 0;
		if($sortBy != '') {
			if($jobListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$jobListingSession->sortBy	= $sortBy;
		} else if($jobListingSession->offsetExists('sortBy')) {
			$sortBy	= $jobListingSession->sortBy;
		}
		if($sortType != '') {
			if($jobListingSession->sortType == $sortType && $columnFlag == 1)
				$jobListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$jobListingSession->sortType	= $sortType;
		} else if($jobListingSession->offsetExists('sortType')) {
			$sortType	= $jobListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$jobListingSession->perPage	= $perPage;
		} else if($jobListingSession->offsetExists('perPage')) {
			$perPage		= $jobListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetViewList($jobStatus));
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'jobStatus'				=> $jobStatus,
			'paginator'				=> $paginator,
			'parts_purchase_array'	=> $parts_purchase_array,
			'repairUrgency'			=> $this->repairUrgency,
			'perPage'				=> $perPage,
			'activeArrray'			=> $this->activeArrray,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewMechanicJobAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$job_id 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$get_parts_details = $get_job_details = '';
		if($job_id)
		{
			$get_parts_details	= $this->getTable('JobTable')->getPartsPurchaseDetails($identity->location_id);
			if(is_object($get_parts_details) && count($get_parts_details) > 0)
			{
				foreach($get_parts_details as $parts_key => $parts_value)
				{
					$parts_purchase_array[$parts_value['parts_id']]	= $parts_value['parts_name'];
				}
			}
			$get_job_details	= $this->getTable('JobTable')->viewJobSheet($job_id);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $get_job_details,
				'parts_purchase_array'	=> $parts_purchase_array,
				'datetime'				=> $datetime,
				'repairUrgency'			=> $this->repairUrgency,
				'requestBy'				=> $this->requestBy,
				'jobBikeStatus'			=> $this->jobBikeStatus,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function mechanicRequestListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$get_parts_details = '';
		$parts_purchase_array = array();
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		// Create Filter form
		$mechanicRequestFilterForm 	= new MechanicRequestFilterForm();
		$session_container		= 'mechanicRequestedJob';
		$jobListingSession 		= new Container($session_container);
		$status	 				= $this->getCommonDataObj()->destroySessionVariables(array($session_container));
		if ($request->isPost()) {
			$mechanicRequestFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_job_sheet']) && !empty($formData['search_job_sheet']))
				$jobListingSession->job_sheet	= $formData['search_job_sheet'];
			else
				$jobListingSession->job_sheet	= '';
			
			if(isset($formData['search_job_date']) && $formData['search_job_date'] != '')
				$jobListingSession->job_date	= $formData['search_job_date'];
			else
				$jobListingSession->job_date	= '';
		}
		
		if($jobListingSession->offsetExists('job_sheet') && $jobListingSession->job_sheet != '' ) {
			$mechanicRequestFilterForm->get('search_job_sheet')->setValue($jobListingSession->job_sheet);
		}
		if($jobListingSession->offsetExists('job_date') && $jobListingSession->job_date != '' ) {
			$mechanicRequestFilterForm->get('search_job_date')->setValue($jobListingSession->job_date);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetRequestList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'				=> $identity,
			'mechanicRequestFilterForm' => $mechanicRequestFilterForm,
			'pc_users'					=> $this->pcUser,
			'datetime'					=> $datetime,
			'page'						=> $page,
			'sortBy'					=> $sortBy,
			'paginator'					=> $paginator,
			'perPage'					=> $perPage,
			'repairUrgency'				=> $this->repairUrgency,
			'requestBy'					=> $this->requestBy,
			'perPageArray'				=> $this->perPageArray,
			'controller'				=> $this->params('controller'),
			'commonData'				=> $this->getCommonDataObj()
		));
    }
	public function mechanicRequestListAction()
    {
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		$get_parts_details = $parts_purchase_array = '';
		
		$session_container		= 'mechanicRequestedJob';
		$jobListingSession 		= new Container($session_container);
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($jobListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$jobListingSession->sortBy	= $sortBy;
		} else if($jobListingSession->offsetExists('sortBy')) {
			$sortBy	= $jobListingSession->sortBy;
		}
		if($sortType != '') {
			if($jobListingSession->sortType == $sortType && $columnFlag == 1)
				$jobListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$jobListingSession->sortType	= $sortType;
		} else if($jobListingSession->offsetExists('sortType')) {
			$sortType	= $jobListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$jobListingSession->perPage	= $perPage;
		} else if($jobListingSession->offsetExists('perPage')) {
			$perPage		= $jobListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('JobTable')->getJobSheetRequestList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'repairUrgency'			=> $this->repairUrgency,
			'requestBy'				=> $this->requestBy,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function requestJobSheetAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$json_array	= $insertArray = array();
		$getJobSheetDetails = $getLocationManager = '';
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$formData		= $request->getPost();
			$jobId			= $formData['jobId'];
			if($jobId)
			{
				$where				= " and job_mechanic = 0 and job_id = ".$jobId;
				$getJobSheetDetails	= $this->getTable('JobTable')->getJobDetails($where);
				if(is_object($getJobSheetDetails) && count($getJobSheetDetails) > 0)
				{
					foreach($getJobSheetDetails as $jobKey => $jobValue)
					{
						$json_array['err']		= 0;
						$getLocationManager		= $this->getTable('JobTable')->getuserDetails($identity->location_id,3);
						if(is_object($getLocationManager) && count($getLocationManager) > 0)
						{
							$notificationSubject	= " Job Sheet (".$jobValue['job_number'].") has been assigned for bike number(".$jobValue['job_bike_number'].")";
							foreach($getLocationManager as $locaKey => $locaValue)
							{
								$insertArray[]		= "'".$jobId."','".$identity->user_id."','".$locaValue['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notificationSubject)."',now(),'8'";
							}
							if(is_array($insertArray) && count($insertArray) > 0)
							{
								$insertMultiString	= "(".implode("),(",$insertArray).")";
							}
							if(isset($insertMultiString) && $insertMultiString != '')
							{
								$this->getTable('JobTable')->insertManagerNotification($insertMultiString);
							}
						}
						$updateString			= " job_mechanic = '".$identity->user_id."',job_mechanic_status = 1";
						$this->getTable('JobTable')->updateJobSheet($updateString,$jobId);
					}
				}
				else
				{
					$json_array['err']		= 2;
				}
			}
		}
		echo json_encode($json_array);
		die();
	}
}
