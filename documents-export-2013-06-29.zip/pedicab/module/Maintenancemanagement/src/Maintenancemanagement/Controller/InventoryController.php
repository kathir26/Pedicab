<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Maintenancemanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Maintenancemanagement\Form\AddPartsForm,
	Maintenancemanagement\Form\PartsFilterForm,
	Maintenancemanagement\Form\PartsPurchaseFilterForm,
	Maintenancemanagement\Form\AddPartsPurchaseForm,
	Maintenancemanagement\Form\PartsRequestFilterForm;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter,
	Maintenancemanagement\Model\Parts,
	Maintenancemanagement\Model\PartsPurchase;

class InventoryController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("UsersTable" => "Users-Table", "PartsTable" => "Parts-Table", "PartsPurchaseTable" => "Parts-Purchase-Table", "JobTable" => "Job-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Add Part
	*	Detail	:	Used to add the Parts
	*/
	public function addPartAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addPartsForm 			=  new AddPartsForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		
		if ($request->isPost()) {
            $partsModel			=  new Parts();
//            $addPartsForm->setInputFilter($partsModel->getInputFilter());
			$postData			=  $request->getPost()->toArray();
        	$Files    			= $this->params()->fromFiles();
			
			//	Get Adapter
			$sm 				=  $this->getServiceLocator();
            $this->dbAdapter 	=  $sm->get('db-adapter');
			
//            $addPartsForm->setData($postData);
			
            if (is_array($postData)) {	//	$addPartsForm->isValid()
				$formData		 = $postData;
				$excludeClause	 = 'parts_isdelete = 0 AND location_id = '.$identity->location_id;
				//	Check that the Parts name already exists in the database
				$validator = new RecordExists(
				    array(
				        'table' 	=> 'parts',
				        'field' 	=> 'parts_name',
						'adapter'	=> $this->dbAdapter,
						'message'	=> 'Part Name already exist',
						'exclude'	=> $excludeClause
				    )
				);
				
				if ($validator->isValid($formData['parts_name'])) {
					$errorMessages	= $validator->getMessages();
					$message		= 'Part Name already exist';
					$errorMessage	= '1';
				} else {
					// My File uplaod plugins
					$partsImageFlag				=  '';
					$myFileUpload   			=   $this->MyFileUpload();
					$myFileUpload->fileTypes	=	$this->imageTypes;
					$myFileUpload->fileSizes	=	$this->imageSizes;
					
					// Validations for Parts image
					$fileNameArray				=	array("parts_image");
					$partsImageFlag				=   $myFileUpload->checkUploadFiles($fileNameArray);
					$location_id				=   $this->pcUser->location_id;
					
					if(!$partsImageFlag) {
						$datetime				=   $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate			=   $datetime(time(), 0, 'Y-m-d H:i:s');
						$parts_image			= '';
						
						$partsArray 				  = array(
							'parts_id'			  	  => '',
							'parts_name'			  => $formData['parts_name'],
				            'parts_jb'			  	  => $formData['parts_jb'],
							'parts_qbp'			  	  => $formData['parts_qbp'],
				            'parts_min_quantity'	  => $formData['parts_in_stock'],
							//'parts_max_quantity' 	  => $formData['parts_max_quantity'],
							'parts_in_stock'		  => $formData['parts_on_hand'],
							//'parts_to_order'	      => $formData['parts_to_order'],
							'parts_description'	      => $formData['parts_description'],
							'parts_image'	          => $parts_image,
							'parts_status'			  => $formData['parts_status'],
							'parts_created_date'	  => $createdDate,
							'parts_updated_date'	  => $createdDate,
				            'parts_isdelete' 		  => 0,
							'location_id' 			  => $location_id,
				        );
						
						$partsId  					  =  $this->getTable("PartsTable")->saveParts($partsArray);						//	Insert the parts details
						
						// Upload the files
						$fileNameArray				  =	 array("parts_image");
						$myFileUpload->uploadPath	  =  $this->siteImageUploadPath."/parts_image";
						$partsImage			  	      =  $myFileUpload->uploadFiles($partsId, $fileNameArray);
						
						$partsImageArray 			  = array(
							'parts_id'			  	  => $partsId,
							'parts_image'	  		  => $partsImage
				        );
						$partsId  					  =  $this->getTable("PartsTable")->savePartsImages($partsImageArray);				 //	Insert the parts Image details
						
						$message	= 'Parts added successfully.';
						return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-listing'));
					} else {
//						 die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
					}
				}
			} else {
				$errorMessages	= $addPartsForm->getMessages();
			}
        } else {
				$message		= 'Parts Name already exist.';
		}
		
		//$addPartsForm->get('location_id')->setValueOptions('');		//	Todo : Assign the users location id
		
		return new ViewModel(array(
			'page' 				 => 1,
			'userObject'		 => $identity,
			'addPartsForm'	 	 => $addPartsForm,
			'message'			 => $message,
			'pc_users'			 => $this->pcUser,
		));
    }
	
	/*	Action	: 	Ajax Add Part, Ajax action
	*	Detail	:	Used to Validate the Part name already exist or Available, via Ajax
	*/
	public function ajaxAddPartAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$addPartsForm 			=  new AddPartsForm();
	 	$request 				= $this->getRequest();
		$message				= '';
		
		if($request->isPost()) {
			$partsModel			=  new Parts();
//            $addPartsForm->setInputFilter($partsModel->getInputFilter());
			$postData			=  $request->getPost()->toArray();
        	$Files    			= $this->params()->fromFiles();
			
			//	Get Adapter
			$sm 				=  $this->getServiceLocator();
            $this->dbAdapter 	=  $sm->get('db-adapter');
			
			// RETURN VALUE
			$arrayToJs 	  	 	=  array('0' => array('0' => 'parts_name'));
//			$addPartsForm->setData($postData);
            if (is_array($postData)) {	//	$addPartsForm->isValid()
				$formData		 = $postData;
				
				//Check that the Parts name already exists in the database
				if(isset($postData['parts_id']) && !empty($postData['parts_id'])) {
					$excludeClause		= " parts_id != '".addslashes($postData['parts_id'])."' AND parts_isdelete = 0 AND location_id = ".$identity->location_id;
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'parts',
					        'field' 	=> 'parts_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Part Name already exist',
							'exclude'   => $excludeClause,
					    )
					);
				} else {
					$excludeClause		= 'parts_isdelete = 0 AND location_id = '.$identity->location_id;
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'parts',
					        'field' 	=> 'parts_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Part Name already exist',
							'exclude'   => $excludeClause,
					    )
					);
				}
				// Validation block for Parts name already exist conditions
				if ($validator->isValid($formData['parts_name'])) {
					//	Send error message.
					$arrayToJs[0][1] 	= false;
					$arrayToJs[0][2] 	= "Part Name already exist";
				} else {
					$arrayToJs[0][1] 	= true;
					$arrayToJs[0][2] 	= "Part Name validation success";
				}
				
			} else {
					$arrayToJs[0][1] 	= false;
					$arrayToJs[0][2] 	= "Part Name already exist";
			}
			echo json_encode($arrayToJs);
		}
		return $this->getResponse();
	}
	
	/*	Action	: 	Edit Parts
	*	Detail	:	Used to Edit the Parts details
	*	TODO	:	Mail sending is inprocess
	*/
	public function editPartAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$editPartsForm 				=  new AddPartsForm();
	 	$request 					=  $this->getRequest();
		$message					=  '';
		$partId 					= (int) $this->params()->fromRoute('id', 0);
		$partsDetails				= '';
		
		if ($partId) {
			if ($request->isPost()) {
	            $partsModel			=  new Parts();
//	            editPartsForm->setInputFilter($partsModel->getInputFilter());
				$postData			=  $request->getPost()->toArray();
	        	$Files    			=  $this->params()->fromFiles();
				
				//	Get Adapter
				$sm 				=  $this->getServiceLocator();
	            $this->dbAdapter 	=  $sm->get('db-adapter');
//	            $editPartsForm->setData($postData);
	            if (is_array($postData)) {	//	$editPartsForm->isValid() 
					$formData		 = $postData;
					$excludeClause		= " parts_id != '".addslashes($postData['parts_id'])."' AND parts_isdelete = 0 AND location_id = ".$identity->location_id;
					//	Check that the email address exists in the database
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'parts',
					        'field' 	=> 'parts_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Part Name already exist',
							'exclude'   => $excludeClause
					    )
					);
					
					if ($validator->isValid($formData['parts_name'])) {
						$errorMessages	= $validator->getMessages();
						$message		= 'Part Name already exist';
						$errorMessage	= '1';
					} else {
						// fileExtensionFalse, fileSizeTooBig
						$partsImages				=  '';
						
						// Flag assignment for edit modes.
						$partsImageFlag				=   ($formData['parts_image_hidden'] != $formData['parts_image_fakefilepc']) ? true : false;
						
						// My File uplaod plugins
						$myFileUpload   			=   $this->MyFileUpload();
						$myFileUpload->fileTypes	=	$this->imageTypes;
						$myFileUpload->fileSizes	=	$this->imageSizes;
						
						// Validations for parts image
						if($partsImageFlag) {
							$fileNameArray			=	array("parts_image");
							$partsImages			=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						
						if(!$partsImages) {
							$datetime				=   $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
							$createdDate			=   $datetime(time(), 0, 'Y-m-d H:i:s');
							$parts_image			=  '';
							$partsId  				=  $formData['parts_id'];
							$location_id			=   $this->pcUser->location_id;
							
							if($partsImageFlag) {
								$fileNameArray		=  array("parts_image");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/parts_image";
								if(isset($formData['parts_image_hidden']) && $formData['parts_image_hidden'] != '') {
									$unlinkFile		=  $this->siteImageUploadPath."/parts_image/".$formData['parts_image_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$parts_image		=  $myFileUpload->uploadFiles($partsId, $fileNameArray);
							}
							
							$partsArray 				  = array(
								'parts_id'			  	  => $partsId,
								'parts_name'			  => $formData['parts_name'],
					            'parts_jb'			  	  => $formData['parts_jb'],
								'parts_qbp'			  	  => $formData['parts_qbp'],
					            'parts_min_quantity'	  => $formData['parts_in_stock'],
								//'parts_max_quantity' 	  => $formData['parts_max_quantity'],
								'parts_in_stock'		  => $formData['parts_on_hand'],
								//'parts_to_order'	      => $formData['parts_to_order'],
								'parts_description'	      => $formData['parts_description'],
								'parts_status'			  => $formData['parts_status'],
								'parts_updated_date'	  => $createdDate,
					            'parts_isdelete' 		  => 0,
								'location_id' 			  => $location_id,
					        );
							
							if($partsImageFlag) {
								$partsArray['parts_image'] = $parts_image;
							}
							$this->getTable("PartsTable")->saveParts($partsArray);											//	Update the parts details
							
							$message	= 'Parts updated successfully.';
							
							return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-listing'));
						} else {
							 //die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
						}
					}
				} else {
					$errorMessages	= $editPartsForm->getMessages();
				}
	        } else {
					$message		= 'Parts name already exist.';
			}
			
			$partsResult		= $this->getTable("PartsTable")->getPartsDetails($partId);
			if($partsResult && $partsResult->count()) {
				foreach($partsResult as $value) {
					$partsDetails	= $value;
				}
				
				$editPartsForm->get('parts_id')->setValue($partsDetails->parts_id);
				$editPartsForm->get('parts_name')->setValue($partsDetails->parts_name);
				$editPartsForm->get('parts_jb')->setValue($partsDetails->parts_jb);
				$editPartsForm->get('parts_qbp')->setValue($partsDetails->parts_qbp);
				//$editPartsForm->get('parts_min_quantity')->setValue($partsDetails->parts_min_quantity);
				//$editPartsForm->get('parts_max_quantity')->setValue($partsDetails->parts_max_quantity);
				$editPartsForm->get('parts_on_hand')->setValue($partsDetails->parts_in_stock);
				$editPartsForm->get('parts_in_stock')->setValue($partsDetails->parts_min_quantity);
				//$editPartsForm->get('parts_to_order')->setValue($partsDetails->parts_to_order);
				$editPartsForm->get('parts_description')->setValue($partsDetails->parts_description);
				$editPartsForm->get('parts_status')->setValue($partsDetails->parts_status);
				
				// Images
				$editPartsForm->get('parts_image')->setValue($partsDetails->parts_image);
				
				return new ViewModel(array(
					'page' 				 	=> 1,
					'userObject'		 	=> $identity,
					'editPartsForm'	 	 	=> $editPartsForm,
					'message'			 	=> $message,
					'partsDetails'		 	=> $partsDetails,
					'pc_users'			 	=> $this->pcUser,
					'sitePath'	 			=> $this->sitePath,
					'siteImagePath'	 		=> $this->siteImagePath,
					'siteImageUploadPath'	=> $this->siteImageUploadPath,
				));
				
			} else {
				return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-listing'));
			}
		} else {
			return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-listing'));
		}
    }
	
	/*	Action	: 	parts listing
	*	Detail	:	Used to List the parts details
	*/
	public function partsListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		
		// Create Filter form
		$partsFilterForm = new PartsFilterForm();
		
		//	Destroy listing Session Vars
		$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('partsListing'));
		$partsListingSession = new Container('partsListing');
		
		if ($request->isPost()) {
			$partsFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_parts_name']) && !empty($formData['search_parts_name']))
				$partsListingSession->parts_name	= $formData['search_parts_name'];
			else
				$partsListingSession->parts_name	= '';
			
			if(isset($formData['search_parts_jbno']) && $formData['search_parts_jbno'] != '')
				$partsListingSession->parts_jbno	= $formData['search_parts_jbno'];
			else
				$partsListingSession->parts_jbno	= '';
		}
		
		if($partsListingSession->offsetExists('parts_name') && $partsListingSession->parts_name != '' ) {
			$partsFilterForm->get('search_parts_name')->setValue($partsListingSession->parts_name);
		}
		if($partsListingSession->offsetExists('parts_jbno') && $partsListingSession->parts_jbno != '' ) {
			$partsFilterForm->get('search_parts_jbno')->setValue($partsListingSession->parts_jbno);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsTable')->getPartsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		return new ViewModel(array(
			'userObject'	=> $identity,
			'partsFilterForm' => $partsFilterForm,
			'pc_users'		=> $this->pcUser,
			'message'		=> $message,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'activeArrray'	=> $this->activeArrray,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Parts list, Ajax action
	*	Detail	:	Used to list the parts details via Ajax
	*/
	public function partsListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$partsListingSession = new Container('partsListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($partsListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$partsListingSession->sortBy	= $sortBy;
		} else if($partsListingSession->offsetExists('sortBy')) {
			$sortBy	= $partsListingSession->sortBy;
		}
		if($sortType != '') {
			if($partsListingSession->sortType == $sortType && $columnFlag == 1)
				$partsListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$partsListingSession->sortType	= $sortType;
		} else if($partsListingSession->offsetExists('sortType')) {
			$sortType	= $partsListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$partsListingSession->perPage	= $perPage;
		} else if($partsListingSession->offsetExists('perPage')) {
			$perPage		= $partsListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsTable')->getPartsList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$result->setVariables(array(
			'message'		=> $message,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'activeArrray'	=> $this->activeArrray,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Part
	*	Detail	:	Used to View the Parts details, selected parts
	*/
	public function viewPartAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$partId 		= (int) $this->params()->fromRoute('id', 0);
		$usersDetail	= '';
		
		if ($partId) {
			$partsResult		= $this->getTable("PartsTable")->getPartsDetails($partId);
			foreach($partsResult as $value) {
				$partsDetails	= $value;
			}
		}
		
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'activeArrray'	 		=> $this->activeArrray,
				'partsDetails'	 		=> $partsDetails,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Delete Parts, Ajax action
	*	Detail	:	Used to Delete the Parts details
	*/
	public function deletePartsAction()
    {
		$partId = (int) $this->params()->fromRoute('id', 0);
        if ($partId) {
			$this->getTable("PartsTable")->deleteParts($partId);
		}
        return $this->getResponse();
    }
	
	/*	Action	:   Parts Purchase listing
	*	Detail	:	Used to List the Parts Purchase details
	*/
	public function partsPurchaseListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		$parts_ids_array = $parts_ids_implode = $purchase_parts_detail = '';
		$parts_edit_array = array();
		// Create Filter form
		$purchaseFilterForm 	= new PartsPurchaseFilterForm();
		$fkpartsId 	 = $this->params()->fromRoute('id', '');
		//	Destroy listing Session Vars
		if(isset($fkpartsId) && $fkpartsId == '')
		{
			$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('partsPurchaseListing'));
		}
		else
		{
			$page	 = 1;
		}
		$purchaseListingSession = new Container('partsPurchaseListing');
		
		if ($request->isPost()) {
			$purchaseFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_parts_name']) && !empty($formData['search_parts_name']))
				$purchaseListingSession->parts_name	= $formData['search_parts_name'];
			else
				$purchaseListingSession->parts_name	= '';
			
			if(isset($formData['search_purchase_date']) && $formData['search_purchase_date'] != '')
				$purchaseListingSession->purchase_date	= $formData['search_purchase_date'];
			else
				$purchaseListingSession->purchase_date	= '';
		}
		
		if($purchaseListingSession->offsetExists('parts_name') && $purchaseListingSession->parts_name != '' ) {
			$purchaseFilterForm->get('search_parts_name')->setValue($purchaseListingSession->parts_name);
		}
		if($purchaseListingSession->offsetExists('purchase_date') && $purchaseListingSession->purchase_date != '' ) {
			$purchaseFilterForm->get('search_purchase_date')->setValue($purchaseListingSession->purchase_date);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsPurchaseTable')->getPartsPurchaseList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$parts_ids_Session 		= new Container('partsPurchaseIds');
		$where_part				= " and parts.parts_isdelete = 0 and (purchase.purchase_isdelete =0 || purchase.fk_parts_id IS NULL) and location_id = '".$identity->location_id."'";
		$purchase_parts_detail	= $this->getTable('PartsPurchaseTable')->getAllPartsPurchaseDetails($where_part);
		if(is_object($purchase_parts_detail) && count($purchase_parts_detail) > 0)
		{
			$el = 0;
			foreach($purchase_parts_detail as $part_key => $part_value)
			{
				if(isset($fkpartsId) && $fkpartsId == $part_value['parts_id'] && $fkpartsId > 0)
				{
					if($el == 0)
					{
						$parts_edit_array[]	= $part_value;
						$el++;
					}
				}
				else
				{
					$parts_ids_array[]	= $part_value['parts_id'];
				}
			}
			if(is_array($parts_ids_array) && count($parts_ids_array) > 0)
			{
				$parts_ids_implode	= implode(",",$parts_ids_array);
			}
		}
		$parts_ids_Session->parts_id_exclude	= $parts_ids_implode;
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'purchaseFilterForm' 	=> $purchaseFilterForm,
			'pc_users'				=> $this->pcUser,
			'message'				=> $message,
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'parts_edit_array'		=> $parts_edit_array,
			'activeArrray'			=> $this->activeArrray,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Parts Purchase list, Ajax action
	*	Detail	:	Used to list the Parts Purchase details via Ajax
	*/
	public function partsPurchaseListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$purchaseListingSession = new Container('partsPurchaseListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($purchaseListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$purchaseListingSession->sortBy	= $sortBy;
		} else if($purchaseListingSession->offsetExists('sortBy')) {
			$sortBy	= $purchaseListingSession->sortBy;
		}
		if($sortType != '') {
			if($purchaseListingSession->sortType == $sortType && $columnFlag == 1)
				$purchaseListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$purchaseListingSession->sortType	= $sortType;
		} else if($purchaseListingSession->offsetExists('sortType')) {
			$sortType	= $purchaseListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$purchaseListingSession->perPage	= $perPage;
		} else if($purchaseListingSession->offsetExists('perPage')) {
			$perPage		= $purchaseListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsPurchaseTable')->getPartsPurchaseList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'message'		=> $message,
			'datetime'		=> $datetime,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'activeArrray'	=> $this->activeArrray,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View Parts Purchase
	*	Detail	:	Used to View the Parts Purchase details, selected parts Purchase
	*/
	public function viewPartsPurchaseAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$purchaseId 	 = (int) $this->params()->fromRoute('id', 0);
		$purchaseDetails = '';
		if ($purchaseId) {
			$purchaseResult		= $this->getTable("PartsPurchaseTable")->getPartsPurchaseDetails($purchaseId);
			foreach($purchaseResult as $purchase) {
				$purchaseDetails	= $purchase;
			}
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'activeArrray'	 		=> $this->activeArrray,
				'datetime'	 			=> $datetime,
				'purchaseDetails'	 	=> $purchaseDetails,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Delete Parts Purchase, Ajax action
	*	Detail	:	Used to Delete the Parts Purchase details
	*/
	public function deletePartsPurchaseAction()
    {
		$purchaseId = (int) $this->params()->fromRoute('id', 0);
		
        if ($purchaseId) {
			$this->getTable("PartsPurchaseTable")->deletePurchase($purchaseId);
		}
        return $this->getResponse();
    }
	public function getPartsDetailsAction()
    {
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		$locationId	  =  $pcUser->location_id;
		$request 	  =  $this->getRequest();
		$get_search_text = $get_parts_details = $curr_array_diff = $implode_parts_ids = $where_new = $parts_ids_exl = $new_ids = '';
		$current_array = $parts_id_array = array();
		$json_array = array();
		if($request->isPost())
		{
			$form_data			= $request->getPost();
			$get_search_text	= $form_data['search'];
			if(isset($get_search_text) && $get_search_text != '')
			{
				if(isset($form_data['curr']) && $form_data['curr'] != '')
				{
					$current_array[]	= $form_data['curr'];
				}
				if(is_array($form_data['parts_id']) && count($form_data['parts_id']) > 0)
				{
					$parts_id_array		= $form_data['parts_id'];
					$curr_array_diff	= array_diff($parts_id_array,$current_array);
				}
				$parts_ids_Session 		= new Container('partsPurchaseIds');
				if(isset($parts_ids_Session->parts_id_exclude) && $parts_ids_Session->parts_id_exclude != '')
				{
					//$parts_ids_exl			= $parts_ids_Session->parts_id_exclude;
				}
				if(is_array($curr_array_diff) && count($curr_array_diff) > 0)
				{
					$implode_parts_ids	= implode(",",$curr_array_diff);
					$implode_parts_ids	= rtrim(trim($implode_parts_ids),",");
				}
				if(isset($parts_ids_exl) && $parts_ids_exl != '')
				{
					$new_ids		.= $parts_ids_exl;
				}
				if(isset($implode_parts_ids) && $implode_parts_ids != '')
				{
					if(isset($new_ids) && $new_ids != '')
					{
						$new_ids	.= ','.$implode_parts_ids;
					}
					else
					{
						$new_ids	.= $implode_parts_ids;
					}
				}
				if(isset($new_ids) && $new_ids != '')
				{
					$where_new		= " and parts_id not in (".$new_ids.")";
				}
				$where					= " and parts_name like '".addslashes($get_search_text)."%' and parts_isdelete = 0 and location_id = '".addslashes($locationId)."'".$where_new;
				$get_parts_details		= $this->getTable('PartsTable')->getPartsDetailsSearch($where);
				if(is_object($get_parts_details) && count($get_parts_details) > 0)
				{
					$e = 0;
					foreach($get_parts_details as $parts_key => $parts_value)
					{
						$json_array[$e]['id']		= $parts_value->parts_id;
						$json_array[$e]['name']		= $parts_value->parts_name;
						$json_array[$e]['job']		= $parts_value->parts_jb;
						$json_array[$e]['qbp']		= $parts_value->parts_qbp;
						$e++;
					}
				}
			}
		}
		echo json_encode($json_array);
		die();
    }
	public function saveMultiplePurchaseAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$parts_id_array = $get_parts_purchase = '';
		$parts_new_id 	= $insertArray = array();
		$request 	  	= $this->getRequest();
		if($request->isPost())
		{
			$form_data			= $request->getPost();
			$parts_id_array		= $form_data['parts_id'];
			$parts_id_array		= array_filter($parts_id_array,'strlen');// To remove the null values in array
			$parts_id_count		= count($parts_id_array);
			$parts_name_count	= count($form_data['part_name']);
			if(is_array($parts_id_array) && count($parts_id_array) > 0)
			{
				$parts_ids_implode	= implode(",",$parts_id_array);
				$where				= " and fk_parts_id in (".$parts_ids_implode.")";
				$get_parts_purchase = $this->getTable("PartsPurchaseTable")->checkPartsPurchaseDetails($where);
				if(is_object($get_parts_purchase) && count($get_parts_purchase) > 0)
				{
					foreach($get_parts_purchase as $parts_key => $parts_value)
					{
						$parts_new_id[$parts_value->fk_parts_id]	= $parts_value->parts_purchase_id;
					}
				}
				$parts_id_count		= count($parts_new_id);
			}
			for($e = 0; $e < $parts_name_count; $e++)
			{
				$purchase_id = $update_string = $insert_string = $date_purchase = '';
				$new_stock	= 0;
				if(isset($form_data['purchase_date'][$e]) && $form_data['purchase_date'][$e] != '')
				{
					$sess_open_date		= explode('-',$form_data['purchase_date'][$e]);
					if(is_array($sess_open_date) && count($sess_open_date) > 0)
					{
						$date_purchase	= $sess_open_date[2]."-".$sess_open_date[0]."-".$sess_open_date[1];
					}
				}
				if(isset($form_data['purchase_id'][$e]) && $form_data['purchase_id'][$e] != '')
				{
					//if(isset($parts_new_id[$parts_id_array[$e]]) && $parts_new_id[$parts_id_array[$e]] != '')
					{
						$purchase_id	= $form_data['purchase_id'][$e];
						$new_stock_up	= $form_data['quantity'][$e] - $form_data['quantity_old'][$e];
						$update_string	= " fk_parts_id = '".addslashes($parts_id_array[$e])."', purchase_updated_date = now(), purchase_date = '".addslashes($date_purchase)."', purchase_quantity = '".addslashes($form_data['quantity'][$e])."'";
						$this->getTable("PartsPurchaseTable")->updatePartsPurchase($update_string,$purchase_id);
						$this->getTable("PartsPurchaseTable")->updatePartsStock("parts_in_stock = parts_in_stock + ".$new_stock_up,$parts_id_array[$e]);
					}
				}
				else
				{
					//$insert_string	= " fk_parts_id = '".addslashes($parts_id_array[$e])."', fk_location_id = '".$identity->location_id."', fk_user_id = '".$identity->user_id."', purchase_created_date = mow(), purchase_date = '".addslashes($date_purchase)."', purchase_quantity = '".addslashes($form_data['quantity'][$e])."',purchase_isdelete = 0";
					$insertArray[]		= " '".addslashes($parts_id_array[$e])."', '".$identity->location_id."', '".$identity->user_id."', now(), '".addslashes($date_purchase)."', '".addslashes($form_data['quantity'][$e])."', 0";
					$new_stock_up	= $form_data['quantity'][$e];
					//$this->getTable("PartsPurchaseTable")->insertPartsPurchase($insert_string);
					$this->getTable("PartsPurchaseTable")->updatePartsStock("parts_in_stock = parts_in_stock + ".$new_stock_up,$parts_id_array[$e]);
				}
			}
			if(is_array($insertArray) && count($insertArray) > 0)
			{
				$insertString			= "(".implode("),(",$insertArray).")";
				$this->getTable("PartsPurchaseTable")->insertMultiPartsPurchase($insertString);
			}
			return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-purchase-listing','id' => 0));
		}
	}
	public function getPartsPurchaseAction()
    {
		$get_purchase_details = '';
		$parts_array_details = array();
		$request 	  	=  $this->getRequest();
		if($request->isPost())
		{
			$matches	= $this->getEvent()->getRouteMatch();
			$editId		= $matches->getParam('editId', '');
			if($editId != '')
			{
				$get_purchase_details	= $this->getTable("PartsPurchaseTable")->getPartsPurchaseDetails($editId);
				if(is_object($get_purchase_details) && count($get_purchase_details) > 0)
				{
					foreach($get_purchase_details as $pur_key => $pur_value)
					{
						$parts_array_details['parts_id']	= $pur_value->parts_id;
						$parts_array_details['pur_id']		= $pur_value->parts_purchase_id;
						$parts_array_details['name']		= $pur_value->parts_name;
						$parts_array_details['job']			= $pur_value->parts_jb;
						$parts_array_details['qbp']			= $pur_value->parts_qbp;
						$parts_array_details['date']		= $this->getCommonDataObj()->removeZerosInDate($pur_value->purchase_date);
						$parts_array_details['qty']			= $pur_value->purchase_quantity;
					}
				}
			}
		}
		echo json_encode($parts_array_details);
		die();
	}
	public function partsRequestAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		// Create Filter form
		$purchaseFilterForm 	= new PartsRequestFilterForm();
		//	Destroy listing Session Vars
		$status	 				=  $this->getCommonDataObj()->destroySessionVariables(array('partsPurchaseRequestListing'));
		
		$purchaseListingSession = new Container('partsPurchaseRequestListing');
		
		if ($request->isPost()) {
			$purchaseFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_parts_name']) && !empty($formData['search_parts_name']))
				$purchaseListingSession->parts_name	= $formData['search_parts_name'];
			else
				$purchaseListingSession->parts_name	= '';
			
			if(isset($formData['search_purchase_date']) && $formData['search_purchase_date'] != '')
				$purchaseListingSession->purchase_date	= $formData['search_purchase_date'];
			else
				$purchaseListingSession->purchase_date	= '';
		}
		
		if($purchaseListingSession->offsetExists('parts_name') && $purchaseListingSession->parts_name != '' ) {
			$purchaseFilterForm->get('search_parts_name')->setValue($purchaseListingSession->parts_name);
		}
		if($purchaseListingSession->offsetExists('purchase_date') && $purchaseListingSession->purchase_date != '' ) {
			$purchaseFilterForm->get('search_purchase_date')->setValue($purchaseListingSession->purchase_date);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsPurchaseTable')->getPartsRequestList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'RequestFilterForm' 	=> $purchaseFilterForm,
			'pc_users'				=> $this->pcUser,
			'datetime'				=> $datetime,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax Parts Purchase list, Ajax action
	*	Detail	:	Used to list the Parts Purchase details via Ajax
	*/
	public function partsRequestListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$purchaseListingSession = new Container('partsPurchaseRequestListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($purchaseListingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$purchaseListingSession->sortBy	= $sortBy;
		} else if($purchaseListingSession->offsetExists('sortBy')) {
			$sortBy	= $purchaseListingSession->sortBy;
		}
		if($sortType != '') {
			if($purchaseListingSession->sortType == $sortType && $columnFlag == 1)
				$purchaseListingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$purchaseListingSession->sortType	= $sortType;
		} else if($purchaseListingSession->offsetExists('sortType')) {
			$sortType	= $purchaseListingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$purchaseListingSession->perPage	= $perPage;
		} else if($purchaseListingSession->offsetExists('perPage')) {
			$perPage		= $purchaseListingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('PartsPurchaseTable')->getPartsRequestList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'datetime'		=> $datetime,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function saveRequestPartsAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$partsIdArray 				= $insertArray = $partsNameArray = array();
		$partsIdCount				= $partsNameCount = 0;
		$createText					= $updateText = $partIdsImplode = $getPartsDetails = $notificationSubject = $notifyDate = '';
		if($request->isPost())
		{
			$formData				= $request->getPost();
			$partsIdArray			= $formData['parts_id'];
			$partsIdArray			= array_filter($partsIdArray,'strlen'); // To remove the null values in array
			$partsIdCount			= count($partsIdArray);
			$partsNameCount			= count($formData['part_name']);
			$partIdsImplode			= implode(",",$formData['parts_id']);
			if(isset($partIdsImplode) && $partIdsImplode != '')
			{
				$where				= " and parts_isdelete = 0 and  parts_id in (".$partIdsImplode.")";
				$getPartsDetails	= $this->getTable("PartsTable")->getPartsDetailsAll($where);
				if(is_object($getPartsDetails) && count($getPartsDetails) > 0)
				{
					foreach($getPartsDetails as $partsKey => $partsValue)
					{
						$partsNameArray[$partsValue['parts_id']]	= $partsValue['parts_name']."(".$partsValue['parts_jb'].")"." = ";
					}
				}
			}
			for($e = 0; $e < $partsNameCount; $e++)
			{
				$purchaseId			= $updateString = $insertString = $datePurchase = $sessOpenDate = '';
				if(isset($formData['purchase_date'][$e]) && $formData['purchase_date'][$e] != '')
				{
					$sessOpenDate		= explode('-',$formData['purchase_date'][$e]);
					if(is_array($sessOpenDate) && count($sessOpenDate) > 0)
					{
						$datePurchase	= $sessOpenDate[2]."-".$sessOpenDate[0]."-".$sessOpenDate[1];
					}
				}
				if(isset($formData['purchase_id'][$e]) && $formData['purchase_id'][$e] != '')
				{
					if(isset($updateText) && $updateText == '')
					{
						$updateText		= 'Parts Request has been updated for<br>';
					}
					$updateText			.= $partsNameArray[$partsIdArray[$e]].' '.$formData['quantity'][$e].'<br>';
					$notifyDate			.= $partsNameArray[$partsIdArray[$e]].' '.$formData['quantity'][$e].'<br>';
					$purchaseId			= $formData['purchase_id'][$e];
					$updateString		= " fk_parts_id = '".addslashes($partsIdArray[$e])."', purchase_date = '".addslashes($datePurchase)."', purchase_quantity = '".addslashes($formData['quantity'][$e])."'";
					//$this->getTable("PartsPurchaseTable")->updatePartsRequest($updateString,$purchaseId);
				}
				else
				{
					if(isset($createText) && $createText == '')
					{
						$createText		= 'Parts Request has been created for<br>';
					}
					$createText			.= $partsNameArray[$partsIdArray[$e]].' '.$formData['quantity'][$e].'<br>';
					$notifyDate			.= $partsNameArray[$partsIdArray[$e]].' '.$formData['quantity'][$e].'<br>';
					$insertArray[]		= "'".addslashes($partsIdArray[$e])."', '".$identity->location_id."', '".$identity->user_id."', '".addslashes($datePurchase)."', '".addslashes($formData['quantity'][$e])."', 0, now()";
				}
			}
			$notificationSubject		= $updateText.$createText;
			$roleId						= '3'; //Manager
			$getUserDetails 			= $this->getTable("JobTable")->getuserDetails($identity->location_id,$roleId);
			if(is_object($getUserDetails) && count($getUserDetails) > 0)
			{
				foreach($getUserDetails as $userKey => $userValue)
				{
					$notificationArray[]	= "'".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notificationSubject)."','".addslashes($notifyDate)."','12'";
				}
			}
			if(is_array($notificationArray) && count($notificationArray) > 0)
			{
				$notificationInsert			= "(".implode("),(",$notificationArray).")";
				$this->getTable("PartsPurchaseTable")->insertManagerNotification($notificationInsert);
			}
			echo "<strong style='color:green;'><br>File : ".__FILE__."<br>Line No : ".__LINE__."<br><pre>=====notificationArray=><br>";print_r($notificationArray);echo "</pre></strong>";die();
			echo "<strong style='color:green;'><br>File : ".__FILE__."<br>Line No : ".__LINE__."===createText===><br>".$createText."</strong>";
			echo "<strong style='color:green;'><br>File : ".__FILE__."<br>Line No : ".__LINE__."====updateText==><br>".$updateText."</strong>";die();
			if(is_array($insertArray) && count($insertArray) > 0)
			{
				$insertString			= "(".implode("),(",$insertArray).")";
				//$this->getTable("PartsPurchaseTable")->insertMutliPartsRequest($insertString);
			}
			//return $this->redirect()->toRoute('maintenancemanagement', array('controller' => 'inventory', 'action' => 'parts-request','id' => 0));
		}
	}
	public function getPartsRequestAction()
    {
		$get_purchase_details = '';
		$parts_array_details = array();
		$request 	  	=  $this->getRequest();
		if($request->isPost())
		{
			$matches	= $this->getEvent()->getRouteMatch();
			$editId		= $matches->getParam('id', '');
			if($editId != '')
			{
				$get_purchase_details	= $this->getTable("PartsPurchaseTable")->getPartsRequestDetails($editId);
				if(is_object($get_purchase_details) && count($get_purchase_details) > 0)
				{
					foreach($get_purchase_details as $pur_key => $pur_value)
					{
						$parts_array_details['parts_id']	= $pur_value->parts_id;
						$parts_array_details['pur_id']		= $pur_value->parts_request_id;
						$parts_array_details['name']		= $pur_value->parts_name;
						$parts_array_details['job']			= $pur_value->parts_jb;
						$parts_array_details['qbp']			= $pur_value->parts_qbp;
						$parts_array_details['date']		= $this->getCommonDataObj()->removeZerosInDate($pur_value->request_date);
						$parts_array_details['qty']			= $pur_value->request_quantity;
					}
				}
			}
		}
		echo json_encode($parts_array_details);
		die();
	}
	public function viewPartsRequestAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$purchaseId 	 = (int) $this->params()->fromRoute('id', 0);
		$purchaseDetails = '';
		if ($purchaseId) {
			$purchaseResult		= $this->getTable("PartsPurchaseTable")->getPartsRequestDetails($purchaseId);
			foreach($purchaseResult as $purchase) {
				$purchaseDetails	= $purchase;
			}
		}
		
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'activeArrray'	 		=> $this->activeArrray,
				'datetime'	 			=> $datetime,
				'purchaseDetails'	 	=> $purchaseDetails,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function deletePartsRequestAction()
    {
		$purchaseId = (int) $this->params()->fromRoute('id', 0);
		
        if ($purchaseId) {
			$this->getTable("PartsPurchaseTable")->deletePartsRequest($purchaseId);
		}
        return $this->getResponse();
    }
}
