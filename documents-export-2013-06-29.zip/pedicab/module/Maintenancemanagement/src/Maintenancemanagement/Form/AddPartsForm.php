<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class AddPartsForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_parts_form');
		$this->setAttribute('id', 'pc_add_parts_form');
		
		$this->add(array(
            'name' => 'parts_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'parts_id'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'parts_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'parts_name',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '1',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Part Name is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_jb',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'parts_jb',
				'class'								=> 'wid131',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '2',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'J&B Part# is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_qbp',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_qbp',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '3',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Other/QBP Part # is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_min_quantity',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_min_quantity',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '4',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Min quantity is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Min quantity value',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_max_quantity',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_max_quantity',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '5',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Max quantity is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Max quantity value',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_on_hand',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_on_hand',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '4',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Number on hand is required!',
				'data-errormessage' 			 	=> 'Please enter a valid quantity value',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_in_stock',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_in_stock',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '6',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Number we should have in stock is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Parts In-Stock value',
            )
        ));
		
		$this->add(array(
            'name' => 'parts_to_order',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'parts_to_order',
				'class'								=> 'wid131',
                'value' 							=> '',
				'tabindex'							=> '7',
				'data-validation-engine' 			=> 'validate[required,custom[integer]]',
				'data-errormessage-value-missing' 	=> 'Parts to Order is required!',
				'data-errormessage' 			 	=> 'Please enter a valid Parts to Order value',
            )
        ));
		
		$this->add(array(
            'name'		 => 'parts_description',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'parts_description',
				'class'								=> '',
				'tabindex'							=> '8',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Description is required!',
            )
        ));
		
		$this->add(array(
            'name' 		 => 'parts_image',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'parts_image',
				'class'								=> 'filepc',
				'size'								=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '9',
				'data-validation-engine' 			=> 'validate[required,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Parts Image is required!',
				//'data-errormessage' 			 	=> 'Profile Image is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'parts_status',
            'options'   => array(
                'value_options' => array(
                    '1' => 'Active',
                    '0' => 'InActive',
                ),
            ),
            'attributes' => array(
				'id'    	=> 'parts_status',
				'tabindex'	=> '10',
                'value' 	=> '1', 		//set checked to '1'
				'style' 	=> '',
				'class' 	=> ''
            )
        ));
		
        $this->add(array(
            'name' 		=> 'part_save',
            'attributes'=> array(
				'id'		=> 'part_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'tabindex'	=> '11',
				'class'		=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'part_reset',
            'attributes' => array(
				'id'		=> 'part_reset',
                'type'  	=> 'reset',
                'value' 	=> 'Reset',
				'tabindex'	=> '12',
				'class'		=> '',
            ),
        ));
    }
}
?>