<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class MechanicJobFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'pc_mechanic_filter_form');
		$this->setAttribute('name', 'pc_mechanic_filter_form');
		
		$this->add(array(
            'name' 		 => 'search_job_sheet',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_job_sheet',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Job Sheet #',
				'class' 							=> 'wid140',
            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'name' => 'search_bike_number',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_bike_number',
				'class'								=> 'wid140',
				'PlaceHolder'						=> 'Bike Number'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_job_submit',
            'attributes' => array(
                'type'  => 'submit',
				'id'    => 'search_job_submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_job_reset',
            'attributes' => array(
                'type'  => 'reset',
				'id'    => 'search_job_reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>