<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class MechanicRequestFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'pc_mechanic_filter_form');
		$this->setAttribute('name', 'pc_mechanic_filter_form');
		
		$this->add(array(
            'name' 		 => 'search_job_sheet',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_job_sheet',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Job Sheet #',
				'class' 							=> 'wid140',
            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'name' => 'search_job_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_job_date',
				'class'								=> 'calc-txbox',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
            )
        ));
		
        $this->add(array(
            'name' => 'search_job_submit',
            'attributes' => array(
                'type'  => 'submit',
				'id'    => 'search_job_submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_job_reset',
            'attributes' => array(
                'type'  => 'reset',
				'id'    => 'search_job_reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>