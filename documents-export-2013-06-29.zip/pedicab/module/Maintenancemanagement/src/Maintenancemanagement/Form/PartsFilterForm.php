<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class PartsFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'parts_filter_form');
		$this->setAttribute('name', 'parts_filter_form');
		
		$this->add(array(
            'name' 		 => 'search_parts_name',
            'attributes' => array(
				                'type'  							=> 'text',
								'id'								=> 'search_parts_name',
								'autofocus'							=> '',
								'PlaceHolder' 						=> 'Part Name',
								'class' 							=> 'wid240',
//								'data-validation-engine' 			=> 'validate[required]',
								'data-errormessage-value-missing' 	=> 'Parts name is required!',
				            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'name' 		 => 'search_parts_jbno',
            'attributes' => array(
				                'type'  							=> 'text',
								'id'								=> 'search_parts_jbno',
								'autofocus'							=> '',
								'PlaceHolder' 						=> 'J&B Part #',
								'class' 							=> 'wid140',
//								'data-validation-engine' 			=> 'validate[required]',
								'data-errormessage-value-missing' 	=> 'J&B Part No is required!',
				            ),
            'options' => array(),
        ));
		
        $this->add(array(
            'name' => 'search_parts_submit',
            'attributes' => array(
                'type'  => 'submit',
				'id'    => 'search_parts_submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_parts_reset',
            'attributes' => array(
                'type'  => 'reset',
				'id'    => 'search_parts_reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>