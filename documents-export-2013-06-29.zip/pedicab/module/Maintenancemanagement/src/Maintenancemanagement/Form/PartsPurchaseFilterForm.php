<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class PartsPurchaseFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'parts_purchase_filter_form');
		$this->setAttribute('name', 'parts_purchase_filter_form');
		
		$this->add(array(
            'name' 		 => 'search_parts_name',
            'attributes' => array(
				                'type'  							=> 'text',
								'id'								=> 'search_parts_name',
								'autofocus'							=> '',
								'PlaceHolder' 						=> 'Part Name',
								'class' 							=> 'wid240',
//								'data-validation-engine' 			=> 'validate[required]',
								'data-errormessage-value-missing' 	=> 'Parts name is required!',
				            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'name' => 'search_purchase_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'search_purchase_date',
				'class'								=> 'wid140 calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Purchase Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Purchase Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_purchase_submit',
            'attributes' => array(
                'type'  => 'submit',
				'id'    => 'search_purchase_submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_purchase_reset',
            'attributes' => array(
                'type'  => 'reset',
				'id'    => 'search_purchase_reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>