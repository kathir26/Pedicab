<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class AddPartsPurchaseForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_parts_purchase_form');
		$this->setAttribute('id', 'pc_add_parts_purchase_form');
		
		$this->add(array(
            'name' => 'parts_purchase_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'parts_purchase_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'fk_parts_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'fk_parts_id'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'purchase_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'purchase_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Purchase Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'purchase_quantity',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'purchase_quantity',
				'class'								=> 'wid81',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'tabindex'							=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Quantity purchased is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'part_purchase_save',
            'attributes'=> array(
				'id'		=> 'part_purchase_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'tabindex'	=> '',
				'class'		=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'part_purchase_add_more',
            'attributes' => array(
				'id'		=> 'part_purchase_add_more',
                'type'  	=> 'button',
                'value' 	=> 'Add',
				'tabindex'	=> '',
				'class'		=> '',
            ),
        ));
    }
}
?>