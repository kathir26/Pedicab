<?php
namespace Maintenancemanagement\Form;

use Zend\Form\Form;

class AddJobForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_job_form');
		$this->setAttribute('id', 'pc_add_job_form');
		
		$this->add(array(
            'name' => 'job_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'job_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'job_back',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'job_back'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'job_status',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'job_status'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'job_number',
            'attributes' => array(
				'type' 								=> 'hidden',
				'id'  								=> 'job_number',
            )
        ));
		
		$this->add(array(
            'name' => 'job_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'job_date',
				'class'								=> 'wid131 tabindex',//calc-txbox datepicker
				'autofocus'							=> '',
				'readonly'							=> 'readonly',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',//,custom[date]
				'data-errormessage-value-missing' 	=> 'Date is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_bike',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'job_bike',
				'class'								=> 'wid131 tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Bike Number is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_bike_id',
            'attributes' => array(
				'type' 								=> 'hidden',
				'id'  								=> 'job_bike_id',
            )
        ));
		
		$this->add(array(
            'name' => 'job_issue',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'job_issue',
				'class'								=> ' tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Issue is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_additional_desc',
            'attributes' => array(
				'type' 								=> 'textarea',
				'id'  								=> 'job_additional_desc',
				'class'								=> 'tabindex',
                'value' 							=> '',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'job_repair_urgency',
            'options'   => array(
                'value_options' => array(
                    
                ),
            ),
            'attributes' => array(
				'id'    							=> 'job_repair_urgency',
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Repair urgency is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'job_request_by',
            'options'   => array(
                'value_options' => array(
                   
                ),
            ),
            'attributes' => array(
				'id'    							=> 'job_request_by',
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Request by is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_request_id',
            'attributes' => array(
				'type' 								=> 'hidden',
				'id'  								=> 'job_request_id',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'job_mechanic',
            'options'   => array(
                'value_options' => array(
                    
                ),
            ),
            'attributes' => array(
				'id'    							=> 'job_mechanic',
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Mechanic is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_est_time',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'job_est_time',
				'class'								=> 'clock-txbox datepicker tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[required]',//,custom[time]
				'data-errormessage-value-missing' 	=> 'Estimated Time is required!',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'job_used_parts',
            'options'   => array(
                'value_options' => array(
                    
                ),
            ),
            'attributes' => array(
				'id'    							=> 'job_used_parts',
				'style' 							=> '',
				'multiple'							=> 'multiple',
				'data-placeholder'					=> 'Choose a parts',
				'class' 							=> 'parts-chosen tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Parts is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'job_description',
            'attributes' => array(
				'type' 								=> 'textarea',
				'id'  								=> 'job_description',
				'class'								=> 'tabindex',
                'value' 							=> '',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'job_bike_status',
            'options'   => array(
                'value_options' => array(
					
                ),
            ),
            'attributes' => array(
				'id'    							=> 'job_bike_status',
				'value'								=> 0,
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Status is required!',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'job_save',
            'attributes'=> array(
				'id'		=> 'job_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'class'		=> 'tabindex',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'job_reset',
            'attributes' => array(
				'id'		=> 'job_reset',
                'type'  	=> 'reset',
                'value' 	=> 'Reset',
				'class'		=> 'tabindex',
            ),
        ));
    }
}
?>