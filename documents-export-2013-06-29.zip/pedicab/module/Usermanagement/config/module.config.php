<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Usermanagement\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'usermanagement' => array(
                'type'    => 'Segment',
                'options' => array(
                    //'route'    => '/usermanagement[/:action][/:id]',
					'route'    => '/usermanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
                         	//'route'     => '/usermanagement[/:action[/:id]]',
							'route'    	  => '/usermanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'role-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/role-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'    => 'Role',
                        'action'        => 'role-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'role-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/role-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'   => 'Role',
                        'action'       => 'role-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'user-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/user-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'    => 'User',
                        'action'        => 'user-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'user-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/user-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'   => 'User',
                        'action'       => 'user-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-location-list' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-location-list[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'    => 'Location',
                        'action'        => 'manage-location-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
						'sortType' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-location-listcount' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-location-listcount[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' => 'Usermanagement\Controller',
                        'controller'   => 'Location',
                        'action'       => 'manage-location-list',
						'perPage' 	   => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'Usermanagement\Controller\Index' 		=> 'Usermanagement\Controller\IndexController',
			'Usermanagement\Controller\User'  		=> 'Usermanagement\Controller\UserController',
			'Usermanagement\Controller\Role' 		=> 'Usermanagement\Controller\RoleController',
			'Usermanagement\Controller\Location' 	=> 'Usermanagement\Controller\LocationController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
			'sendMail'   => 'Usermanagement\View\Helper\SendMail',
			'minifyHelper' => 'Usermanagement\View\Helper\MinifyHelper',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../view/layout/layout.phtml',
            'usermanagement/index/index' => __DIR__ . '/../view/usermanagement/index/index.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
