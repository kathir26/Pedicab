<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

class AclresourcesTable extends AbstractTableGateway
{
    protected $table  = 'acl_resources';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
    }
	
    public function getAllAclResources() {
		// SELECT distinct LOWER(controller_name) as controller, module_name, action_name FROM acl_resources
		$result  = $this->select(function (Select $select) {
						$select->where(array('status' => 1))
				         	   ->order('sort_order ASC');
							// echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		/*$count 	 = $result->count();
		$toArray = $result->toArray();
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==count==>".$count;
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==toArray==><pre>"; print_r($toArray); echo "</pre><==";
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getDataSource==><pre>"; print_r($result->getDataSource()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getFieldCount==><pre>"; print_r($result->getFieldCount()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==next==><pre>"; print_r($result->next()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==key==><pre>"; print_r($result->key()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==current==><pre>"; print_r($result->current()); echo "</pre><==";
		*/
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
    public function deleteUser($id)
    {
       //  $this->delete(array('user_id' => $id));
    }
	
	public function sampleFetchAll() {
        /*
		$resultSet = $this->select(function (Select $select) {
	                    $select->order('sort_order ASC')
						 	   ->limit(5)
						 	   ->offset(1);
						echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
	                 });
		*/
		$id = '';
		$result  = $this->select(function (Select $select) use ($id) {
				        $select->order('sort_order ASC')
						 	   ->limit(5)
						 	   ->offset(1);
						// echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		return $result;
		/*
		$result  = $this->select(function (Select $select) use ($id){
				        $select->where(array('album_id'=>$id));
				        $select->join('album', 'tracks.album_id = album.id');
				     });
        return $result;
		*/
		/*
		$sql 	    = "SELECT * FROM acl_resources";
		$statement = $this->adapter->query($sql);
		$results   = $statement->execute();
		//echo "<br/>==Line==".__LINE__."==File==".__FILE__."====><pre>"; print_r($results); echo "</pre><==";
		return $results;
		*/
    }
	
}	//  AclresourcesTable class