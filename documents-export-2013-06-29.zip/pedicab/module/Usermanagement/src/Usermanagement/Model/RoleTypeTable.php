<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

class RoleTypeTable extends AbstractTableGateway
{
    protected $table = 'role_type_privileges';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 				= $adapter;
        /*$this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new RoleType());
        $this->initialize();*/
    }
	
    public function getRolePrivileges($role_type_id) {
		$result  = $this->select(function (Select $select) use ($role_type_id){
						$select->where(array('role_type_id' => $role_type_id))
				         	   ->order('resource_id ASC');
//							 echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
    public function getUser($id)
    {
        $id  	= (int) $id;
        $rowset = $this->select(array('role_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	/*
	*	Save the Role Privileges details
	*/
    public function saveRolePrivileges($roleId, $rolePrivileges)
    {
		$sql	   = '';
		foreach($rolePrivileges as $key => $resource_id) {
			$sql  .= "(NULL, '".$roleId."', '".$resource_id."'), ";
			/*
			// It's commented to avoid the loop iterations.
			$data  =  array('role_type_privileges_id'	=> '', 'role_type_id'	=> $roleId, 'resource_id'=> $resource_id);
      		$this->insert($data);
			*/
		}
		if($sql) {
			if(!empty($sql)) $sql =	substr($sql, 0, -2);
			$sqlInsert 	   = "Insert into role_type_privileges (`role_type_privileges_id`, `role_type_id`, `resource_id`) VALUES ".$sql;
			$statement = $this->adapter->query($sqlInsert);
			$results   = $statement->execute();
			return $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		}
    }
	
	/*
	*	Save the Role Privileges details
	*/
    public function deleteRolePrivileges($roleId, $rolePrivileges)
    {
		$sql	   = implode(",", $rolePrivileges);
		$deleteSql = "Delete from role_type_privileges where role_type_id = '".$roleId."' and resource_id in (".$sql.")";
		$statement = $this->adapter->query($deleteSql);
		$results   = $statement->execute();
    }
}