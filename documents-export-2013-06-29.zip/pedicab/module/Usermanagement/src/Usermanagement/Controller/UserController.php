<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

//	Forms
use Usermanagement\Form\AddUserForm,
	Usermanagement\Form\EditUserForm,
	Usermanagement\Form\UserFilterForm;

//	Models
use Usermanagement\Model\Users,
	Usermanagement\Model\Role,
	Usermanagement\Model\Aclresources,
	Usermanagement\Model\MyAuthenticationAdapter;

use Zend\Validator\File\Size;

class UserController extends AbstractActionController
{
	protected $roleTable;
	protected $roleTypeTable;
	protected $usersTable;
	protected $driverInfoTable;
	protected $aclresourcesTable;
	protected $locationTable;
	protected $pcUser;
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $hirearcheArray;
	protected $commonData;
	
	public function __construct()
    {
        // Image and file
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;	//	10
		$this->perPageArray			=  array('5', '10', '25', '50', '100');			//	array('1', '2', '3', '4', '5', '6');
		$this->hirearcheArray		= array(1, 2, 6);
		
		//	Session for users
		$userSession 		=   new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	=   $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("roleTable" => "Role-Table", "roleTypeTable" => "Role-Type-Table", "usersTable" => "Users-Table", "driverInfoTable" => "Driver-Info-Table", "aclresourcesTable" => "Aclresources-Table", "locationTable" => "Location-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Default Redirections
	*	Detail	:	To redirect the users on their default landing pages
	*/
	private function defaultRedirect()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		if($identity && $identity->user_role_id == 1) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'driver-dashboard');
		} else if($identity && $identity->user_role_id == 2) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'mechanic-dashboard');
		} else if($identity && $identity->user_role_id == 6) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'client-dashboard');
		} else {
			$params		= array('module' => 'usermanagement', 'controller' => 'user', 'action' => 'dashboard');
		}
		return $this->redirect()->toRoute($params['module'], array('controller' => $params['controller'], 'action' => $params['action']));
    }
	
	/*	Action	: 	Reset the Identities
	*	Detail	:	To Reset the Existing Identities
	*/
	private function resetIdentity()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		if($identity && $identity->user_role_id == 1) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'driver-dashboard');
		} else if($identity && $identity->user_role_id == 2) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'mechanic-dashboard');
		} else if($identity && $identity->user_role_id == 6) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'client-dashboard');
		} else {
			$params		= array('module' => 'usermanagement', 'controller' => 'user', 'action' => 'dashboard');
		}
		return $this->redirect()->toRoute($params['module'], array('controller' => $params['controller'], 'action' => $params['action']));
    }
	
	/*	Action	: 	dashboard
	*	Detail	:	Location managers and Gm Dashboard
	*   TODO	:   Later we need to design the Dashboard
	*/
	public function dashboardAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
	}
	
	/*	Action	: 	Index
	*	Detail	:	Used to load the default page for this controller
	*/
	public function indexAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		//return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
		return $this->defaultRedirect();
	}
	
	/*	Action	: 	Add Users
	*	Detail	:	Used to add the New users.
	*	TODO	:	Mail sending is inprocess
	*/
	public function addUserAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addUserForm 			=  new AddUserForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		
		if ($request->isPost()) {
            $userModel			= new Users();
            $addUserForm->setInputFilter($userModel->getInputFilterForAddUser());
			$postData			= $request->getPost()->toArray();
        	$Files    			= $this->params()->fromFiles();
			
			//	Get Adapter
			$sm 				= $this->getServiceLocator();
            $this->dbAdapter 	= $sm->get('db-adapter');
			
            $addUserForm->setData($postData);
			
            if (is_array($postData)) {	//	$addUserForm->isValid()
				$formData		 = $postData;
				//	Check that the email address exists in the database
				$excludeClause  = " user_isdelete = 0";
				$validator = new RecordExists(
				    array(
				        'table' 	=> 'user',
				        'field' 	=> 'user_email',
						'adapter'	=> $this->dbAdapter,
						'message'	=> 'User Email is already exist',
						'exclude'	=> $excludeClause
				    )
				);
				
				if ($validator->isValid($formData['user_email'])) {
					$errorMessages	= $validator->getMessages();
					$message		= 'User Email is already exist';
					$errorMessage	= '1';
				} else {
					$driverFlag					=	($formData['user_role_id'] && !empty($formData['user_role_id']) && $formData['user_role_id'] == 1) ? true : false;
					$userDriversLicense			=	$userProfileImage		=	$userContract		=	'';
					
					// My File uplaod plugins
					$myFileUpload   			=   $this->MyFileUpload();
					$myFileUpload->fileTypes	=	$this->imageTypes;
					$myFileUpload->fileSizes	=	$this->imageSizes;
					
					// Validations for User driving license
					if($driverFlag) {
						if(isset($formData['user_drivers_license_fakefilepc']) && !empty($formData['user_drivers_license_fakefilepc'])) {
							$fileNameArray		=	array("user_drivers_license");
							$userDriversLicense	=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
					}
					// Validations for User profile image
					if(isset($formData['user_profile_image_fakefilepc']) && !empty($formData['user_profile_image_fakefilepc'])) {
						$fileNameArray			=	array("user_profile_image");
						$userProfileImage		=   $myFileUpload->checkUploadFiles($fileNameArray);
					}
					
					// Validations for User contract
					$myFileUpload->fileTypes	=	$this->fileTypes;
					$myFileUpload->fileSizes	=	$this->fileSizes;
					if(isset($formData['user_contract_fakefilepc']) && !empty($formData['user_contract_fakefilepc'])) {
						$fileNameArray			=	array("user_contract");
						$userContract			=   $myFileUpload->checkUploadFiles($fileNameArray);
					}
					
					if(($driverFlag && !$userDriversLicense && !$userProfileImage && !$userContract) || (!$driverFlag && !$userProfileImage && !$userContract)) {
						$datetime				=   $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate			=   $datetime(time(), 0, 'Y-m-d H:i:s');
						if(strpos($formData['user_leasecontract_date'], '-') !== false ) {
							$formData['user_leasecontract_date']	=  str_replace('-', '/', $formData['user_leasecontract_date']);
							$user_leasecontract_date  =  $datetime->getDates(strtotime($formData['user_leasecontract_date']), 0, 'Y-m-d H:i:s');
						} else {
							$user_leasecontract_date  =  '0000-00-00 00:00:00';
						}
						
						$user_profile_image			  = '';
						$user_contract				  = '';
						
						$userArray 					  = array(
							'user_id'			  	  => '',
							'user_role_id'			  => $formData['user_role_id'],
				            'user_email'			  => $formData['user_email'],
							'user_password'			  => $formData['user_password'],
				            'user_firstname'		  => $formData['user_firstname'],
							'user_lastname' 		  => $formData['user_lastname'],
							'user_gender'			  => $formData['user_gender'],
							'user_telephone_number'	  => $formData['user_telephone_number'],
							'user_mailing_address'	  => $formData['user_mailing_address'],
							'user_text_address'		  => $formData['user_text_address'],
							'user_profile_image'	  => $user_profile_image,
							'user_contract'			  => $user_contract,
							'user_status'			  => $formData['user_status'],
							'user_updateddate'		  => $createdDate,
							'user_createddate'		  => $createdDate,
				            'user_leasecontract_date' => $user_leasecontract_date,
							'location_id' 			  => $formData['location_id'],
				        );
						
						$userId  					  =  $this->getTable("usersTable")->saveUser($userArray);											//	Insert the User
						if(strpos($formData['user_training_date'], '-') !== false ) {
							$formData['user_training_date']	 =  str_replace('-', '/', $formData['user_training_date']);
							$user_training_date		  =  $datetime->getDates(strtotime($formData['user_training_date']), 0, 'Y-m-d H:i:s');
						} else {
							$user_training_date		  =  '0000-00-00 00:00:00';
						}
						
						$user_drivers_license		  = '';
						$userDriversLicenseImage	  =  (isset($formData['user_drivers_license_fakefilepc']) && !empty($formData['user_drivers_license_fakefilepc'])) ? true : false;
						if($driverFlag && $userDriversLicenseImage) {
							$fileNameArray			  =	 array("user_drivers_license");
							$myFileUpload->uploadPath =  $this->siteImageUploadPath."/driver_license";
							$user_drivers_license  	  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							
							$driverInfoArray			  = array(
								'user_id'				  => $userId,
					            'user_training_date'	  => $user_training_date,
								'user_drivers_license'	  => $user_drivers_license,
								'user_citylicense_permit' => $formData['user_citylicense_permit'],
					        );
							$userStatus  			  =  $this->getTable("driverInfoTable")->saveDriverInfo($driverInfoArray);						//	Insert the Drivers Info
						}
						
						$userProfileImageImage	  	  =  (isset($formData['user_profile_image_fakefilepc']) && !empty($formData['user_profile_image_fakefilepc'])) ? true : false;
						$userContractImage	  		  =  (isset($formData['user_contract_fakefilepc']) && !empty($formData['user_contract_fakefilepc'])) ? true : false;
						
						if($userProfileImageImage || $userContractImage) {
							
							if($userProfileImageImage) {
								$fileNameArray			  =	 array("user_profile_image");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/profile_image";
								$user_profile_image		  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							
							if($userContractImage) {
								$fileNameArray			  =	 array("user_contract");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/contract_image";
								$user_contract			  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							
							$userImageArray 			  = array(
								'user_id'			  	  => $userId,
								'user_profile_image'	  => $user_profile_image,
								'user_contract'			  => $user_contract
					        );
							$userId  					  =  $this->getTable("usersTable")->saveImages($userImageArray);											//	Insert the User
						}
						
						// Get the Role details
						$allRoleSession 		= new Container('allRole');
						$role					= (isset($allRoleSession->allRoles[$formData['user_role_id']])) ? $allRoleSession->allRoles[$formData['user_role_id']] : '';
						
						// User Registration mail sending	:	Start
						$mail_title				= 'Hello '.strtolower(ucFirst($formData['user_firstname'])).' '.$formData['user_lastname'];
						$mail_descriptions		= 'Registration is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
						
						$mailArray			    =  array(
							'subject'		  	=> 'Registration mail',
				            'from_email'	  	=> '',
							'from_name' 	  	=> '',
							'to_email' 	  	  	=> $formData['user_email'],
							'mail_title' 	  	=> $mail_title,
							'mail_descriptions' => $mail_descriptions,
							'mail_preview' 		=> 0,			//	1 - Preview the Email, 0 - Send the Email
				        );
						
						$contentData			=  array(
							'Email'		  		=> $formData['user_email'],
							'Password'		  	=> $formData['user_password'],
							'First Name'		=> ucfirst($formData['user_firstname']),
							'Last Name'		  	=> $formData['user_lastname'],
							'Role'		  		=> $role
				        );
						
						$this->getCommonDataObj()->siteMailSending($contentData, $mailArray);
						// User Registration mail sending	:	End
						
						$message = 'User added successfully.';
						$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('allUserCountByRole', 'allClients'));
						return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
					} else {
						// die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
					}
				}
			} else {
				$errorMessages	= $addUserForm->getMessages();
			}
        } else {
				$message		= 'User Email is already exist.';
		}
		// Get the All roles
		$allRoleSession 		= new Container('allRole');
		$allRoles				= array();
		if($allRoleSession->offsetExists('allRoles') && $allRoleSession->allRoles != '' ) {
			$allRoles			= $allRoleSession->allRoles;
		} else {
			$allRoles			= array(''  => 'Select Role');
			$roles				= $this->getTable('roleTable')->getAllRoles();
			if($roles) {
				foreach($roles as $role) {
					$allRoles[$role->role_id]  =  $role->role_name;
				}
			}
			$allRoleSession->allRoles  		   =  $allRoles;
		}
		// Condition handling for Location Managers and Owners Logins
		$allRolesOption	 	= array();
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
			foreach($allRoles as $roleId => $roleName) {
				if($roleId == '' || (in_array($roleId, $this->hirearcheArray))) {
					$allRolesOption[$roleId] = $roleName;
				}
			}
		} else {
			$allRolesOption	= $allRoles;
		}
		$addUserForm->get('user_role_id')->setValueOptions($allRolesOption);
		
		// Get the All Locations
		$allLocationSession 	= new Container('allLocations');
		$allLocations			= array();
		if($allLocationSession->offsetExists('locations') && $allLocationSession->locations != '' ) {
			$allLocations		= $allLocationSession->locations;
		} else {
			$allLocations		= array(''  => 'Select Location');
			$locations			= $this->getTable('locationTable')->getAllLocationDetails();
			if($locations) {
				foreach($locations as $location) {
					$allLocations[$location->loc_id]  =  $location->loc_title;
				}
			}
			$allLocationSession->locations  =  $allLocations;
		}
		
		/*$addUserForm->get('location_id')->setValueOptions($allLocations);
		if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
			$addUserForm->get('location_id')->setValue($this->pcUser->location_id);
		}*/
		$addUserForm->get('location_id')->setValue($this->pcUser->location_id);
		// Get All Email to Text Message Addresses By Carrier 
		$allTextAddressesSession 	= new Container('allTextAddresses');
		$allTextAddresses			= array();
		if($allTextAddressesSession->offsetExists('textAddresses') && $allTextAddressesSession->textAddresses != '' ) {
			$allTextAddresses		= $allTextAddressesSession->textAddresses;
		} else {
			$textAddressResults		=  $this->getTable('usersTable')->getAllTextAddresses();
			if($textAddressResults && $textAddressResults->count()) {
				$textAddressResult	=  $textAddressResults->toArray();
				foreach($textAddressResult as $textAddress) {
					$allTextAddresses[$textAddress["text_addresses_id"]]  =  $textAddress;
				}
			}
			$allTextAddressesSession->textAddresses  =  $allTextAddresses;
		}
		
		return new ViewModel(array(
			'page' 				 => 1,
			'userObject'		 => $identity,
			'addUserForm'	 	 => $addUserForm,
			'message'			 => $message,
			'allTextAddresses'	 => $allTextAddresses,
			'pc_users'			 => $this->pcUser,
		));
    }
	
	/*	Action	: 	Ajax Add User, Ajax action
	*	Detail	:	Used to Validate the User Email is already exist or Available, via Ajax
	*/
	public function ajaxAddUserAction()
	{
		$addUserForm 			=  new AddUserForm();
	 	$request 				= $this->getRequest();
		$message				= '';
		
		if($request->isPost()) {
			$userModel			=  new Users();
            $addUserForm->setInputFilter($userModel->getInputFilterForAddUser());
			$postData			=  $request->getPost()->toArray();
        	$Files    			= $this->params()->fromFiles();
			
			//	Get Adapter
			$sm 				=  $this->getServiceLocator();
            $this->dbAdapter 	=  $sm->get('db-adapter');
			
			// RETURN VALUE
			$arrayToJs 	  	 	=  array('0' => array('0' => 'user_email'));
			$addUserForm->setData($postData);
            if (is_array($postData)) {	//	$addUserForm->isValid()
				$formData		 = $postData;
				//Check that the email address exists in the database
				if(isset($postData['user_id']) && !empty($postData['user_id'])) {
					$excludeClause  = " user_id != '".addslashes($postData['user_id'])."' AND user_isdelete = 0";
					$validator 		= new RecordExists(
					    array(
					        'table' 	=> 'user',
					        'field' 	=> 'user_email',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'User Email is already exist',
							'exclude'   => $excludeClause
					    )
					);
				} else {
					$excludeClause  = " user_isdelete = 0";
					$validator 		= new RecordExists(
					    array(
					        'table' 	=> 'user',
					        'field' 	=> 'user_email',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'User Email is already exist',
							'exclude'   => $excludeClause
					    )
					);
				}
				// Validation block for Email already exist conditions
				if ($validator->isValid($formData['user_email'])) {
					//	Send error message.
					$arrayToJs[0][1] 	= false;
					$arrayToJs[0][2] 	= "User Email is already exist";
				} else {
					$arrayToJs[0][1] 	= true;
					//$arrayToJs[0][2] 	= "User Email validation success";
				}
				
			} else {
					$arrayToJs[0][1] 	= false;
					$arrayToJs[0][2] 	= "User Email is already exist";
			}
			echo json_encode($arrayToJs);
		}
		return $this->getResponse();
	}
	
	/*	Action	: 	Edit User
	*	Detail	:	Used to Edit the Users details
	*	TODO	:	Mail sending is inprocess
	*/
	public function editUserAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$editUserForm 				=  new EditUserForm();
	 	$request 					=  $this->getRequest();
		$message					=  '';
		if(isset($this->pcUser->user_role_id) && ($this->pcUser->user_role_id == 1 || $this->pcUser->user_role_id == 2)) {
			$userId 				= $this->pcUser->user_id;
		} else {
			$userId 				= (int) $this->params()->fromRoute('id', 0);
		}
		$usersDetail				= '';
		
		if ($userId) {
			if ($request->isPost()) {
	            $userModel			=  new Users();
	            $editUserForm->setInputFilter($userModel->getInputFilterForAddUser());
				$postData			=  $request->getPost()->toArray();
	        	$Files    			=  $this->params()->fromFiles();
				
				//	Get Adapter
				$sm 				=  $this->getServiceLocator();
	            $this->dbAdapter 	=  $sm->get('db-adapter');
	            $editUserForm->setData($postData);
	            if (is_array($postData)) {	//	$editUserForm->isValid() 
					$formData		 = $postData;
					$excludeClause   = " user_id != '".addslashes($formData['user_id'])."' AND user_isdelete = 0";
					//	Check that the email address exists in the database
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'user',
					        'field' 	=> 'user_email',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'User Email is already exist',
							'exclude'   => $excludeClause
					    )
					);
					
					if ($validator->isValid($formData['user_email'])) {
						$errorMessages	= $validator->getMessages();
						$message		= 'User Email is already exist';
						$errorMessage	= '1';
					} else {
						
						// Condition handling for Drivers And Mechanic
						if(isset($this->pcUser->user_role_id) && ($this->pcUser->user_role_id == 1 || $this->pcUser->user_role_id == 2)) {
						  $formData['user_role_id'] =   $formData['user_role_id_hidden'];
						}
						
						$driverFlag					=	(isset($formData['user_role_id']) && !empty($formData['user_role_id']) && $formData['user_role_id'] == 1) ? true : false;
						$userDriversLicense			=	$userProfileImage		=	$userContract		=	'';
						
						// Flag assignment for edit modes.
						$userDriversLicenseFlag		=   ($formData['user_drivers_license_hidden'] != $formData['user_drivers_license_fakefilepc']) ? true : false;
						$userProfileImageFlag		=   ($formData['user_profile_image_hidden'] != $formData['user_profile_image_fakefilepc']) ? true : false;
						$userContractFlag			=   ($formData['user_contract_hidden'] != $formData['user_contract_fakefilepc']) ? true : false;
						
						// My File uplaod plugins
						$myFileUpload   			=   $this->MyFileUpload();
						$myFileUpload->fileTypes	=	$this->imageTypes;
						$myFileUpload->fileSizes	=	$this->imageSizes;
						
						// Validations for User driving license
						if($driverFlag && $userDriversLicenseFlag) {
							$fileNameArray			=	array("user_drivers_license");
							$userDriversLicense		=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						// Validations for User profile image
						if($userProfileImageFlag) {
							$fileNameArray				=	array("user_profile_image");
							$userProfileImage			=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						// Validations for User contract
						if($userContractFlag) {
							$myFileUpload->fileTypes	=	$this->fileTypes;
							$myFileUpload->fileSizes	=	$this->fileSizes;
							$fileNameArray				=	array("user_contract");
							$userContract				=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						
						if(($driverFlag && !$userDriversLicense && !$userProfileImage && !$userContract) || (!$driverFlag && !$userProfileImage && !$userContract)) {
							$datetime					  =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
							$createdDate				  =  $datetime(time(), 0, 'Y-m-d H:i:s');
							if(strpos($formData['user_leasecontract_date'], '-') !== false ) {
								$formData['user_leasecontract_date']	=  str_replace('-', '/', $formData['user_leasecontract_date']);
								$user_leasecontract_date  =  $datetime->getDates(strtotime($formData['user_leasecontract_date']), 0, 'Y-m-d H:i:s');
							} else {
								$user_leasecontract_date  =  '0000-00-00 00:00:00';
							}
							
							$userId  					  =  $formData['user_id'];
							if($userProfileImageFlag) {
								$fileNameArray			  =	 array("user_profile_image");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/profile_image";
								if(isset($formData['user_profile_image_hidden']) && $formData['user_profile_image_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/profile_image/".$formData['user_profile_image_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_profile_image		  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							if($userContractFlag) {
								$fileNameArray			  =	 array("user_contract");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/contract_image";
								if(isset($formData['user_contract_hidden']) && $formData['user_contract_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/contract_image/".$formData['user_contract_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_contract			  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							
							$userArray 					  = array(
								'user_id'			  	  => $formData['user_id'],
								'user_role_id'			  => $formData['user_role_id'],
					            'user_email'			  => $formData['user_email'],
					            'user_firstname'		  => $formData['user_firstname'],
								'user_lastname' 		  => $formData['user_lastname'],
								'user_gender'			  => $formData['user_gender'],
								'user_telephone_number'	  => $formData['user_telephone_number'],
								'user_mailing_address'	  => $formData['user_mailing_address'],
								'user_text_address'		  => $formData['user_text_address'],
								'user_status'			  => $formData['user_status'],
								'user_updateddate'		  => $createdDate,
					            'user_leasecontract_date' => $user_leasecontract_date,
								'location_id' 			  => $formData['location_id'],
					        );
							
							if($userProfileImageFlag) {
								$userArray['user_profile_image'] =	$user_profile_image;
							}
							
							if($userContractFlag) {
								$userArray['user_contract']		 =	$user_contract;
							}
							
							// Condition handling for Password change
							$mailSendingFlag			    = '';
							if(isset($formData['user_password']) && $formData['user_password'] != '') {
								$userArray['user_password']	=  $formData['user_password'];
								
								// Mail sending for Password change
								$mailSendingFlag			= 1;
							}
							
							// Condition handling for Email change
							if($formData['user_email_hidden'] != $formData['user_email']) {
								// Mail sending for Email change
								$mailSendingFlag			= ($mailSendingFlag != '') ? 3 : 2;
							}
							
							$this->getTable("usersTable")->saveUser($userArray);											//	Update user details
							if(strpos($formData['user_training_date'], '-') !== false ) {
								$formData['user_training_date']	 =  str_replace('-', '/', $formData['user_training_date']);
								$user_training_date		  =  $datetime->getDates(strtotime($formData['user_training_date']), 0, 'Y-m-d H:i:s');
							} else {
								$user_training_date		  =  '0000-00-00 00:00:00';
							}
							
							if($driverFlag && $userDriversLicenseFlag) {
								$fileNameArray			  =	 array("user_drivers_license");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/driver_license";
								if(isset($formData['user_drivers_license_hidden']) && $formData['user_drivers_license_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/driver_license/".$formData['user_drivers_license_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_drivers_license  	  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							
							//	D-D, D-M, M-D
							if( ($formData['user_role_id'] == 1) || ($formData['user_role_id_hidden'] == 1 && $formData['user_role_id'] == $formData['user_role_id_hidden']) ) {
								$driverInfoArray			  =  array(
									'user_id'				  => $formData['user_id'],
						            'user_training_date'	  => $user_training_date,
									'user_citylicense_permit' => $formData['user_citylicense_permit'],
						        );
								
								if($driverFlag && $userDriversLicenseFlag) {
									$driverInfoArray['user_drivers_license'] =	$user_drivers_license;
								}
								
								$userStatus  				  =  $this->getTable("driverInfoTable")->saveDriverInfo($driverInfoArray);						//	Update Drivers Info
							} else if($formData['user_role_id_hidden'] == 1) {
								$userStatus  			  	  =  $this->getTable("driverInfoTable")->deleteDriverInfo($userId);						//	Delete the Drivers Info for Role change
								// Delete the user drivers license
								if(isset($formData['user_drivers_license_hidden']) && $formData['user_drivers_license_hidden'] != '') {
									$unlinkFile			  	  =	 $this->siteImageUploadPath."/driver_license/".$formData['user_drivers_license_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
							}
							
							if($mailSendingFlag) {
								// Password change mail sending	:	Start
								$mail_title				= 'Hello '.strtolower(ucFirst($formData['user_firstname'])).' '.$formData['user_lastname'];
								if($mailSendingFlag == 1) {
									$subject			= "Password change";
									$mail_descriptions	= 'Password change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								} else if($mailSendingFlag == 2) {
									$subject			= "Email change";
									$mail_descriptions	= 'Email change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								} else {
									$subject			= "Email And Password change";
									$mail_descriptions	= 'Email And Password change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								}
								
								$mailArray			    =  array(
									'subject'		  	=> $subject,
						            'from_email'	  	=> '',
									'from_name' 	  	=> '',
									'to_email' 	  	  	=> $formData['user_email'],
									'mail_title' 	  	=> $mail_title,
									'mail_descriptions' => $mail_descriptions,
									'mail_preview' 		=> 0,			//	1 - Preview the Email, 0 - Send the Email
						        );
								
								$allRoleSession 		= new Container('allRole');
								$role					= (isset($allRoleSession->allRoles[$formData['user_role_id']])) ? $allRoleSession->allRoles[$formData['user_role_id']] : '';
								
								$contentData			=  array(
									'Email'		  		=> $formData['user_email'],
									'Password'		  	=> $formData['user_password'],
									'First Name'		=> ucfirst($formData['user_firstname']),
									'Last Name'		  	=> $formData['user_lastname'],
									'Role'		  		=> $role
						        );
								
								$this->getCommonDataObj()->siteMailSending($contentData, $mailArray);
								// Password change mail sending	:	End
							}
							
							$message 	 = 'User upadated successfully.';
							// Delete the Session values
							if((isset($this->pcUser->user_role_id) && ($this->pcUser->user_role_id == 1 || $this->pcUser->user_role_id == 2)) || ($this->pcUser->user_id == $userId)) {
								$status	 = $this->getCommonDataObj()->destroySessionVariables(array('pcUsers', 'allUserCountByRole', 'allClients'));
								$this->getCommonDataObj()->setUsersDetails($this->pcUser->user_id);
							} else {
								$status	 = $this->getCommonDataObj()->destroySessionVariables(array('allUserCountByRole', 'allClients'));
							}
							
							if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 1) {
								return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'driver-dashboard'));
							} else if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 2) {
								return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'mechanic-dashboard'));
							} else {
								return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
							}
						} else {
							 //die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
						}
					}
				} else {
					$errorMessages	= $editUserForm->getMessages();
				}
	        } else {
					$message		= 'User Email is already exist.';
			}
			
			// Get the All roles
			$allRoleSession 		= new Container('allRole');
			$allRoles				= array();
			if($allRoleSession->offsetExists('allRoles') && $allRoleSession->allRoles != '' ) {
				$allRoles			= $allRoleSession->allRoles;
			} else {
				$allRoles			= array(''  => 'Select Role');
				$roles				= $this->getTable('roleTable')->getAllRoles();
				if($roles) {
					foreach($roles as $role) {
						$allRoles[$role->role_id]  =  $role->role_name;
					}
				}
				$allRoleSession->allRoles  		   =  $allRoles;
			}
			
			// Get the All Locations
			$allLocationSession 	= new Container('allLocations');
			$allLocations			= array();
			if($allLocationSession->offsetExists('locations') && $allLocationSession->locations != '' ) {
				$allLocations		= $allLocationSession->locations;
			} else {
				$allLocations		= array(''  => 'Select Location');
				$locations			= $this->getTable('locationTable')->getAllLocationDetails();
				
				if($locations) {
					foreach($locations as $location) {
						$allLocations[$location->loc_id]  =  $location->loc_title;
					}
				}
				$allLocationSession->locations  =  $allLocations;
			}
			
			// Get All Email to Text Message Addresses By Carrier 
			$allTextAddressesSession 	= new Container('allTextAddresses');
			$allTextAddresses			= array();
			if($allTextAddressesSession->offsetExists('textAddresses') && $allTextAddressesSession->textAddresses != '' ) {
				$allTextAddresses		= $allTextAddressesSession->textAddresses;
			} else {
				$textAddressResults		=  $this->getTable('usersTable')->getAllTextAddresses();
				if($textAddressResults && $textAddressResults->count()) {
					$textAddressResult	=  $textAddressResults->toArray();
					foreach($textAddressResult as $textAddress) {
						$allTextAddresses[$textAddress["text_addresses_id"]]  =  $textAddress;
					}
				}
				$allTextAddressesSession->textAddresses  =  $allTextAddresses;
			}
			
			$userDetails		= $this->getTable("usersTable")->getUserDetails($userId);
			if($userDetails) {
				foreach($userDetails as $userDetail) {
					$usersDetail	= $userDetail;
				}
				
				// Condition handling for Location Managers and Owners Logins
				$allRolesOption	 	= array();
				if(isset($this->pcUser->user_role_id) && $this->pcUser->user_role_id == 3) {
					foreach($allRoles as $roleId => $roleName) {
						if($roleId == '' || (in_array($roleId, $this->hirearcheArray))) {
							$allRolesOption[$roleId] = $roleName;
						}
					}
				} else {
					$allRolesOption	= $allRoles;
				}
				
				$editUserForm->get('user_role_id')->setValueOptions($allRolesOption);
				//$editUserForm->get('user_role_id')->setValueOptions($allRoles);
				$editUserForm->get('user_role_id')->setValue($usersDetail['user_role_id']);
				//$editUserForm->get('location_id')->setValueOptions($allLocations);
				$editUserForm->get('location_id')->setValue($usersDetail['location_id']);
				$editUserForm->get('user_id')->setValue($usersDetail['user_id']);
				$editUserForm->get('user_email')->setValue($usersDetail['user_email']);
				$editUserForm->get('user_email_hidden')->setValue($usersDetail['user_email']);
				$editUserForm->get('user_firstname')->setValue($usersDetail['user_firstname']);
				$editUserForm->get('user_lastname')->setValue($usersDetail['user_lastname']);
				$editUserForm->get('user_gender')->setValue($usersDetail['user_gender']);
				$editUserForm->get('user_telephone_number')->setValue($usersDetail['user_telephone_number']);
				$editUserForm->get('user_mailing_address')->setValue($usersDetail['user_mailing_address']);
				$editUserForm->get('user_text_address')->setValue($usersDetail['user_text_address']);
				$editUserForm->get('user_status')->setValue($usersDetail['user_status']);
				$editUserForm->get('user_citylicense_permit')->setValue($usersDetail['user_citylicense_permit']);
				
				// Date
				$datetime				=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
				$userTrainingDate		=  (isset($usersDetail['user_training_date']) && $usersDetail['user_training_date'] != '0000-00-00 00:00:00') ? $datetime->getDates(strtotime($usersDetail['user_training_date']), 0, 'n-j-Y') : '';
				$userLeasecontractDate	=  (isset($usersDetail['user_leasecontract_date']) && $usersDetail['user_leasecontract_date'] != '0000-00-00 00:00:00') ? $datetime->getDates(strtotime($usersDetail['user_leasecontract_date']), 0, 'n-j-Y') : '';
				
				$editUserForm->get('user_training_date')->setValue($userTrainingDate);
				$editUserForm->get('user_leasecontract_date')->setValue($userLeasecontractDate);
				
				// Images
				$editUserForm->get('user_profile_image')->setValue($usersDetail['user_profile_image']);
				$editUserForm->get('user_drivers_license')->setValue($usersDetail['user_drivers_license']);
				$editUserForm->get('user_contract')->setValue($usersDetail['user_contract']);
				
				return new ViewModel(array(
					'page' 				 	=> 1,
					'userObject'		 	=> $identity,
					'editUserForm'	 	 	=> $editUserForm,
					'message'			 	=> $message,
					'usersDetail'		 	=> $usersDetail,
					'allTextAddresses'		=> $allTextAddresses,
					'allRoles'				=> $allRoles,
					'pc_users'			 	=> $this->pcUser,
					'sitePath'	 			=> $this->sitePath,
					'siteImagePath'	 		=> $this->siteImagePath,
					'siteImageUploadPath'	=> $this->siteImageUploadPath,
				));
			} else {
				return $this->defaultRedirect();
			}
		} else {
			//return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
			return $this->defaultRedirect();
		}
    }
	
	/*	Action	: 	Edit Client
	*	Detail	:	Used to Edit the Client Users details
	*	TODO	:	Mail sending is inprocess
	*/
	public function editClientAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$editUserForm 				=  new EditUserForm();
	 	$request 					=  $this->getRequest();
		$message					=  '';
		//$userId 					= (int) $this->params()->fromRoute('id', 0);
		$userId 					= $this->pcUser->user_id;
		$usersDetail				= '';
		
		if ($userId) {
			if ($request->isPost()) {
	            $userModel			=  new Users();
	            $editUserForm->setInputFilter($userModel->getInputFilterForAddUser());
				$postData			=  $request->getPost()->toArray();
	        	$Files    			=  $this->params()->fromFiles();
				
				//	Get Adapter
				$sm 				=  $this->getServiceLocator();
	            $this->dbAdapter 	=  $sm->get('db-adapter');
	            $editUserForm->setData($postData);
	            if (is_array($postData)) {	//	$editUserForm->isValid() 
					$formData		 = $postData;
					$excludeClause   = " user_id != '".addslashes($postData['user_id'])."' AND user_isdelete = 0";
					//	Check that the email address exists in the database
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'user',
					        'field' 	=> 'user_email',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'User Email is already exist',
							'exclude'   => $excludeClause
					    )
					);
					
					if ($validator->isValid($formData['user_email'])) {
						$errorMessages	= $validator->getMessages();
						$message		= 'User Email is already exist';
						$errorMessage	= '1';
					} else {
						/*
						// fileExtensionFalse, fileSizeTooBig
						$driverFlag					=	($formData['user_role_id'] && !empty($formData['user_role_id']) && $formData['user_role_id'] == 1) ? true : false;
						$userDriversLicense			=	$userProfileImage		=	$userContract		=	'';
						
						// Flag assignment for edit modes.
						$userDriversLicenseFlag		=   ($formData['user_drivers_license_hidden'] != $formData['user_drivers_license_fakefilepc']) ? true : false;
						$userProfileImageFlag		=   ($formData['user_profile_image_hidden'] != $formData['user_profile_image_fakefilepc']) ? true : false;
						$userContractFlag			=   ($formData['user_contract_hidden'] != $formData['user_contract_fakefilepc']) ? true : false;
						
						// My File uplaod plugins
						$myFileUpload   			=   $this->MyFileUpload();
						$myFileUpload->fileTypes	=	$this->imageTypes;
						$myFileUpload->fileSizes	=	$this->imageSizes;
						
						// Validations for User driving license
						if($driverFlag && $userDriversLicenseFlag) {
							$fileNameArray			=	array("user_drivers_license");
							$userDriversLicense		=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						// Validations for User profile image
						if($userProfileImageFlag) {
							$fileNameArray				=	array("user_profile_image");
							$userProfileImage			=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						// Validations for User contract
						if($userContractFlag) {
							$myFileUpload->fileTypes	=	$this->fileTypes;
							$myFileUpload->fileSizes	=	$this->fileSizes;
							$fileNameArray				=	array("user_contract");
							$userContract				=   $myFileUpload->checkUploadFiles($fileNameArray);
						}
						
						if(($driverFlag && !$userDriversLicense && !$userProfileImage && !$userContract) || (!$driverFlag && !$userProfileImage && !$userContract)) {
						*/
							$datetime					  =  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
							$createdDate				  =  $datetime(time(), 0, 'Y-m-d H:i:s');
							/*
							if(strpos($formData['user_leasecontract_date'], '-') !== false ) {
								$formData['user_leasecontract_date']	=  str_replace('-', '/', $formData['user_leasecontract_date']);
								$user_leasecontract_date  =  $datetime->getDates(strtotime($formData['user_leasecontract_date']), 0, 'Y-m-d H:i:s');
							} else {
								$user_leasecontract_date  =  '0000-00-00 00:00:00';
							}
							*/
							$userId  					  =  $formData['user_id'];
							/*
							if($userProfileImageFlag) {
								$fileNameArray			  =	 array("user_profile_image");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/profile_image";
								if(isset($formData['user_profile_image_hidden']) && $formData['user_profile_image_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/profile_image/".$formData['user_profile_image_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_profile_image		  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							if($userContractFlag) {
								$fileNameArray			  =	 array("user_contract");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/contract_image";
								if(isset($formData['user_contract_hidden']) && $formData['user_contract_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/contract_image/".$formData['user_contract_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_contract			  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							*/
							$userArray 					  = array(
								'user_id'			  	  => $formData['user_id'],
								//'user_role_id'			  => $formData['user_role_id'],
					            'user_email'			  => $formData['user_email'],
					            'user_firstname'		  => $formData['user_firstname'],
								'user_lastname' 		  => $formData['user_lastname'],
								//'user_gender'			  => $formData['user_gender'],
								'user_telephone_number'	  => $formData['user_telephone_number'],
								'user_mailing_address'	  => $formData['user_mailing_address'],
								//'user_text_address'		  => $formData['user_text_address'],
								//'user_status'			  => $formData['user_status'],
								'user_updateddate'		  => $createdDate,
					            //'user_leasecontract_date' => $user_leasecontract_date,
								//'location_id' 			  => $formData['location_id'],
					        );
							/*
							if($userProfileImageFlag) {
								$userArray['user_profile_image'] =	$user_profile_image;
							}
							
							if($userContractFlag) {
								$userArray['user_contract']		 =	$user_contract;
							}
							*/
							
							// Condition handling for Password change
							$mailSendingFlag			    = '';
							if(isset($formData['user_password']) && $formData['user_password'] != '') {
								$userArray['user_password']	=  $formData['user_password'];
								
								// Mail sending for Password change
								$mailSendingFlag			= 1;
							}
							
							// Condition handling for Email change
							if($formData['user_email_hidden'] != $formData['user_email']) {
								// Mail sending for Email change
								$mailSendingFlag			= ($mailSendingFlag != '') ? 3 : 2;
							}
							
							$this->getTable("usersTable")->saveUserProfile($userArray);											//	Update user details
							/*
							if(strpos($formData['user_training_date'], '-') !== false ) {
								$formData['user_training_date']	 =  str_replace('-', '/', $formData['user_training_date']);
								$user_training_date		  =  $datetime->getDates(strtotime($formData['user_training_date']), 0, 'Y-m-d H:i:s');
							} else {
								$user_training_date		  =  '0000-00-00 00:00:00';
							}
							
							if($driverFlag && $userDriversLicenseFlag) {
								$fileNameArray			  =	 array("user_drivers_license");
								$myFileUpload->uploadPath =  $this->siteImageUploadPath."/driver_license";
								if(isset($formData['user_drivers_license_hidden']) && $formData['user_drivers_license_hidden'] != '') {
									$unlinkFile			  =	 $this->siteImageUploadPath."/driver_license/".$formData['user_drivers_license_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
								$user_drivers_license  	  =  $myFileUpload->uploadFiles($userId, $fileNameArray);
							}
							
							//	D-D, D-M, M-D
							if( ($formData['user_role_id'] == 1) || ($formData['user_role_id_hidden'] == 1 && $formData['user_role_id'] == $formData['user_role_id_hidden']) ) {
								$driverInfoArray			  =  array(
									'user_id'				  => $formData['user_id'],
						            'user_training_date'	  => $user_training_date,
									'user_citylicense_permit' => $formData['user_citylicense_permit'],
						        );
								
								if($driverFlag && $userDriversLicenseFlag) {
									$driverInfoArray['user_drivers_license'] =	$user_drivers_license;
								}
								
								$userStatus  				  =  $this->getTable("driverInfoTable")->saveDriverInfo($driverInfoArray);						//	Update Drivers Info
							} else if($formData['user_role_id_hidden'] == 1) {
								$userStatus  			  	  =  $this->getTable("driverInfoTable")->deleteDriverInfo($userId);						//	Delete the Drivers Info for Role change
								// Delete the user drivers license
								if(isset($formData['user_drivers_license_hidden']) && $formData['user_drivers_license_hidden'] != '') {
									$unlinkFile			  	  =	 $this->siteImageUploadPath."/driver_license/".$formData['user_drivers_license_hidden'];
									$myFileUpload->unlinkFile($unlinkFile);
								}
							}
							*/
							if($mailSendingFlag) {
								// Password change mail sending	:	Start
								$mail_title				= 'Hello '.strtolower(ucFirst($formData['user_firstname'])).' '.$formData['user_lastname'];
								if($mailSendingFlag == 1) {
									$subject			= "Password change";
									$mail_descriptions	= 'Password change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								} else if($mailSendingFlag == 2) {
									$subject			= "Email change";
									$mail_descriptions	= 'Email change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								} else {
									$subject			= "Email And Password change";
									$mail_descriptions	= 'Email And Password change is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
								}
								
								$mailArray			    =  array(
									'subject'		  	=> $subject,
						            'from_email'	  	=> '',
									'from_name' 	  	=> '',
									'to_email' 	  	  	=> $formData['user_email'],
									'mail_title' 	  	=> $mail_title,
									'mail_descriptions' => $mail_descriptions,
									'mail_preview' 		=> 0,			//	1 - Preview the Email, 0 - Send the Email
						        );
								
								$allRoleSession 		= new Container('allRole');
								$role					= (isset($allRoleSession->allRoles[$this->pcUser->user_role_id])) ? $allRoleSession->allRoles[$this->pcUser->user_role_id] : '';
								
								$contentData			=  array(
									'Email'		  		=> $formData['user_email'],
									'Password'		  	=> $formData['user_password'],
									'First Name'		=> ucfirst($formData['user_firstname']),
									'Last Name'		  	=> $formData['user_lastname'],
									'Role'		  		=> $role
						        );
								
								$this->getCommonDataObj()->siteMailSending($contentData, $mailArray);
								// Password change mail sending	:	End
							}
							
							$message = 'User Profile upadated successfully.';
							$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('pcUsers', 'allUserCountByRole', 'allClients'));
							$this->getCommonDataObj()->setUsersDetails($this->pcUser->user_id);
							return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'client-dashboard'));
						/*} else {
							 //die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
						}*/
					}
				} else {
					$errorMessages	= $editUserForm->getMessages();
				}
	        } else {
					$message		= 'User Email is already exist.';
			}
			
			// Get the All roles
			$allRoleSession 		= new Container('allRole');
			$allRoles				= array();
			if($allRoleSession->offsetExists('allRoles') && $allRoleSession->allRoles != '' ) {
				$allRoles			= $allRoleSession->allRoles;
			} else {
				$allRoles			= array(''  => 'Select Role');
				$roles				= $this->getTable('roleTable')->getAllRoles();
				if($roles) {
					foreach($roles as $role) {
						$allRoles[$role->role_id]  =  $role->role_name;
					}
				}
				$allRoleSession->allRoles  		   =  $allRoles;
			}
			/*
			// Get the All Locations
			$allLocationSession 	= new Container('allLocations');
			$allLocations			= array();
			if($allLocationSession->offsetExists('locations') && $allLocationSession->locations != '' ) {
				$allLocations		= $allLocationSession->locations;
			} else {
				$allLocations		= array(''  => 'Select Location');
				$locations			= $this->getTable('locationTable')->getAllLocationDetails();
				
				if($locations) {
					foreach($locations as $location) {
						$allLocations[$location->loc_id]  =  $location->loc_title;
					}
				}
				$allLocationSession->locations  =  $allLocations;
			}
			
			// Get All Email to Text Message Addresses By Carrier 
			$allTextAddressesSession 	= new Container('allTextAddresses');
			$allTextAddresses			= array();
			if($allTextAddressesSession->offsetExists('textAddresses') && $allTextAddressesSession->textAddresses != '' ) {
				$allTextAddresses		= $allTextAddressesSession->textAddresses;
			} else {
				$textAddressResults		=  $this->getTable('usersTable')->getAllTextAddresses();
				if($textAddressResults && $textAddressResults->count()) {
					$textAddressResult	=  $textAddressResults->toArray();
					foreach($textAddressResult as $textAddress) {
						$allTextAddresses[$textAddress["text_addresses_id"]]  =  $textAddress;
					}
				}
				$allTextAddressesSession->textAddresses  =  $allTextAddresses;
			}
			*/
			$userDetails		= $this->getTable("usersTable")->getUserDetails($userId);
			foreach($userDetails as $userDetail) {
				$usersDetail	= $userDetail;
			}
			
//			$editUserForm->get('user_role_id')->setValueOptions($allRoles);
//			$editUserForm->get('user_role_id')->setValue($usersDetail['user_role_id']);
//			$editUserForm->get('location_id')->setValueOptions($allLocations);
//			$editUserForm->get('location_id')->setValue($usersDetail['location_id']);
			$editUserForm->get('user_id')->setValue($usersDetail['user_id']);
			$editUserForm->get('user_email')->setValue($usersDetail['user_email']);
			$editUserForm->get('user_email_hidden')->setValue($usersDetail['user_email']);
			$editUserForm->get('user_firstname')->setValue($usersDetail['user_firstname']);
			$editUserForm->get('user_lastname')->setValue($usersDetail['user_lastname']);
//			$editUserForm->get('user_gender')->setValue($usersDetail['user_gender']);
			$editUserForm->get('user_telephone_number')->setValue($usersDetail['user_telephone_number']);
			$editUserForm->get('user_mailing_address')->setValue($usersDetail['user_mailing_address']);
//			$editUserForm->get('user_text_address')->setValue($usersDetail['user_text_address']);
//			$editUserForm->get('user_status')->setValue($usersDetail['user_status']);
//			$editUserForm->get('user_citylicense_permit')->setValue($usersDetail['user_citylicense_permit']);
			
			// Date
			$datetime				=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
			/*
			$userTrainingDate		=  $datetime->getDates(strtotime($usersDetail['user_training_date']), 0, 'n-j-Y');
			$userLeasecontractDate	=  $datetime->getDates(strtotime($usersDetail['user_leasecontract_date']), 0, 'n-j-Y');
			
			$editUserForm->get('user_training_date')->setValue($userTrainingDate);
			$editUserForm->get('user_leasecontract_date')->setValue($userLeasecontractDate);
			
			// Images
			$editUserForm->get('user_profile_image')->setValue($usersDetail['user_profile_image']);
			$editUserForm->get('user_drivers_license')->setValue($usersDetail['user_drivers_license']);
			$editUserForm->get('user_contract')->setValue($usersDetail['user_contract']);
			*/
			return new ViewModel(array(
				'page' 				 	=> 1,
				'userObject'		 	=> $identity,
				'editUserForm'	 	 	=> $editUserForm,
				'message'			 	=> $message,
				'usersDetail'		 	=> $usersDetail,
//				'allTextAddresses'		=> $allTextAddresses,
				'pc_users'			 	=> $this->pcUser,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
			));
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'user', 'action' => 'user-listing'));
		}
    }
	
	/*	Action	: 	User Listing
	*	Detail	:	Used to List the Users details
	*/
	public function userListingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		/*
		$data	= $this->getCommonDataObj()->getCommonData(array('imageSizes', 'imageTypes', 'fileSizes', 'defaultPerPage'));
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==data==><pre>"; print_r($data); echo "</pre><==";
		*/
		
		// assign default values
		$matches		= $this->getEvent()->getRouteMatch();
		$page			= $matches->getParam('id', 1);
		$sortBy			= $matches->getParam('sortBy', '');
		$sortType		= $matches->getParam('sortType', '');
		$perPage		= $matches->getParam('perPage', '');
		
		// Create Filter form
		$userFilterForm = new UserFilterForm();
		
		//	Destroy listing Session Vars
		$listingSession = new Container('userListing');
		$sessionArray	= array();
		foreach($listingSession->getIterator() as $key => $value) {
			$sessionArray[]	= $key;
		}
		foreach($sessionArray as $key => $value) {
			$listingSession->offsetUnset($value);
		}
		
		if ($request->isPost()) {
			$userFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_keyward_name']) && !empty($formData['search_keyward_name']))
				$listingSession->keyward_name	= $formData['search_keyward_name'];
			else
				$listingSession->keyward_name	= '';
			
			if(isset($formData['search_keyward_value']) && $formData['search_keyward_value'] != '')
				$listingSession->keyward_value	= $formData['search_keyward_value'];
			else
				$listingSession->keyward_value	= '';
		}
		
		if($listingSession->offsetExists('keyward_name') && $listingSession->keyward_name != '' ) {
			$userFilterForm->get('search_keyward_name')->setValue($listingSession->keyward_name);
		}
		if($listingSession->offsetExists('keyward_value') && $listingSession->keyward_value != '' ) {
			$userFilterForm->get('search_keyward_value')->setValue($listingSession->keyward_value);
		}
		
		// User listing
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('usersTable')->getUsersList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		
		return new ViewModel(array(
			'userObject'	=> $identity,
			'userFilterForm'=> $userFilterForm,
			'pc_users'		=> $this->pcUser,
			'message'		=> $message,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'activeArrray'	=> $activeArrray,
			'hirearcheArray' => $this->hirearcheArray,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
    }
	
	/*	Action	: 	Ajax User list, Ajax action
	*	Detail	:	Used to list the Users details via Ajax
	*/
	public function userListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('userListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('usersTable')->getUsersList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		$result->setVariables(array(
			'message'		=> $message,
			'page'			=> $page,
			'sortBy'		=> $sortBy,
			'paginator'		=> $paginator,
			'perPage'		=> $perPage,
			'activeArrray'	=> $activeArrray,
			'hirearcheArray' => $this->hirearcheArray,
			'perPageArray'	=> $this->perPageArray,
			'controller'	=> $this->params('controller'),
			'commonData'	=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	View User
	*	Detail	:	Used to View the Users details, selected user
	*/
	public function viewUserAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		
		$user_id 		= (int) $this->params()->fromRoute('id', 0);
		$usersDetail	= '';
		
		if ($user_id) {
			$userDetails		= $this->getTable("usersTable")->getUserDetails($user_id);
			foreach($userDetails as $userDetail) {
				$usersDetail	=	$userDetail;
			}
		}
		// Date
		$datetime				=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		if(isset($usersDetail->user_leasecontract_date) && $usersDetail->user_leasecontract_date != "0000-00-00 00:00:00") {
			$usersDetail->user_leasecontract_date	=  $datetime->getDates(strtotime($usersDetail->user_leasecontract_date), 0, 'n-j-Y');
		} else {
			$usersDetail->user_leasecontract_date	=  '-';
		}
		
		if(isset($usersDetail->user_training_date) && $usersDetail->user_training_date != "0000-00-00 00:00:00") {
			$usersDetail->user_training_date		=  $datetime->getDates(strtotime($usersDetail->user_training_date), 0, 'n-j-Y');
		} else {
			$usersDetail->user_training_date		=  '-';
		}
		$usersDetail->loc_title						=  (isset($usersDetail->loc_title) && !empty($usersDetail->loc_title)) ? $usersDetail->loc_title : '-';
		
		$activeArrray	= array('0' => 'Inactive', '1' => 'Active');
		$genderArrray	= array('1' => 'Male', '2' => 'Female');
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'activeArrray'	 		=> $activeArrray,
				'genderArrray'	 		=> $genderArrray,
				'userDetails'	 		=> $usersDetail,
				'sitePath'	 			=> $this->sitePath,
				'siteImagePath'	 		=> $this->siteImagePath,
				'siteImageUploadPath'	=> $this->siteImageUploadPath,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
    }
	
	/*	Action	: 	Delete User, Ajax action
	*	Detail	:	Used to Delete the Users details
	*/
	public function deleteUserAction()
    {
		$user_id = (int) $this->params()->fromRoute('id', 0);
        if ($user_id) {
			$this->getTable("usersTable")->deleteUser($user_id);
			$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('allUserCountByRole', 'allClients'));
		}
        return $this->getResponse();
    }
	
	/*	Action	: 	Testing
	*	Detail	:	Used to test something for development
	*/
	public function testAction()
	{
		$this->renderer 		= $this->getServiceLocator()->get('ViewRenderer');
		$content 				= $this->renderer->render('usermanagement/mail_templates/registration_mail_template', null);
		
		$mailArray			    =  array(
			'subject'		  	=> 'Registration mail',
            'from_email'	  	=> '',
			'from_name' 	  	=> '',
			'to_email' 	  	  	=> 'vijayakumars@sdi.la',
			'mail_title' 	  	=> 'Hello',
			'mail_descriptions' => 'Registration mails',
			'mail_preview' 		=> 0,
        );
		
		$user	= array('Name' => 'Vijayakumar', 'Role' => 'Manager');
		
		$this->getCommonDataObj()->siteMailSending($user, $mailArray);
		return $this->getResponse();
		
		
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
	
}
/*
	http://unofficial-zf2.readthedocs.org/en/test/modules/zend.validator.db.html
*/