<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Usermanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//	Session
use Zend\Session\Container;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

//	Forms
use Usermanagement\Form\LoginForm;
use Usermanagement\Form\ForgetPasswordForm;

//	Models
use Usermanagement\Model\Users;
use Usermanagement\Model\MyAuthenticationAdapter;



class IndexController extends AbstractActionController
{
	protected $usersTable;
	protected $pcUser;
	protected $commonData;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	
	public function __construct()
    {
       /* //$adapter				  = new Adapter;
		$this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();*/
		//	Session for 
		
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("roleTable" => "Role-Table", "roleTypeTable" => "Role-Type-Table", "usersTable" => "Users-Table", "driverInfoTable" => "Driver-Info-Table", "aclresourcesTable" => "Aclresources-Table", "locationTable" => "Location-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action	: 	Default Redirections
	*	Detail	:	To redirect the users on their default landing pages
	*/
	private function defaultRedirect()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		if($identity && $identity->user_role_id == 1) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'driver-dashboard');
		} else if($identity && $identity->user_role_id == 2) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'mechanic-dashboard');
		} else if($identity && $identity->user_role_id == 6) {
			$params		= array('module' => 'schedulemanagement', 'controller' => 'shift', 'action' => 'client-dashboard');
		} else {
			$params		= array('module' => 'usermanagement', 'controller' => 'user', 'action' => 'dashboard');
		}
		return $this->redirect()->toRoute($params['module'], array('controller' => $params['controller'], 'action' => $params['action']));
    }
	
	
	/*	Action	: 	Index Action
	*	Detail	:	Used to load the default landing page for side and Login page.
	*/
	public function indexAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
		}
		
	    $loginForm 			= new LoginForm();
	    $loginForm->get('submit')->setValue('Login');
		$forgetPasswordForm = new ForgetPasswordForm();
	 	$request 			= $this->getRequest();
		$message			= '';
		
		if ($request->isPost()) {
            $usersModel		= new Users();
            $loginForm->setInputFilter($usersModel->getInputFilter());
            $loginForm->setData($request->getPost());
			
            if ($loginForm->isValid()) {
				$formData 	 = $loginForm->getData();
                $authAdapter = new MyAuthenticationAdapter(
					$formData["pc_login_email"],
					$formData["pc_password"]
				);
				$authAdapter->setDbAdapter(
						$this->getServiceLocator()->get('Zend\Db\Adapter\Adapter'));
				$result 	 = $auth->authenticate($authAdapter);
				if (!$result->isValid()) {
					// Authentication failed; print the reasons why
					foreach ($result->getMessages() as $message) {
						$message = "$message\n";
					}
					
				} else {
					$auth->getStorage()->write($authAdapter->getResultRowObject(null, array('user_password')));
					if ($auth->hasIdentity()) {
						$identity 	= $auth->getIdentity();
						$todayDate	= strtotime(date('Y-m-d H:i:s'));
						$leaseDate	= strtotime($identity->user_leasecontract_date);
						if($todayDate >= $leaseDate && $identity->user_role_id == 1)
						{
							// Authentication failed; print the reasons why
							$message = "1";
							$auth->clearIdentity();
						}
						else
						{
							$location_postal_code = $location_details = $allLocationDetails = '';
							$location_details	= $this->getLocationTable()->getLocationDetails($identity->location_id);
							if(is_object($location_details) && count($location_details) > 0)
							{
								foreach($location_details as $loc_key => $loc_value)
								{
									$location_postal_code			= $loc_value['loc_postal_code'];
								}
							}
							if(isset($location_postal_code) && $location_postal_code != '')
							{
								$identity->location_postal_code		= $location_postal_code;
							}
							if(isset($identity->user_role_id) && $identity->user_role_id == 5)
							{
								$allLocationDetails					= $this->getLocationTable()->getAllLocationDetails();
								$allLocationDetailSession			= new Container('allLocationDetailsSession');
								foreach($allLocationDetails as $locKey => $locValue)
								{
									$allLocationDetailSession[$locValue->loc_id] = (array)$locValue;	//	$locValue->loc_title
								}
							}
							// Begin user cookie
	//						setcookie('cookie_pc_user_email', $identity->user_email, time()+60*60*24*30, '/');
	//						setcookie('cookie_pc_user_password', $formData["pc_password"], time()+60*60*24*30, '/');
							$cookieUserName  =  (isset($formData["pc_remember"]) && !empty($formData["pc_remember"])) ? $identity->user_email : '';
							$cookiePassword  =  (isset($formData["pc_remember"]) && !empty($formData["pc_remember"])) ? $formData["pc_password"] : '';
							$cookieRemember  =  (isset($formData["pc_remember"])) ? $formData["pc_remember"] : true;
							
							$expires 		 =	time()+60*60*24*30;
							$domain	 		 =	($_SERVER["HTTP_HOST"] != 'http://localhost') ? $_SERVER["HTTP_HOST"] : '';
							$path	 		 =	'/';
							
							// Set the Use name cookie
							$userNameCookie  =  new SetCookie('cookie_pc_user_email', $cookieUserName, $expires, $path);
							$this->getResponse()->getHeaders()->addHeader($userNameCookie);
							
							// Set the Use password cookie
							$passwordCookie  =  new SetCookie('cookie_pc_user_password', $cookiePassword, $expires, $path);
							$this->getResponse()->getHeaders()->addHeader($passwordCookie);
							
							// Set the Use Remember cookie
							$rememberCookie  =  new SetCookie('cookie_pc_user_remember', $cookieRemember, $expires, $path);
							$this->getResponse()->getHeaders()->addHeader($rememberCookie);
							// End user cookie
							
							//	Session for User Role
							$userSession 			= new Container('pcUsers');
							$userSession->pc_users	= $identity;
							$this->pcUser			= $identity;
							return $this->defaultRedirect();
						}
						/*
						if($this->pcUser && $this->pcUser->user_role_id	 == 1)
						{
							return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'driver-dashboard'));
						}
						else if($this->pcUser && $this->pcUser->user_role_id == 6)
						{
							return $this->redirect()->toRoute('schedulemanagement', array('controller' => 'shift', 'action' => 'client-dashboard'));
						}
						else
						{
					 		return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
						}
						*/
					 }
				}
            }
        } else {
			/*	Cookie for Remember me option	*/
			$cookie = $this->getRequest()->getCookie();
			
			if ($cookie && $cookie->offsetExists('cookie_pc_user_email') && $cookie->offsetExists('cookie_pc_user_password') && $cookie->offsetExists('cookie_pc_user_remember')) {
				$loginForm->get('pc_login_email')->setValue($cookie->offsetGet('cookie_pc_user_email'));
				$loginForm->get('pc_password')->setValue($cookie->offsetGet('cookie_pc_user_password'));	//->setAttribute('value', 'Edit');
				$checked	= ($cookie->offsetGet('cookie_pc_user_remember')) ? true : false;
				$loginForm->get('pc_remember')->setAttribute('checked', $checked);
			}
		}
		
		return new ViewModel(array(
            'page' 				 => 1,
			'loginForm' 		 => $loginForm,
			'forgetPasswordForm' => $forgetPasswordForm,
			'message'			 => $message,
        ));
    }
	
	/*	Action	: 	Logout
	*	Detail	:	Used to Unset the user session values and logout the user from the site.
	*	TODO	:	Need to Unset the upcomming sessions
	*/
	public function logoutAction()
	{
		$auth = new AuthenticationService();
		$auth->clearIdentity();
		//	Destroy Session Vars
		/*
			pcUsers, roleListing, allRoles, allUserCountByRole, roleListing, allRole, allLocations, userListing, locationListing, 
			unsettledAccidentListing, settledAccidentListing, bikeListing 
		*/
		$status	 		= $this->getCommonDataObj()->destroySessionVariables(array('allRoles', 'allLocations', 'pcUsers','shiftDateTime', 'allClients','allLocationDetailsSession'));
		return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
	}
	
	/*	Action	: 	Ajax Forget Password, Ajax action
	*	Detail	:	Used to Validate the User email already exist
	*	TODO	:	Mail sending is inprocess 'Passwordreset message'.
	*/
	public function ajaxForgetPasswordAction() {
	 	$request 				= $this->getRequest();
		$message				= '';
		
		if($request->isPost()) {
			$usersModel			= new Users();
			$forgetPasswordForm = new ForgetPasswordForm();
            $forgetPasswordForm->setInputFilter($usersModel->getInputFilterForgetPassword());
            $forgetPasswordForm->setData($request->getPost());
			
			// RETURN VALUE
			$arrayToJs 	  	 	= array('0' => array('0' => 'pc_forget_password_email'));
			
            if ($forgetPasswordForm->isValid()) {
				$formData	 	= $request->getPost();
				$userArray		= $this->getUsersTable()->getUserByEmail($formData['pc_forget_password_email']);
				if($userArray) {
					//	Send Forgot and Reset password mail.
					$datetime				=  $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$createdDate			=  $datetime(time(), 0, 'Y-m-d H:i:s');
					$user_id				=  $userArray->user_id;
					$user_email				=  $userArray->user_email;
					$user_firstname			=  $userArray->user_firstname;
					$user_lastname			=  $userArray->user_lastname;
					
					$rand					=  rand();
					$user_password			=  $this->getCommonDataObj()->encode($rand);
					$userArray 				=  array(
						'user_id'			=> $user_id,
						'user_password'	  	=> $user_password,
						'user_updateddate'	=> $createdDate
			        );
					$this->getTable("usersTable")->saveUserProfile($userArray);				//	Forget password options
					
					// Password change mail sending	:  Start
					$mail_title				= 'Hello '.strtolower(ucFirst($user_firstname)).' '.$user_lastname;
					$subject				= "Forget Password";
					$mail_descriptions		= 'Forget Password options is successfully done !, Can you check your login details. <a target="_blank" href="'.$this->sitePath.'" title="Click here">Click here</a> to login on Pedicab';
					$mailArray			    =  array(
						'subject'		  	=> $subject,
			            'from_email'	  	=> '',
						'from_name' 	  	=> '',
						'to_email' 	  	  	=> $user_email,
						'mail_title' 	  	=> $mail_title,
						'mail_descriptions' => $mail_descriptions,
						'mail_preview' 		=> 0,			//	1 - Preview the Email, 0 - Send the Email
			        );
					
					$contentData			=  array(
						'Email'		  		=> $user_email,
						'Password'		  	=> $user_password,
						'First Name'		=> $user_firstname,
						'Last Name'		  	=> $user_lastname
			        );
					
					$this->getCommonDataObj()->siteMailSending($contentData, $mailArray);
					// Password change mail sending	:	End
					
					$arrayToJs[0][1] = true;
					//$arrayToJs[0][2] = "User Email validation success";
				} else {
					$arrayToJs[0][1] = false;
					$arrayToJs[0][2] = "User Email validation failure";
				}
			} else {
					$arrayToJs[0][1] = false;
					$arrayToJs[0][2] = "User Email validation failure";
			}
			echo json_encode($arrayToJs);
		}
		return $this->getResponse();
	}
	
	public function setCurrentLocationAction()
	{
		$auth 		  			= new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity 			= $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 				= $this->getRequest();
		if($request->isPost())
		{
			$formData			= $request->getPost();
			$currentLocation	= $formData['curLoc'];
			if(is_object($identity) && count($identity) > 0 && isset($currentLocation))
			{
				$identity->location_id		= $currentLocation;
			}
		}
		echo 1;die();
	}
	private function getUsersTable()
    {
        if (!isset($this->usersTable)) {
            $sm = $this->getServiceLocator();
            $this->usersTable = $sm->get('Users-Table');
        }
        return $this->usersTable;
    } 
	private function getLocationTable()
    {
        if (!isset($this->locationTable)) {
            $sm = $this->getServiceLocator();
            $this->locationTable = $sm->get('Location-Table');
        }
        return $this->locationTable;
    } 
	public function testAction()
	{
		echo '<br>==>'.__LINE__.'==>'.__FILE__.'==>';
		$datetime	= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		echo '<br>==>'.__LINE__.'==>'.__FILE__.'==>'.$datetime(time(), 0, 'Y-m-d H:i:s');
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
}
