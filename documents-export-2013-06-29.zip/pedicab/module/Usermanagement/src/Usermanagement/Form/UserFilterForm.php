<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class UserFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'user_filter_form');
		$this->setAttribute('name', 'user_filter_form');
		
		$this->add(array(
            'name' 		 => 'search_keyward_value',
            'attributes' => array(
				                'type'  							=> 'text',
								'id'								=> 'search_keyward_value',
								'autofocus'							=> '',
								'PlaceHolder' 						=> '',
								'class' 							=> 'wid240',
//								'data-validation-engine' 			=> 'validate[required]',
								'data-errormessage-value-missing' 	=> 'Search keyword is required!',
				            ),
            'options' => array(),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'search_keyward_name',
            'options' => array(
                'value_options' 	=> array(
                   ''  				=> 'Select Search Type',
				   'user_firstname' => 'First Name',
				   'user_lastname' 	=> 'Last Name',
				   'role_name' 		=> 'Role',
				   'user_email' 	=> 'Email',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'  								=> 'search_keyward_name',
//				'data-validation-engine' 			=> 'validate[funcCall[checkUserFilterForm]]',
				'data-errormessage-value-missing' 	=> 'Search Name is required!',
            )
        ));
		
        $this->add(array(
            'name' => 'search_role_submit',
			'id'   => 'search_role_submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_role_reset',
			'id'   => 'search_role_reset',
            'attributes' => array(
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>