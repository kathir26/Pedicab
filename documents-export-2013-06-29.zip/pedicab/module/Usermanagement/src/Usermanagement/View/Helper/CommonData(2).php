<?php
namespace Usermanagement\View\Helper;

use Zend\View\Helper\AbstractHelper,
    Zend\ServiceManager\ServiceLocatorAwareInterface,
    Zend\ServiceManager\ServiceLocatorInterface,
    Zend\View\Exception;
use Usermanagement\View\Helper\Datetime;
	
//	Session
use Zend\Session\Container;

/**
* 	CommonData helper
*/
class CommonData extends AbstractHelper
{
    /**
	 * Type of image
	 * 
	 * @var array image types
	 */
    private $imageTypes			=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
	
	/**
	 * size of image
	 * 
	 * @var int image size
	 */
	private $imageSizes 		=  '3145728';		//	3 Mb
	
	/**
	 * Type of file
	 * 
	 * @var array image types
	 */
	private $fileTypes			=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
	
	/**
	 * size of file
	 * 
	 * @var int file size
	 */
	private $fileSizes			=  '5242880';		//	5 Mb
	
	/**
	 * site image upload path
	 * 
	 * @var string
	 */
	private $siteImageUploadPath =  SITE_IMAGE_PATH_UPLOAD;
	
	/**
	 * site image path
	 * 
	 * @var string
	 */
	private $siteImagePath 		=  SITE_IMAGE_PATH;
	
	/**
	 * site path
	 * 
	 * @var string
	 */
	private $sitePath			=  SITE_PATH;
	
	/**
	 * default per page
	 * 
	 * @var int
	 */
	private $defaultPerPage		=  5;
	
	/**
	 * per page
	 * 
	 * @var array per page
	 */
	private $perPage			=   array('10', '20', '30', '40', '50');
	
	/**
	 * per page
	 * 
	 * @var array shiftTypeArray
	 */
	private $shiftTypeArray		=  array('1' => 'Day','2' => 'Night','3' => 'Double','4' => 'Special');
	
	/**
	 * sm
	 * 
	 * @var sm var
	 */
	private $sm					=   '';
	
	/**
	 * renderer
	 * 
	 * @var renderer var
	 */
	private $renderer			=   '';
	
	/**
	 * sendMail
	 * 
	 * @var sendMail var
	 */
	private $sendMail			=   '';
	
	/**
	 * siteDetail
	 * 
	 * @var siteDetail var
	 */
	private $siteDetail			=   array('adminEmail' => 'pajany@sdi.la', 'adminName' => 'Pajany', 'siteName' => 'Pedicab', 'sitePath' => SITE_PATH);
	
	public function __construct()
    {
        // Todo : We do some thing
    }
	
	public function set($sm)
    {
        $this->sm =  $sm;
    }
	
	public function renderer($renderer)
    {
        $this->renderer = $renderer;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("ShiftTable" => "Shift-Table", "LocationTable" => "Location-Table", "ShiftRequestTable" => "Shift-Request-Table", "UsersTable" => "Users-Table", "LogtimeTable" => "Logtime-Table", "LeasePaymentsTable" => "Lease-Payments-Table");
		if (!isset($this->$tableName)) {
            $this->$tableName 	=  $this->sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
    public function viewFormatForTelephone($phone_number)
    {
		$returnVal			=  '';
		$phone_number 		=  preg_replace("/[^0-9]/", "", $phone_number);
		$strLen				=  strlen($phone_number);
		
		if($strLen <= 10) {
	        $returnVal		=	preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})/", "$1 $2 $3", $phone_number);
	    } else if($strLen > 10 && $strLen <= 15) {
	        $returnVal		=	preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})([0-9]{5})/", "$1 $2 $3 $4", $phone_number);
	    } else if($strLen > 15 && $strLen <= 20) {
	        $returnVal		=	preg_replace("/([0-9]{3})([0-9]{3})([0-9]{4})([0-9]{5})([0-9]{5})/", "$1 $2 $3 $4 $5", $phone_number);
		} else {
			$returnVal		=	$phone_number;
		}
		return $returnVal;
    }
	
	public function destroySessionVariables($data)
    {
		$status		  = '';
		if (is_string($data)) {
			$containerArray[]	= $data;
		} else if (is_array($data)) {
			$containerArray		= $data;
		}
		if(is_array($containerArray) && count($containerArray)) {
			foreach($containerArray as $sessionName) {
				//	Destroy Session Vars
				$containerSession 	= new Container($sessionName);
				$sessionArray 		= array();
				if($containerSession && $containerSession->getIterator()) {
					foreach($containerSession->getIterator() as $key => $value) {
						$sessionArray[]	= $key; 	//	$containerSession->offsetUnset($key);
					}
					foreach($sessionArray as $key => $value) {
						$containerSession->offsetUnset($value);
					}
					$status	  = true;
				}
			}
		}
		return $status;
    }
	/**
	* gets the data
	* 
	* @param string}array name of the data|array of names
	* @return the data, if exist
	*/
	public function getCommonData($data)
	{
		if (is_string($data)) {
			$data = $data;
			if (isset($this->$data)) {
				return $this->$data;
			}
		} else if (is_array($data)) {
			$resource = array();
			foreach ($data as $element) {
				$key  = $element;
				if (isset($this->$key)) {
					$resource[$element] = $this->$key;
				}
			}
			return $resource;
		}
		return;
	}
	
	 /*
		Change UI date formate to DB data formate 
	 */
	 public function getDBdateFormat($userdate)
	 {
		  if($userdate!=''){
			  $date 	=	explode('/',$userdate);
			  $date   = 	$date[2].'-'.$date[1].'-'.$date[0];
			  return $date;
		  }
	 }
	
	 /*
		Change the time as 12 and 24 hours formates.
	 */
	 public function getTimeFormate($time = '', $type = 1)
	 {
		  if($time) {
			  $timeFormat =	($type == 1) ? "h:i A" : "H:i";
			  if($time !=' '){
				  $time   = date($timeFormat, strtotime($time));
			  }
			  return $time;
		  } else {
		  	return false;
		  }
	 }
	 
	 /*
		Get the Start And End time for the specidied months
	 */
	 public function getStartAndEndDates($type = 1, $time = 1)
	 {
	 	$timePeriodArray  = array(1 => 'now');
		$dateArray		  = array();
		if(isset($timePeriodArray[$time]) && !empty($timePeriodArray[$time])) {
			$timePeriod	 			 = $timePeriodArray[$time];
			if($type == 2) {
				$dateArray['start_date'] = date("n-Y", strtotime($timePeriod));
				$dateArray['end_date']   = date("n-Y", strtotime($timePeriod));
			} else {
				$dateArray['start_date'] = date("n-1-Y", strtotime($timePeriod));
				$dateArray['end_date']   = date("n-t-Y", strtotime($timePeriod));
			}
			return $dateArray;
		} else {
			return false;
		}
	 }
	
	
	/**
	 * change the image extension
	 * jpeg, pjpeg, jep are jpg
	 * gif as gif
	 * png as png
	 * @param string ext of the image
	 * @return string type, if exist
	 */
	public function getImageType($extension)
	 {
		$type = '';
		if (($extension == 'pjpeg') or ($extension == 'jpeg'))
			$extension = 'jpg';
		if ($extension == 'jpg')
			$type = 'jpg';
		if ($extension == 'gif')
			$type = 'gif';
		if ($extension == 'png')
			$type = 'png';
		if ($extension == 'bmp')
			$type = 'bmp';
		return $type;
	 }
	 
	/**
	 * gets file type
	 * 
	 * @param string ext of the image
	 * @return the int type, if exist
	 */
	 public function getFileType($extension)
	 { 	// 'doc', 'docx', 'rtf', 'txt', 'pdf'
		$type  =  '';
		if (($extension == 'doc') or ($extension == 'docx'))
			$extension = 'doc';
		if ($extension == 'doc')
			$type = 'doc';
		else if ($extension == 'rtf')
			$type = 'rtf';
		else if ($extension == 'txt')
			$type = 'txt';
		else if ($extension == 'pdf')
			$type = 'pdf';
		return $type;
	 }
	 
	/**
	 * make directory
	 * 
	 * @param string path
	 * @param int optional for write permission
	 */
	 public function makeDirectory($path , $rights = 0777) 
	 {
		$folder_path = array(strstr($path, '.') ? dirname($path) : $path);
		while(!@is_dir(dirname(end($folder_path)))
	         && dirname(end($folder_path)) != '/'
	         && dirname(end($folder_path)) != '.'
	         && dirname(end($folder_path)) != '')
	   		array_push($folder_path, dirname(end($folder_path)));
		while($parent_folder_path = array_pop($folder_path)) {
			clearstatcache();
			if(!is_dir($parent_folder_path))
				@mkdir($parent_folder_path);
			@chmod($parent_folder_path, 0777);
		}
	 }
	 
	/**
	 * make permission
	 * 
	 * @param string path
	 * @param int optional for write permission
	 */
	public function makePermission($path , $rights = 0777)
	{	if(is_dir($path)) {
	 		$permission   	=  substr(sprintf('%o', fileperms($path)), -4);
			if($permission != $rights) {
			   @chmod($path, $rights);
			}
		}
	}
	
	public function encodeCrypt($path)
	{
		$key 	 =	"pedicab";
		$iv_size =	8;
		$iv		 =	mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$enc	 =	mcrypt_encrypt(MCRYPT_XTEA, $key, $path, MCRYPT_MODE_ECB, $iv);
		return base64_encode($enc);
	}
	
	public function decode_crypt($path) {
	 	$path	 	=	str_replace(' ','+',$path);
		$key 	 	=	"pedicab";
		$iv_size 	=	8;
		$path1 	 	=	base64_decode($path);
		$iv			=	mcrypt_create_iv($iv_size, MCRYPT_RAND);
		$crypttext 	=	mcrypt_decrypt(MCRYPT_XTEA, $key, $path1, MCRYPT_MODE_ECB, $iv);
		return trim($crypttext);
	}
	
	public function getReferenceId($referencevalue) {
		//$referencevalue	=	10;
	 	$referencevalue = 'PC'.sprintf('%03s',$referencevalue);
		return trim($referencevalue);
	}
	
	public function getAgebyDOB($dob) {
		$returnage =  (date("md", date("U",$dob)) > date("md") ? ((date("Y")- date("Y",$dob))-1).'&nbsp;':(date("Y")-date("Y",$dob)).'&nbsp;');
		return trim($returnage);
	}
	
	//Function to disable  magic_quotes_gpc at runtime and to replace double quotes into HTML character entity references.
	//value may be an array or value
	
	public function addSlashesDuplicate($fieldValue) {
		if(get_magic_quotes_gpc()) {
			$returnValue =	$fieldValue;
		}
		else {
			$returnValue =	addslashes($fieldValue);
		}
		return $returnValue;
	}
	
	public function StripSlashesDuplicate($fieldValue) {
		if(get_magic_quotes_gpc()) {
			$returnValue =	$fieldValue;
		}
		else {
			$returnValue =	stripslashes($fieldValue);
		}
		return $returnValue;
	}
	
	public function customNumberFormats($number = 0, $decimals = 0, $dec_point = '.', $thousands_sep = ',') {
		$returnValue	 = $number;
		if($number) {
			$returnValue =	number_format($number , $decimals, $dec_point, $thousands_sep);
		}
		return $returnValue;
	}
	
	public function customizedAddSlashes ($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj   = 1;
		}
		
		if (is_array($value)) {
			$value = array_map(array($this, 'customizedAddSlashes'),  $value);
		} else {
			$value = (get_magic_quotes_gpc()) ? $value : addslashes ($value);
		}
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function customizedStripSlashes ($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj   = 1;
		}
		
		if (is_array($value)) {
			$value = array_map(array($this, 'customizedStripSlashes'),  $value);
		} else {
			$value = (get_magic_quotes_gpc()) ? $value : stripslashes ($value);
		}
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function removeMagicQuotes ($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, 'removeMagicQuotes'),  $value) : stripslashes ($value);
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function escapeString ($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, 'escapeString'),  $value) : addslashes($value);
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function stripUnwantedTag ($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, 'stripUnwantedTag'),  $value) : strip_tags($value,'<b><br><a>');
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function _urlDecode($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, '_urlDecode'),  $value) : urldecode($value);
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function _utf8Decode($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, '_utf8Decode'),  $value) : utf8_decode($value);
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	/**
		* Construct update array for tables
		* 
		* @param	array		array of fields
		* @param	array		array of form data
		* @return the form data
	*/
	public function constructUpdateArray($fieldArray, $formData)
	{
		$fieldsArray = array();
		foreach ($fieldArray as $key => $value){
			if (isset ($formData[$value]))
				$fieldsArray[$value] =  $formData[$value];
			}
		return $fieldsArray;
	}
	
	/**
		* encrypts the id
		* 
		* @param string
	*/
	public function encode($id)
	{
		return dechex(($id + 5) * 101);
	}
	
	/**
		* decrypts the id
		* 
		* @param string
	*/
	public function decode($id)
	{
		return hexdec($id)/101-5;
	}
	
	public function dateNumericToTimeString($date, $text = "h") {
		$getDate	=	explode(" ",$date);
		$numDate 	= 	explode("-", $getDate[0]);
		$getTime	=	explode(":",$getDate[1]);
		$stringDate = 	$getTime[0]. $text .$getTime[1];
		return $stringDate;
	}
	
	public function displayShortText($text, $length) {
		if (strlen($text) > $length) return strip_tags( substr ($text, 0, $length)).'...'; else return $text;
	}
	
	public function isKeyExists($string, $key) {
		if(isset($string) && $string != '' && $string != 'NULL') {
			$tempArray	= array();
			$tempArray	= explode('#', $string);
			if(in_array($key, $tempArray))
				echo 'checked';
			else
				echo '';
		}
		else echo '';
	}
	
	public function makeString($array) {
		if(is_array($array) && count($array)>0) {
			$str	= implode('#', $array);
			return $str;
		}
		else return '';
	}
	
	public function displayText($text, $length) {
		if (strlen($text) > $length) return strip_tags( substr ($text, 0, $length)).'...'; else return $text;
	}
	
	public function displayTextNew($text, $length) {
		$text = strip_tags($text);
		if (strlen($text) > $length) {
			if(trim(strrpos(substr($text, 0, $length), ' ')) == '')
				return  substr($text, 0, $length) . '...';
			else{
				return  substr($text, 0, strrpos(substr($text, 0, $length), ' ')) . '...';
			}
		}
		else {
			return $text;
		}
	}
	
	/**
		* gets date in format
		* 
		* @param string input date
		* @param string date format
	*/
	public function getDate($date, $format)
	{
		/*
		$format = str_replace("YYYY","yyyy",$format);
		$dateObject = new Zend_Date($date, $format, 'fr_FR');
		return $dateObject->toString($format);
		*/
	}
	
	public function getDateFormat($timestamp,$format)
	{
		if(trim($timestamp) != '') {
			if(empty($format)) $format = 'd/m/Y H:i';
			$date	=	date($format,$timestamp);
			return str_replace(":","h",$date);
		} else
			return '';
	}
	
	/**
		*  Get microtime Float
		*  
	*/
	public function microtimeFloat()
	{
	    list($usec, $sec) = explode(" ", microtime());
	    return ((float)$usec + (float)$sec);
	}
	
	public function encodeText($text) {
		$text = $text;
		return base64_encode($text);
	}
	
	public function decodeText($text) {
		$text = $text;
		return base64_decode($text);
	}
	
	// get image extension for given url
	public function stripExtension($filename  = '') {
	    if (!empty($filename)) {
		    $filename = strtolower($filename);
	        $extArray = explode(".", $filename);
	        $p = count($extArray)-1;
	        $extension = $extArray[$p];
	        return $extension;
	    } else {
	        return false;
	    }
	}
	
	public function checkEmailCorrectDNS($email)
	{
		if (function_exists('checkdnsrr'))
		{
			list($t_compte, $t_domaine) = split("@", $email, 2);
			return checkdnsrr($t_domaine, "MX");
		}
		else
		{
			return true;
		}
	}
	
	public function getCandidateDOBYear($type, $diff = false)
	{
		$returnValue	=	'';
		if($diff == '') {
			$diff	=	($type == 1) ? 80 : 18;		//	1 - startyear , 2 - endyear
		}
		switch($type) {
			case 1:
				 $returnValue	=	date('Y')- $diff;
				 break;
			case 2:
				 $returnValue	=	date('Y')- $diff;
				 break;
			default:
				 $returnValue	=	date('Y');
				 break;
		}
		return $returnValue;
	}
	
	
	public function numberFormat($int){
		return preg_replace("/(?<=\d)(?=(\d{2})+(?!\d))/"," ",$int);
	}
	
	/*	public function wraptext($string, $limit) {
		return preg_replace("/(\w{{$limit}})/", "$1&shy;", $string);
	}	*/
	
	public function wraptext($string, $limit) {
		if(trim($string) != '') {
			$stringArray	= explode(' ', html_entity_decode($string));
			if(is_array($stringArray) && count($stringArray)>0) {
				$output	= '';
				foreach($stringArray as $key => $value) {
					if(isset($value[$limit])) {
						$outputArray	= str_split($value, $limit);
						$output	.= implode(' - ', $outputArray);
					} else {
						$output	.= $value.' ';
					}
				}
				return $this->findUrl($output);
			}
		}
	}
	
	/*	Function: findUrl
		Paramter: string
		Return:	Integrated the anchor tags with the urls.
	*/
	public function findUrl($text) {
		// The Regular Expression filter
		$reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
		// Check if there is a url in the text
		if(preg_match($reg_exUrl, $text, $url)) {
		    // make the urls hyper links
			return preg_replace($reg_exUrl, "<a target='_blank' href=".$url[0]." title=".$url[0].">{$url[0]}</a>", $text);
		} else {
		    // if no urls in the text just return the text
			return $text;
		}
	}
	
	public function decodeHtmlEntitiesText($value)
	{
		$obj = 0;
		if (is_object ($value)) {
			$value = (array) $value;
			$obj = 1;
		}
		
		$value = is_array($value) ? array_map(array($this, 'decodeHtmlEntitiesText'),  $value) : html_entity_decode($value);
		
		if ($obj == 1) {
			$value = (object) $value;
		}
	    return $value;
	}
	
	public function removeAllSlashes($text)
	{
		// $text = str_replace("\\","",htmlentities($this->replaceCodeByAccent(html_entity_decode($text))));
		$text = str_replace("\\","", $this->replaceCodeByAccent(html_entity_decode($text)));
		//$text = str_replace("&#339;", "œ", $text);
		return $text;
	}
	
	public function checkAccentForLocalisation($text, $type = 1)
	{
		$text = ($type && $type == 1) ? urldecode($text) : $text;
		$text = utf8_decode($text);
		return $text;
	}
	
	public function getFileContents($fileAbsPath,$fileName,$fileType) {
		if( file_exists($fileAbsPath.$fileName.".".$fileType) ) {
			$fileContents = file_get_contents($fileAbsPath.$fileName.".".$fileType);
			return $fileContents;
		}
	 }
	 
	 public function getPdfPageCount($fileRelativePath){
	 	if (!$fp = @fopen($fileRelativePath,"r")) {
       	 	echo 'failed opening file '.$fileRelativePath;
		}
		else {
		        $max=0;
		        while(!feof($fp)) {
		                $line = fgets($fp,255);
		                if (preg_match('/\/Count [0-9]+/', $line, $matches)){
		                        preg_match('/[0-9]+/',$matches[0], $matches2);
		                        if ($max<$matches2[0]) $max=$matches2[0];
		                }
		        }
		        fclose($fp);
				//echo 'There '.($max<2?'is ':'are ').$max.' page'.($max<2?'':'s').' in '. "vresume.pdf".'.';
				return $max;
		}
	 }
	 
	 public function heightPdf($size){
		$hauteur = round(substr($size,7,7)/2.83);
		return $hauteur;
	 }
	 
	 public function widthPdf($size){
		$largeur = round(substr($size,17,7)/2.83);
		return $largeur;
	 }
	 
	 public function checkIsString($value) {
	 	$return 	= false;
		if($value != '' && ctype_alnum($value)) {
			$return = true;
		}
		return $return;
	 }
	 
	/**
	* Changes the case of values in an array
	* @param array $array
	* @param string $case
    * @return array
	*/
	public function arraycase(array $array, $case) {
        switch (strtolower($case)) {
                case 'lower':
                $newarray = unserialize(strtolower(serialize($array)));
                break;
                
                case 'upper':
                // using same method as 'lower' doesn't work
                //$newarray = unserialize(strtoupper(serialize($array)));
                // flip it, change it, flip it back
                $newarray = array_flip($array);
                $newarray = array_flip(array_change_key_case($newarray,CASE_UPPER));
                break;
                
                case 'first':
                // this doesn't work
                $newarray = unserialize(ucfirst(serialize($array)));
                break;
                
                case 'words':
                // this doesn't work
                $newarray = unserialize(ucwords(serialize($array)));
                break;
                
                default:
                // if they don't specifiy a case, be nice and give them their array back
                $newarray = $array;
                break;
        }
        return $newarray;
	}
	
	public function setCommonUTF_encoding(){ 
		mb_internal_encoding('UTF-8');
	 	mb_http_output('UTF-8');
		mb_http_input('UTF-8');
		mb_language('uni');
		mb_regex_encoding('UTF-8');
		ob_start('mb_output_handler');
	}
	
	public function setUTFcharset($myString) {
		$myString           = replaceManualCode($myString);
		$current_encoding 	= mb_detect_encoding($myString , 'UTF-8, ISO-8859-1','ASCII');
		$myString 	  	  	= iconv($current_encoding, 'UTF-8', $myString);
		$myString           = replaceManualCodebyAccent($myString);
		return $myString;
	}
	
	public function unlinkFile($fileAbsolutePath) {
		if(file_exists($fileAbsolutePath) )
			unlink($fileAbsolutePath);
	}
	
	public function writeFile($fileAbsolutePath,$myString,$fileWriteEncoding = ''){
		str_replace('?','',$myString);
		$fh		  	= fopen($fileAbsolutePath,"w") or die("can't open file");
		if( $fileWriteEncoding == 'encode' )
			fwrite($fh,utf8_encode($myString));
		else if ( $fileWriteEncoding == 'decode' )
			fwrite($fh,utf8_decode($myString));
		else
			fwrite($fh,$myString);
		fclose($fh);
	}
	
	public function substr_unicode($str, $s, $l = null) {
    	return join("", array_slice(
        	preg_split("//u", $str, -1, PREG_SPLIT_NO_EMPTY), $s, $l));
	}
	
	public function documentSpecialTags($myString, $type){
		
		if($type==1){
			$myString         = str_replace('﻿','',$myString);
			$myString         = str_replace('�','mjbullet',$myString);
		}else if($type==2){
			$myString         = str_replace('mjbullet','�',$myString);
		}
		return $myString;
	}
	
	public function getUserTimeDifferent($usertime)
	{
		$start = strtotime(date("d-m-Y H:i",$usertime));
		$stop  = strtotime(date("d-m-Y H:i"));
		// Diferences
		$difference = $stop - $start;
		// Hours
		$hours = round($difference / (60*60), 0);
		// Minutes
		$minutes = ($difference % (60*60)) / 60;
		if($minutes>20) return 1;
		else return 0;
	}
	
	//	Replace single quote in Filter(Localization field)\
	public function replaceSingleQuote($string) {
		//$string	=	str_replace("'", "&#039;", $string);
		$string	= str_replace("�", "&#146;", $string);
		return $string;
		//�
	}
	public function getCurrentDateTime()
	{
		$datetime		= new Datetime();
		$createdDate	= $datetime(time(), 0, 'Y-m-d H:i:s');
		return $createdDate;
	}
	public function getAllParticularDates($start_date, $end_date,$date_array)//$date_array = array(1,4,6); //sunday = 0 ...... saturday = 6
	{
	    // parse the $start_date and $end_date string values
	    $stime 		= new \DateTime($start_date);
	    $etime 		= new \DateTime($end_date);
	    // make a copy so we can increment by day
	    $ctime 		= clone $stime;
	    $results 	= array();
	    while($ctime <= $etime)
		{
	        $dow 	= $ctime->format("w");
	        // assumes $date_array is array containing integers for Sun (0) - Sat (6)
	        if(in_array($dow, $date_array))
			{
	            // make a copy to return in results
	            $results[] 	= clone $ctime;
	        }
	        // incrememnt by 1 day
	        //$ctime=date_add($ctime, date_interval_create_from_date_string('1 days'));
	        $ctime->modify("+1 days");
	    }
	    return $results;
	}
	public function getAllDates($start_date,$end_date,$date_interval) //$date_interval => P1D = 1 day, P1M = 1 month , P1Y = 1 year
	{
		$begin 		= new \DateTime($start_date);
	 	$end 		= new \DateTime($end_date);
	 	$results  	= new \DatePeriod($begin, new \DateInterval($date_interval), $end);
	 	return $results;
	}
	public function getPreviousDateTime($hour,$date)
	{
		$etime = new \DateTime($date);
		$etime->sub(new \DateInterval($hour)); //P7Y5M4DT4H3M2S ==> P 7Y - Years 5M - Months 4D - Days T - Time 4H - Hours 3M - Minutes 2S - Seconds
		return $etime->format('Y-m-d H:i:s');
	}
	public function getDateDifference($startDate, $endDate) //Format "2007-03-24"
	{
		$date1 = new \DateTime($startDate);
		$date2 = new \DateTime($endDate);
		$interval = $date1->diff($date2);//echo "difference " . $interval->y . " years, " . $interval->m." months, ".$interval->d." days ";
		return $interval;// getting time $interval->format('%h:%i:%s');
	}
	public function secondsToTime($time, $return_type = "string") //Convert H:i:s to 1 Hour 2 minutes
	{
        $seconds				=  strtotime($time) - strtotime('00:00:00');
		// extract days
        $days 					= floor($seconds / 3600 / 24);
        // extract hours
        $hours 					= floor($seconds / 3600) - $days*24;
        // extract minutes
        $divisor_for_minutes 	= $seconds % 3600;
        $minutes 				= floor($divisor_for_minutes / 60);
        // extract the remaining seconds
        $divisor_for_seconds 	= $divisor_for_minutes % 60;
        $seconds 				= ceil($divisor_for_seconds);
        // return the final array
        $obj = array(
            "d" => (int) $days,
            "h" => (int) $hours,
            "m" => (int) $minutes,
            "s" => (int) $seconds
        );
        $str 					= "";
        if($obj["d"] != 0)
		{
			$str 				.= $obj["d"]."d ";
		}
        $str 					.= $obj["h"]."h ";
        $str 					.= $obj["m"]."m ";
        if($return_type == "string")
		{
			$returnObj = '';
			if(isset($obj["d"]) && $obj["d"] > 0)
			{
				$returnObj		.= $obj["d"]." Days, ";
			}
			if(isset($obj["h"]) && $obj["h"] > 0)
			{
				$returnObj		.= $obj["h"]." Hours, ";
			}
			if(isset($obj["m"]) && $obj["m"] > 0)
			{
				$returnObj		.= $obj["m"]." Minutes, ";
			}
			if(isset($obj["s"]) && $obj["s"] > 0)
			{
				//$returnObj		.= $obj["s"]." Seconds";
			}
			return rtrim(trim($returnObj),',');
		}
        else
		{
			return $obj;
		}
    }
	public function getWeatherKey()
	{
		if(isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] == 'www.pedicablocal.com')
		{
			$weather_key	= '36d98e6c7232983f'; //For Local =====> Developer key
		}
		else
		{
			$weather_key 	= '36d98e6c7232983f';
		}
		return $weather_key;
	}
	
	/*
	 *	 Function to construct the Get argument arrays
	 *   @var array args, @var int type (1 = encode, 2 = decode), @var string char
	*/
	 public function customArguments($args = '', $type = 1, $char = '##')
	 {
	 	$values  			= '';
	 	 if($args) {
		 	if($type == 1) {
				/*$impValue	=  implode($char, $args); // encode , decode
				$values		=  $this->encodeCrypt($impValue);
				*/
				$values		=  implode($char, $args);
			} else {
				/*$temp		=  $this->decode_crypt($args);
				$values		=  explode($char, $temp);
				*/
				$values		=  explode($char, $args);
			}
		 }
		 return $values;
	 }
	
	/*
	 *	 Function to construct the Get argument arrays
	 *   @var array args, @var int type (1 = encode, 2 = decode), @var string char
	*/
	 public function customArguments1($args = '', $type = 1, $char = '-')
	 {
	 	$values  			= '';
	 	 if($args) {
		 	if($type == 1) {
				$impValue	=  implode($char, $args); // encode , decode
				$values		=  $this->encodeCrypt($impValue);
			} else {
				$temp		=  $this->decode_crypt($args);
				$values		=  explode($char, $temp);
			}
		 }
		 return $values;
	 }
	 
	/*
	 *	 Function to Assign the Sorting values
	*/
	 public function getSortings($sortBy, $key, $type = 1)
	 {
	 	$values  	= '';
		if($type == 2) {
			$values = ($sortBy == $key) ? "sortup-arrow" : "sort-arrow";
		} else {
			$values = ($sortBy == $key) ? 1 : 0;
		}
		return $values;
	 }
	 
	/*
	*	Function to Check the Bike Availability
	*	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
	*/
	 public function checkBikeAvailability($shiftDetails, $type, $pcUser)
	 {
//		$shiftDetails['start_time']	= ''; $shiftDetails['end_time']	= '';
		
		$bikeAvailables		= array();
		$bikeResults		= $this->getTable("ShiftRequestTable")->getBikesAvailable($shiftDetails['shift_date']);
		if($bikeResults) {
			foreach($bikeResults as $key => $value) {
				$bikeAvailables	= $value;
			}
		}
		
		/*
		*	Get the Available bikes for all shifts in a particulat day.
		*/
		$bikeRequired	=  $bikeAllocated  =  0;
		$availableBikes	=  $repeating  =  $events  =  array();
		$results		=  $this->getTable("ShiftRequestTable")->getAllShiftAvailableBikes($shiftDetails);
		$startTime		=  $shiftDetails['start_time'];
		$endTime		=  $shiftDetails['end_time'];
		if($results) {
			foreach($results as $key => $value) {
				if($value['shift_occurs'] == 1) {
					 $repeating[$value['shift_dt_id']] = $value;
					 $bikeAllocated += ($value['shift_dt_total_bikes'] - $value['shift_dt_bike_available']);
					/*if($shiftDetails['special_id'] != $value['shift_dt_id']) {
					   $repeating[$value['shift_dt_id']] = $value;
					} else {
					  $bikeAllocated += ($value['shift_dt_total_bikes'] - $value['shift_dt_bike_available']);
					}*/
				} else {
					$events[$value['event_id']] 	= $value;
					$bikeAllocated += ($value['event_total_bikes'] - $value['shift_bike_available']);
					/*if($shiftDetails['special_id'] != $value['event_id']) {
					   $events[$value['event_id']] 	= $value;
					} else {
					  $bikeAllocated += ($value['event_total_bikes'] - $value['shift_bike_available']);
					}*/
				}
				$count				= ($value['shift_occurs'] == 1) ? $value['shift_dt_bike_available'] : $value['shift_bike_available'];
				$bikeRequired 	   += $count;
				$availableBikes[]   = $value;
			}
		}
		
		/*
		* 	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
		*/
		$bikeAvailable	= ($bikeAvailables['available_bikes'] - $bikeAllocated);
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==bikeRequired==>".$bikeRequired."==bikeAvailable==>".$bikeAvailable."==bikeAllocated==>".$bikeAllocated."<==";
//		return false;
		
		if($bikeRequired > $bikeAvailable) {
			$notificationLoop		= 0;
			$notifications     		= array();
			if(isset($repeating) && is_array($repeating) && count($repeating)) {
				foreach($repeating as $key_repeat => $value_repeat) {
//					echo "<br/>==Line==".__LINE__."==File==".__FILE__."==shift_dt_bike_available==>".$value_repeat['shift_dt_bike_available']."<====bikeAvailable==>".$bikeAvailable."<==";
					if($value_repeat['shift_dt_bike_available'] > $bikeAvailable) {
						$bike_available	= ($value_repeat['shift_dt_bike_available'] > $bikeAvailable) ? $bikeAvailable: $value_repeat['shift_dt_bike_available'];
						$total_bike		= ($value_repeat['shift_dt_total_bikes'] > $bikeAvailable) ? $bikeAvailable + ($value_repeat['shift_dt_total_bikes'] - $value_repeat['shift_dt_bike_available']): $value_repeat['shift_dt_total_bikes'];
						$shift_dt_id 	= $value_repeat['shift_dt_id'];
						$updates     	= array(
							'bike_available' => $bike_available,
							'total_bike' 	 => $total_bike,
							'shift_dt_id' 	 => $shift_dt_id,
							'shift_occurs' 	 => 1
						);
						$this->getTable("ShiftRequestTable")->updateBikesAvailable($updates, 2);
						
						/*
						* 	TODO :  Need to send the Notifications to Locations Managers and Drivers
						*	1 - Reduced the Shift Bikes reservation, 2 - Reduced the Shift Bikes reservation and Cancel the Allocations
						*/
						$msg			= '('.$this->shiftTypeArray[$value_repeat['shift_type']].' Shift Timing : '.$this->convertTimeFormat($value_repeat['shift_start_time']).'-'.$this->convertTimeFormat($value_repeat['shift_end_time']).')';
						if($value_repeat['shift_dt_bike_available'] > $bikeAvailable) {
							$subject	= 'Shift Bike confirmation affect the other shifts '.$msg;
						} else {
							$subject	= 'Shift Bike confirmation affect the other shifts '.$msg.'. So Manager could check and change the assigned driver status to on call list';
						}
						
						$notifications[$notificationLoop]['notify_date'] 	= $value_repeat['shift_dt_start_date'];
						$notifications[$notificationLoop]['notify_type'] 	= 6;
						$notifications[$notificationLoop]['shift_id'] 	 	= $value_repeat['shift_id'];
						$notifications[$notificationLoop]['shift_dt_id'] 	= $value_repeat['shift_dt_id'];
						$notifications[$notificationLoop]['shift_occurs'] 	= $value_repeat['shift_occurs'];
						$notifications[$notificationLoop]['subject'] 	 	= $subject;
						$notifications[$notificationLoop]['receiver_id'] 	= $pcUser->user_id;
						$notifications[$notificationLoop]['user_id'] 		= $pcUser->user_id;
						$notifications[$notificationLoop]['user_role_id'] 	= $pcUser->user_role_id;
						$notifications[$notificationLoop]['location_id'] 	= $pcUser->location_id;
						$notificationLoop++;
					}
				}
			}
			
			if(isset($events) && is_array($events) && count($events)) {
				foreach($events as $key_event => $value_event) {
//					echo "<br/>==Line==".__LINE__."==File==".__FILE__."==shift_bike_available==>".$value_event['shift_bike_available']."<====bikeAvailable==>".$bikeAvailable."<==";
					if($value_event['shift_bike_available'] > $bikeAvailable) {
						$bike_available	= ($value_event['shift_bike_available'] > $bikeAvailable) ? $bikeAvailable: $value_event['shift_bike_available'];
						$total_bike		= ($value_event['shift_bike_available'] > $bikeAvailable) ? $bikeAvailable + ($value_event['event_total_bikes'] - $value_event['shift_bike_available']): $value_event['event_total_bikes'];
						$event_id 		= $value_event['event_id'];
						$updates  		= array(
							'bike_available' => $bike_available,
							'total_bike' 	 => $total_bike,
							'event_id' 		 => $event_id,
							'shift_occurs' 	 => 2
						);
						$this->getTable("ShiftRequestTable")->updateBikesAvailable($updates, 2);
						
						/*
						* 	TODO :  Need to send the Notifications to Locations Managers and Drivers
						*	1 - Reduced the Shift Bikes reservation, 2 - Reduced the Shift Bikes reservation and Cancel the Allocations
						*/
						$msg			= '('.$this->shiftTypeArray[$value_event['shift_type']].' Shift Timing : '.$this->convertTimeFormat($value_event['shift_start_time']).'-'.$this->convertTimeFormat($value_event['shift_end_time']).')';
						if($value_event['shift_bike_available'] > $bikeAvailable) {
							$subject	= 'Event Bike confirmation affect the other shifts '.$msg;
						} else {
							$subject	= 'Event Bike confirmation affect the other shifts '.$msg.'. So Manager could check and change the assigned driver status to on call list';
						}
						
						$notifications[$notificationLoop]['notify_date'] 	= $value_event['event_date'];
						$notifications[$notificationLoop]['notify_type'] 	= 7;
						$notifications[$notificationLoop]['shift_id'] 	 	= $value_event['shift_id'];
						$notifications[$notificationLoop]['event_id'] 		= $value_event['event_id'];
						$notifications[$notificationLoop]['shift_occurs'] 	= $value_event['shift_occurs'];
						$notifications[$notificationLoop]['subject'] 	 	= $subject;
						$notifications[$notificationLoop]['receiver_id'] 	= $pcUser->user_id;
						$notifications[$notificationLoop]['user_id'] 		= $pcUser->user_id;
						$notifications[$notificationLoop]['user_role_id'] 	= $pcUser->user_role_id;
						$notifications[$notificationLoop]['location_id'] 	= $pcUser->location_id;
						$notificationLoop++;
					}
				}
			}
			
			// Send the Notifications for Confirmed Drivers
			if(isset($notifications) && is_array($notifications) && count($notifications)) {
//				echo "<br/>==Line==".__LINE__."==File==".__FILE__."==notifications==><pre>"; print_r($notifications); echo "</pre><==";
				$this->sendShiftAllocationNote($notifications);
			}
		}
		
	 }	//	End - checkBikeAvailability
	 
	/*	Action	: 	Send Shift Allocation Note 
	*	Detail	:	Used to Send Shift Allocation Note to Drivers
	*	TODO	:	Mail sending is inprocess
	*/
	public function sendShiftAllocationNote($notifications = false)
    {
        if($notifications && is_array($notifications) && count($notifications)) {
			foreach($notifications as $key => $notification) {
				$insert_array[]		 = "'".$notification['shift_id']."','".$notification['user_id']."','".$notification['receiver_id']."','".$notification['user_role_id']."','".$notification['location_id']."',0,now(),0,0,'".addslashes($notification['subject'])."','".addslashes($notification['notify_date'])."','".addslashes($notification['notify_type'])."'";
			}
			if(isset($insert_array) && is_array($insert_array) && count($insert_array) > 0) {
				$insert_multi_string = "(".implode("),(",$insert_array).")";
			}
			if(isset($insert_multi_string) && $insert_multi_string != '') {
				$this->getTable("ShiftTable")->insertManagerNotification($insert_multi_string);
			}
		}
    }
	
	
	/*
	*	Function to Check the Bike Availability
	*	Condition handling for Bikes reservation of one shift confirmation may affect other shifts (and the quantity of bikes left available)
	*/
	 public function checkDriversAvailability($shiftDetails, $type, $pcUser)
	 {
//		$shiftDetails['start_time']	= ''; $shiftDetails['end_time']	= '';
		
		$bikeAvailables		= array();
		$bikeResults		= $this->getTable("ShiftRequestTable")->getBikesAvailable($shiftDetails['shift_date']);
		if($bikeResults) {
			foreach($bikeResults as $key => $value) {
				$bikeAvailables	= $value;
			}
		}
		
		/*
		*	Get the Available bikes for all shifts in a particulat day.
		*/
		$bikeRequired	=  $bikeAllocated  =  0;
		$availableDrivr	=  $repeating  =  $events  =  array();
		$results		=  $this->getTable("ShiftRequestTable")->getAllShiftAvailableDrivers($shiftDetails);
		$startTime		=  $shiftDetails['start_time'];
		$endTime		=  $shiftDetails['end_time'];
		if($results) {
			foreach($results as $key => $value) {
				if($value['shift_occurs'] == 1) {
					 $repeating[$value['shift_dt_id']] = $value;
					 $bikeAllocated += ($value['shift_dt_total_bikes'] - $value['shift_dt_bike_available']);
					/*if($shiftDetails['special_id'] != $value['shift_dt_id']) {
					   $repeating[$value['shift_dt_id']] = $value;
					} else {
					  $bikeAllocated += ($value['shift_dt_total_bikes'] - $value['shift_dt_bike_available']);
					}*/
				} else {
					$events[$value['event_id']] 	= $value;
					$bikeAllocated += ($value['event_total_bikes'] - $value['shift_bike_available']);
					/*if($shiftDetails['special_id'] != $value['event_id']) {
					   $events[$value['event_id']] 	= $value;
					} else {
					  $bikeAllocated += ($value['event_total_bikes'] - $value['shift_bike_available']);
					}*/
				}
				$count				= ($value['shift_occurs'] == 1) ? $value['shift_dt_bike_available'] : $value['shift_bike_available'];
				$bikeRequired 	   += $count;
				$availableBikes[]   = $value;
			}
		}
		
		
	 }	//	End - checkBikeAvailability
	 
	/*
	*	Function to check the given fields is fount for not in given array.
	*/
	public function customIsset($field = '', $formData = '') {
		$returnVal		= '';
		if($field && is_array($formData) && count($formData)) {
			$returnVal	= (isset($formData[$field])) ? $formData[$field] : '';
		}
		return $returnVal;
    }
	
	/*
	*	Function to used to convert the Object as array.
	*/
	public function toArray($obj) {
	    if(is_object($obj)) $obj = (array) $obj;
	    if(is_array($obj)) {
	      $new = array();
	      foreach($obj as $key => $val) {
	        $new[$key] = self::toArray($val);
	      }
	    }
	    else {
	      $new = $obj;
	    }
	    return $new;
	}
	
	/*
	*	Function to convert the as 12 and 24 hours formates.
	*/
	public function convertTimeFormat($time = '',$stamp = '')
	{
		$convertedTime = '';
		if($time)
		{
			if($stamp == 1)
			{
				$convertedTime = date('H:i:s', strtotime($time)); //to 24 Hour format
			}
			else
			{
				$convertedTime = date('h:i A', strtotime($time));//$convertedTime = date('h:i:s A', strtotime($time)); //to 12 Hour format
			}
		}
		return $convertedTime;
	}
	
	/*	Action	: 	Site Mail Sending
	*	Detail	:	Send the mails
	*/
	public function siteMailSending($contentData, $mailArray)
    {
		// Assign Global Mail Data. It's Accessed on the required templates
		global $mailData;
		
//		if (!isset($this->sendMail)) {
            $this->sendMail 	= $this->sm->get('viewhelpermanager')->get('sendMail');
//      }
		
		$mailData['mail_data']  = $contentData;
		$mailData['mail_title'] = $mailArray['mail_title'];
		$mailData['mail_descriptions']  = $mailArray['mail_descriptions'];
		
		// Empty site name
		if(!isset($mailArray['site_name']) || empty($mailArray['site_name'])) {
			$mailData['site_name']		=	$this->siteDetail['siteName'];
		}
		
		// Empty site name
		if(!isset($mailArray['site_path']) || empty($mailArray['site_path'])) {
			$mailData['site_path']		=	$this->siteDetail['sitePath'];
		}
		//'template_name'		=	'usermanagement/mail_templates/registration_mail_template';
		// Render the Mail templates.
		$templateName			= (isset($mailArray['template_path']) && !empty($mailArray['template_path'])) ? $mailArray['template_path'] : 'usermanagement/mail_templates/registration_mail_template';
		$content 				= $this->renderer->render($templateName, null);
		$mailArray['content']	= $content;
		
		// Empty admin email
		if(!isset($mailArray['from_email']) || empty($mailArray['from_email'])) {
			$mailArray['from_email']	=	$this->siteDetail['adminEmail'];
		}
		
		// Empty admin name
		if(!isset($mailArray['from_name']) || empty($mailArray['from_name'])) {
			$mailArray['from_name']	=	$this->siteDetail['adminName'];
		}
		
		if(isset($mailArray['mail_preview']) && $mailArray['mail_preview'] == 1) {
			// Preview Send mails
			$this->sendMail->previewMailSend($mailArray);
		} else {
			// Send mails
			$this->sendMail->mailSend($mailArray);
		}
		
		return true;
    }
	
	/*	Action	: 	Site Mail Sending
	*	Detail	:	Send the mails
	*/
	public function setUsersDetails($userId)
    {
		$userSession  = new Container('pcUsers');
		$usersDetail  = '';
		$results	  = $this->getTable("UsersTable")->getUserDetailById($userId);
		if($results) {
			foreach($results as $user) {
			  $usersDetail 	= (array)$user;
			}
			$userSession->pc_users	= (object)$usersDetail;
		}
	}
	
	public function commonDataTesting()
    {
		echo "====>5<==";
	}
	public function forceDownload($fileName, $filePath, $fileSize, $fileExt)
	{
		//Required for IE, otherwise Content-disposition is ignored
		if(ini_get('zlib.output_compression'))
		{
			ini_set('zlib.output_compression', 'Off');
		}
		/*header("Content-type: application/vnd.ms-word");
		header("Content-Disposition: attachment; Filename=SaveAsWordDoc.doc");*/
		switch($fileExt)
		{
			case "pdf": $ctype="application/pdf"; break;
			case "exe": $ctype="application/octet-stream"; break;
			case "zip": $ctype="application/zip"; break;
			case "doc": $ctype="application/vnd.ms-word"; break;
			case "docx":$ctype="application/msword"; break;
			case "xls": $ctype="application/vnd.ms-excel"; break;
			case "xlsx": $ctype="application/vnd.ms-excel"; break;
			case "ppt": $ctype="application/vnd.ms-powerpoint"; break;
			case "gif": $ctype="image/gif"; break;
			case "png": $ctype="image/png"; break;
			case "jpe": case "jpeg":
			case "jpg": $ctype="image/jpg"; break;
			case "txt": $ctype="text/plain"; break;
			case "mp3": $ctype="audio/mpeg"; break;
			case "wav": $ctype="audio/x-wav"; break;
			case "mpg": case "mpeg":
			case "mpe": $ctype="video/mpeg"; break;
			case "mov": $ctype="video/quicktime"; break;
			case "avi": $ctype="video/x-msvideo"; break;
			case "flv": $ctype="application/flv"; break;
			case "txt": $ctype="text/plain"; break;
			default: $ctype="application/force-download";
		}
		$this->ob_clean_all();
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false);
		header("Content-Type: $ctype");
		header("Content-Disposition: attachment; filename=".$fileName.";" );
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: ". $fileSize);
		readfile($filePath);
		exit();
	}
	public function ob_clean_all()
	{
		$ob_active = ob_get_length ()!== FALSE;
		while($ob_active)
		{
			ob_end_clean();
			$ob_active = ob_get_length ()!== FALSE;
		}
		return FALSE;
	}
	
	/*	Action	: 	Get Session Details
	*	Detail	:	getSessionDetails
	*/
	public function getSessionDetails($sessionKey)
    {
		$sessionValue  = new Container($sessionKey);
		return $sessionValue;
	}
	public function removeZerosInDate($date)
	{
		$dateNew	= date('n-j-Y',strtotime($date));
		return $dateNew;
	}
	
	/*	Get Historuical Data for Revenue and Drivers Shoft Counts.
	*	Detail	:	Condition handling arguments type is used. $type : 1  -  listing,  2  -  View page
	*/
	public function getRevenueHistoricalDataDetails($type = 1, $dateDetails = '') {
		$revenueDetails		= array();
		
		if($type == 2) {
			$revenueResults		=  $this->getTable('LeasePaymentsTable')->viewRevenueHistoricalData($dateDetails);
		} else {
			$revenueResults		=  $this->getTable('LeasePaymentsTable')->getRevenueHistoricalData();
		}
		if($revenueResults) {
			foreach($revenueResults as $revenue) {
				$totalRevenue	=  $revenue['total_lease_payment'] - $revenue['total_discount_amount'];
				$shiftCount		=  floor($revenue['shift_count'] / 4);
				
				// Actual Revenue
				if(isset($revenueDetails[$revenue['shifts_date_new']]['actualRevenue'])) {
					$revenueDetails[$revenue['shifts_date_new']]['actualRevenue'] += $totalRevenue;
				} else {
					$revenueDetails[$revenue['shifts_date_new']]['actualRevenue']  = $totalRevenue;
				}
				
				//	Shift Counts
				if(isset($revenueDetails[$revenue['shifts_date_new']]['shiftCount'])) {
					$revenueDetails[$revenue['shifts_date_new']]['shiftCount'] 	  += $shiftCount;
				} else {
					$revenueDetails[$revenue['shifts_date_new']]['shiftCount'] 	   = $shiftCount;
				}
			}
		}
		return $revenueDetails;
	}
	
	/*
	*	Custom report json array
	*	$dataArray  : Input data
	*	$reports    : Identify the Reports like 1 - Occupancy Rate, 2 - New Users, 3 - Actual Revenue, 4 - Actual Lease Payments, 5 - Forecasted Revenue, 6 - Financial Goals
	*	$type		: Identify the view type ie: 1 - Day, 2 - Week, 3 - Month, 4 - Year
	*	Sample Data : {'title' : 'Occupancy Rate', 'xAxis' : ['2004', '2005', '2006', '2007', '2008'], 'yAxis' : 'Percentage (%)', 'valueSuffix' : '%', 'name' : 'Occupancy Rate', 'data' : [80, 91.6, 96.3, 93.2, 97.1]}
	*/
	public function customJsonArrayForReports($dataArray = false, $reports = 1, $type = 1) {
		$jsonArray	=  array();
		$statusFlag = true;
		$errorMsg	= '';
		if($dataArray && count($dataArray)) {
			
			if($reports == 1) {
					
					if($type == 2) {
						$xAxis	=  array('4/1/2013 - 4/7/2013', '4/8/2013 - 4/14/2013', '4/15/2013 - 4/21/2013', '4/22/2013 - 4/28/2013', '4/29/2013 - 5/5/2013', '5/6/2013 - 5/12/2013', '<span style="color:#ff0000;">5/13/2013 - 5/19/2013</span>');
						$data 	=  array(80, 91.6, 96.3, 93.2, 97.1, 97.7, 83.3);
					} else if($type == 3) {
						$xAxis	=  array('Jul 2012', 'Aug 2012', 'Sep 2012', 'Oct 2012', 'Nov 2012', 'Dec 2012', 'Jan 2013', 'Feb 2013', 'Mar 2013', '<span style="color:#ff0000;">Apr 2013</span>');
						$data 	=  array(80, 91.6, 96.3, 93.2, 97.1, 97.7, 83.3, 80, 95.8, 75);
					} else if($type == 4) {
						$xAxis	=  array('2004', '2005', '2006', '2007', '2008', '2009', '2010', '2011', '2012', '<span style="color:#ff0000;">2013</span>');
						$data 	=  array(80, 91.6, 96.3, 93.2, 97.1, 97.7, 83.3, 80, 95.8, 75);
					} else {
						$xAxis	=  array('4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>');
						$data 	=  array(96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3);
					}
					
					$dataArray	=  array('type' 		=> 'line',
										 'title' 		=> 'Occupancy Rate',
										 'xAxis' 		=> $xAxis,
										 'yAxis' 		=> 'Percentage (%)',
										 'valueSuffix' 	=> '%',
										 'name' 		=> 'Occupancy Rate',
									     'data' 		=> $data,
										 'statusFlag' 	=> $statusFlag,
										 'errorMsg' 	=> $errorMsg
										 );
					$jsonArray		=	json_encode($dataArray);
			}
		} else {
			$statusFlag = false;
			$errorMsg	= 'No Data Found';
			$dataArray	=  array('statusFlag' 	=> $statusFlag,
								 'errorMsg' 	=> $errorMsg
								 );
			$jsonArray	= json_encode($dataArray);
		}
		return $jsonArray;
	}
	
}