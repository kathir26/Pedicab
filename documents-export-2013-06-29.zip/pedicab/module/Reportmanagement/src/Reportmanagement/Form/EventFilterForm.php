<?php
namespace Reportmanagement\Form;

use Zend\Form\Form;

class EventFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('reportmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'event_filter_form');
		$this->setAttribute('name', 'event_filter_form');
		
		$this->add(array(
            'name' 		 => 'event_pay_status',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'event_pay_status'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Event Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Event date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'event_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'event_title',
				'class'								=> 'wid240',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Event Name',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Event Name is required!',
				'data-errormessage' 			 	=> 'Event Name is invalid!',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_event_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_event_submit',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_event_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_event_reset',
            ),
        ));
    }
}
?>