<?php
namespace Reportmanagement\Form;

use Zend\Form\Form;

class DepositLeaseFeesFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('reportmanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'deposit_lease_fees_filter_form');
		$this->setAttribute('name', 'deposit_lease_fees_filter_form');
		
		$this->add(array(
            'name' 		 => 'lease_status',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'lease_status'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'shift_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'shift_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Shift Date',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'user_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_name',
				'class'								=> 'wid240',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'User Name',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'User Name is required!',
				'data-errormessage' 			 	=> 'User Name is invalid!',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' 		 => 'search_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_submit',
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'search_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_reset',
            ),
        ));
    }
}
?>