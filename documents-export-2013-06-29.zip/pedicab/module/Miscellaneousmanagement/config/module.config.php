<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

return array(
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'miscellaneousmanagement\Controller\Schedule',
                        'action'     => 'meeting-schedule',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'miscellaneousmanagement' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/miscellaneousmanagement[/[:controller[/[:action[/[:id]]]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Miscellaneousmanagement\Controller',
                        'controller'    => 'Schedule',
                        'action'        => 'meeting-schedule',
                    ),
                ),
                'may_terminate' => true,
                'child_routes'  => array(
                    'default'   => array(
                        'type'    => 'Segment',
                        'options' => array(
							'route'    	  => '/miscellaneousmanagement[/[:controller[/[:action[/[:id]]]]]]',
							'constraints' => array(
                        		'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
								'action' 	 => '[a-zA-Z][a-zA-Z0-9_-]*',
                        		'id'     	 => '[a-zA-Z][a-zA-Z0-9_-]*',
							),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			'meeting-schedule-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/meeting-schedule-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Miscellaneousmanagement\Controller',
                        'controller'    => 'Schedule',
                        'action'        => 'meeting-schedule-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'meeting-schedule-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/meeting-schedule-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' 	=> 'Miscellaneousmanagement\Controller',
                        'controller'   	=> 'Schedule',
                        'action'      	=> 'meeting-schedule-list',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-document-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-document-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Miscellaneousmanagement\Controller',
                        'controller'    => 'Document',
                        'action'        => 'manage-documents-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-document-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-document-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' 	=> 'Miscellaneousmanagement\Controller',
                        'controller'   	=> 'Document',
                        'action'      	=> 'manage-documents-list',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-video-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-video-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Miscellaneousmanagement\Controller',
                        'controller'    => 'Document',
                        'action'        => 'video-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'manage-video-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/manage-video-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' 	=> 'Miscellaneousmanagement\Controller',
                        'controller'   	=> 'Document',
                        'action'      	=> 'video-list',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'contract-reminder-sort' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/contract-reminder-sort[/[:sortBy[/[:sortType]]]]',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Miscellaneousmanagement\Controller',
                        'controller'    => 'Reminder',
                        'action'        => 'contract-reminder-list',
						'sortBy' 		=> '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
			'contract-reminder-page' => array(
                'type'    => 'Segment',
                'options' => array(
					'route'    => '/contract-reminder-page[/[:perPage]]',
                    'defaults' => array(
                       '__NAMESPACE__' 	=> 'Miscellaneousmanagement\Controller',
                        'controller'   	=> 'Reminder',
                        'action'      	=> 'contract-reminder-list',
						'perPage' 	    => '[a-zA-Z][a-zA-Z0-9_-]*',
                    ),
                ),
            ),
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
	'controllers' => array(
        'invokables' => array(
			'miscellaneousmanagement\Controller\Schedule'	 	=> 'Miscellaneousmanagement\Controller\ScheduleController',
			'miscellaneousmanagement\Controller\Document'	 	=> 'Miscellaneousmanagement\Controller\DocumentController',
			'miscellaneousmanagement\Controller\Reminder'	 	=> 'Miscellaneousmanagement\Controller\ReminderController',
        ),
    ),
	'controller_plugins' => array(
	    'invokables' => array(
	       'Myplugin' 	  => 'Usermanagement\Controller\Plugin\Myplugin',
		   'MyFileUpload' => 'Usermanagement\Controller\Plugin\MyFileUpload',
	     )
	 ),
	'view_helpers' => array(
		'invokables' => array(
			'datetime' 	 => 'Usermanagement\View\Helper\Datetime',
			'commonData' => 'Usermanagement\View\Helper\CommonData',
		),
	),
    'view_manager' => array(
		'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           	 => __DIR__ . '/../../Usermanagement/view/layout/layout.phtml',
            'error/404'               	 => __DIR__ . '/../view/error/404.phtml',
            'error/index'             	 => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
