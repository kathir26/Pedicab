<?php
namespace Miscellaneousmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class ScheduleTable extends AbstractTableGateway
{
    protected $table = 'meeting';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Parts());
        $this->initialize();
    }
	
	public function getuserDetails($locationId,$role,$userId)
	{
		$where		= " and user_role_id in (".$role.") and user_id != ".$userId;
		if(isset($locationId) && $locationId != '')
		{
			$where	.= " and location_id = ".$locationId;
		}
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertMeeting($data)
    {
        $sql 				= "insert into meeting set ".$data;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updateMeeting($data,$meetingId)
    {
	    $sql		= " update meeting set ".$data." where meeting_id = ".$meetingId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getMeetingScheduleList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 				= $userSession->pc_users;
		}
		$locationId	 		 		= $pcUser->location_id;
		$whereClause   	  	 		= ' WHERE 1 and m.meeting_isdelete = 0 and m.meeting_location = '.$locationId;
		if(isset($pcUser->user_role_id) && ($pcUser->user_role_id == 1 || $pcUser->user_role_id == 2))
		{
			$whereClause   	  	 	.= ' and m.meeting_to = '.$pcUser->user_role_id;
		}
		else if(isset($pcUser->user_role_id) && $pcUser->user_role_id != 5)
		{
			$whereClause   	  	 	.= ' and m.fk_user_id = '.$pcUser->user_id;
		}
		$meetingScheduleSession  	=  new Container('meetingScheduleListing');
		if($meetingScheduleSession->offsetExists('meeting_date') && $meetingScheduleSession->meeting_date != '') {
			$tempDate		 		= str_replace('-', '/', $meetingScheduleSession->meeting_date);
			$meeting_date   	 	= date('Y-m-d', strtotime($tempDate));
			$whereClause			.= ' AND m.meeting_date = "' . addslashes($meeting_date) . '"';
		}
		if($meetingScheduleSession->offsetExists('meeting_loc') && $meetingScheduleSession->meeting_loc != '') {
			$whereClause			.= ' AND l.loc_title like "%' . $meetingScheduleSession->meeting_loc . '%"';
		}
		$orderClause		 		= '';
		if($meetingScheduleSession->offsetExists('sortBy')) {
			$orderClause			.= ' ORDER BY '.$meetingScheduleSession->sortBy;
		}
		
		if($meetingScheduleSession->offsetExists('sortType') && $meetingScheduleSession->sortType == 1) {
			$orderClause			.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause			.= ' ORDER BY m.meeting_id DESC';
		}
		if(isset($pc_users->user_role_id) && $pc_users->user_role_id == 5)
		{
			$orderClause			.= ' m.meeting_status asc';
		}
		$sql	= ' SELECT m.*,l.loc_title from meeting as m
						left join location as l on (m.meeting_location = l.loc_id) '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function insertManagerNotification($insert_string)
    {
		$sql 				= " INSERT INTO manager_notification (fk_meeting_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insert_string;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getMeetingDetails($meetingId)
	{
		$sql 		= "SELECT m.*,l.loc_title from meeting as m left join location as l on (m.meeting_location = l.loc_id) where meeting_id = ".$meetingId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getParticularMeetingDetails($meetingId)
	{
		$sql 		= "SELECT * from meeting where meeting_id = ".$meetingId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertDocument($data)
    {
        $sql 				= "insert into document set ".$data;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updateDocument($data,$documentId)
    {
	    $sql		= " update document set ".$data." where document_id = ".$documentId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function getDocumentList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 				= $userSession->pc_users;
		}
		$locationId	 		 		= $pcUser->location_id;
		$whereClause   	  	 		= ' WHERE 1 and document_isdelete = 0 and document_type = 1 and fk_location_id = '.$locationId;
		if(isset($pcUser->user_role_id) && $pcUser->user_role_id != 5)
		{
			$whereClause   	  	 	.= ' and fk_user_id = '.$pcUser->user_id;
		}
		$manageDocumentSession  	=  new Container('manageDocumentListing');
		if($manageDocumentSession->offsetExists('document_date') && $manageDocumentSession->document_date != '') {
			$tempDate		 		= str_replace('-', '/', $manageDocumentSession->document_date);
			$meeting_date   	 	= date('Y-m-d', strtotime($tempDate));
			$whereClause			.= ' AND DATE(document_created_date) = "' . addslashes($meeting_date) . '"';
		}
		if($manageDocumentSession->offsetExists('document_title') && $manageDocumentSession->document_title != '') {
			$whereClause			.= ' AND document_title like "%' . $manageDocumentSession->document_title . '%"';
		}
		$orderClause		 		= '';
		if($manageDocumentSession->offsetExists('sortBy')) {
			$orderClause			.= ' ORDER BY '.$manageDocumentSession->sortBy;
		}
		
		if($manageDocumentSession->offsetExists('sortType') && $manageDocumentSession->sortType == 1) {
			$orderClause			.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause			.= ' ORDER BY document_id DESC';
		}
		
		$sql	= ' SELECT * from document '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getDocumentDetails($documentId)
	{
		$sql 		= "SELECT * from document where document_id = ".$documentId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getVideoList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 				= $userSession->pc_users;
		}
		$locationId	 		 		= $pcUser->location_id;
		$whereClause   	  	 		= ' WHERE 1 and document_isdelete = 0 and document_type = 2 and fk_location_id = '.$locationId;
		if(isset($pcUser->user_role_id) && $pcUser->user_role_id != 5)
		{
			$whereClause   	  	 	.= ' and (fk_user_id = '.$pcUser->user_id.' || FIND_IN_SET('.$pcUser->user_role_id.',document_share))';
		}
		$videoTrainingSession  	=  new Container('videoTrainingListing');
		if($videoTrainingSession->offsetExists('video_date') && $videoTrainingSession->video_date != '') {
			$tempDate		 		= str_replace('-', '/', $videoTrainingSession->video_date);
			$meeting_date   	 	= date('Y-m-d', strtotime($tempDate));
			$whereClause			.= ' AND DATE(document_created_date) = "' . addslashes($meeting_date) . '"';
		}
		if($videoTrainingSession->offsetExists('video_title') && $videoTrainingSession->video_title != '') {
			$whereClause			.= ' AND document_title like "%' . $videoTrainingSession->video_title . '%"';
		}
		$orderClause		 		= '';
		if($videoTrainingSession->offsetExists('sortBy')) {
			$orderClause			.= ' ORDER BY '.$videoTrainingSession->sortBy;
		}
		
		if($videoTrainingSession->offsetExists('sortType') && $videoTrainingSession->sortType == 1) {
			$orderClause			.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause			.= ' ORDER BY document_id DESC';
		}
		
		$sql	= ' SELECT * from document '.$whereClause . ' ' . $orderClause;
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function insertVideoNotification($insertString)
    {
		$sql 				= " INSERT INTO manager_notification (fk_document_id,fk_sender_user_id,fk_receiver_user_id,fk_role_id,fk_location_id,notification_status,notification_created_date,notification_sender_delete,notification_receiver_delete,notification_subject,notification_date,notification_type) values ".$insertString;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function getReminderList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 				= $userSession->pc_users;
		}
		$locationId	 		 		= $pcUser->location_id;
		$whereClause   	  	 		= ' WHERE 1 and user_isdelete = 0 and user_status = 1 and user_role_id in ("1,2") and location_id = '.$locationId;
		$reminderContractSession  	=  new Container('reminderContractListing');
		if($reminderContractSession->offsetExists('start_date') && $reminderContractSession->start_date != '') {
			$tempDate		 		= str_replace('-', '/', $reminderContractSession->start_date);
			$meeting_date   	 	= date('Y-m-d', strtotime($tempDate));
			$whereClause			.= ' AND DATE(user_leasecontract_date) >= "' . addslashes($meeting_date) . '"';
		}
		if($reminderContractSession->offsetExists('end_date') && $reminderContractSession->end_date != '') {
			$endtempDate		 	= str_replace('-', '/', $reminderContractSession->end_date);
			$endDate   	 			= date('Y-m-d', strtotime($endtempDate));
			$whereClause			.= ' AND DATE(user_leasecontract_date) <= "' . addslashes($endDate) . '"';
		}
		if($reminderContractSession->offsetExists('name') && $reminderContractSession->name != '') {
			$whereClause			.= ' AND user_firstname like "%' . $reminderContractSession->name . '%"';
		}
		$orderClause		 		= '';
		if($reminderContractSession->offsetExists('sortBy')) {
			$orderClause			.= ' ORDER BY '.$reminderContractSession->sortBy;
		}
		
		if($reminderContractSession->offsetExists('sortType') && $reminderContractSession->sortType == 1) {
			$orderClause			.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause			.= ' ORDER BY user_leasecontract_date ASC';
		}
		
		$sql		= ' SELECT * from user '.$whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function getParticularUserDetails($userId)
	{
		$where		= " and user_id = ".$userId;
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function updateLease($data,$userId)
    {
	    $sql		= " update user set ".$data." where user_id = ".$userId;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
}