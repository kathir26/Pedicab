<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Miscellaneousmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Miscellaneousmanagement\Form\FilterReminderForm,
	Miscellaneousmanagement\Form\AddReminderForm;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter;

class ReminderController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	protected $meetingToArray;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf','doc', 'docx', 'rtf', 'txt', 'xls', 'csv');	// 
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->meetingToArray		=  array('' => 'Select', '1' => 'Drivers','2' => 'Mechanics','3' => 'General managers');
		$this->fileTypesArray 		=  array('1' => 'pdf', '2' => 'doc', '3' => 'docx', '4' => 'txt', '5' => 'xls', '6' => 'csv', '7' => 'rtf');
		$this->videoFilesArray 		=  array('1' => 'm4v', '2' => 'mp4', '3' => 'ogv', '4' => 'flv', '5' => '3gp', '6' => 'mov', '7' => 'mpeg', '8' => 'mpg', '9' => 'wmv', '10' => 'avi','11' => 'mkv','12' => 'webm');
		$this->videoFormatArray		=  array('mov' => 'mov', 'mp4' => 'mp4', 'ogv' => 'ogg', 'flv' => 'flv', '3gp' => '3gp', 'm4v' => 'mp4', 'mpeg' => 'mpeg', 'mpg' => 'mpeg', 'wmv' => 'wmv', 'avi' => 'avi','mkv' => 'mkv','webm' => 'webm');
		$this->userRoleDetails		=  array('1' => 'Drivers', '2' => 'Mechanics', '3' => 'General Managers');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("LocationTable" => "Location-Table","ScheduleTable" => "Schedule-Table","roleTable" => "Role-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	public function contractReminderAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$startDate					= date('n-j-Y');
		$endDate					= date('n-j-Y',strtotime('+30 days'));
		$paginator					= '';
		// assign default values
		$matches					= $this->getEvent()->getRouteMatch();
		$page						= $matches->getParam('id', 1);
		$sortBy						= $matches->getParam('sortBy', '');
		$sortType					= $matches->getParam('sortType', '');
		$perPage					= $matches->getParam('perPage', '');
		// Create Filter form
		$filterReminderForm			= new FilterReminderForm();
		$addReminderForm			= new AddReminderForm();
		
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('reminderContractListing'));
		$reminderContractSession  	=  new Container('reminderContractListing');
		if(isset($startDate) && $startDate != '')
		{
			$reminderContractSession->start_date	= $startDate;
		}
		if(isset($endDate) && $endDate != '')
		{
			$reminderContractSession->end_date	= $endDate;
		}
		if($request->isPost()) {
			$filterReminderForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['fil_start_date']) && !empty($formData['fil_start_date']))
				$reminderContractSession->start_date	= $formData['fil_start_date'];
			else
				$reminderContractSession->start_date	= '';
			
			if(isset($formData['fil_end_date']) && $formData['fil_end_date'] != '')
				$reminderContractSession->end_date		= $formData['fil_end_date'];
			else
				$reminderContractSession->end_date		= '';
			if(isset($formData['fil_driver_name']) && !empty($formData['fil_driver_name']))
				$reminderContractSession->name			= $formData['fil_driver_name'];
			else
				$reminderContractSession->name			= '';
		}
		
		if($reminderContractSession->offsetExists('start_date') && $reminderContractSession->start_date != '' ) {
			$filterReminderForm->get('fil_start_date')->setValue($reminderContractSession->start_date);
		}
		if($reminderContractSession->offsetExists('end_date') && $reminderContractSession->end_date != '' ) {
			$filterReminderForm->get('fil_end_date')->setValue($reminderContractSession->end_date);
		}
		if($reminderContractSession->offsetExists('name') && $reminderContractSession->name != '' ) {
			$filterReminderForm->get('fil_driver_name')->setValue($reminderContractSession->name);
		}
		// listing
		$perPage					= $this->defaultPerPage;
		$iteratorAdapter			= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getReminderList());
		$paginator					= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$allRoles					= array();
		$roles						= $this->getTable('roleTable')->getAllRoles();
		if($roles) {
			foreach($roles as $role) {
				$allRoles[$role->role_id]  =  $role->role_name;
			}
		}
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterReminderForm'	=> $filterReminderForm,
			'addReminderForm'		=> $addReminderForm,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'roleArray'				=> $allRoles,
			'paginator'				=> $paginator,
			'pc_users'				=> $this->pcUser,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'fileUploadPath'		=> $this->siteImageUploadPath."/contract_image",
			'siteImagePath'			=> $this->siteImagePath,
			'fileTypesArray'		=> $this->fileTypesArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
	}
	public function contractReminderListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$reminderContractSession  	=  new Container('reminderContractListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($reminderContractSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$reminderContractSession->sortBy	= $sortBy;
		} else if($reminderContractSession->offsetExists('sortBy')) {
			$sortBy	= $reminderContractSession->sortBy;
		}
		if($sortType != '') {
			if($reminderContractSession->sortType == $sortType && $columnFlag == 1)
				$reminderContractSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$reminderContractSession->sortType	= $sortType;
		} else if($reminderContractSession->offsetExists('sortType')) {
			$sortType	= $reminderContractSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$reminderContractSession->perPage	= $perPage;
		} else if($reminderContractSession->offsetExists('perPage')) {
			$perPage		= $reminderContractSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getReminderList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$allRoles			= array();
		$roles				= $this->getTable('roleTable')->getAllRoles();
		if($roles) {
			foreach($roles as $role) {
				$allRoles[$role->role_id]  =  $role->role_name;
			}
		}
		$result->setVariables(array(
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'roleArray'			=> $allRoles,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'fileUploadPath'	=> $this->siteImageUploadPath."/contract_image",
			'siteImagePath'		=> $this->siteImagePath,
			'fileTypesArray'	=> $this->fileTypesArray,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function viewContractAction()
    {
		$result 			= new ViewModel();
	    $result->setTerminal(true);
		$userDetails		= '';
		$request 	  		=  $this->getRequest();
		if($request->isPost())
		{
			$formData		= $request->getPost();
			$matches		= $this->getEvent()->getRouteMatch();
			$userId			= $matches->getParam('id', '');
			if($userId > 0)
			{
				$userDetails		= $this->getTable('ScheduleTable')->getParticularUserDetails($userId);
			}
		}
		$allRoles			= array();
		$roles				= $this->getTable('roleTable')->getAllRoles();
		if($roles) {
			foreach($roles as $role) {
				$allRoles[$role->role_id]  =  $role->role_name;
			}
		}
		$result->setVariables(array(
			'roleArray'			=> $allRoles,
			'viewArray'			=> $userDetails,
			'pc_users'			=> $this->pcUser,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function forceDownloadAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$userId 				= (int) $this->params()->fromRoute('id', 0);
		if($userId)
		{
			$userDetails		= $this->getTable('ScheduleTable')->getParticularUserDetails($userId);
			if(is_object($userDetails) && count($userDetails) > 0)
			{
				foreach($userDetails as $userKey => $userValue)
				{
					$fileExt			= 'pdf';
					$filePath			= $this->siteImageUploadPath."/contract_image/".$userValue['user_contract'];
					$fileName			= ucfirst($userValue['user_firstname']).'_'.ucfirst($userValue['user_lastname']).'_Lease'.'.pdf';
					$fileSize 			= filesize($filePath);
					$this->getCommonDataObj()->forceDownload($fileName, $filePath, $fileSize, $fileExt);
				}
			}
		}
		die();
	}
	public function saveReminderAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
	 	$request 						=  $this->getRequest();
		if($request->isPost())
		{
			$formData					= $request->getPost();
			$tempDate		 			= str_replace('-', '/', $formData['lease_date']);
			$leaseDate   	 			= date('Y-m-d', strtotime($tempDate));
			$data						= " user_leasecontract_date			= '".addslashes($leaseDate)."'";
			$userId						= $formData['user_id'];
			$this->getTable('ScheduleTable')->updateLease($data,$userId);
			$fileTransfer 				= new \Zend\File\Transfer\Adapter\Http();
			$fileInfo 	  				= $fileTransfer->getFileInfo();
			if(isset($fileInfo['reminder_file']['name']) && $fileInfo['reminder_file']['name'] != '')
			{
				$fileType					= '';
				$myFileUpload   			= $this->MyFileUpload();
				$myFileUpload->fileTypes	= $this->fileTypes;
				$myFileUpload->fileSizes	= $this->fileSizes;
				$fileNameArray				= array("reminder_file");
				$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
				$myFileUpload->uploadPath	= $this->siteImageUploadPath."/contract_image";
				$fileName					= $myFileUpload->uploadFiles($userId, $fileNameArray);
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'reminder', 'action' => 'contract-reminder'));
	}
	public function editReminderAction()
	{
		$request 		=  $this->getRequest();
		$userDetail		=  array();
		if($request->isPost())
		{
			$userId 	= (int) $this->params()->fromRoute('id', 0);
			if($userId)
			{
				$userDetails		= $this->getTable('ScheduleTable')->getParticularUserDetails($userId);
				if(is_object($userDetails) && count($userDetails) > 0)
				{
					foreach($userDetails as $userKey => $userValue)
					{
						$userDetail['id']			= $userValue['user_id'];
						$userDetail['name']			= $userValue['user_firstname']." ".$userValue['user_lastname'];
						$userDetail['err']			= 0;
					}
				}
				else
				{
					$userDetail['err']				= 1;
				}
			}
			else
			{
				$userDetail['err']					= 1;
			}
		}
		echo json_encode($userDetail);die();
	}
}
