<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Miscellaneousmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Miscellaneousmanagement\Form\AddMeetingForm,
	Miscellaneousmanagement\Form\FilterMeetingForm;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter;

class ScheduleController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	protected $meetingToArray;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->fileTypesArray		=  array('pdf', 'doc', 'docx', 'xls');
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->meetingToArray		=  array('' => 'Select', '1' => 'Drivers','2' => 'Mechanics','3' => 'General managers');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("LocationTable" => "Location-Table","ScheduleTable" => "Schedule-Table","roleTable" => "Role-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	public function meetingScheduleAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$paginator					= '';
		// assign default values
		$matches					= $this->getEvent()->getRouteMatch();
		$page						= $matches->getParam('id', 1);
		$sortBy						= $matches->getParam('sortBy', '');
		$sortType					= $matches->getParam('sortType', '');
		$perPage					= $matches->getParam('perPage', '');
		// Create Filter form
		$filterMeetingForm			= new FilterMeetingForm();
		//	Destroy listing Session Vars
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('meetingScheduleListing'));
		$meetingScheduleSession  	=  new Container('meetingScheduleListing');
		if($request->isPost()) {
			$filterMeetingForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['fil_meeting_date']) && !empty($formData['fil_meeting_date']))
				$meetingScheduleSession->meeting_date	= $formData['fil_meeting_date'];
			else
				$meetingScheduleSession->meeting_date	= '';
			
			if(isset($formData['fil_meeting_loc']) && $formData['fil_meeting_loc'] != '')
				$meetingScheduleSession->meeting_loc	= $formData['fil_meeting_loc'];
			else
				$meetingScheduleSession->meeting_loc	= '';
		}
		
		if($meetingScheduleSession->offsetExists('meeting_date') && $meetingScheduleSession->meeting_date != '' ) {
			$filterMeetingForm->get('fil_meeting_date')->setValue($meetingScheduleSession->meeting_date);
		}
		if($meetingScheduleSession->offsetExists('meeting_loc') && $meetingScheduleSession->meeting_loc != '' ) {
			$filterMeetingForm->get('fil_meeting_loc')->setValue($meetingScheduleSession->meeting_loc);
		}
		// listing
		$perPage					= $this->defaultPerPage;
		$iteratorAdapter			= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getMeetingScheduleList());
		$paginator					= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'filterMeetingForm'		=> $filterMeetingForm,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'pc_users'				=> $this->pcUser,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'fileUploadPath'		=> $this->siteImageUploadPath."/meeting_report",
			'fileArray'				=> $this->fileTypesArray,
			'perPageArray'			=> $this->perPageArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function meetingScheduleListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$meetingScheduleSession  	=  new Container('meetingScheduleListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($meetingScheduleSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$meetingScheduleSession->sortBy	= $sortBy;
		} else if($meetingScheduleSession->offsetExists('sortBy')) {
			$sortBy	= $meetingScheduleSession->sortBy;
		}
		if($sortType != '') {
			if($meetingScheduleSession->sortType == $sortType && $columnFlag == 1)
				$meetingScheduleSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$meetingScheduleSession->sortType	= $sortType;
		} else if($meetingScheduleSession->offsetExists('sortType')) {
			$sortType	= $meetingScheduleSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$meetingScheduleSession->perPage	= $perPage;
		} else if($meetingScheduleSession->offsetExists('perPage')) {
			$perPage		= $meetingScheduleSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getMeetingScheduleList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'fileUploadPath'	=> $this->siteImageUploadPath."/meeting_report",
			'fileArray'			=> $this->fileTypesArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function addMeetingAction()
    {
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		$allLocationDetails =  $locationArray = array();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$addMeetingForm				= new AddMeetingForm();
		/*$locationArray				= $this->getTable('LocationTable')->getAllLocationDetails();
		$allLocationDetails['']		= 'Select Location';
		if(is_object($locationArray) && count($locationArray) > 0)
		{
			foreach($locationArray as $locKey => $locValue)
			{
				$allLocationDetails[$locValue->loc_id]		= $locValue->loc_title;
			}
		}*/
		$addMeetingForm->get('meeting_to')->setValueOptions($this->meetingToArray);
		$addMeetingForm->get('meeting_location')->setValue($identity->location_id);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addMeetingForm'		=> $addMeetingForm,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function saveMeetingScheduleAction()
    {
		$auth 	 	  		=  new AuthenticationService();
		$insertNotifyArray	= array();
		$notifySubject 		= $notifySubject = $notifyDate = $notifyType = $locationId = $userRoleId = $meetingId = $meetingDate = '';
		if ($auth->hasIdentity()) {
		    $identity 		= $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$request 			= $this->getRequest();
		if($request->isPost())
		{
			$formData		= $request->getPost();
			if(isset($formData['meeting_to']) && $formData['meeting_to'] != '')
			{
				$userRoleId			= 5;
				$locationId			= $formData['meeting_location'];
				/*if(isset($formData['meeting_to']) && $formData['meeting_to'] != 1)
				{
					if(isset($formData['meeting_send_notif']) && $formData['meeting_send_notif'] == 1)
					{
						$userRoleId		.= ",1";
					}
				}*/
				if(isset($formData['meeting_date']) && $formData['meeting_date'] != '')
				{
					$locationDate		= explode('-',$formData['meeting_date']);
					if(is_array($locationDate) && count($locationDate) > 0)
					{
						$meetingDate	= $locationDate[2]."-".$locationDate[0]."-".$locationDate[1];
					}
				}
				$meetingTime			= $this->getCommonDataObj()->convertTimeFormat($formData['meeting_time'],1);
				$insertMeetingData		= " meeting_date			= '".addslashes($meetingDate)."',
											meeting_location		= '".addslashes($locationId)."',
											fk_user_id				= '".addslashes($identity->user_id)."',
											meeting_time			= '".addslashes($meetingTime)."',
											meeting_to				= '".addslashes($formData['meeting_to'])."',
											meeting_attendees		= '".addslashes($formData['meeting_attendees'])."',
											meeting_budget_request	= '".addslashes($formData['meeting_budget'])."',
											meeting_add_notes		= '".addslashes($formData['meeting_add_notes'])."',
											meeting_venue			= '".addslashes($formData['meeting_venue'])."',
											meeting_description		= '".addslashes($formData['meeting_description'])."',
											meeting_isdelete		= 0";//meeting_notif_send		= '".addslashes($formData['meeting_send_notif'])."',
				if(isset($formData['meeting_id']) && $formData['meeting_id'] != '')
				{
					$insertMeetingData		.= ",meeting_update_date	= now()";
					$meetingId				= $formData['meeting_id'];
					$this->getTable('ScheduleTable')->updateMeeting($insertMeetingData,$meetingId);
				}
				else
				{
					$insertMeetingData		.= ",meeting_created_date	= now()";
					$meetingId				= $this->getTable('ScheduleTable')->insertMeeting($insertMeetingData);
				}
				if(!isset($formData['meeting_id']))
				{
					$getRoleDetails			= $this->getTable('ScheduleTable')->getuserDetails('',$userRoleId,$identity->user_id);//$locationId
					if(is_object($getRoleDetails) && count($getRoleDetails) > 0)
					{
						$notifySubject		= "Meeting has been created and waiting for your approval <br>Meeting Date : ".$formData['meeting_date']."<br>Meeting Time : ".$formData['meeting_time'];
						$notifyDate			= $formData['meeting_date'];
						$notifyType			= "11";
						foreach($getRoleDetails as $UserKey => $userValue)
						{
							$insertNotifyArray[]	= "'".$meetingId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$locationId."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
						}
						if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
						{
							$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
						}
						if(isset($insertMultiString) && $insertMultiString != '')
						{
							$this->getTable('ScheduleTable')->insertManagerNotification($insertMultiString);
						}
					}
				}
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'schedule', 'action' => 'meeting-schedule'));
	}
	public function viewMeetingAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$meetingId 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$meetingDetails	= '';
		if($meetingId)
		{
			$meetingDetails	= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $meetingDetails,
				'datetime'				=> $datetime,
				'meetingArray'			=> $this->meetingToArray,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function editMeetingAction()
    {
		$request 	 		=  $this->getRequest();
		$auth 	 	  		=  new AuthenticationService();
		$allLocationDetails =  $locationArray = array();
		$meetingDetails		= '';
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$matches					= $this->getEvent()->getRouteMatch();
		$meetingId					= $matches->getParam('id', '');
		$editMeetingForm			= new AddMeetingForm();
		/*$locationArray				= $this->getTable('LocationTable')->getAllLocationDetails();
		$allLocationDetails['']		= 'Select Location';
		if(is_object($locationArray) && count($locationArray) > 0)
		{
			foreach($locationArray as $locKey => $locValue)
			{
				$allLocationDetails[$locValue->loc_id]		= $locValue->loc_title;
			}
		}
		$editMeetingForm->get('meeting_location')->setValueOptions($allLocationDetails);*/
		$editMeetingForm->get('meeting_to')->setValueOptions($this->meetingToArray);
		if($meetingId)
		{
			$meetingDetails	= $this->getTable('ScheduleTable')->getParticularMeetingDetails($meetingId);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $meetKey => $meetValue)
				{
					$editMeetingForm->get('meeting_id')->setValue(stripslashes($meetValue['meeting_id']));
					$editMeetingForm->get('meeting_date')->setValue(date('n-j-Y',strtotime(stripslashes($meetValue['meeting_date']))));
					$editMeetingForm->get('meeting_time')->setValue($this->getCommonDataObj()->convertTimeFormat(stripslashes($meetValue['meeting_time']),''));
					$editMeetingForm->get('meeting_location')->setValue(stripslashes($meetValue['meeting_location']));
					$editMeetingForm->get('meeting_to')->setValue(stripslashes($meetValue['meeting_to']));
					$editMeetingForm->get('meeting_attendees')->setValue(stripslashes($meetValue['meeting_attendees']));
					$editMeetingForm->get('meeting_budget')->setValue(stripslashes($meetValue['meeting_budget_request']));
					$editMeetingForm->get('meeting_add_notes')->setValue(stripslashes($meetValue['meeting_add_notes']));
					$editMeetingForm->get('meeting_venue')->setValue(stripslashes($meetValue['meeting_venue']));
					$editMeetingForm->get('meeting_description')->setValue(stripslashes($meetValue['meeting_description']));
					$editMeetingForm->get('meeting_send_notif')->setValue(stripslashes($meetValue['meeting_notif_send']));
				}
			}
		}
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'editMeetingForm'		=> $editMeetingForm,
			'pc_users'				=> $this->pcUser,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
    }
	public function deleteMeetingAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$meetingDetails = $getRoleDetails = '';
		$request 	 		=  $this->getRequest();
		if($request->isPost())
		{
			$formData		= $request->getPost();
			if(isset($formData['meetingId']) && $formData['meetingId'] != '')
			{
				$meetingId					= $formData['meetingId'];
				if($meetingId)
				{
					$meetingDetails			= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
					if(is_object($meetingDetails) && count($meetingDetails) > 0)
					{
						foreach($meetingDetails as $delKey => $delValue)
						{
							$userRoleId		= $delValue['meeting_to'];
							if(isset($delValue['meeting_to']) && $delValue['meeting_to'] != 1)
							{
								if(isset($delValue['meeting_notif_send']) && $delValue['meeting_notif_send'] == 1)
								{
									$userRoleId		.= ',1';
								}
							}
							$getRoleDetails			= $this->getTable('ScheduleTable')->getuserDetails($delValue['meeting_location'],$userRoleId,$identity->user_id);
							if(is_object($getRoleDetails) && count($getRoleDetails) > 0)
							{
								$meetingDate		= date('n-j-Y',strtotime(stripslashes($delValue['meeting_date'])));
								$meetingTime		= $this->getCommonDataObj()->convertTimeFormat(stripslashes($delValue['meeting_time']),'');
								$notifySubject		= "Meeting has been cancelled <br>Meeting Date : ".$meetingDate."<br>Meeting Time : ".$meetingTime;
								$notifyDate			= $meetingDate;
								$notifyType			= "11";
								foreach($getRoleDetails as $UserKey => $userValue)
								{
									$insertNotifyArray[]	= "'".$meetingId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$delValue['meeting_location']."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
								}
								if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
								{
									$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
								}
								if(isset($insertMultiString) && $insertMultiString != '')
								{
									$this->getTable('ScheduleTable')->insertManagerNotification($insertMultiString);
								}
							}
						}
					}
					$meetingData			= " meeting_isdelete = 1";
					$this->getTable('ScheduleTable')->updateMeeting($meetingData,$meetingId);
				}
			}
		}
		echo 1;die();
	}
	public function approveMeetingAction()
	{
		$auth 	 	  				=  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$meetingId 					= (int) $this->params()->fromRoute('id', 0);
		if($meetingId)
		{
			$meetingData			= " meeting_status = 1,meeting_update_date	= now()";
			$this->getTable('ScheduleTable')->updateMeeting($meetingData,$meetingId);
			$userRoleId				= 3;
			$meetingDetails			= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $delKey => $delValue)
				{
					$getRoleDetails			= $this->getTable('ScheduleTable')->getuserDetails($identity->location_id,$userRoleId,$identity->user_id);
					if(is_object($getRoleDetails) && count($getRoleDetails) > 0)
					{
						$meetingDate		= date('n-j-Y',strtotime(stripslashes($delValue['meeting_date'])));
						$meetingTime		= $this->getCommonDataObj()->convertTimeFormat(stripslashes($delValue['meeting_time']),'');
						$notifySubject		= "Meeting has been approved <br>Meeting Date : ".$meetingDate."<br>Meeting Time : ".$meetingTime;
						$notifyDate			= $meetingDate;
						$notifyType			= "11";
						foreach($getRoleDetails as $UserKey => $userValue)
						{
							$insertNotifyArray[]	= "'".$meetingId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$delValue['meeting_location']."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
						}
						if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
						{
							$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
						}
						if(isset($insertMultiString) && $insertMultiString != '')
						{
							$this->getTable('ScheduleTable')->insertManagerNotification($insertMultiString);
						}
					}
				}
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'schedule', 'action' => 'meeting-schedule'));
	}
	public function sendMeetingNotificationAction()
	{
		$auth 	 	  				=  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$meetingId 					= (int) $this->params()->fromRoute('id', 0);
		if($meetingId)
		{
			$meetingDetails			= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $delKey => $delValue)
				{
					$meetingData			= " meeting_status = 2,meeting_update_date	= now()";
					$this->getTable('ScheduleTable')->updateMeeting($meetingData,$meetingId);
					$userRoleId				= $delValue['meeting_to'];
					$getRoleDetails			= $this->getTable('ScheduleTable')->getuserDetails($identity->location_id,$userRoleId,$identity->user_id);
					if(is_object($getRoleDetails) && count($getRoleDetails) > 0)
					{
						$meetingDate		= date('n-j-Y',strtotime(stripslashes($delValue['meeting_date'])));
						$meetingTime		= $this->getCommonDataObj()->convertTimeFormat(stripslashes($delValue['meeting_time']),'');
						$notifySubject		= "Meeting has been created <br>Meeting Date : ".$meetingDate."<br>Meeting Time : ".$meetingTime;
						$notifyDate			= $meetingDate;
						$notifyType			= "11";
						foreach($getRoleDetails as $UserKey => $userValue)
						{
							$insertNotifyArray[]	= "'".$meetingId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$delValue['meeting_location']."',0,now(),0,0,'".addslashes($notifySubject)."','".addslashes($notifyDate)."','".addslashes($notifyType)."'";
						}
						if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
						{
							$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
						}
						if(isset($insertMultiString) && $insertMultiString != '')
						{
							$this->getTable('ScheduleTable')->insertManagerNotification($insertMultiString);
						}
					}
				}
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'schedule', 'action' => 'meeting-schedule'));
	}
	public function editBudgetAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$meetingId 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$meetingDetails	= '';
		if($meetingId)
		{
			$meetingDetails	= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $meetingDetails,
				'datetime'				=> $datetime,
				'sitePath'				=> $this->sitePath,
				'meetingArray'			=> $this->meetingToArray,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function approveBudgetAction()
	{
		$auth 	 	  		=  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$meetingDetails 	= $getRoleDetails = '';
		$request 	 		=  $this->getRequest();
		if($request->isPost())
		{
			$formData		= $request->getPost();
			if(isset($formData['meeting_id']) && $formData['meeting_id'] != '')
			{
				$budgetrequest		= $formData['budget_request'];
				$additionalNotes	= $formData['add_notes'];
				$updateMeeting		= " meeting_budget_request = '".addslashes($budgetrequest)."',
										meeting_add_notes	   = '".addslashes($additionalNotes)."'";
				$meetingId			= $formData['meeting_id'];
				$this->getTable('ScheduleTable')->updateMeeting($updateMeeting,$meetingId);
			}
		}
		echo 1; die();
	}
	public function meetingDetailsAction()
	{
		$meetingDetails 	= '';
		$meetingArray 		= array();
		$request 	 		=  $this->getRequest();
		if($request->isPost())
		{
			$meetingId 		= (int) $this->params()->fromRoute('id', 0);
			if($meetingId)
			{
				$meetingDetails	= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
				if(is_object($meetingDetails) && count($meetingDetails) > 0)
				{
					$allRoles					= array();
					$roles						= $this->getTable('roleTable')->getAllRoles();
					if($roles) {
						foreach($roles as $role) {
							$allRoles[$role->role_id]  =  $role->role_name;
						}
					}
					foreach($meetingDetails as $meetKey => $meetValue)
					{
						$meetingArray['meet_id']			= stripslashes($meetValue['meeting_id']);
						$meetingArray['date']				= $this->getCommonDataObj()->removeZerosInDate($meetValue['meeting_date']);
						$meetingArray['time']				= $this->getCommonDataObj()->convertTimeFormat(stripslashes($meetValue['meeting_time']),'');
						$meetingArray['venue']				= (isset($meetValue['meeting_venue']) && $meetValue['meeting_venue'] != '') ? stripslashes($meetValue['meeting_venue']): '-';
						$meetingArray['add_notes']			= (isset($meetValue['meeting_venue']) && $meetValue['meeting_venue'] != '') ? stripslashes($meetValue['meeting_add_notes']): '';
						$meetingArray['desc']				= (isset($meetValue['meeting_venue']) && $meetValue['meeting_venue'] != '') ? stripslashes($meetValue['meeting_description']): '';
						$meetingArray['budget']				= stripslashes($meetValue['meeting_budget_request']);
						$meetingArray['attend']				= stripslashes($meetValue['meeting_attendees']);
						$meetingArray['meet_to']			= $allRoles[stripslashes($meetValue['meeting_to'])];
					}
				}
			}
		}
		echo json_encode($meetingArray); die();
	}
	public function uploadReportAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$meetingId 		= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$meetingDetails	= '';
		if($meetingId)
		{
			$meetingDetails	= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $meetingDetails,
				'datetime'				=> $datetime,
				'sitePath'				=> $this->sitePath,
				'meetingArray'			=> $this->meetingToArray,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function saveReportAction()
	{
		$meetingDetails 	= '';
		$meetingArray 		= array();
		$request 	 		=  $this->getRequest();
		if($request->isPost())
		{
			$meetingId 		= (int) $this->params()->fromRoute('id', 0);
			$formData		= $request->getPost();
			if($meetingId)
			{
				$fileTransfer 				= new \Zend\File\Transfer\Adapter\Http();
				$fileInfo 	  				= $fileTransfer->getFileInfo();
				if(isset($fileInfo['report_file']['name']) && $fileInfo['report_file']['name'] != '')
				{
					$fileType					= '';
					if(isset($formData['file_type']) && $formData['file_type'] != '')
					{
						$this->getCommonDataObj()->unlinkFile($this->siteImageUploadPath."/meeting_report/".$formData['file_type']);
					}
					$myFileUpload   			= $this->MyFileUpload();
					$myFileUpload->fileTypes	= $this->fileTypes;
					$myFileUpload->fileSizes	= $this->fileSizes;
					$fileNameArray				= array("report_file");
					$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
					$myFileUpload->uploadPath	= $this->siteImageUploadPath."/meeting_report";
					$fileName					= $myFileUpload->uploadFiles($meetingId, $fileNameArray);
					$fileArray					= explode(".",$fileInfo['report_file']['name']);
					$fileType					= array_search(array_pop($fileArray), $this->fileTypesArray);
					$fileNameImplode			= implode(".",$fileArray);
					$updateData					= " meeting_report_file 		= '".addslashes($fileName)."',
													meeting_file_status			= '1'";
					$this->getTable('ScheduleTable')->updateMeeting($updateData,$meetingId);
				}
			}
		}
		echo $fileName;
		die();
	}
	public function forceDownloadAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$meetingId 			= (int) $this->params()->fromRoute('id', 0);
		if($meetingId)
		{
			$meetingDetails	= $this->getTable('ScheduleTable')->getMeetingDetails($meetingId);
			if(is_object($meetingDetails) && count($meetingDetails) > 0)
			{
				foreach($meetingDetails as $docKey => $docValue)
				{
					$fileExt			= array_pop(explode(".",$docValue['meeting_report_file']));
					$filePath			= $this->siteImageUploadPath."/meeting_report/".$docValue['meeting_report_file'];
					$fileName			= 'Meeting_'.date("n-j-Y",strtotime($docValue['meeting_date'])).'.'.$fileExt;
					$fileSize 			= filesize($filePath);
					$this->getCommonDataObj()->forceDownload($fileName, $filePath, $fileSize, $fileExt);
				}
			}
		}
		die();
	}
}
