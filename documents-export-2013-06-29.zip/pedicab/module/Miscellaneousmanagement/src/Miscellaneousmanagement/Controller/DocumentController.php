<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Miscellaneousmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Forms
use Miscellaneousmanagement\Form\AddDocumentForm,
	Miscellaneousmanagement\Form\FilterDocumentForm,
	Miscellaneousmanagement\Form\AddVideoForm,
	Miscellaneousmanagement\Form\FilterVideoForm;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter;

class DocumentController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	protected $meetingToArray;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf','doc', 'docx', 'rtf', 'txt', 'xls', 'csv');	// 
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->meetingToArray		=  array('' => 'Select', '1' => 'Drivers','2' => 'Mechanics','3' => 'General managers');
		$this->fileTypesArray 		=  array('1' => 'pdf', '2' => 'doc', '3' => 'docx', '4' => 'txt', '5' => 'xls', '6' => 'csv', '7' => 'rtf');
		$this->videoFilesArray 		=  array('1' => 'm4v', '2' => 'mp4', '3' => 'ogv', '4' => 'flv','5' => 'xls', '6' => 'doc',  '7' => 'docx', '8' => 'mpg', '9' => 'wmv', '10' => 'avi','11' => 'mkv','12' => 'webm', '13' => '3gp', '14' => 'mov', '15' => 'mpeg');
		$this->videoFormatArray		=  array('mov' => 'mov', 'mp4' => 'mp4', 'ogv' => 'ogg', 'flv' => 'flv', '3gp' => '3gp', 'm4v' => 'mp4', 'mpeg' => 'mpeg', 'mpg' => 'mpeg', 'wmv' => 'wmv', 'avi' => 'avi','mkv' => 'mkv','webm' => 'webm');
		$this->userRoleDetails		=  array('1' => 'Drivers', '2' => 'Mechanics', '3' => 'General Managers');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("LocationTable" => "Location-Table","ScheduleTable" => "Schedule-Table","roleTable" => "Role-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	public function manageDocumentsAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$paginator					= '';
		// assign default values
		$matches					= $this->getEvent()->getRouteMatch();
		$page						= $matches->getParam('id', 1);
		$sortBy						= $matches->getParam('sortBy', '');
		$sortType					= $matches->getParam('sortType', '');
		$perPage					= $matches->getParam('perPage', '');
		// Create Filter form
		$addDocumentForm			= new AddDocumentForm();
		$filterDocumentForm			= new FilterDocumentForm();
		
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('manageDocumentListing'));
		$manageDocumentSession  	=  new Container('manageDocumentListing');
		if($request->isPost()) {
			$filterDocumentForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['fil_document_date']) && !empty($formData['fil_document_date']))
				$manageDocumentSession->document_date	= $formData['fil_document_date'];
			else
				$manageDocumentSession->document_date	= '';
			
			if(isset($formData['fil_document_title']) && $formData['fil_document_title'] != '')
				$manageDocumentSession->document_title	= $formData['fil_document_title'];
			else
				$manageDocumentSession->document_title	= '';
		}
		
		if($manageDocumentSession->offsetExists('document_date') && $manageDocumentSession->document_date != '' ) {
			$filterDocumentForm->get('fil_document_date')->setValue($manageDocumentSession->document_date);
		}
		if($manageDocumentSession->offsetExists('document_title') && $manageDocumentSession->document_title != '' ) {
			$filterDocumentForm->get('fil_document_title')->setValue($manageDocumentSession->document_title);
		}
		// listing
		$perPage					= $this->defaultPerPage;
		$iteratorAdapter			= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getDocumentList());
		$paginator					= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		return new ViewModel(array(
			'userObject'			=> $identity,
			'pc_users'				=> $this->pcUser,
			'addDocumentForm'		=> $addDocumentForm,
			'filterDocumentForm'	=> $filterDocumentForm,
			'page'					=> $page,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'perPageArray'			=> $this->perPageArray,
			'fileUploadPath'		=> $this->siteImageUploadPath."/document",
			'siteImagePath'			=> $this->siteImagePath,
			'fileTypesArray'		=> $this->fileTypesArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
	}
	public function manageDocumentsListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$manageDocumentSession  	=  new Container('manageDocumentListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($manageDocumentSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$manageDocumentSession->sortBy	= $sortBy;
		} else if($manageDocumentSession->offsetExists('sortBy')) {
			$sortBy	= $manageDocumentSession->sortBy;
		}
		if($sortType != '') {
			if($manageDocumentSession->sortType == $sortType && $columnFlag == 1)
				$manageDocumentSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$manageDocumentSession->sortType	= $sortType;
		} else if($manageDocumentSession->offsetExists('sortType')) {
			$sortType	= $manageDocumentSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$manageDocumentSession->perPage	= $perPage;
		} else if($manageDocumentSession->offsetExists('perPage')) {
			$perPage		= $manageDocumentSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getDocumentList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		
		$result->setVariables(array(
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'fileUploadPath'	=> $this->siteImageUploadPath."/document",
			'siteImagePath'		=> $this->siteImagePath,
			'fileTypesArray'	=> $this->fileTypesArray,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function saveDocumentAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
	 	$request 						=  $this->getRequest();
		if($request->isPost())
		{
			$formData					= $request->getPost();
			$data						= " document_title			= '".addslashes($formData['document_title'])."',
											fk_location_id			= '".addslashes($identity->location_id)."',
											fk_user_id				= '".addslashes($identity->user_id)."',
											fk_role_id				= '".addslashes($identity->user_role_id)."',
											document_type			= 1,
											document_created_date	= now()";
			$documentId					= $this->getTable('ScheduleTable')->insertDocument($data);
			$fileTransfer 				= new \Zend\File\Transfer\Adapter\Http();
			$fileInfo 	  				= $fileTransfer->getFileInfo();
			if(isset($fileInfo['document_file']['name']) && $fileInfo['document_file']['name'] != '')
			{
				$fileType					= '';
				$myFileUpload   			= $this->MyFileUpload();
				$myFileUpload->fileTypes	= $this->fileTypes;
				$myFileUpload->fileSizes	= $this->fileSizes;
				$fileNameArray				= array("document_file");
				$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
				$myFileUpload->uploadPath	= $this->siteImageUploadPath."/document";
				$fileName					= $myFileUpload->uploadFiles($documentId, $fileNameArray);
				$fileArray					= explode(".",$fileInfo['document_file']['name']);
				$fileType					= array_search(array_pop($fileArray), $this->fileTypesArray);
				$fileNameImplode			= implode(".",$fileArray);
				$updateData					= " document_file 		= '".addslashes($fileName)."',
												document_name		= '".addslashes($fileNameImplode)."',
												document_file_type	= '".addslashes($fileType)."'";
				$this->getTable('ScheduleTable')->updateDocument($updateData,$documentId);
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'document', 'action' => 'manage-documents'));
	}
	public function viewDocumentAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$documentId 	= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$documentDetails= '';
		if($documentId)
		{
			$documentDetails	= $this->getTable('ScheduleTable')->getDocumentDetails($documentId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $documentDetails,
				'datetime'				=> $datetime,
				'fileTypesArray'		=> $this->fileTypesArray,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function forceDownloadAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$documentId 			= (int) $this->params()->fromRoute('id', 0);
		if($documentId)
		{
			$documentDetails	= $this->getTable('ScheduleTable')->getDocumentDetails($documentId);
			if(is_object($documentDetails) && count($documentDetails) > 0)
			{
				foreach($documentDetails as $docKey => $docValue)
				{
					if($docValue['document_type'] == 1)
					{
						$fileExt		= $this->fileTypesArray[$docValue['document_file_type']];
						$filePath		= $this->siteImageUploadPath."/document/".$docValue['document_file'];
					}
					else
					{
						$fileExt		= $this->videoFilesArray[$docValue['document_file_type']];
						$filePath		= $this->siteImageUploadPath."/videos/".$docValue['document_file'];
					}
					$fileName			= $docValue['document_name'].'.'.$fileExt;
					$fileSize 			= filesize($filePath);
					$this->getCommonDataObj()->forceDownload($fileName, $filePath, $fileSize, $fileExt);
				}
			}
		}
		die();
	}
	public function videoAction()
	{
		$request 	  =  $this->getRequest();
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$paginator					= '';
		// assign default values
		$matches					= $this->getEvent()->getRouteMatch();
		$page						= $matches->getParam('id', 1);
		$sortBy						= $matches->getParam('sortBy', '');
		$sortType					= $matches->getParam('sortType', '');
		$perPage					= $matches->getParam('perPage', '');
		$filterVideoForm			= new FilterVideoForm();
		$addVideoForm				= new AddVideoForm();
		$status	 					=  $this->getCommonDataObj()->destroySessionVariables(array('videoTrainingListing'));
		$videoTrainingSession  	=  new Container('videoTrainingListing');
		if($request->isPost()) {
			$filterVideoForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['fil_video_date']) && !empty($formData['fil_video_date']))
				$videoTrainingSession->video_date	= $formData['fil_video_date'];
			else
				$videoTrainingSession->video_date	= '';
			
			if(isset($formData['fil_video_title']) && $formData['fil_video_title'] != '')
				$videoTrainingSession->video_title	= $formData['fil_video_title'];
			else
				$videoTrainingSession->video_title	= '';
		}
		
		if($videoTrainingSession->offsetExists('video_date') && $videoTrainingSession->video_date != '' ) {
			$filterVideoForm->get('fil_video_date')->setValue($videoTrainingSession->video_date);
		}
		if($videoTrainingSession->offsetExists('video_title') && $videoTrainingSession->video_title != '' ) {
			$filterVideoForm->get('fil_video_title')->setValue($videoTrainingSession->video_title);
		}
		// listing
		$perPage					= $this->defaultPerPage;
		$iteratorAdapter			= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getVideoList());
		$paginator					= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		// Date
		$datetime		  			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$allRoles					= array();
		$roles						= $this->getTable('roleTable')->getAllRoles();
		if($roles) {
			foreach($roles as $role) {
				$allRoles[$role->role_id]  =  $role->role_name;
			}
		}
		return new ViewModel(array(
			'userObject'			=> $identity,
			'addVideoForm'			=> $addVideoForm,
			'filterVideoForm'		=> $filterVideoForm,
			'page'					=> $page,
			'roleArray'				=> $allRoles,
			'sortBy'				=> $sortBy,
			'paginator'				=> $paginator,
			'perPage'				=> $perPage,
			'pc_users'				=> $this->pcUser,
			'perPageArray'			=> $this->perPageArray,
			'fileUploadPath'		=> $this->siteImageUploadPath."/videos",
			'siteImagePath'			=> $this->siteImagePath,
			'fileTypesArray'		=> $this->videoFilesArray,
			'controller'			=> $this->params('controller'),
			'commonData'			=> $this->getCommonDataObj()
		));
	}
	public function videoListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$videoTrainingSession  	=  new Container('videoTrainingListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($videoTrainingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$videoTrainingSession->sortBy	= $sortBy;
		} else if($videoTrainingSession->offsetExists('sortBy')) {
			$sortBy	= $videoTrainingSession->sortBy;
		}
		if($sortType != '') {
			if($videoTrainingSession->sortType == $sortType && $columnFlag == 1)
				$videoTrainingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$videoTrainingSession->sortType	= $sortType;
		} else if($videoTrainingSession->offsetExists('sortType')) {
			$sortType	= $videoTrainingSession->sortType;
		}
		
		//	Perpage
		if($perPage != '') {
			$videoTrainingSession->perPage	= $perPage;
		} else if($videoTrainingSession->offsetExists('perPage')) {
			$perPage		= $videoTrainingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('ScheduleTable')->getVideoList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$datetime			= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$allRoles			= array();
		$roles				= $this->getTable('roleTable')->getAllRoles();
		if($roles) {
			foreach($roles as $role) {
				$allRoles[$role->role_id]  =  $role->role_name;
			}
		}
		$result->setVariables(array(
			'page'				=> $page,
			'sortBy'			=> $sortBy,
			'paginator'			=> $paginator,
			'perPage'			=> $perPage,
			'roleArray'			=> $allRoles,
			'pc_users'			=> $this->pcUser,
			'perPageArray'		=> $this->perPageArray,
			'datetime'			=> $datetime,
			'pc_users'			=> $this->pcUser,
			'fileUploadPath'	=> $this->siteImageUploadPath."/videos",
			'siteImagePath'		=> $this->siteImagePath,
			'fileTypesArray'	=> $this->videoFilesArray,
			'controller'		=> $this->params('controller'),
			'commonData'		=> $this->getCommonDataObj()
		));
		return $result;
    }
	public function deleteDocumentAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$documentDetails = '';
		$request 		 = $this->getRequest();
		if($request->isPost())
		{
			$formData				= $request->getPost();
			$documentId				= $formData['documentId'];
			$documentDetails		= $this->getTable('ScheduleTable')->getDocumentDetails($documentId);
			if(is_object($documentDetails) && count($documentDetails) > 0)
			{
				foreach($documentDetails as $documentKey => $documentValue)
				{
					$fileName			= $documentValue['document_file'];
					$fileAbsolutePath	= $this->siteImageUploadPath."/document/".$fileName;
					$deleteData			= " document_isdelete = 1";
					$this->getTable('ScheduleTable')->updateDocument($deleteData,$documentId);
					$this->getCommonDataObj()->unlinkFile($fileAbsolutePath);
					echo 1;die();
				}
			}
		}
	}
	public function saveVideoAction()
	{
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
	 	$request 						=  $this->getRequest();
		if($request->isPost())
		{
			$formData					= $request->getPost();
			$data						= " document_title			= '".addslashes($formData['video_title'])."',
											fk_location_id			= '".addslashes($identity->location_id)."',
											fk_user_id				= '".addslashes($identity->user_id)."',
											fk_role_id				= '".addslashes($identity->user_role_id)."',
											document_type			= 2,
											document_created_date	= now()";
			$documentId					= $this->getTable('ScheduleTable')->insertDocument($data);
			$fileTransfer 				= new \Zend\File\Transfer\Adapter\Http();
			$fileInfo 	  				= $fileTransfer->getFileInfo();
			if(isset($fileInfo['video_file']['name']) && $fileInfo['video_file']['name'] != '')
			{
				$fileType					= '';
				$myFileUpload   			= $this->MyFileUpload();
				$myFileUpload->fileTypes	= $this->fileTypes;
				$myFileUpload->fileSizes	= $this->fileSizes;
				$fileNameArray				= array("video_file");
				$userProfileImage			= $myFileUpload->checkUploadFiles($fileNameArray);
				$myFileUpload->uploadPath	= $this->siteImageUploadPath."/videos";
				$fileName					= $myFileUpload->uploadFiles($documentId, $fileNameArray);
				$fileArray					= explode(".",$fileInfo['video_file']['name']);
				$fileType					= array_search(array_pop($fileArray), $this->videoFilesArray);
				$fileNameImplode			= implode(".",$fileArray);
				$updateData					= " document_file 		= '".addslashes($fileName)."',
												document_name		= '".addslashes($fileNameImplode)."',
												document_file_type	= '".addslashes($fileType)."'";
				$this->getTable('ScheduleTable')->updateDocument($updateData,$documentId);
			}
		}
		return $this->redirect()->toRoute('miscellaneousmanagement', array('controller' => 'document', 'action' => 'video'));
	}
	public function viewVideoAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$documentId 	= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$documentDetails= '';
		if($documentId)
		{
			$documentDetails	= $this->getTable('ScheduleTable')->getDocumentDetails($documentId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $documentDetails,
				'datetime'				=> $datetime,
				'sitePath'				=> $this->sitePath,
				'fileTypesArray'		=> $this->videoFilesArray,
				'videoFormatArray'		=> $this->videoFormatArray,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function deleteVideoAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$documentDetails = '';
		$request 		 = $this->getRequest();
		if($request->isPost())
		{
			$formData				= $request->getPost();
			$videoId				= $formData['videoId'];
			$documentDetails		= $this->getTable('ScheduleTable')->getDocumentDetails($videoId);
			if(is_object($documentDetails) && count($documentDetails) > 0)
			{
				foreach($documentDetails as $documentKey => $documentValue)
				{
					$fileName			= $documentValue['document_file'];
					$fileAbsolutePath	= $this->siteImageUploadPath."/videos/".$fileName;
					$deleteData			= " document_isdelete = 1";
					$this->getTable('ScheduleTable')->updateDocument($deleteData,$videoId);
					$this->getCommonDataObj()->unlinkFile($fileAbsolutePath);
					echo 1;die();
				}
			}
		}
	}
	public function shareVideoAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$documentId 	= (int) $this->params()->fromRoute('id', 0);
		$datetime		= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
		$documentDetails= '';
		if($documentId)
		{
			$documentDetails	= $this->getTable('ScheduleTable')->getDocumentDetails($documentId);
		}
		$result->setVariables(array(
				'controller'	 		=> $this->params('controller'),
				'viewArray'				=> $documentDetails,
				'datetime'				=> $datetime,
				'sitePath'				=> $this->sitePath,
				'fileTypesArray'		=> $this->videoFilesArray,
				'videoFormatArray'		=> $this->videoFormatArray,
				'userRoleDetails'		=> $this->userRoleDetails,
				'commonData'			=> $this->getCommonDataObj()
		));
		return $result;
	}
	public function shareMemberAction()
	{
		$auth 	 	  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$documentDetails = $role = '';
		$sharedExplode	 = $notificationArray = $shareArray = array();
		$request 		 = $this->getRequest();
		if($request->isPost())
		{
			$formData						= $request->getPost();
			if(isset($formData['videoId']) && $formData['videoId'] != '')
			{
				$videoId					= $formData['videoId'];
				$documentDetails			= $this->getTable('ScheduleTable')->getDocumentDetails($videoId);
				if(is_object($documentDetails) && count($documentDetails) > 0)
				{
					foreach($documentDetails as $documentKey => $documentValue)
					{
						$sharedPeople		= $documentValue['document_share'];
						if(isset($sharedPeople) && $sharedPeople != '')
						{
							$sharedExplode	= explode(",",$sharedPeople);
						}
						$shareArray			= $formData['share_members'];
						$notificationArray	= array_diff($shareArray,$sharedExplode);
						$role				= implode(",",$formData['share_members']);
						if(is_array($notificationArray) && count($notificationArray) > 0)
						{
							$notificationSubject	= "New Video (".$documentValue['document_title'].") has been shared to you.";
							$roleNew				= implode(",",$notificationArray);
							$userDetails			= $this->getTable('ScheduleTable')->getuserDetails($identity->location_id,$roleNew,$identity->user_id);
							foreach($userDetails as $userKey => $userValue)
							{
								$insertNotifyArray[] = "'".$videoId."','".$identity->user_id."','".$userValue['user_id']."','".$identity->user_role_id."','".$identity->location_id."',0,now(),0,0,'".addslashes($notificationSubject)."','".date('Y-m-d')."','8'";
							}
							if(is_array($insertNotifyArray) && count($insertNotifyArray) > 0)
							{
								$insertMultiString	= "(".implode("),(",$insertNotifyArray).")";
							}
							if(isset($insertMultiString) && $insertMultiString != '')
							{
								$this->getTable('ScheduleTable')->insertVideoNotification($insertMultiString);
							}
						}
						$updateShare		= " document_share		= '".addslashes($role)."'";
						$this->getTable('ScheduleTable')->updateDocument($updateShare,$videoId);
						echo 1;
					}
				}
			}
		}
		die();
	}
}
