<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class FilterVideoForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_filter_video_form');
		$this->setAttribute('id', 'pc_filter_video_form');
		
		$this->add(array(
            'name' => 'fil_video_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_video_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
		$this->add(array(
            'name' => 'fil_video_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_video_title',
				'class'								=> 'tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Video Title',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'fil_video_save',
            'attributes'=> array(
				'id'			=> 'fil_video_save',
                'type'  		=> 'submit',
                'value' 		=> 'Save',
				'class'			=> 'tabindex',
				
            ),
        ));
		
		$this->add(array(
			'name'	=> 'fil_video_reset',
            'attributes' => array(
				'id'			=> 'fil_video_reset',
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> 'tabindex',
            ),
        ));
    }
}
?>