<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class FilterReminderForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_contract_reminder_form');
		$this->setAttribute('id', 'pc_contract_reminder_form');
		
		$this->add(array(
            'name' => 'fil_start_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_start_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Start Date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
		$this->add(array(
            'name' => 'fil_end_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_end_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'End Date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
		$this->add(array(
            'name' => 'fil_driver_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_driver_name',
				'class'								=> 'tabindex wid240',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Name',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'fil_reminder_save',
            'attributes'=> array(
				'id'			=> 'fil_reminder_save',
                'type'  		=> 'submit',
                'value' 		=> 'Save',
				'class'			=> 'tabindex',
				
            ),
        ));
		
		$this->add(array(
			'name'	=> 'fil_reminder_reset',
            'attributes' => array(
				'id'			=> 'fil_reminder_reset',
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> 'tabindex',
            ),
        ));
    }
}
?>