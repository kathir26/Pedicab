<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class AddReminderForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_reminder_form');
		$this->setAttribute('id', 'pc_add_reminder_form');
		
		$this->add(array(
            'name' => 'user_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'user_id'
            )
        ));
		
		$this->add(array(
            'name' => 'role_name',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'role_name',
				'class'								=> 'tabindex wid240',
				'autofocus'							=> '',
				'readonly'							=> 'readonly',
				'PlaceHolder' 						=> '',
            )
        ));
		
		$this->add(array(
            'name' => 'lease_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'lease_date',
				'class'								=> 'tabindex calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'reminder_fake_file',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'reminder_fake_file',
				'class'								=> 'tabindex fakefilepc',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
            )
        ));
		
		$this->add(array(
            'name' => 'reminder_file',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'reminder_file',
				'class'								=> 'tabindex filepc',
				'height'							=> '30',
				'size' 								=> '35',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'reminder_save',
            'attributes'=> array(
				'id'		=> 'reminder_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'class'		=> 'tabindex',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'reminder_reset',
            'attributes' => array(
				'id'		=> 'reminder_reset',
                'type'  	=> 'reset',
                'value' 	=> 'Reset',
				'class'		=> 'tabindex',
            ),
        ));
    }
}
?>