<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class AddVideoForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_video_form');
		$this->setAttribute('id', 'pc_add_video_form');
		
		$this->add(array(
            'name' => 'video_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'video_title',
				'class'								=> 'tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Video Title is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'video_fake_file',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'video_fake_file',
				'class'								=> 'tabindex fakefilepc',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
            )
        ));
		
		$this->add(array(
            'name' => 'video_file',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'video_file',
				'class'								=> 'tabindex filepc',
				'height'							=> '30',
				'size' 								=> '35',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'video_save',
            'attributes'=> array(
				'id'		=> 'video_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'class'		=> 'tabindex',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'video_reset',
            'attributes' => array(
				'id'		=> 'video_reset',
                'type'  	=> 'reset',
                'value' 	=> 'Reset',
				'class'		=> 'tabindex',
            ),
        ));
    }
}
?>