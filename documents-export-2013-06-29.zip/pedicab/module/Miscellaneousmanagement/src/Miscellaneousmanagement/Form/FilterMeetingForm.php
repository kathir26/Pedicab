<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class FilterMeetingForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_filter_meeting_form');
		$this->setAttribute('id', 'pc_filter_meeting_form');
		
		$this->add(array(
            'name' => 'fil_meeting_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_meeting_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
		$this->add(array(
            'name' => 'fil_meeting_loc',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_meeting_loc',
				'class'								=> 'tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Location',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'fil_meeting_save',
            'attributes'=> array(
				'id'			=> 'fil_meeting_save',
                'type'  		=> 'submit',
                'value' 		=> 'Save',
				'class'			=> 'tabindex',
				
            ),
        ));
		
		$this->add(array(
			'name'	=> 'fil_meeting_reset',
            'attributes' => array(
				'id'			=> 'fil_meeting_reset',
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> 'tabindex',
            ),
        ));
    }
}
?>