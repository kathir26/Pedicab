<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class FilterDocumentForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_filter_document_form');
		$this->setAttribute('id', 'pc_filter_document_form');
		
		$this->add(array(
            'name' => 'fil_document_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_document_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Date',
				'data-validation-engine' 			=> 'validate[custom[date]]',
            )
        ));
		
		$this->add(array(
            'name' => 'fil_document_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'fil_document_title',
				'class'								=> 'tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> 'Document Title',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'fil_document_save',
            'attributes'=> array(
				'id'			=> 'fil_document_save',
                'type'  		=> 'submit',
                'value' 		=> 'Save',
				'class'			=> 'tabindex',
				
            ),
        ));
		
		$this->add(array(
			'name'	=> 'fil_document_reset',
            'attributes' => array(
				'id'			=> 'fil_document_reset',
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> 'tabindex',
            ),
        ));
    }
}
?>