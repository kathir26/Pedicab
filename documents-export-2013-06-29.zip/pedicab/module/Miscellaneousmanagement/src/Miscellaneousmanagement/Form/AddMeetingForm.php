<?php
namespace Miscellaneousmanagement\Form;

use Zend\Form\Form;

class AddMeetingForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('maintenancemanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_meeting_form');
		$this->setAttribute('id', 'pc_add_meeting_form');
		
		$this->add(array(
            'name' => 'meeting_id',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'meeting_id'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_location',
            'attributes' => array(
                'type'   => 'hidden',
				'id'	 => 'meeting_location'
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'meeting_date',
				'class'								=> 'calc-txbox datepicker tabindex',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_time',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'meeting_time',
				'class'								=> 'clock-txbox datepicker tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[required],custom[time]',
				'data-errormessage-value-missing' 	=> 'Estimated Time is required!',
            )
        ));
		
		/*$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'meeting_location',
            'options'   => array(
                'value_options' => array(
                    
                ),
            ),
            'attributes' => array(
				'id'    							=> 'meeting_location',
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Location is required!',
            )
        ));*/
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'meeting_to',
            'options'   => array(
                'value_options' => array(
                    
                ),
            ),
            'attributes' => array(
				'id'    							=> 'meeting_to',
				'class' 							=> 'tabindex',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Meeting to is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_attendees',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'meeting_attendees',
				'class'								=> 'wid138 tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'No. of Attendees is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_budget',
            'attributes' => array(
				'type' 								=> 'text',
				'id'  								=> 'meeting_budget',
				'class'								=> 'dollar-txbox tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Budget Request is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_add_notes',
            'attributes' => array(
				'type' 								=> 'textarea',
				'id'  								=> 'meeting_add_notes',
				'class'								=> 'tabindex',
                'value' 							=> '',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_venue',
            'attributes' => array(
				'type' 								=> 'textarea',
				'id'  								=> 'meeting_venue',
				'class'								=> 'wid138 tabindex',
                'value' 							=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Meeting Venue is required!',
            )
        ));
		
		$this->add(array(
            'name' => 'meeting_description',
            'attributes' => array(
				'type' 								=> 'textarea',
				'id'  								=> 'meeting_description',
				'class'								=> 'tabindex',
                'value' 							=> '',
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Checkbox',
            'name' => 'meeting_send_notif',
            'options'   => array(
                'value_options' => array(
					
                ),
            ),
            'attributes' => array(
				'id'    							=> 'meeting_send_notif',
				'value'								=> 1,
				'class' 							=> 'tabindex',
            )
        ));
		
        $this->add(array(
            'name' 		=> 'meeting_save',
            'attributes'=> array(
				'id'		=> 'meeting_save',
                'type'  	=> 'submit',
                'value' 	=> 'Save',
				'class'		=> 'tabindex',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'meeting_reset',
            'attributes' => array(
				'id'		=> 'meeting_reset',
                'type'  	=> 'reset',
                'value' 	=> 'Reset',
				'class'		=> 'tabindex',
            ),
        ));
    }
}
?>