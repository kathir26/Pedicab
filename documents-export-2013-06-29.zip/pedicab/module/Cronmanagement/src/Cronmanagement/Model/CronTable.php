<?php
namespace Cronmanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class CronTable extends AbstractTableGateway
{
    protected $table = 'cron_tracking';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
//        $this->resultSetPrototype->setArrayObjectPrototype(new Parts());
        $this->initialize();
    }
	public function getuserDetails($roleId, $locationId)
	{
		$where		= '';
		if(isset($roleId) && $roleId != '')
		{
			$where	.= " and user_role_id in(".$roleId.")";
		}
		if(isset($locationId) && $locationId != '')
		{
			$where	.= " and location_id = ".$locationId;
		}
		$sql 		= "Select * from user where user_isdelete = 0 and user_status = 1 ".$where." order by user_firstname asc";
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertCron($data)
    {
        $this->insert($data);
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updateCron($data,$cronId)
    {
	    $cronId				= (int)$cronId;
		$this->update($data, array('cron_id' => $cronId));
        return $cronId;
    }
	public function getReminderList($locationId,$roleId,$startDate,$endDate)
	{
		$where		= '';
		if(isset($roleId) && $roleId != '')
		{
			$where	.= " and user_role_id in(".$roleId.")";
		}
		if(isset($locationId) && $locationId != '')
		{
			$where	.= " and location_id = ".$locationId;
		}
		if(isset($startDate) && $startDate != '')
		{
			$where	.= " AND DATE(user_leasecontract_date) >= '".addslashes($startDate)."'";
		}
		if(isset($endDate) && $endDate != '')
		{
			$where	.= " AND DATE(user_leasecontract_date) <= '".addslashes($endDate)."'";
		}
		$sql		= " SELECT * from user WHERE 1 and user_isdelete = 0 and user_status = 1 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
}