<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Cronmanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;
use Zend\Mvc\Controller\Plugin\FlashMessenger;

//	Models
use Usermanagement\Model\MyAuthenticationAdapter;

class CronController extends AbstractActionController
{
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $activeArrray;
	protected $commonData;
	protected $meetingToArray;
	
	public function __construct()
    {
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->fileTypesArray		=  array('pdf', 'doc', 'docx', 'xls');
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		$this->activeArrray			=  array('0' => 'Inactive', '1' => 'Active');
		$this->meetingToArray		=  array('' => 'Select', '1' => 'Drivers','2' => 'Mechanics','3' => 'General managers');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("PartsTable" => "Parts-Table", "ScheduleTable" => "Schedule-Table", "RoleTable" => "Role-Table", "UsersTable" => "Users-Table", 
										 "LocationTable" => "Location-Table", "CronTable" => "Cron-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	/*
		Insert and Update the Cron Tracking
	*/
	public function cronTrackingAction($data, $type = 1, $cronId = '')
	{
		if(is_array($data))
		{
			if($cronId != '')
			{
				$data['cron_end_date'] 		= date('Y-n-j H:i:s');
				$cronId						= $this->getTable("CronTable")->updateCron($data, $cronId);
			}
			else
			{
				$data['cron_type']			= $type;
				$data['cron_start_date']	= date('Y-n-j H:i:s');
				$cronId						= $this->getTable("CronTable")->insertCron($data);
			}
		}
		return $cronId;
	}
	public function getRoleDetails()
	{
		$getRoleArray			= $getRoleDetails = '';
		$getRoleDetails			= $this->getTable("RoleTable")->getAllRoles();
		if(is_object($getRoleDetails) && count($getRoleDetails) > 0)
		{
			foreach($getRoleDetails as $roleKey => $roleValue)
			{
				$getRoleArray[$roleValue->role_id]		= $roleValue->role_name;
			}
		}
		return $getRoleArray;
	}
	
	/*
		Notify Parts when the quantity reach minimum part.
		http://www.pedicablocal.com/cronmanagement/cron/notify-parts
	*/
	
	public function notifyPartsAction()
	{
		$gerLocationList 		= $userEmails = $userLocation = '';
		$insertCronData			= $updateCronData = $userEmail = array();
		$gerLocationList		= $this->getTable("LocationTable")->getAllLocationDetails();
		if(is_object($gerLocationList) && count($gerLocationList) > 0)
		{
			$insertCronData['cron_name']			= "Minimum Parts Notification";
			$cronId									= $this->cronTrackingAction($insertCronData,1,'');
			foreach($gerLocationList as $locKey => $locValue)
			{
				$getPartsList			= $getUserDetails = $partsHtmlContent = '';
				$toMailAddr				= array();
				$locationId				= '';
				$locationId				= $locValue->loc_id;
				$roleId					= '5'; //Admin and Manager
				$getUserDetails 		= $this->getTable("CronTable")->getuserDetails($roleId,'');
				if(is_object($getUserDetails) && count($getUserDetails) > 0)
				{
					foreach($getUserDetails as $userKey => $userValue)
					{
						$toMailAddr[]							= $userValue['user_email'];
						$userEmail[$userValue['user_id']]		= $userValue['user_email'];
					}
				}
				$where					= '';
				$where					= " and parts_isdelete = 0 and parts_in_stock <= parts_min_quantity and location_id = ".$locationId;
				$getPartsList			= $this->getTable("PartsTable")->getPartsDetailsAll($where);
				if(is_object($getPartsList) && count($getPartsList) > 0)
				{
					$roleId				= '3'; //Admin and Manager
					$userLocation		.= $locationId.",";
					$getUserDetails 	= $this->getTable("CronTable")->getuserDetails($roleId,$locationId);
					if(is_object($getUserDetails) && count($getUserDetails) > 0)
					{
						foreach($getUserDetails as $userKey => $userValue)
						{
							$toMailAddr[]							= $userValue['user_email'];
							$userEmail[$userValue['user_id']]		= $userValue['user_email'];
						}
					}
					$partsHtmlContent	.= '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr style="background:#2D4C05;color: #FFFFFF;font-size: 12px;font-weight: normal;font-family:Arial"><th style="width:25%; padding:10px 0px">Part Name</th><th style="width:25%">Part Number</th><th style="width:20%">No.should have in stock</th><th style="width:15%">No. on Hand</th><th style="width:15%">Parts to Order</th></tr>';
					foreach($getPartsList as $partsKey => $partsValue)
					{
						$partsHtmlContent	.= '<tr style="padding:10px 0px;background:#ECF1E6;color:#404040;font-size: 12px;font-family:Arial;text-align:center;">
													<td style="border:1px solid #2D4C05;border-top:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_name']).'</td>
													<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_jb']).'</td>
													<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_min_quantity']).'</td>
													<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($partsValue['parts_in_stock']).'</td>
													<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.abs($partsValue['parts_in_stock'] - $partsValue['parts_min_quantity']).'</td>
												</tr>';
					}
					$partsHtmlContent	.= '</table>';
				}
				if(is_array($toMailAddr) && count($toMailAddr) > 0 && isset($partsHtmlContent) && $partsHtmlContent != '')
				{
					$mailArray			    =  array(
						'subject'		  	=> 'Minimum Parts Notification from '.ucfirst($locValue->loc_title),
			            'from_email'	  	=> '',
						'from_name' 	  	=> '',
						'to_email' 	  	  	=> $toMailAddr,//'kathiravan@sdi.la',//
						'mail_title' 	  	=> 'Parts to Order in '.ucfirst($locValue->loc_title),
						'mail_descriptions' => '',
						'mail_preview' 		=> 1, // Change to 0 for mail sending
						'template_path' 	=> 'usermanagement/mail_templates/parts_notification',
						//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
			        );
					$this->getCommonDataObj()->siteMailSending($partsHtmlContent, $mailArray);
				}
			}
			if(is_array($userEmail) && count($userEmail) > 0)
			{
				$userEmails							= implode(",",$userEmail);
				$userRole							= rtrim(trim($userLocation),",");
				$updateCronData['cron_email_sent']	= $userEmails;
				$updateCronData['cron_location_id']	= $userRole;
			}
			$this->cronTrackingAction($updateCronData,1,$cronId);
		}
		die();
	}
	
	/*
		Notify Expire Lease contract to Owner, Manager, Driver, Mechanic.
		http://www.pedicablocal.com/cronmanagement/cron/expire-lease
	*/
	
	public function expireLeaseAction()
	{
		$gerLocationList 		= $userEmails = $userLocation = $getRoleDetails = '';
		$insertCronData			= $updateCronData = $userEmail = array();
		$gerLocationList		= $this->getTable("LocationTable")->getAllLocationDetails();
		if(is_object($gerLocationList) && count($gerLocationList) > 0)
		{
			$insertCronData['cron_name']	= "Upcoming Expire Lease Contract Reminder";
			$cronId							= $this->cronTrackingAction($insertCronData,1,'');
			$getRoleDetails					= $this->getRoleDetails();
			foreach($gerLocationList as $locKey => $locValue)
			{
				$getUserDetails 			= $contractHtmlContent = $getEmailDetails = '';
				$toMailAddr					= array();
				$locationId					= '';
				$locationId					= $locValue->loc_id;
				$roleId						= '1,2'; //Driver and Mechanic
				$startDate					= date('Y-m-d');
				$endDate					= date('Y-m-d',strtotime('+30 days'));
				$getUserDetails 			= $this->getTable("CronTable")->getReminderList($locationId,$roleId,$startDate,$endDate);
				if(is_object($getUserDetails) && count($getUserDetails) > 0)
				{
					$roleId					= '3,5'; //Admin, Manager
					$userLocation			.= $locationId.",";
					$getEmailDetails 		= $this->getTable("CronTable")->getuserDetails($roleId,'');
					if(is_object($getEmailDetails) && count($getEmailDetails) > 0)
					{
						foreach($getEmailDetails as $emailKey => $emailValue)
						{
							$toMailAddr[]							= $emailValue['user_email'];
							$userEmail[$emailValue['user_id']]		= $emailValue['user_email'];
						}
					}
					$contractHtmlContent		.= '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr style="background:#2D4C05;color: #FFFFFF;font-size: 12px;font-weight: normal;font-family:Arial"><th style="width:25%; padding:10px 0px">Name</th><th style="width:15%">Role</th><th style="width:20%">Email</th><th style="width:15%">Phone Number</th><th style="width:15%">Expire Lease Date</th></tr>';
					foreach($getUserDetails as $userKey => $userValue)
					{
						$contractHtmlContent	.= '<tr style="padding:10px 0px;background:#ECF1E6;color:#404040;font-size: 12px;font-family:Arial;text-align:center;">
														<td style="border:1px solid #2D4C05;border-top:0px;padding:10px 0px;">'.stripslashes($userValue['user_firstname']).' '.stripslashes($userValue['user_lastname']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.$getRoleDetails[stripslashes($userValue['user_role_id'])].'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($userValue['user_email']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes($userValue['user_telephone_number']).'</td>
														<td style="border:1px solid #2D4C05;border-top:0px;border-left:0px;padding:10px 0px;">'.stripslashes(date('n-j-Y',strtotime($userValue['user_leasecontract_date']))).'</td>
													</tr>';
						$userEmail[$userValue['user_id']]		= $userValue['user_email'];
						//Seperate mail to expire user
						$getDateDifference		= $this->getCommonDataObj()->getDateDifference($startDate, $userValue['user_leasecontract_date']);
						$mailArray			    =  array(
							'subject'		  	=> 'Your Lease Contract is going to Expire Soon',
				            'from_email'	  	=> '',
							'from_name' 	  	=> '',
							'to_email' 	  	  	=> $userValue['user_email'],//'kathiravan@sdi.la',//
							'mail_title' 	  	=> 'Lease Contract going to expire in '.$getDateDifference->d.' days ',
							'mail_descriptions' => '',
							'mail_preview' 		=> 1, // Change to 0 for mail sending
							'template_path' 	=> 'usermanagement/mail_templates/expire_lease_contract',
							//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
				        );
						$userHtmlContent		= 'Hi <strong>'.stripslashes($userValue['user_firstname']).' '.stripslashes($userValue['user_lastname']).'</strong>, <br><br>';
						$userHtmlContent		.= '&nbsp;&nbsp;&nbsp;&nbsp;Your contract in pedicab is going to expire.Please contact site manager for more details.';
						$this->getCommonDataObj()->siteMailSending($userHtmlContent, $mailArray);
					}
					$contractHtmlContent		.= '</table>';
					$mailArray			    =  array(
						'subject'		  	=> 'Upcoming Expire Lease Contract Reminder from '.ucfirst($locValue->loc_title),
			            'from_email'	  	=> '',
						'from_name' 	  	=> '',
						'to_email' 	  	  	=> $toMailAddr,//'kathiravan@sdi.la',//
						'mail_title' 	  	=> 'Upcoming Expire List from '.date("n-j-Y",strtotime($startDate)).' to '.date("n-j-Y",strtotime($endDate)),
						'mail_descriptions' => '',
						'mail_preview' 		=> 1, // Change to 0 for mail sending
						'template_path' 	=> 'usermanagement/mail_templates/expire_lease_contract',
						//'cc_mail' 	  	=> array('vijayakumars@sdi.la', 'kathiravan@sdi.la'),
			        );
					$this->getCommonDataObj()->siteMailSending($contractHtmlContent, $mailArray);
				}
			}
			if(is_array($userEmail) && count($userEmail) > 0)
			{
				$userEmails							= implode(",",$userEmail);
				$userRole							= rtrim(trim($userLocation),",");
				$updateCronData['cron_email_sent']	= $userEmails;
				$updateCronData['cron_location_id']	= $userRole;
			}
			$this->cronTrackingAction($updateCronData,1,$cronId);
		}
		die();
	}
}
