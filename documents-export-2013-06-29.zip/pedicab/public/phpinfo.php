<?php
	//echo "<br/>==Line==".__LINE__."==File==".__FILE__."====><pre>"; print_r($_SERVER); echo "</pre><==";
	phpinfo();
?>