<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<!-- <!doctype html> -->
<html>
<head>
	<title>Html5</title>	
</head>
<body>
        <h1>Heading 1</h1>
        <h2>Heading 2</h2>
        <h3>Heading 3</h3>
        <h4>Heading 4</h4>
        <h5>Heading 5</h5>
        <h6>Heading 6</h6>

        <section>
            <h1>Heading 1 (in section)</h1>
            <h2>Heading 2 (in section)</h2>
            <h3>Heading 3 (in section)</h3>
            <h4>Heading 4 (in section)</h4>
            <h5>Heading 5 (in section)</h5>
            <h6>Heading 6 (in section)</h6>
        </section>

        <article>
            <h1>Heading 1 (in article)</h1>
            <h2>Heading 2 (in article)</h2>
            <h3>Heading 3 (in article)</h3>
            <h4>Heading 4 (in article)</h4>
            <h5>Heading 5 (in article)</h5>
            <h6>Heading 6 (in article)</h6>
        </article>

        <header>
            <hgroup>
                <h1>Heading 1 (in hgroup)</h1>
                <h2>Heading 2 (in hgroup)</h2>
            </hgroup>
            <nav>
                <ul>
                    <li><a href="#">navigation item #1</a></li>
                    <li><a href="#">navigation item #2</a></li>
                    <li><a href="#">navigation item #3</a></li>
                </ul>
            </nav>
        </header>

        <h1>Text-level semantics</h1>

        <p hidden="">This should be hidden in all browsers, apart from IE6</p>

        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque 
penatibus et m. Lorem ipsum dolor sit amet, consectetuer adipiscing 
elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
 penatibus et m. Lorem ipsum dolor sit amet, consectetuer adipiscing 
elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
 penatibus et m.</p>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque 
penatibus et m. Lorem ipsum dolor sit amet, consectetuer adipiscing 
elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
 penatibus et m. Lorem ipsum dolor sit amet, consectetuer adipiscing 
elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque
 penatibus et m.</p>

        <address>Address: somewhere, world</address>

        <p>
        The <a href="#">a element</a> example<br>
        The <abbr>abbr element</abbr> and <abbr title="Title text">abbr element with title</abbr> examples<br>
        The <b>b element</b> example<br>
        The <cite>cite element</cite> example<br>
        The <code>code element</code> example<br>
        The <del>del element</del> example<br>
        The <dfn>dfn element</dfn> and <dfn title="Title text">dfn element with title</dfn> examples<br>
        The <em>em element</em> example<br>
        The <i>i element</i> example<br>
        The img element <img src="img/16.jpg" alt=""> example<br>
        The <ins>ins element</ins> example<br>
        The <kbd>kbd element</kbd> example<br>
        The <mark>mark element</mark> example<br>
        The <q>q element <q>inside</q> a q element</q> example<br>
        The <s>s element</s> example<br>
        The <samp>samp element</samp> example<br>
        The <small>small element</small> example<br>
        The <span>span element</span> example<br>
        The <strong>strong element</strong> example<br>
        The <sub>sub element</sub> example<br>
        The <sup>sup element</sup> example<br>
        The <var>var element</var> example<br>
        The <u>u element</u> example
        </p>

        <h1>Embedded content</h1>

        <h3>audio</h3>

        <audio tabindex="0" controls="controls"></audio>
        <audio></audio>

        <h3>img</h3>

        <img src="img/100.jpg" alt="">
        <a href="#"><img src="img/100.jpg" alt=""></a>

        <h3>svg</h3>

        <svg width="100px" height="100px">
            <circle cx="100" cy="100" r="100" fill="#ff0000"></circle>
        </svg>

        <h3>video</h3>

        <video tabindex="0" controls="controls"></video>
        <video tabindex="0"></video>

        <h1>Grouping content</h1>

        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. 
Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque 
penatibus et m.</p>

        <h3>pre</h3>

        <pre>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et me.</pre>

        <pre><code>&lt;html&gt;
    &lt;head&gt;
    &lt;/head&gt;
    &lt;body&gt;
        &lt;div class="main"&gt; &lt;div&gt;
    &lt;/body&gt;
&lt;/html&gt;</code></pre>

        <h3>blockquote</h3>

        <blockquote>
            <p>Some sort of famous witty quote marked up with a &lt;blockquote&gt; and a child &lt;p&gt; element.</p>
        </blockquote>

        <blockquote>Even better philosophical quote marked up with just a &lt;blockquote&gt; element.</blockquote>

        <h3>ordered list</h3>

        <ol>
            <li>list item 1</li>
            <li>list item 1
                <ol>
                    <li>list item 2</li>
                    <li>list item 2
                        <ol>
                            <li>list item 3</li>
                            <li>list item 3</li>
                        </ol>
                    </li>
                    <li>list item 2</li>
                    <li>list item 2</li>
                </ol>
            </li>
            <li>list item 1</li>
            <li>list item 1</li>
        </ol>

        <h3>unordered list</h3>

        <ul>
            <li>list item 1</li>
            <li>list item 1
                <ul>
                    <li>list item 2</li>
                    <li>list item 2
                        <ul>
                            <li>list item 3</li>
                            <li>list item 3</li>
                        </ul>
                    </li>
                    <li>list item 2</li>
                    <li>list item 2</li>
                </ul>
            </li>
            <li>list item 1</li>
            <li>list item 1</li>
        </ul>

        <h3>description list</h3>

        <dl>
            <dt>Description name</dt>
            <dd>Description value</dd>
            <dt>Description name</dt>
            <dd>Description value</dd>
            <dd>Description value</dd>
            <dt>Description name</dt>
            <dt>Description name</dt>
            <dd>Description value</dd>
        </dl>

        <h3>figure</h3>

        <figure>
            <img src="img/200.jpg" alt="">
            <figcaption>Figcaption content</figcaption>
        </figure>

        <h1>Tabular data</h1>

        <table>
            <caption>Jimi Hendrix - albums</caption>
            <thead>
                <tr>
                    <th>Album</th>
                    <th>Year</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Album</th>
                    <th>Year</th>
                    <th>Price</th>
                </tr>
            </tfoot>
            <tbody>
                <tr>
                    <td>Are You Experienced</td>
                    <td>1967</td>
                    <td>$10.00</td>
                </tr>
                <tr>
                    <td>Axis: Bold as Love</td>
                    <td>1967</td>
                    <td>$12.00</td>
                </tr>
                <tr>
                    <td>Electric Ladyland</td>
                    <td>1968</td>
                    <td>$10.00</td>
                </tr>
                <tr>
                    <td>Band of Gypsys</td>
                    <td>1970</td>
                    <td>$12.00</td>
                </tr>
            </tbody>
        </table>

        <h1>Forms</h1>

        <form>
            <fieldset>
                <legend>Inputs as descendents of labels (form legend)</legend>
                <p><label>Text input <input value="default value that goes on and on without stopping or punctuation" type="text"></label></p>
                <p><label>Email input <input type="email"></label></p>
                <p><label>Search input <input type="search"></label></p>
                <p><label>Tel input <input type="tel"></label></p>
                <p><label>URL input <input placeholder="http://" type="url"></label></p>
                <p><label>Password input <input value="password" type="password"></label></p>
                <p><label>File input <input type="file"></label></p>

                <p><label>Radio input <input name="rad" type="radio"></label></p>
                <p><label>Checkbox input <input type="checkbox"></label></p>
                <p><label><input name="rad" type="radio"> Radio input</label></p>
                <p><label><input type="checkbox"> Checkbox input</label></p>

                <p><label>Select field <select><option selected="selected">Option 01</option><option>Option 02</option></select></label></p>
                <p><label>Textarea <textarea cols="30" rows="5">Textarea text</textarea></label></p>
            </fieldset>

            <fieldset>
                <legend>Inputs as siblings of labels</legend>
                <p><label for="ic">Color input</label> <input id="ic" value="#000000" type="color"></p>
                <p><label for="in">Number input</label> <input id="in" min="0" max="10" value="5" type="number"></p>
                <p><label for="ir">Range input</label> <input id="ir" value="10" type="range"></p>
                <p><label for="idd">Date input</label> <input id="idd" value="1970-01-01" type="date"></p>
                <p><label for="idm">Month input</label> <input id="idm" value="1970-01" type="month"></p>
                <p><label for="idw">Week input</label> <input id="idw" value="1970-W01" type="week"></p>
                <p><label for="idt">Datetime input</label> <input id="idt" value="1970-01-01T00:00:00Z" type="datetime"></p>
                <p><label for="idtl">Datetime-local input</label> <input id="idtl" value="1970-01-01T00:00" type="datetime-local"></p>

                <p><label for="irb">Radio input</label> <input id="irb" name="rad" type="radio"></p>
                <p><label for="icb">Checkbox input</label> <input id="icb" type="checkbox"></p>
                <p><input id="irb2" name="rad" type="radio"> <label for="irb2">Radio input</label></p>
                <p><input id="icb2" type="checkbox"> <label for="icb2">Checkbox input</label></p>

                <p><label for="s">Select field</label> <select id="s"><option selected="selected">Option 01</option><option>Option 02</option></select></p>
                <p><label for="t">Textarea</label> <textarea id="t" cols="30" rows="5">Textarea text</textarea></p>
            </fieldset>

            <fieldset>
                <legend>Clickable inputs and buttons</legend>
                <p><input src="img/24.jpg" alt="Image (input)" type="image"></p>
                <p><input value="Reset (input)" type="reset"></p>
                <p><input value="Button (input)" type="button"></p>
                <p><input value="Submit (input)" type="submit"></p>

                <p><button type="reset">Reset (button)</button></p>
                <p><button type="button">Button (button)</button></p>
                <p><button type="submit">Submit (button)</button></p>
            </fieldset>

            <fieldset id="boxsize">
                <legend>box-sizing tests</legend>
                <div><input value="text" type="text"></div>
                <div><input value="email" type="email"></div>
                <div><input value="search" type="search"></div>
                <div><input value="http://example.com" type="url"></div>
                <div><input value="password" type="password"></div>

                <div><input value="#000000" type="color"></div>
                <div><input value="5" type="number"></div>
                <div><input value="10" type="range"></div>
                <div><input value="1970-01-01" type="date"></div>
                <div><input value="1970-01" type="month"></div>
                <div><input value="1970-W01" type="week"></div>
                <div><input value="1970-01-01T00:00:00Z" type="datetime"></div>
                <div><input value="1970-01-01T00:00" type="datetime-local"></div>
    
                <div><input type="radio"></div>
                <div><input type="checkbox"></div>

                <div><select><option selected="selected">Option 01</option><option>Option 02</option></select></div>
                <div><textarea cols="30" rows="5">Textarea text</textarea></div>

                <div><input src="img/24.jpg" alt="Image (input)" type="image"></div>
                <div><input value="Reset (input)" type="reset"></div>
                <div><input value="Button (input)" type="button"></div>
                <div><input value="Submit (input)" type="submit"></div>

                <div><button type="reset">Reset (button)</button></div>
                <div><button type="button">Button (button)</button></div>
                <div><button type="submit">Submit (button)</button></div>
            </fieldset>
        </form>

    

</body>
</html>
