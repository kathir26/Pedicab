<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>
<head>
	<title>Testing</title>	
</head>

<body>
<?php
/*
// Time Setup :
if(!in_array($_SERVER['HTTP_HOST'],array('www.pedicablocal.com','192.168.1.250')))
{
	date_default_timezone_set('America/Los_Angeles');
}

$script_tz = date_default_timezone_get();
echo "<br/>==Line==".__LINE__."==File==".__FILE__."==script_tz==>".$script_tz."<==";
echo "<br/>==Line==".__LINE__."==File==".__FILE__."==date.timezone==>".ini_get('date.timezone')."<==";
if (strcmp($script_tz, ini_get('date.timezone'))){
    echo 'Script timezone differs from ini-set timezone.';
} else {
    echo 'Script timezone and ini-set timezone match.';
}
*/


?>
<div id="inpage_test">
	<h3>This is testing page</h3>
	<p>This is for testing process, This is for testing process.</p>
</div>
</body>
<script type="text/javascript">
jQuery(document).ready(function() {
	$('a').live('click',function (e) {
		e.preventDefault();
	});
	
	$('#notification').live('click',function (e) {		
		$.notify({
	        inline: true,
	        href: '#inpage_test',
	        close: '<a href="#">Close Notification</a>'
	    })	//	, 3000
		
		/*
		 $.notify({
	        inline: true,
	        html: '<h3>This is inline</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<p>',
	        onStart: function(){ alert('This is onStart()!') },
	        onComplete: function(){ alert('This is onComplete()!') },
	        onCleanup: function(){ alert('This is onCleanup()!') },
	        onClosed: function(){ alert('This is onClosed()!') }
	    }, 3000)
		*/
	});
				
});
</script>
</html>
