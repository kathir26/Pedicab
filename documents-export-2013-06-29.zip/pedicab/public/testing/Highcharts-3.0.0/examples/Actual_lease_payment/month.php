<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Total Actual revenues report</title>

		<script src="../../js/jquery.min.js"></script>
		<script type="text/javascript">

$(function () {			
        $('#container').highcharts({
            chart: {
                type: 'line',
                marginRight: 60,
                marginBottom: 60
            },
            title: {
                text: 'Lease Payouts',
                x: -20 //center
            },
			credits: {
				enabled:0
			},
            /*subtitle: {
                text: 'Source: WorldClimate.com',
                x: -20
            },*/
            xAxis: {
                /*categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']*/
				categories: ['Jul 2012', 'Aug 2012', 'Sep 2012', 'Oct 2012', 'Nov 2012', 'Dec 2012', 'Jan 2013', 'Feb 2013', 'Mar 2013', '<span style="color:#ff0000;">Apr 2013</span>']
            },
            yAxis: {
                title: {
                    text: 'Lease Payouts ($)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valuePrefix: '$',
				valueDecimals: 2
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',               
				borderColor: '#CCCCCC',
				x: 10,
                y: 10
            },
			plotOptions: {
                series: {
                    cursor: 'pointer',
                }
            },
            series: [/*{
                name: 'Total Shifts',
                data: [50, 60, 55, 65, 70, 45, 60, 75, 48, 80, 90, 95]
            }, {
                name: 'Actually leased',
                data: [40, 55, 53, 60, 68, 44, 50, 60, 46, 60, 59, 70]
            }, */
			{
                name: 'Lease Payouts',
                data: [5050, 8000, 2300, 7500, 1500, 4500, 2500, 500, 7000, 9090]
            }/*, {
                name: 'London',
                data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
            }*/
			]
        });
});
		</script>
	</head>
	<body>
<!-- <script src="../../js/highcharts.js"></script> -->
<script src="../../js/highcharts.src.js"></script>
<!-- <script src="../../js/modules/exporting.js"></script> -->
<!-- 
/**
* Dark blue theme for Highcharts JS
* @author Torstein H�nsi
*/
 -->
<script src="../../js/themes/dark-green.js"></script>

<div id="container" style="min-width: 400px; height: 400px; margin: 0 auto"></div>

	</body>
</html>
