<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<title>Total Actual lease payouts by user report</title>

		<script src="../../js/jquery.min.js"></script>
		<script type="text/javascript">

$(function () {			
        $('#container').highcharts({
            chart: {
                type: 'line',
                marginRight: 60,
                marginBottom: 60
            },
            title: {
                text: 'Lease Payouts',
                x: -20 //center
            },
			credits: {
				enabled:0
			},
            /*subtitle: {
                text: 'Source: WorldClimate.com',
                x: -20
            },*/
            xAxis: {
                //categories: ['Mar 1 - Mar 2', 'Mar 3 - Mar 9', 'Mar 10 - Mar 16', 'Mar 17 - Mar 23', 'Mar 24 - Mar 30', 'Mar 31 - Apr 6', 'Apr 7 - Apr 13', 'Apr 14 - Apr 20', 'Apr 21 - Apr 27', 'Apr 28 - Apr 30']
            	//categories: ['4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>']
				categories: ['4/6/2013', '4/7/2013', '4/8/2013', '4/9/2013', '4/10/2013', '4/11/2013', '<span style="color:#ff0000;">4/12/2013</span>']
			},
            yAxis: {
                title: {
                    text: 'Lease Payouts ($)'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valuePrefix: '$',
				valueDecimals: 2
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',               
				borderColor: '#CCCCCC',
				x: 10,
                y: 10
            },
			plotOptions: {
                series: {
                    cursor: 'pointer',
                }
            },
            series: [/*{
                name: 'Total Shifts',
                data: [50, 60, 55, 65, 70, 45, 60, 75, 48, 80, 90, 95]
            }, {
                name: 'Actually leased',
                data: [40, 55, 53, 60, 68, 44, 50, 60, 46, 60, 59, 70]
            }, */
			{
                name: 'Lease Payouts',
                data: [2500, 2000, 7000, 3500, 2500, 500, 2000]
            }/*, {
                name: 'London',
                data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
            }*/
			]
        });
});
		</script>
	</head>
	<body>
<!-- <script src="../../js/highcharts.js"></script> -->
<script src="../../js/highcharts.src.js"></script>
<!-- <script src="../../js/modules/exporting.js"></script> -->
<!-- 
/**
* Dark blue theme for Highcharts JS
* @author Torstein H�nsi
*/
 -->
<script src="../../js/themes/dark-green.js"></script>

<div id="container" style="min-width: 400px; height: 400px; margin: 0 auto"></div>

	</body>
</html>
