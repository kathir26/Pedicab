jQuery(document).ready(function() {
	
	if($("#pc_add_event_form, #pc_edit_event_form").length) {	
		
		$("#upload_post_install").change(function () { 
			$("#upload_post_install_fakefilepc").val($("#upload_post_install").val())
		});
		
		$("#upload_bike_install").change(function () { 
			$("#upload_bike_install_fakefilepc").val($("#upload_bike_install").val())
		});
		
		
		// Date picker
		$("#event_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		$("#event_start_time, #event_end_time").timepicker({
			showSecond: false,//showSecond: true,
			/*addSliderAccess: true,
			sliderAccessArgs: { touchonly: false }*/
			timeFormat: 'hh:mm TT' //timeFormat: 'hh:mm:ss TT'
		});
		
		// Condition handling for Edit mode
		if($("#pc_edit_event_form").length) {
			if($('#user_drivers_license_hidden').val() !='') {
				$('#user_drivers_license').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
			if($('#user_profile_image_hidden').val() !='') {
				$('#user_profile_image').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
		}
		
		jQuery("#pc_add_event_form, #pc_edit_event_form").validationEngine({
			promptPosition: "topLeft",
			onValidationComplete: function(form, status) {
					// totalCostAutofill();
					var totalBikes	 = ($("#event_total_bikes").val() * 1);
					var driverCount  = ($("#event_confirmed_drivers_div ul li").length * 1);
					var bikeCount  	 = ($("#event_confirmed_bikes_div ul li").length * 1);
					var quotType	 = $(".radio-quote input[name='event_quote_type']:checked").val();
					var bikeType	 = $(".radio-quote input[name='bike_reserved_type']:checked").val();
					var categoryType = $("#event_category_type").val();
					
					var errorMsg	 = '';
					var errorFlag	 = true;
					
					if(bikeType == 2 && (bikeCount == 0 || bikeCount > totalBikes)) {
						errorMsg	 = (bikeCount == 0) ? "Select the bikes, It's required!" : "Available Bikes is exist, You want to select more bikes, <br/>Please remove the existing bikes and then select the required bikes, <br/>No. of Bikes Needed : "+totalBikes+" !";
						showCustomPrompt("event_confirmed_bikes_div", errorMsg, 1);
						errorFlag	 = false;
						backtoTop();
					}
					
					if(categoryType != 1 && quotType == 2 && (driverCount == 0 || driverCount > totalBikes)) {
						errorMsg	 = (driverCount == 0) ? "Select the drivers, It's required!" : "Available Bike is exist, You want to select more drivers, Please remove the existing drivers and then select the required drivers, No. of Drivers Needed : "+totalBikes+" !";
						showCustomPrompt("event_confirmed_drivers_div", errorMsg, 1);
						errorFlag	 = false;
						backtoTop();
					}
					
					// Condition handling for Other costs
					var ulIds	 = 'other_costs_ul';
				    var liCount	 = ($('#'+ulIds+" li").length * 1);
					if(liCount && liCount > 1) {
						$("#"+ulIds+" li input[type=text]").each(function(e) {
							vals	   = $.trim($(this).val());
							textId	   = $(this).attr('id');
							if(vals == '') {
								var errorMsg = $.trim($("#"+textId).attr('data-errormessage-value-missing'));
								showCustomPrompt(textId, errorMsg, 1);
								errorFlag	 = false;
							}
						});
					}
					
					if(errorFlag && status){					
						form.validationEngine('detach');
						form.submit();
					} else {
						return false;
					}
					
				}
		});
		
		$("#pc_add_event_form input[type='file'], #pc_edit_event_form input[type='file']").on('change',function (e) {
			var field		=	$(this);
			checkCustomFileUploads(field, 1, '', '', '');
		});
		
		$(".other-cost-add, .other-cost-remove").live('click',function (e) {
			e.preventDefault();
			var ulIds	 = 'other_costs_ul';
			var liCount	 = $('#'+ulIds+" li").length;
			var action	 = ($(this).attr('class') == 'other-cost-add') ? "add" : "remove";
			var parentId = $(this).parent().attr('id');
			var vals	 = '';
			var textId	 = '';
			var status	 = true;
			
			if(action == 'add') {
				$('#'+ulIds+" li input[type=text]").each(function(e) {
					vals	   = $.trim($(this).val());
					textId	   = $(this).attr('id');
					if(vals == '') {
						var errorMsg = $.trim($("#"+textId).attr('data-errormessage-value-missing'));
						showCustomPrompt(textId, errorMsg, 1);
						status = false;
					}
				});
				
				if(status == true) {
					if(confirm('Are you sure You want to add more Other Costs?')) {
						addMoreOtherCosts();
					} else {
						return false;
					}
				}
			} else {
				if(confirm('Are you sure to remove?')) {
					$(this).parent().remove();
					if(liCount == 1) {
						addMoreOtherCosts();
					}
					// Show the add button in the first li
					$('#'+ulIds+" li:first a.other-cost-add").css('display', 'block');		
				} else {
					return false;
				}
			}
		});
		
		function addMoreOtherCosts() {
			var ulIds	 = 'other_costs_ul';
			var liCount	 = ($('#'+ulIds+" li").length * 1);
			var newCount = ( ($('#other_costs_labels_count').val() * 1) + 1);
			var liHtml	 = '<li id="other_costs_labels_li_'+newCount+'">';
			 	liHtml	+= '<input type="text" class="wid152" value="" name="other_costs_labels[]" id="other_costs_labels_'+newCount+'" data-validation-engine="validate[optional]" data-errormessage-value-missing="Other Costs type is required!"/>';
			 	liHtml	+= '<input type="text" class="wid90" value="" name="other_costs_values[]" id="other_costs_value_'+newCount+'" data-validation-engine="validate[optional,custom[integer]]" data-errormessage-value-missing="Other Costs type is required!" data-errormessage="Please enter a valid Cost"/>';
				liHtml	+= '<a class="other-cost-remove" href="#">Remove</a>';
				if(liCount == 0) {
					liHtml += '<a class="other-cost-add" style="display:block;" href="#">Add</a>';
				} else {
					liHtml += '<a class="other-cost-add" style="display:none;" href="#">Add</a>';
				}
				liHtml	+= '</li>';
		   $("#"+ulIds).append(liHtml);
		}
		
		$(".radio-quote input:radio").live('click',function (e) {			
			var radioIds	= $(this).attr('name');
			var divIds		= (radioIds == 'event_quote_type') ? "driver_select" : "bike_select";
			var obj			= $("#formContainer .formError");
			hideInOutTimeError(obj);
		
			if($(this).val() == 1) {
				$("#"+divIds).fadeOut();
				$("#"+divIds+" li").removeClass('sel');
				$("#"+divIds+" input:checkbox").attr('checked', false);
				$("#"+divIds).parent().parent().addClass('padding_0');
				if(radioIds == 'event_quote_type') {
					$(".driver_count_class, .event_manager_class").fadeOut();
					$(".driver_count_class, .event_manager_class").parent().parent().addClass('padding_0');
				}
			} else {
				$("#"+divIds).fadeIn();
				$("#"+divIds).parent().parent().removeClass('padding_0');
				if(radioIds == 'event_quote_type') {
					$(".driver_count_class, .event_manager_class").fadeIn();
					$(".driver_count_class, .event_manager_class").parent().parent().removeClass('padding_0');
				}
			}
		});
		
		// Client Phone and Email Auto fill		
		$("#contact_client_id").on('change',function (evt) {
			var ids	 	=  ($(this).val() * 1);
			var phone	=  (ids && ids != '' && ids != 0) ? $.trim($("#client_phone_"+ids).val()) : '';
			var email	=  (ids && ids != '' && ids != 0) ? $.trim($("#client_email_"+ids).val()) : '';
			
			$("#contact_client_phone").val(phone);
			$("#contact_client_email").val(email);
		});
		
		// Event Manager Phone Auto fill		
		$("#shift_manager_id").on('change',function (e) {
			var ids	 	=  ($(this).val() * 1);
			assignEventManagerPhone(ids);
		});
		
		function assignEventManagerPhone(ids) {
			var phone	=  (ids && ids != '' && ids != 0) ? $.trim($("#drivers_phone_"+ids).val()) : '';
			$("#event_manager_phone").val(phone);
		}
		
		// Category selections.
		$("#pc_add_event_form #event_category_type").on('change',function (evt) {
			var eventCategories = [ 4, 5, 6, 7, 8, 9, 10, 11, 12 ];
			var previousValue	= ($("#hidden_event_category_type").val() * 1);
			var reloadUrl 		= siteUrl + '/eventsmanagement/event/add-event';
			var val				= ($(this).val() * 1);

			if(val && (($.inArray(val, eventCategories) === -1) || ($.inArray(val, eventCategories) !== -1 && $.inArray(previousValue, eventCategories) === -1))) {
				reloadUrl	+= '/' + val;
//				console.log("==reloadUrl==>" + reloadUrl + "<==");
				location.href = reloadUrl;
			}
			$("#hidden_event_category_type").val(val);			
		});
		
		/*
		$("#pc_edit_event_form #event_category_type").on('change',function (evt) {
			var eventCategories = [ 4, 5, 6, 7, 8, 9, 10, 11, 12 ];
			var previousValue	= ($("#hidden_event_category_type").val() * 1);
			var reloadUrl 		= siteUrl + '/eventsmanagement/event/edit-event';
			var val				= ($(this).val() * 1);

			if(val && (($.inArray(val, eventCategories) === -1) || ($.inArray(val, eventCategories) !== -1 && $.inArray(previousValue, eventCategories) === -1))) {
				reloadUrl	+= '/' + val;
//				console.log("==reloadUrl==>" + reloadUrl + "<==");
				location.href = reloadUrl;
			}
			$("#hidden_event_category_type").val(val);			
		});
		*/
		
		// Begin : Assign drivers
		$("#event_all_drivers_div li").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(1, 2);
			var liId     	= $(this).attr('id');
			var checkBoxObj = $("#"+liId + " input:checkbox");
			
			if(checkBoxObj.is(':checked')) {
				$(this).removeClass('sel');
			} else {
				$(this).addClass('sel');
			}
			
			var status	 	= (checkBoxObj.is(':checked')) ? false : true;
			checkBoxObj.attr('checked', status);
			checkEventSelectionErrorMsg(2, 2);
		});
		
		// click events. assigned drivers
		$("#event_confirmed_drivers_div li").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(1, 2);
			if(confirm('Are you sure to remove the selected Driver?')) {
				var tempIds	=  '';
				var newIds	=  '';
				var liHtml	=  '';
				var liId  	=  $(this).attr('id');
				var aTagObj =  $("#"+liId + " a");
				var toDivId	=  'event_all_drivers_div';
				liHtml		=  $("#" +liId).html();
				tempIds		=  liId;
				tempIds		=  tempIds.split('_');
				newIds		=  'event_all_drivers_li_'+tempIds.last();
				$("#"+newIds+ " input[type=checkbox]").attr('checked', false);
				$("#"+newIds).show();
				$("#"+liId).remove();
				
				liHtml  	=  liHtml.replace("event_confirmed_drivers_ids", "event_all_drivers_ids");
				liHtml  	=  liHtml.replace("event_confirmed_drivers_checkbok_", "event_all_drivers_checkbok_");
				liHtml  	=  liHtml.replace("event_confirmed_drivers_div", "event_all_drivers_div");
				
			    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
				$("#"+toDivId+" ul").append(liHtml);
				$("#" + toDivId + " input[type=checkbox]").attr('checked', false);
				$("#" + toDivId + " li").removeClass('sel');
				$("#" + liId).remove();
				checkAndUpdateEventBikeAvailability(1, 1);
				
				// status msg				
				var LoadTypes = "";
				var msg 	  = "Selected Driver is successfully removed!";
				jQuery('#event_confirmed_drivers_div').validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
				
				// Reassign the classes
				var rowClass = ''
				$("#" + toDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
				// Reorder the Shift managers
				var manager_id		=  $('#shift_manager_id').val();
				var optionHtml		=  '<option value="">Select Event manager</option>';
				$('#shift_manager_id').html(optionHtml);
				$("#event_confirmed_drivers_div li").each(function(index) {
					var textVal  	=  $(this).text();
					var liId  	 	=  $(this).attr('id');
					var tempIds		=  liId.split('_');
					 	optionHtml	=  '<option value="'+tempIds.last()+'">'+textVal+'</option>';
					$('#shift_manager_id').append(optionHtml);
				});
				$('#shift_manager_id').val(manager_id);				
				assignEventManagerPhone(manager_id);
			} else {
				return false;
			}
			checkEventSelectionErrorMsg(1, 2);
		});
		
		function checkAndUpdateEventBikeAvailability(type, value) {
			var hiddenId	=  $('#event_driver_available_hidden');
			var spanId		=  $('#event_driver_count');
			var count		=  (hiddenId.val() * 1);
				count		=  (type == 1) ? count + value : count - value;
			hiddenId.val(count);
			spanId.html(count);
		}
		
		$("#event_move_icon").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(2, 2);
			if(confirm('Are you sure you want to move the selected Drivers?')) {
				var parentDivId =  '';
				var liHtml		=  '';
				var tempIds		=  '';
				var newIds		=  '';
				var loopFlag	=  0;
				var countFlag	=  0;
				var toDivId		=  'event_confirmed_drivers_div';
				var fromDivId	=  'event_all_drivers_div';
				var totalCount	=  ($('#event_total_bikes').val() * 1);
				$("#" + fromDivId + " input[type=checkbox]:checked").each(function(e) {
					var countValue	=  ($('#event_driver_available_hidden').val() * 1);
					if((countValue - 1) >= 0) {
					    parentDivId =  $(this).parent().parent().attr('id');
						liHtml		=  $("#"+parentDivId).html();
						tempIds		=  parentDivId;
						tempIds		=  parentDivId.split('_');
						newIds		=  'event_confirmed_drivers_li_'+tempIds.last();
						liHtml  	=  liHtml.replace("event_all_drivers_ids", "event_confirmed_drivers_ids");
						liHtml  	=  liHtml.replace("event_all_drivers_checkbok_", "event_confirmed_drivers_checkbok_");
					    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
						$("#event_confirmed_drivers_div ul").append(liHtml);
						$("#" + newIds + " input[type=checkbox]").attr('checked', true);
						$("#" + parentDivId).remove();
						checkAndUpdateEventBikeAvailability(2, 1);
					} else {
						countFlag++;
						return false;
						e.stopPropagation();
					}
			        loopFlag++;
			    });
				// event_total_bikes_hidden
				// Reassign the classes
				var rowClass = ''
				$("#" + fromDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
				// Reorder the Shift managers
				if(loopFlag) {
					var manager_id		=  $('#shift_manager_id').val();
					var optionHtml		=  '<option value="">Select Event manager</option>';
					$('#shift_manager_id').html(optionHtml);
					$("#event_confirmed_drivers_div li").each(function(index) {
						var textVal  	=  $(this).text();
						var liId  	 	=  $(this).attr('id');
						var tempIds		=  liId.split('_');
						 	optionHtml	=  '<option value="'+tempIds.last()+'">'+textVal+'</option>';
						$('#shift_manager_id').append(optionHtml);
					});
					$('#shift_manager_id').val(manager_id);
					assignEventManagerPhone(manager_id);
				}
				
				// Status msg	
				var LoadTypes 	  = (loopFlag) ? "" : "";
				if(countFlag) {
					var msg   	  = "Available Drivers is exist, You want to select more drivers, Please remove the existing drivers and then select the required drivers, No. of Drivers Needed : "+totalCount+" !";
					var errorDiv  = "event_confirmed_drivers_div";
				} else {
					var msg   	  = (loopFlag) ? "Selected Driver are successfully moved!" : "Select the drivers, It's required!";
					var errorDiv  = (loopFlag) ? "event_confirmed_drivers_div" : fromDivId;
				}				
				jQuery('#'+errorDiv).validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
			} else {
				return false;
			}
			checkEventSelectionErrorMsg(1, 2);
		});
		// End : Assign drivers
		
		// Begin : Select bikes
		$("#event_all_bikes_div li").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(1, 1);
			var liId     	= $(this).attr('id');
			var checkBoxObj = $("#"+liId + " input:checkbox");
			
			if(checkBoxObj.is(':checked')) {
				$(this).removeClass('sel');
			} else {
				$(this).addClass('sel');
			}
			
			var status	 	= (checkBoxObj.is(':checked')) ? false : true;
			checkBoxObj.attr('checked', status);
			checkEventSelectionErrorMsg(2, 1);
		});
		
		// click events.
		$("#event_confirmed_bikes_div li").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(1, 1);
			if(confirm('Are you sure to remove the selected Bikes?')) {
				var tempIds	=  '';
				var newIds	=  '';
				var liHtml	=  '';
				var liId  	=  $(this).attr('id');
				var aTagObj =  $("#"+liId + " a");
				var toDivId	=  'event_all_bikes_div';
				liHtml		=  $("#" +liId).html();
				tempIds		=  liId;
				tempIds		=  tempIds.split('_');
				newIds		=  'event_all_bikes_li_'+tempIds.last();
				$("#"+newIds+ " input[type=checkbox]").attr('checked', false);
				$("#"+newIds).show();
				$("#"+liId).remove();
				
				liHtml  	=  liHtml.replace("event_confirmed_bikes_ids", "event_all_bikes_ids");
				liHtml  	=  liHtml.replace("event_confirmed_bikes_checkbok_", "event_all_bikes_checkbok_");
				liHtml  	=  liHtml.replace("event_confirmed_bikes_div", "event_all_bikes_div");
				
			    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
				$("#"+toDivId+" ul").append(liHtml);
				$("#" + toDivId + " input[type=checkbox]").attr('checked', false);
				$("#" + toDivId + " li").removeClass('sel');
				$("#" + liId).remove();
				checkAndUpdateBikeBikeAvailability(1, 1);
				
				// status msg				
				var LoadTypes = "";
				var msg 	  = "Selected Bike(s) is successfully removed!";
				jQuery('#event_confirmed_bikes_div').validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
				
				// Reassign the classes
				var rowClass = ''
				$("#" + toDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
			} else {
				return false;
			}
			checkEventSelectionErrorMsg(1, 1);
		});
		
		function checkAndUpdateBikeBikeAvailability(type, value) {
			var hiddenId	=  $('#event_bike_available_hidden');
			var spanId		=  $('#event_bike_count');
			var count		=  (hiddenId.val() * 1);
				count		=  (type == 1) ? count + value : count - value;
			hiddenId.val(count);
			spanId.html(count);
		}
		
		$("#bike_move_icon").live('click',function (e) {
			e.preventDefault();
			checkEventSelectionErrorMsg(2, 1);
			if(confirm('Are you sure you want to move the selected Bikes?')) {
				var parentDivId =  '';
				var liHtml		=  '';
				var tempIds		=  '';
				var newIds		=  '';
				var loopFlag	=  0;
				var countFlag	=  0;
				var toDivId		=  'event_confirmed_bikes_div';
				var fromDivId	=  'event_all_bikes_div';
				var totalCount	=  ($('#event_total_bikes').val() * 1);
				$("#" + fromDivId + " input[type=checkbox]:checked").each(function(e) {
					var countValue	=  ($('#event_bike_available_hidden').val() * 1);
					if((countValue - 1) >= 0) {
					    parentDivId =  $(this).parent().parent().attr('id');
						liHtml		=  $("#"+parentDivId).html();
						tempIds		=  parentDivId;
						tempIds		=  parentDivId.split('_');
						newIds		=  'event_confirmed_bikes_li_'+tempIds.last();
						liHtml  	=  liHtml.replace("event_all_bikes_ids", "event_confirmed_bikes_ids");
						liHtml  	=  liHtml.replace("event_all_bikes_checkbok_", "event_confirmed_bikes_checkbok_");
					    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
						$("#event_confirmed_bikes_div ul").append(liHtml);
						$("#" + newIds + " input[type=checkbox]").attr('checked', true);
						$("#" + parentDivId).remove();
						checkAndUpdateBikeBikeAvailability(2, 1);
					} else {
						countFlag++;
						return false;
						e.stopPropagation();
					}
			        loopFlag++;
			    });
				// event_total_bikes_hidden
				// Reassign the classes
				var rowClass = ''
				$("#" + fromDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
				// Status msg	
				var LoadTypes 	  = (loopFlag) ? "" : "";
				if(countFlag) {
					var msg   	  = "Available Bikes is exist, You want to select more bikes, <br/>Please remove the existing bikes and then select the required bikes, <br/>No. of Bikes Needed : "+totalCount+" !";
					var errorDiv  = "event_confirmed_bikes_div";
				} else {
					var msg   	  = (loopFlag) ? "Selected Bikes are successfully moved!" : "Select the Bikes, It's required!";
					var errorDiv  = (loopFlag) ? "event_confirmed_bikes_div" : fromDivId;
				}				
				jQuery('#'+errorDiv).validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
			} else {
				return false;
			}
			checkEventSelectionErrorMsg(1, 1);
		});
		// End : Select bikes
		
		// Condition handling for 
		$("#event_total_bikes").on('keyup',function (evt) {
			var bikeCout 		= ($(this).val() * 1);
				bikeCout   	 	= (customIsInteger(bikeCout)) ? bikeCout : 0;
			var bikeConfCount	= ($("#event_confirmed_bikes_div li").length * 1);
				bikeConfCount   = (customIsInteger(bikeConfCount)) ? bikeConfCount : 0;
			var driverConfCount	= ($("#event_confirmed_drivers_div li").length * 1);
				driverConfCount = (customIsInteger(driverConfCount)) ? driverConfCount : 0;
			
			/* 
			*	TODO : Condition handling for Changling bile count.
			*	In case Bike count have change. The allocated Bikes and Drivers counts has to bee changed.
			*	Need to handle the above case.
			*/
			//if(confirm('Are you sure you want to change the Bike Counts?')) {
				// Update still needed Bike count
				var newBikeCount	= (bikeCout - bikeConfCount) * 1;
				$("#event_bike_available_hidden").val(newBikeCount);
				$("#event_bike_count").html(newBikeCount);
				
				// Update still needed Driver count
				var newDriverCount	= (bikeCout - driverConfCount) * 1;
				$("#event_driver_available_hidden").val(newDriverCount);
				$("#event_driver_count").html(newDriverCount);
				$("#shift_bike_available").val(newDriverCount);
			/*} else {
				return false;
			}*/
			
			// Condition Handling for Total Cost Auto fill
			totalCostAutofill();
		});
		
		// Total Cost Auto fill
		$(".payment-bgL input[type=text]").live('keyup',function (e) {
			var pattern    =  new RegExp(/^[\-\+]?\d+$/);
			var bikeCout   =  ($('#event_total_bikes').val() * 1);
				bikeCout   =  (customIsInteger(bikeCout)) ? bikeCout : 0;
			var totalCost  =  0;
			var cost  	   =  0;
			var ids  	   =  '';
			var name       =  '';
			ids	   	   	   =  $(this).attr('id');
			name	   	   =  $(this).attr('name');
			
			if(ids == 'total_costs' || name == 'other_costs_labels[]') {
				return false;
			} else {
				// Condition Handling for Total Cost Auto fill
				totalCostAutofill();
			}
		});
		
		function totalCostAutofill() {
			var pattern    =  new RegExp(/^[\-\+]?\d+$/);
			var bikeCout   =  ($('#event_total_bikes').val() * 1);
				bikeCout   =  (customIsInteger(bikeCout)) ? bikeCout : 0;
			var totalCost  =  0;
			var cost  	   =  0;
			var ids  	   =  '';
			var name       =  '';
			
			$('.payment-bgL input[type=text]').each(function(e) {
				ids	   	   =  $(this).attr('id');
				name	   =  $(this).attr('name');
				if(ids != 'total_costs' && name != 'other_costs_labels[]') {
					cost   =  ($.trim($(this).val()) * 1);
					cost   =  (customIsInteger(cost)) ? cost : 0;
					cost   =  (ids == 'pay_per_driver') ? (cost * bikeCout) : cost;
					totalCost += cost;
				}
			});
			$("#total_costs").val(totalCost);
		}
		
	}
	
	// Event listing, Filters for Both Confirmed and Quoted Event	
	if($("#confirmed_event_filter_form, #quoted_event_filter_form").length) {
		// Initial Quoted event listing
		loadDiv('quotedListingContainer', '/event-page/1/1', '', '', 0);	
		
		// Date picker
		$("#confirmed_event_filter_form #event_date, #quoted_event_filter_form #event_date_quoted").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#confirmed_event_filter_form, #quoted_event_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/eventsmanagement/event/event-listing/ajax',
			onAjaxFormComplete: ajaxEventListingValidationCallback
		});
	}
	
	// Client Event listing, Filters for Both Confirmed and Quoted Event
	if($("#client_confirmed_event_filter_form, #client_quoted_event_filter_form").length) {
		// Initial Quoted event listing
		loadDiv('confirmedListingContainer', '/client-event-page/2/1', '', '', 0);	
		
		// Date picker
		$("#client_confirmed_event_filter_form #event_date_quoted, #client_quoted_event_filter_form #event_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#client_confirmed_event_filter_form, #client_quoted_event_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/eventsmanagement/event/client-event-listing/ajax',
			onAjaxFormComplete: ajaxClientEventListingValidationCallback
		});
	}
	
	// Event payment histories
	if($("#pc_add_event_payment_form, #pc_edit_event_payment_form").length) {	
		
		// Date picker
		$("#payment_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#pc_add_event_payment_form, #pc_edit_event_payment_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/eventsmanagement/event/ajax-add-event-payment',
			onAjaxFormComplete: ajaxAddEventPaymentValidationCallback
		});
		
		// 				event_payment_edit,   event_title, payment_date, payment_method, payment_cost
		
		$(".event_payment_edit").live('click',function (e) {
			e.preventDefault();
			var ids		= $(this).attr('id');
			var tempIds	= ids.split('_');
			var newIds  = tempIds.last();
			
			//$("#event_title").val($.trim($("#event_title_"+newIds).val()));
			$("#payment_date").val($.trim($("#payment_date_"+newIds).val()));
			$("#payment_cost").val($.trim($("#payment_cost_"+newIds).val()));
			$("#payment_method").val($.trim($("#payment_method_"+newIds).val()));
			$("#payment_id").val(newIds);
		});
		
	}
	
	// Client Event Approval		pc_approval_event_form
	$(".black").live('click',function (e) {
		e.preventDefault();
		$(".close-reveal-modal").click();
	});
	
	// Image Rotate
	/*
	$('.notification img').live('click',function (e) {
		e.preventDefault(); 
		console.log("====>icon-user<==");
		// image-rotate1-plus10 image-rotate1-minus10
	  	$(this).addClass('image-rotate1-plus10');
	});
	
	var varName = function() {
	     if($('.notification img').hasClass('image-rotate1-plus10')) {
		 	$('.notification img').addClass('image-rotate1-minus10');
			console.log("====>image-rotate1-minus10<==");		 
		 } else {
		 	$('.notification img').addClass('image-rotate1-plus10');
			console.log("====>image-rotate1-plus10<==");		
		 }
		 console.log("====>varName<==");
	};
	setInterval(varName, 500);	
	
	setTimeout(function() {
					console.log("====>clearInterval<==");
					clearInterval(varName);
					$(this).removeClass('image-rotate1-plus10');
					$(this).removeClass('image-rotate1-minus10');
				}, 1000);
	*/
	
	//$('.notification img').live('click',function (e) {
		/*
		e.preventDefault();
		$.notify({
	        inline: true,
	        href: '#inpage_test',
	        close: '<a href="#">Close Notification</a>'
	    })	//	, 3000
		*/
		/*
		 $.notify({
	        inline: true,
	        html: '<h3>This is inline</h3><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<p>',
	        onStart: function(){ alert('This is onStart()!') },
	        onComplete: function(){ alert('This is onComplete()!') },
	        onCleanup: function(){ alert('This is onCleanup()!') },
	        onClosed: function(){ alert('This is onClosed()!') }
	    }, 3000)
		*/
	//})
	/*$('#notification').live('click',function (e) {
		e.preventDefault();
		console.log("====>notification<==");
		$.notify({
	        inline: true,
	        //href: '#inpage_test',
			html: '<div id="inpage_test"><h3>This is testing page</h3><p>This is for testing process, This is for testing process.</p></div>',
	        close: '<a href="#">Close Notification</a>'
	    });	//	, 3000
	});
	*/
	
	if($('#mechanic_login_shifts').length && $('#mechanic_login_shifts').hasClass('visibility-hidden')) {
		$('#mechanic_login_shifts').removeClass('visibility-hidden');
	}
			
});

function ajaxApprovalClientEventValidationCallback(status, form, json, options) {
	if (status === true) {
		form.validationEngine('detach');
		$(".close-reveal-modal").click();
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		var eventId  = json.event_id;
		var statusId = json.status_id;
		var msg	     = (statusId == 1) ? "Event Approval successfully done !" : "Event Rejection successfully done !";
		var divId	 = (statusId == 1) ? "event_approved_" + eventId  : "event_rejected_" + eventId;
		jQuery('#'+divId).validationEngine('showPrompt', msg, '', 'topRight:-200', false);	//	bottomLeft
		
		// Assign the status class
		var statusClass	 =  (statusId == 1) ? "he-confirmed" : "he-request";
		var removalClass =  (statusId == 1) ? "he-request" : "he-confirmed";  	//	Remove the already existing class
		var rowObj 		 =  $('#'+divId).parent().parent();
		if(rowObj.hasClass(removalClass)) {
			rowObj.removeClass(removalClass);
		}
		rowObj.addClass(statusClass);
	} else {
		backtoTop();
	}
}

// Called once the server replies to the ajax form validation request
function ajaxAddEventPaymentValidationCallback(status, form, json, options) {
	if (status === true) {
		var payment_flag = json.payment_flag;
				
		if(payment_flag === true) {
			// Condition handling for Event Payments
			var eventId  	 = json.event_id;
			var balanceOwed  = (json.balance_owed * 1);
			var paymentCost  = (json.payment_cost * 1);
			var pendingBals	 = (balanceOwed - paymentCost);
			$("#payment_date, #payment_cost, #payment_method, #payment_id").val('');
			
			$("#balance_owed").val(pendingBals);
			
			var divId	 	 = "event_payment_list_" + eventId;
			var msg	     	 = "Event Payment is successfully done!";
			loadDivEventPayments('listingContainer', '/eventsmanagement/event/event-payments-list/1', '', '', 0, divId, msg, 1);
			
			if(pendingBals <= 0) {
				/*
				var divId	 = "payment_cost";
				var msg	     = "Balance Payment is successfully Payments !";
				jQuery('#'+divId).validationEngine('showPrompt', msg, '', 'bottomLeft', true);	//	bottomLeft	// topRight:-200
				*/
			}
			
		} else {
			var msg	     	 = json.err_msg;
			var divId	 	 = "payment_cost";
			jQuery('#'+divId).validationEngine('showPrompt', msg, '', 'bottomLeft', true);	//	bottomLeft	// topRight:-200
		}
	} else {
		backtoTop();
	}
}

/*
*	Hide the Showing Error msg
*/
function checkEventSelectionErrorMsg(checkType, diveId) {
  		//	1 - Hide after 5000 miliseconds, 2 - Hide immidiate
	var hideDivs = (diveId == 1) ? "bike_select" : "driver_select";
	if(checkType == 1) {
		setTimeout(function() {
					var obj	= $("#" +hideDivs+ " .formError");
					hideInOutTimeError(obj);
				}, 20000);
	} else {
		var obj	= $("#" +hideDivs+ " .formError");
		hideInOutTimeError(obj);
	}
}

/*
*	Condition handling for Confirmed and Quoted Events
*/
function ajaxEventListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');		//	"#confirmed_event_filter_form, #quoted_event_filter_form"
		
		if(formId && formId == 'quoted_event_filter_form') {
			loadDiv('quotedListingContainer', '/event-page/1', '', '', 0);
		} else {
			loadDiv('confirmedListingContainer', '/event-page/2', '', '', 0);
		}
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message		
	}
	return false;
}

/*
*	Condition handling for Confirmed and Quoted Events
*/
function ajaxClientEventListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');		//	"#confirmed_event_filter_form, #quoted_event_filter_form"
		
		if(formId && formId == 'client_quoted_event_filter_form') {
			loadDiv('quotedListingContainer', '/client-event-page/1', '', '', 0);
		} else {
			loadDiv('confirmedListingContainer', '/client-event-page/2', '', '', 0);
		}
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message		
	}
	return false;
}

/*
*	Custom function to find out the Given value is Integer or not.
*/
function customIsInteger(val) {
	var pattern    =  new RegExp(/^[\-\+]?\d+$/);
	var returnVal  =  (pattern.test(val)) ? true : false;
	return returnVal;
}

function loadDivEventPayments(divId, url, sortBy, sortType, urlType, errorMsgId, msg, showListType) {
	loadShowAndHide(1);
	var url	=	(urlType == 1) ? url : siteUrl + url;
	if(sortBy != '' && sortBy != 'undefined') {
		url	= url+'/'+sortBy;
	}
	if(sortType != '' && sortType != 'undefined') {
		url	= url+'/'+sortType;
	}
	
	$.post(url, function(data){
		$('#'+divId).html(data);
		loadShowAndHide(2);
		
		// Condition handling for error msg
		if(errorMsgId) {
			jQuery('#'+errorMsgId).validationEngine('showPrompt', msg, '', 'topLeft:-20', true);	//	bottomLeft
		}
	});
}


/* 
*	Financial Modules	-------------------------------------
*/

jQuery(document).ready(function() {
	// Financial Event listing, Filters for Both Open and Closed Event	
	if($("#opened_event_filter_form, #closed_event_filter_form").length) {
		// Initial Quoted event listing
		loadDiv('closedListingContainer', '/financial-event-page/2/1', '', '', 0);	
		
		// Date picker
		$("#opened_event_filter_form #event_date, #closed_event_filter_form #event_date_closed").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#opened_event_filter_form, #closed_event_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/financialmanagement/financial/financial-event-listing/ajax',
			onAjaxFormComplete: ajaxFinancialEventListingValidationCallback
		});
	}
	
	// Deposit lease fees listing.
	if($("#deposit_lease_fees_filter_form").length) {		
		// Date picker
		$("#deposit_lease_fees_filter_form #shift_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#deposit_lease_fees_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/financialmanagement/financial/deposit-lease-fees-listing/ajax',
			onAjaxFormComplete: ajaxDepositLeaseFeesListingValidationCallback
		});
	}
	
	// Add Deposit lease fees.
	$('.show_depose_lease').click(function(e) {
		e.preventDefault();
		$('.multiple_depose_lease').slideToggle();
		$(this).toggleClass('btn-plus btn-minus');
	});
	
	// Edit Icons
	$('.pay-method-icon-edit').click(function(e) {
		e.preventDefault();
		var id	=   $(this).attr('id');		
		//$('#' + id + '_edit').slideToggle();
		$('#' + id + '_edit').toggleClass('display-block display-none');
	});
	
	$('.pay_method_close').click(function(e) {
		e.preventDefault();
		var id	=   $(this).parent().parent().attr('id');
		//$('#' + id + '_edit').slideToggle();
		$('#' + id).toggleClass('display-block display-none');
	});
	
	if($("#pc_add_drivers_leasefees_form").length) {		
		// Date picker
		/*
		$("#pc_add_drivers_leasefees_form .calc-txbox").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		*/
		
		jQuery("#pc_add_drivers_leasefees_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/financialmanagement/financial/ajax-deposite-lease-payment',
			onAjaxFormComplete: ajaxDepositeLeasePaymentValidationCallback
		});
	}
		
});

function ajaxDepositeLeasePaymentValidationCallback(status, form, json, options) {
	console.log("==status==>" + status + "<==");
	$(".multiple_depose_lease .multi-table").hide();
	$(".multiple_depose_lease .sucess-table").show();
	if (status === true) {
		var formId	=  form.attr('id');		
		loadDiv('listingContainer', '/deposit-lease-fees-list-page/1', '', '', 0);
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message		
	}
	return false;
}

function ajaxDepositLeaseFeesListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');		//	"#confirmed_event_filter_form, #quoted_event_filter_form"
		
		loadDiv('listingContainer', '/deposit-lease-fees-list-page/1', '', '', 0);
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message
	}
	return false;
}

function ajaxFinancialEventListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');
		
		if(formId && formId == 'opened_event_filter_form') {
			loadDiv('openListingContainer', '/financial-event-page/1', '', '', 0);
		} else {
			loadDiv('closedListingContainer', '/financial-event-page/2', '', '', 0);
		}
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message		
	}
	return false;
}
