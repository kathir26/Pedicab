var common_obj;
 $(document).on('click','a.close_event',function(){
   	$(".event_detail_view").fadeOut();
 });
 $('#shift_full_calendar').fullCalendar({
	editable: false,
	header: {
			left: 'prevYear,prev',
			center: 'today title',
			right: 'next,nextYear'
		},
	events: function(start, end, callback) {
       var date 		= $("#shift_full_calendar").fullCalendar('getDate');
		   var month_int 	= date.getMonth();
	   var cur_dat		= new Date();
	   var cur_mon		= cur_dat.getMonth();
	    $.ajax({
            url: siteUrl+'/schedulemanagement/shift/client-calendar-details',
            dataType: 'json',
			type:'post',
            data: {
                // our hypothetical feed requires UNIX timestamps
                start	: Math.round(start.getTime() / 1000),
                end		: Math.round(end.getTime() / 1000),
				month	: parseInt(month_int) + parseInt(1)
            },
            success: function(doc) {
				if(cur_mon != month_int)
				{
					$('div.fc-view-month td').removeClass('fc-state-highlight');
				}
                callback(doc);
            }
        });
    },
	loading: function(bool) {
		if (bool) $('#divLoader').show();
		else $('#divLoader').hide();
	},
	eventClick: function(calEvent, jsEvent){
		$(".event_detail_view").hide();
		if(calEvent.date_check == 1)
		{
			/*var day 	= ($.fullCalendar.formatDate( calEvent.start, 'dd' ));
            var month 	= ($.fullCalendar.formatDate( calEvent.start, 'MM' ))-1;
            var year 	= ($.fullCalendar.formatDate( calEvent.start, 'yyyy' ));*/
			var div_id	= $(this).attr('id-attr');
			var obj_th	= this;
			common_obj	= this;
			$('.event_detail_view').html('');
			if(calEvent.shift_event == 1)
			{
				var html_det 	= '';
				var event_id	= calEvent.event_id;
				$.post(siteUrl+"/schedulemanagement/shift/event-details/"+event_id, function(result){
					if(result.shift_id != '' && result.shift_id != undefined)
					{
						html_det 	+='<a href="javascript:void(0);" class="close-x close_event" style="display:block;">X</a>';
						html_det 	+='<h5>'+result.title+'</h5>';
						html_det 	+='<table class="tab-Eview1"><tr><td width="130">Events Name</td><td width="10">:</td><td width="200">'+result.title+'</td></tr>';
						html_det 	+='<tr><td>Events Time</td><td>:</td><td>'+result.st_time+' to '+result.ed_time+'</td></tr>';
						html_det 	+='<tr><td>Events Category</td><td>:</td><td>'+result.category+'</td></tr>';
						html_det 	+='<tr><td>Events Description</td><td></td><td></td></tr>';
						html_det 	+='<tr><td colspan="3">'+result.description+'</td></tr>';
						html_det	+= '</table>';
						$('.event_detail_view').css('left','');
						$('.event_detail_view').css('top','');
						$('.event_detail_view').html(html_det);
						$('.event_detail_view').fadeIn();
						var center_top  = Math.max(0, (($(window).height() - $('.event_detail_view').outerHeight()) / 2) + $(window).scrollTop());
			    		var center_left = Math.max(0, (($(window).width() - $('.event_detail_view').outerWidth()) / 2) + $(window).scrollLeft());
						$('.event_detail_view').css({
							'left'		: (center_left - 200) +'px',
							'top'		: (center_top - 100) +'px',
							'position'	: 'absolute',
							'z-index'	: '1000'
						});
					}
				},"json");
			}
		}
	}
	
});