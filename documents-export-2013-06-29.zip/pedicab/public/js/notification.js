//Notification Starts
var url_note	= siteUrl+'/managernotemanagement/note/dashboard-notification';
setIntervalFun();
window.setInterval(function(){
	setIntervalFun();
}, 20000);

/*function callback() {
  setTimeout(function() {
    $('.notif-anim-count').effect( 'shake', 700, callback );
  }, 20000 );
};*/
var count 		 = 0;
var countnotif   = '';
var animateNotif = 1000;
var effectNotif  = 5000;
var notifyMinute = 60000 + parseInt(animateNotif + effectNotif);
var notifSec	 = 0;
var notifiTime	 = 0;
$(document).keyup(function(e) //Escape is pressed
{
  if(e.keyCode == 27)
  {
	 $('.notif-anim-count').animate({ bottom: '-200px'}, animateNotif);
  }
});
function notifyAfterMinute()
{
	notifiTime	= setTimeout(function() {
		if(count > 0)
		{
		    $('.notif-anim-count').animate({ bottom: '10px'}, animateNotif);
			setTimeout(function() {
			   $('.notif-anim-count').effect( 'shake', 500 ,callbackNewTime);
			}, effectNotif );
		}
	}, notifyMinute );
}
//var animateDurate
function callbackNewTime() {
    setTimeout(function() {
	    $('.notif-anim-count').animate({ bottom: '-200px'}, animateNotif);
	}, effectNotif );
	notifyAfterMinute();
};
function callbackNew() {
    setTimeout(function() {
	    $('.notif-anim-count').animate({ bottom: '-200px'}, animateNotif);
	}, effectNotif );
};
function setIntervalFun()
{
	var html = '';
	var set_heig = el = 0;
	$.post(url_note,function(result){
		count = result.notif_count;
		if(countnotif != count)
		{
			if(count > 0)
			{
				$('.span_notif_count').html('<strong>'+count+'</strong>');
				$('.count-alert-notif').html('<strong> You have '+count+' new notification.</strong>');
				$('.notif-anim-count').animate({ bottom: '10px'}, animateNotif);
				clearTimeout(notifiTime);
				setTimeout(function() {
				   $('.notif-anim-count').effect( 'shake', 500 ,callbackNew);
				}, effectNotif );
				countnotif = count;
				notifyAfterMinute();
				//$('.notif-anim-count').effect("highlight", {color:'red'}, 3000);
			}
			else
			{
				$('.span_notif_count').html('');
				countnotif = count;
			}
		}
		html  += '<div class="notification-list" style="height:185px;"><b></b><h6>Notifications</h6>';
		html  += '<ul style="height:165px;overflow:auto;">';
		for(n in result)
		{
			var loc_url = 'javascript:void(0);';
			if(result[n].notif_id != undefined)
			{
				el++;
				if(result[n].notif_role == 2)
				{
					if(result[n].notif_type == 0)
					{
						loc_url	= siteUrl+'/managernotemanagement/note/mechanic-receive-listing';
					}
					else if(result[n].notif_type == 5)
					{
						loc_url	= siteUrl+'/bikemanagement/accident/accident-listing';
					}
					else if(result[n].notif_type == 8)
					{
						loc_url	= siteUrl+'/maintenancemanagement/job/mechanic-job/1';
					}
					else if(result[n].notif_type == 11)
					{
						loc_url	= siteUrl+'/miscellaneousmanagement/schedule';
					}
				}
				else if(result[n].notif_role == 1)
				{
					if(result[n].notif_type == 0)
					{
						loc_url	= siteUrl+'/managernotemanagement/note/driver-receive-listing';
					}
					else if(result[n].notif_type == 5)
					{
						loc_url	= siteUrl+'/bikemanagement/accident/accident-listing';
					}
					else if(result[n].notif_type == 8)
					{
						loc_url	= siteUrl+'/maintenancemanagement/job/job-listing';
					}
					else if(result[n].notif_type == 1 || result[n].notif_type == 2)
					{
						loc_url	= siteUrl+'/schedulemanagement/shift/driver-view-shift';
					}
					else if(result[n].notif_type == 3 || result[n].notif_type == 4)
					{
						loc_url	= siteUrl+'/schedulemanagement/shift/driver-confirmed-shift/2';
					}
					else if(result[n].notif_type == 9 || result[n].notif_type == 10)
					{
						loc_url	= siteUrl+'/schedulemanagement/shift/driver-confirmed-shift/1';
					}
					else if(result[n].notif_type == 11)
					{
						loc_url	= siteUrl+'/miscellaneousmanagement/schedule';
					}
				}
				else if(result[n].notif_role == 6)
				{
					if(result[n].notif_type == 0)
					{
						loc_url	= siteUrl+'/managernotemanagement/note/client-receive-listing';
					}
				}
				else if(result[n].notif_role == 3 || result[n].notif_role == 5)
				{
					if(result[n].notif_type == 0)
					{
						loc_url	= siteUrl+'/managernotemanagement/note/location-receive-listing';
					}
					else if(result[n].notif_type == 5)
					{
						loc_url	= siteUrl+'/bikemanagement/accident/accident-listing';
					}
					else if(result[n].notif_type == 8)
					{
						loc_url	= siteUrl+'/maintenancemanagement/job/job-listing';
					}
					else if(result[n].notif_type == 1 || result[n].notif_type == 3 || result[n].notif_type == 6)
					{
						loc_url	= siteUrl+'/schedulemanagement/shift/manage-shift';
					}
					else if(result[n].notif_type == 2 || result[n].notif_type == 4 || result[n].notif_type == 7 || result[n].notif_type == 9 || result[n].notif_type == 10)
					{
						loc_url	= siteUrl+'/eventsmanagement/event';
					}
					else if(result[n].notif_type == 11)
					{
						loc_url	= siteUrl+'/miscellaneousmanagement/schedule';
					}
				}
				html  += '<li><a href="'+loc_url+'">'+result[n].notif_name+'</a><p>'+result[n].notif_sub+'<br> Created on '+result[n].notif_date+'</p></li>';
			}
			if(el == 0)
			{
				html  += '<li>Oops! No notification.</li>';
			}
		}
		html  += ' </ul></div>';
		$('.notif-dashboard-count').html(html);
	},'json')
}
// Notification popups
var durationsFadeInTime	= 1;		//	1200
$(document).click(function(e){
    if(!$(e.target).is('.notif-dashboard-count, .notification,.notif_details_display *,.notification-list *'))
	{
        /*$('.notification-list').animate({
		"height": "-=185px"},{
					duration: durationsFadeInTime,
	  		complete: function() {
	   			$('.notif-dashboard-count').fadeOut('slow');
			}
		});*/
		//$('.notif-dashboard-count').fadeOut();
		$('.notif-dashboard-count').hide();
    }
	if($(e.target).is('.close-notic-alert, .close-notic-alert *'))
	{
		$('.notif-anim-count').animate({ bottom: '-200px'}, animateNotif);
    }
	/*if(!$(e.target).is('.notif-anim-count *'))
	{
		$('.notif-anim-count').animate({ bottom: '-200px'}, animateNotif);
    }*/
});
$(document).on('click','img.notif_details_display',function(e){
	if($(".notif-dashboard-count").is(':hidden'))
	{
		//$('.notif-dashboard-count').fadeIn();
		$('.notif-dashboard-count').show();
		//$('.notification-list').animate({"height": "+=185px"}, durationsFadeInTime);
		$('.notification-list').fadeIn('slow');
		var url_note	= siteUrl+'/managernotemanagement/note/view-notification';
		$.post(url_note,function(result){
			if(result == 1)
			{
				count = 0;
				$('.span_notif_count').html('');
			}
		});
	}
	else
	{
		/*$('.notification-list').animate({
				"height": "-=180px"},{
							duration: durationsFadeInTime,
	    		complete: function() {
	     			$('.notif-dashboard-count').fadeOut('slow');
				}
		});*/
		//$('.notif-dashboard-count').fadeOut();
		$('.notif-dashboard-count').hide();
	}
	e.stopPropagation();
});
/* Notification Ends */