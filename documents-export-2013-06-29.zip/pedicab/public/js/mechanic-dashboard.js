var common_obj;
 $(document).on('click','a.close_event',function(){
   	$(".event_detail_view").fadeOut();
 });
 $('#shift_full_calendar').fullCalendar({
	editable: false,
	header: {
			left: 'prevYear,prev',
			center: 'today title',
			right: 'next,nextYear'
		},
	events: function(start, end, callback) {
       var date 		= $("#shift_full_calendar").fullCalendar('getDate');
	   var month_int 	= date.getMonth();
	   var cur_dat		= new Date();
	   var cur_mon		= cur_dat.getMonth();
	    $.ajax({
            url: siteUrl+'/schedulemanagement/shift/mechanic-calendar-details',
            dataType: 'json',
			type:'post',
            data: {
                // our hypothetical feed requires UNIX timestamps
                start	: Math.round(start.getTime() / 1000),
                end		: Math.round(end.getTime() / 1000),
				month	: parseInt(month_int) + parseInt(1)
            },
            success: function(doc) {
				if(cur_mon != month_int)
				{
					$('div.fc-view-month td').removeClass('fc-state-highlight');
				}
                callback(doc);
            }
        });
    },
	loading: function(bool) {
		if (bool) $('#divLoader').show();
		else $('#divLoader').hide();
	},
	dayClick: function(date, allDay, jsEvent, view) {
       	var curr_date 		= new Date();
		var new_dat			= curr_date.getDate()+curr_date.getMonth()+curr_date.getFullYear();
		var cal_date		= date.getDate()+date.getMonth()+date.getFullYear();
	   	if(new_dat == cal_date)
	   	{
	   		location.href = '/maintenancemanagement/job/mechanic-job/1';
	   	}
    },
	eventClick: function(calEvent, jsEvent){
		$(".event_detail_view").hide();
		if(calEvent.date_check == 1)
		{
			/*var day 	= ($.fullCalendar.formatDate( calEvent.start, 'dd' ));
            var month 	= ($.fullCalendar.formatDate( calEvent.start, 'MM' ))-1;
            var year 	= ($.fullCalendar.formatDate( calEvent.start, 'yyyy' ));*/
			var div_id	= $(this).attr('id-attr');
			var obj_th	= this;
			common_obj	= this;
			$('.event_detail_view').html('');
			if(calEvent.job_id != '' && calEvent.job_id != undefined)
			{
				var html_det 	= '';
				var job_id		= calEvent.job_id;
				$.post(siteUrl+"/schedulemanagement/shift/job-sheet-details/"+job_id, function(result){
					if(result.job_id != '' && result.job_id != undefined)
					{
						html_det 	+='<a href="javascript:void(0);" class="close-x close_event" style="display:block;">X</a>';
						html_det 	+='<h5>'+result.number+'</h5>';
						html_det 	+='<table class="tab-Eview1"><tr><td width="130">Bike Number</td><td width="10">:</td><td width="200">'+result.bike+'</td></tr>';
						html_det 	+='<tr><td>Job Estimated Minutes</td><td>:</td><td>'+result.minutes+'</td></tr>';
						html_det 	+='<tr><td>Job Issue</td><td>:</td><td>'+result.issue+'</td></tr>';
						html_det 	+='<tr><td>Job Urgencty</td><td>:</td><td>'+result.urgency+'</td></tr>';
						html_det 	+='<tr><td>Requested by</td><td>:</td><td>'+result.request+'</td></tr>';
						html_det 	+='<tr><td>Job Status</td><td>:</td><td>'+result.status+'</td></tr>';
						html_det	+= '</table>';
						$('.event_detail_view').css('left','');
						$('.event_detail_view').css('top','');
						$('.event_detail_view').html(html_det);
						$('.event_detail_view').fadeIn();
						var center_top  = Math.max(0, (($(window).height() - $('.event_detail_view').outerHeight()) / 2) + $(window).scrollTop());
			    		var center_left = Math.max(0, (($(window).width() - $('.event_detail_view').outerWidth()) / 2) + $(window).scrollLeft());
						$('.event_detail_view').css({
							'left'		: (center_left - 200) +'px',
							'top'		: (center_top - 100) +'px',
							'position'	: 'absolute',
							'z-index'	: '1000'
						});
					}
				},"json");
			}
			else if(calEvent.shift_event == 4)
			{
				var html_det 	= '';
				var meetId		= calEvent.meet_id;
				$.post(siteUrl+"/miscellaneousmanagement/schedule/meeting-details/"+meetId, function(result){
					if(result.meet_id != '' && result.meet_id != undefined)
					{
						html_det 	+='<a href="javascript:void(0);" class="close-x close_event" style="display:block;">X</a>';
						html_det 	+='<h5>Meeting Details</h5>';
						html_det 	+='<table class="tab-Eview1"><tr><td width="130">Meeting Date</td><td width="10">:</td><td width="200">'+result.date+'</td></tr>';
						html_det 	+='<tr><td>Meeting Time</td><td>:</td><td>'+result.time+'</td></tr>';
						html_det 	+='<tr><td>Venue</td><td>:</td><td>'+result.venue+'</td></tr>';
						html_det 	+='<tr><td>Description</td><td></td><td></td></tr>';
						html_det 	+='<tr><td colspan="3">'+result.desc+'</td></tr>';
						html_det 	+='<tr><td>Additional Notes</td><td></td><td></td></tr>';
						html_det 	+='<tr><td colspan="3">'+result.add_notes+'</td></tr>';
						if(result.req_stat == 2)
						{
							html_det 	+='<tr><td colspan="3" class="tab-Eview-edit"><a href="javascript:void(0);" class="cancel_event_conf" dat-shift="'+result.shift_id+'" div_col="'+$(common_obj).attr('div_col')+'" dat-sdt="'+event_id+'" dat-occ="2" dat-req="'+result.req_id+'" dat-stat="'+result.req_stat+'">Cancel Event</a></td></tr>';
						}
						html_det	+= '</table>';
						$('.event_detail_view').css('left','');
						$('.event_detail_view').css('top','');
						$('.event_detail_view').html(html_det);
						$('.event_detail_view').fadeIn();
						var center_top  = Math.max(0, (($(window).height() - $('.event_detail_view').outerHeight()) / 2) + $(window).scrollTop());
			    		var center_left = Math.max(0, (($(window).width() - $('.event_detail_view').outerWidth()) / 2) + $(window).scrollLeft());
						$('.event_detail_view').css({
							'left'		: (center_left - 200) +'px',
							'top'		: (center_top - 100) +'px',
							'position'	: 'absolute',
							'z-index'	: '1000'
						});
					}
				},"json");
			}
		}
	}
	
});