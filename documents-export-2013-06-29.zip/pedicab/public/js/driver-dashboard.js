 //Slider for Next Shift
var curr_slide  = 1;
var total_slide = 0;
$(".next_next").click(function(){
	total_slide		= $(".next_slider li").length;
	if(curr_slide >= 1 && curr_slide < total_slide)
	{
		$('#next_slide_'+curr_slide).hide();
		curr_slide++;
		$('#next_slide_'+curr_slide).show();
	}
	if(curr_slide == 1)
	{
		$('.prev_next').addClass('hide-arrow');
	}
	else
	{
		$('.prev_next').removeClass('hide-arrow');
	}
	if(curr_slide == total_slide)
	{
		$('.next_next').addClass('hide-arrow');
	}
	else
	{
		$('.next_next').removeClass('hide-arrow');
	}
});
$(".prev_next").click(function(){
	total_slide		= $(".next_slider li").length; 
	if(curr_slide > 1)
	{
		$('#next_slide_'+curr_slide).hide();
		curr_slide--;
		$('#next_slide_'+curr_slide).show();
	}
	if(curr_slide == 1)
	{
		$('.prev_next').addClass('hide-arrow');
	}
	else
	{
		$('.prev_next').removeClass('hide-arrow');
	}
	if(curr_slide == total_slide)
	{
		$('.next_next').addClass('hide-arrow');
	}
	else
	{
		$('.next_next').removeClass('hide-arrow');
	}
	
});
 //Slider for Todays Shift
 var curr_slide_t  = 1;
	 var total_slide_t = 0;
 $(".next_today").click(function(){
	total_slide_t		= $(".todays_slider li").length; // total number of slides
	if(curr_slide_t >= 1 && curr_slide_t < total_slide_t)
	{
		$('#today_slide_'+curr_slide_t).hide();
		curr_slide_t++;
		$('#today_slide_'+curr_slide_t).show();
	}
	if(curr_slide_t == 1)
	{
		$('.prev_today').addClass('hide-arrow');
	}
	else
	{
		$('.prev_today').removeClass('hide-arrow');
	}
	if(curr_slide_t == total_slide_t)
	{
		$('.next_today').addClass('hide-arrow');
	}
	else
	{
		$('.next_today').removeClass('hide-arrow');
	}
});
$(".prev_today").click(function(){
	total_slide_t		= $(".todays_slider li").length; 
	if(curr_slide_t > 1)
	{
		$('#today_slide_'+curr_slide_t).hide();
		curr_slide_t--;
		$('#today_slide_'+curr_slide_t).show();
	}
	if(curr_slide_t == 1)
	{
		$('.prev_today').addClass('hide-arrow');
	}
	else
	{
		$('.prev_today').removeClass('hide-arrow');
	}
	if(curr_slide_t == total_slide_t)
	{
		$('.next_today').addClass('hide-arrow');
	}
	else
	{
		$('.next_today').removeClass('hide-arrow');
	}
	
});
 var common_obj;
 $(document).on('click','a.close_event',function(){
   	$(".event_detail_view").fadeOut();
 });
 $(document).on('click','a.close_shift',function(){
   	$(".shift_cancel_div").fadeOut();
 });
 $(document).on('click','div.undefinedformError',function(){
	$(this).remove();
 });
 $(document).on('click','div.reason_cancelformError',function(){
	$(this).remove();
 });
 $(document).on('click','.valid-reason_text',function(){
	$('div.reason_cancelformError').remove();
	var text_cont	= $('#reason_cancel').val();
	if($.trim(text_cont) == '')
	{
		$('#reason_cancel').validationEngine('showPrompt','Reason is required' , '":"', 'topRight:-260', false);
		return false;
	}
	else
	{
		var shift_id		= $('#reason_cancel').attr('dat-shift');
		var shift_dt_id		= $('#reason_cancel').attr('dat-sdt');
		var shift_occurs	= $('#reason_cancel').attr('dat-occ');
		var req_id			= $('#reason_cancel').attr('dat-req');
		var req_stat		= $('#reason_cancel').attr('dat-stat');
		var dat_col			= $('#reason_cancel').attr('dat-col');
		var url_path		= siteUrl+"/driver-shift-cancel/"+shift_id+"/"+shift_occurs+"/"+shift_dt_id+"/"+req_id+"/"+req_stat;
		$.post(url_path,'reason='+encodeURIComponent(text_cont),function(result){
			$('.shift_cancel_div').fadeOut();
			if(shift_occurs == 1)
			{
				var top_right = 7;
			}
			else
			{
				var top_right = -57;
			}
			if(dat_col == 7)
			{
				if(shift_occurs == 1)
				{
					top_right	= top_right - 44;
				}
				else
				{
					top_right	= top_right - 64;
				}
				
			}
			if(result.err == 0)
			{
				if(shift_occurs == 1)
				{
					if(result.assign == 0 && req_stat == 2)
					{
						var new_bik_count	= parseInt($(common_obj).attr('dat-bike')) + parseInt(1);
						$(common_obj).attr('dat-bike',new_bik_count);
						$(common_obj).find('span').html(new_bik_count);
					}
					$(common_obj).attr('req-stat',result.req_st);
					$(common_obj).find('a').removeClass().addClass('Si-fade');
					$(common_obj).removeClass('li-trig-click');
					$(common_obj).validationEngine('showPrompt','Shift has been cancelled successfully!' , '":"', 'topRight:'+top_right, false);
				}
				else
				{
					$(common_obj).find('a').css('color','#979994');
					$(common_obj).validationEngine('showPrompt','Event has been cancelled successfully!' , '":"', 'topRight:'+top_right, false);
				}
			}
			else if(result.err == 2)
			{
				$(common_obj).validationEngine('showPrompt','Sorry! You will not able to cancel your shift <br> before cut off period.' , '":"', 'topRight:'+top_right, false);
			}
		},'json');
	}
 });
 $(document).on('click','li.li-trig-click',function(){
 	$('.undefinedformError').remove();
	$(".shift_cancel_div").hide();
	$('.full_date_check').css('z-index',8);
	if($(this).attr('dat-chk') == 1)
	{
		var bike_count	= $(this).attr('dat-bike');
		var shift_dt_id	= $(this).attr('shift-dt-id');
		var shift_id	= $(this).attr('shift-id');
		if($(this).attr('li_col') == 7)
		{
			var top_right	= '-44';
		}
		else
		{
			var top_right	= '7';
		}
		var this_obj	= this;
		common_obj		= this;
		var div_full_ca = $(this).parents('div.full_date_check').attr('id');
		$('#'+div_full_ca).css('z-index',10); // for error msg prompt div
		if($(this).attr('req-id') != '' && $(this).attr('req-id') != undefined)
		{
			var req_id	 = $(this).attr('req-id');
			if($(this).attr('req-stat') == 1)
			{
				alert('Your request is in process.');
			}
			else if($(this).attr('req-stat') == 2)
			{
				if(confirm('Are you sure to cancel this shift?'))
				{
					var div_id		= $(this).parents('div.full_date_check').attr('id');
					var center_top  = Math.max(0, (($(window).height() - $('.shift_cancel_div').outerHeight()) / 2) + $(window).scrollTop());
		    		var center_left = Math.max(0, (($(window).width() - $('.shift_cancel_div').outerWidth()) / 2) + $(window).scrollLeft());
					$('.shift_cancel_div').css('left','');
					$('.shift_cancel_div').css('top','');
					$('.shift_cancel_div').css({
						'left'		: (center_left - 200) +'px',
						'top'		: (center_top - 100) +'px',
						'z-index'	: '1000'
					});
					$('.shift_cancel_div #reason_cancel').attr({
						'dat-shift'		: shift_id,
						'dat-sdt'		: shift_dt_id,
						'dat-occ'		: 1,
						'dat-req'		: req_id,
						'dat-stat'		: $(this).attr('req-stat'),
						'dat-col'		: $(this).attr('li_col')
					});
					$('#reason_cancel').val('');
					$('.shift_cancel_div h5').html('Cancel Shift');
					$('.shift_cancel_div').fadeIn();
				}
			}
			else
			{
				if(confirm('Are you sure to cancel this shift?'))
				{
					var url_path		= siteUrl+"/driver-shift-cancel/"+shift_id+"/1/"+shift_dt_id+"/"+req_id+"/"+$(this).attr('req-stat');
					$.post(url_path,function(result){
						if(result.err == 0)
						{
							$(common_obj).attr('req-stat',result.req_st);
							$(common_obj).find('a').removeClass().addClass('Si-fade');
							$(common_obj).removeClass('li-trig-click');
							$(common_obj).validationEngine('showPrompt','Shift has been cancelled successfully!' , '":"', 'topRight:'+top_right, false);
						}
					},'json');
				}
			}
		}
		else
		{
			if(confirm('Are you sure to request this shift?'))
			{
				var url_path	= siteUrl+"/driver-shift-req-cal/"+shift_id+"/1/"+shift_dt_id;
				$.post(url_path,function(result){
					if(result.err == 0)
					{
						var req_id	 = result.req_id;
						var req_stat = result.req_stat;
						var add_cls = '';
						var msg = '';
						$(this_obj).attr({'req-id' 		: req_id,
										  'req-stat'	: req_stat});
						if(req_stat == 1)
						{
							add_cls	= 'Si-blue';
							msg 	= 'Driver shift request successfully logged!';
						}
						else if(req_stat == 2)
						{
							add_cls	= 'Si-green';
							msg 	= 'Driver shift confirmed successfully!';
							$(this_obj).find('span').html(parseInt(bike_count) - 1);
						}
						else if(req_stat == 3)
						{
							add_cls	= 'Si-orange';
							msg 	= 'Driver shift request is in on call list!';
						}
						$(this_obj).find('a').addClass(add_cls);
						$(this_obj).find('a').attr('href','javascript:void(0);');
						$(this_obj).validationEngine('showPrompt',msg , '":"', 'topRight:'+top_right, false);
					}
					else if(result.err == 2)
					{
						msg		= 'Already you have confirmed Shift/Event in this date.';
						$(this_obj).validationEngine('showPrompt',msg , '":"', 'topRight:'+top_right, false);
					}
				},'json');
				return false;
			}
		}
	}
 });
 $(document).on('click','a.cancel_event_conf',function(){
 	if(confirm('Are you sure to cancel this event?'))
	{
		var left_event	= '';
		var top_event	= '';
		$('.event_detail_view').fadeOut();
		$('.shift_cancel_div').css('left','');
		$('.shift_cancel_div').css('top','');
		left_event	= $(this).parents('div.event_detail_view').position().left;
		top_event	= $(this).parents('div.event_detail_view').position().top;
		$('.shift_cancel_div h5').html('Cancel Event');
		$('.shift_cancel_div').css({
			'left'		: parseFloat(left_event),
			'top'		: parseFloat(top_event),
			'z-index'	: '1000'
		});
		$('.shift_cancel_div #reason_cancel').attr({
			'dat-shift'		: $(this).attr('dat-shift'),
			'dat-sdt'		: $(this).attr('dat-sdt'),
			'dat-occ'		: 2,
			'dat-req'		: $(this).attr('dat-req'),
			'dat-stat'		: $(this).attr('dat-stat'),
			'dat-col'		: $(this).attr('div_col')
		});
		$('#reason_cancel').val('');
		$('.shift_cancel_div').fadeIn();
	}
 });
$('#shift_full_calendar').fullCalendar({
	editable: false,
	header: {
			left: 'prevYear,prev',
			center: 'today title',
			right: 'next,nextYear'
		},
	events: function(start, end, callback) {
       var date 		= $("#shift_full_calendar").fullCalendar('getDate');
		   var month_int 	= date.getMonth();
	   var cur_dat		= new Date();
	   var cur_mon		= cur_dat.getMonth();
	    $.ajax({
            url: siteUrl+'/schedulemanagement/shift/driver-calendar-details',
            dataType: 'json',
			type:'post',
            data: {
                // our hypothetical feed requires UNIX timestamps
                start	: Math.round(start.getTime() / 1000),
                end		: Math.round(end.getTime() / 1000),
				month	: parseInt(month_int) + parseInt(1)
            },
            success: function(doc) {
				if(cur_mon != month_int)
				{
					$('div.fc-view-month td').removeClass('fc-state-highlight');
				}
                callback(doc);
				$(".tooltip-rate").tooltip({
				      show: null,
				      position: {
				        my: "left top",
				        at: "left bottom"
				      },
				      open: function( event, ui ) {
				        ui.tooltip.animate({ left: ui.tooltip.position().left + 30 }, "fast" );
				      }
				});
            }
        });
    },
	loading: function(bool) {
		if (bool) $('#divLoader').show();
		else $('#divLoader').hide();
	},
	dayClick: function(date, allDay, jsEvent, view) {
       	var curr_date 		= new Date();
		var new_dat			= curr_date.getDate()+curr_date.getMonth()+curr_date.getFullYear();
		var cal_date		= date.getDate()+date.getMonth()+date.getFullYear();
	   	if(new_dat == cal_date)
	   	{
	   		location.href = '/schedulemanagement/shiftallocation/driver-login-shifts-listing';
	   	}
    },
	eventClick: function(calEvent, jsEvent){
		$(".event_detail_view").hide();
		if(calEvent.date_check == 1)
		{
			/*var day 	= ($.fullCalendar.formatDate( calEvent.start, 'dd' ));
            var month 	= ($.fullCalendar.formatDate( calEvent.start, 'MM' ))-1;
            var year 	= ($.fullCalendar.formatDate( calEvent.start, 'yyyy' ));*/
			var div_id	= $(this).attr('id-attr');
			var obj_th	= this;
			common_obj	= this;
			$('.event_detail_view').html('');
			if(calEvent.shift_event == 1)
			{
				var html_det 	= '';
				var event_id	= calEvent.event_id;
				$.post(siteUrl+"/schedulemanagement/shift/event-details/"+event_id, function(result){
					if(result.shift_id != '' && result.shift_id != undefined)
					{
						html_det 	+='<a href="javascript:void(0);" class="close-x close_event" style="display:block;">X</a>';
						html_det 	+='<h5>'+result.title+'</h5>';
						html_det 	+='<table class="tab-Eview1"><tr><td width="130">Events Name</td><td width="10">:</td><td width="200">'+result.title+'</td></tr>';
						html_det 	+='<tr><td>Events Time</td><td>:</td><td>'+result.st_time+' to '+result.ed_time+'</td></tr>';
						html_det 	+='<tr><td>Events Category</td><td>:</td><td>'+result.category+'</td></tr>';
						html_det 	+='<tr><td>Events Description</td><td></td><td></td></tr>';
						html_det 	+='<tr><td colspan="3">'+result.description+'</td></tr>';
						if(result.req_stat == 2)
						{
							html_det 	+='<tr><td colspan="3" class="tab-Eview-edit"><a href="javascript:void(0);" class="cancel_event_conf" dat-shift="'+result.shift_id+'" div_col="'+$(common_obj).attr('div_col')+'" dat-sdt="'+event_id+'" dat-occ="2" dat-req="'+result.req_id+'" dat-stat="'+result.req_stat+'">Cancel Event</a></td></tr>';
						}
						html_det	+= '</table>';
						$('.event_detail_view').css('left','');
						$('.event_detail_view').css('top','');
						$('.event_detail_view').html(html_det);
						$('.event_detail_view').fadeIn();
						var center_top  = Math.max(0, (($(window).height() - $('.event_detail_view').outerHeight()) / 2) + $(window).scrollTop());
			    		var center_left = Math.max(0, (($(window).width() - $('.event_detail_view').outerWidth()) / 2) + $(window).scrollLeft());
						$('.event_detail_view').css({
							'left'		: (center_left - 200) +'px',
							'top'		: (center_top - 100) +'px',
							'position'	: 'absolute',
							'z-index'	: '1000'
						});
					}
				},"json");
			}
			else if(calEvent.shift_event == 4)
			{
				var html_det 	= '';
				var meetId		= calEvent.meet_id;
				$.post(siteUrl+"/miscellaneousmanagement/schedule/meeting-details/"+meetId, function(result){
					if(result.meet_id != '' && result.meet_id != undefined)
					{
						html_det 	+='<a href="javascript:void(0);" class="close-x close_event" style="display:block;">X</a>';
						html_det 	+='<h5>Meeting Details</h5>';
						html_det 	+='<table class="tab-Eview1"><tr><td width="130">Meeting Date</td><td width="10">:</td><td width="200">'+result.date+'</td></tr>';
						html_det 	+='<tr><td>Meeting Time</td><td>:</td><td>'+result.time+'</td></tr>';
						html_det 	+='<tr><td>Venue</td><td>:</td><td>'+result.venue+'</td></tr>';
						if($.trim(result.desc) != '')
						{
							html_det 	+='<tr><td>Description</td><td></td><td></td></tr>';
							html_det 	+='<tr><td colspan="3">'+result.desc+'</td></tr>';
						}
						if($.trim(result.add_notes) != '')
						{
							html_det 	+='<tr><td>Additional Notes</td><td></td><td></td></tr>';
							html_det 	+='<tr><td colspan="3">'+result.add_notes+'</td></tr>';
						}
						if(result.req_stat == 2)
						{
							html_det 	+='<tr><td colspan="3" class="tab-Eview-edit"><a href="javascript:void(0);" class="cancel_event_conf" dat-shift="'+result.shift_id+'" div_col="'+$(common_obj).attr('div_col')+'" dat-sdt="'+event_id+'" dat-occ="2" dat-req="'+result.req_id+'" dat-stat="'+result.req_stat+'">Cancel Event</a></td></tr>';
						}
						html_det	+= '</table>';
						$('.event_detail_view').css('left','');
						$('.event_detail_view').css('top','');
						$('.event_detail_view').html(html_det);
						$('.event_detail_view').fadeIn();
						var center_top  = Math.max(0, (($(window).height() - $('.event_detail_view').outerHeight()) / 2) + $(window).scrollTop());
			    		var center_left = Math.max(0, (($(window).width() - $('.event_detail_view').outerWidth()) / 2) + $(window).scrollLeft());
						$('.event_detail_view').css({
							'left'		: (center_left - 200) +'px',
							'top'		: (center_top - 100) +'px',
							'position'	: 'absolute',
							'z-index'	: '1000'
						});
					}
				},"json");
			}
		}
	}
	
});