jQuery(document).ready(function() {
	
	// Report managements
	if($(".tabs-noheight").length) {	
		// Tabs > No height
		$(".tabs-noheight").sliderkit({
			auto:false,
			tabs:true,
			freeheight:true,
			circular:true
		});
		
		// Occupance report.
		if($("#chartimgDaily").length) {
			//	Daily 
			var chardId			=	'chartimgDaily';
			var chartDetails	=	xAxisValue	=	dataValue	=	{};
				xAxisValue		=	['4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>'];
				dataValue		=	[96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3];
				chartDetails	=	{'title' : 'Occupancy Rate', 'xAxis' : xAxisValue, 'yAxis' : 'Percentage (%)', 'valueSuffix' : '%', 'name' : 'Occupancy Rate', 'data' : dataValue};
			commonHighCharts(chardId, chartDetails);
			/*
				xAxisValue		=	['4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>','4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>','4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>','4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>'];
				dataValue		=	[96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3,96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3, 96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3, 96.3, 93.2, 97.7, 97.1, 80, 91.6, 83.3];
			*/
		}	
		//	End Occupance Rate
		
	}

});

function commonHighCharts(chardId, chartDetails) {
	if($("#" + chardId).length) {		
		$('#' + chardId).highcharts({
            chart: {
                type: 'line',
                marginRight: 60,
                marginBottom: 60
            },
            title: {
                text: chartDetails.title,
                x: -20 //center
            },
			credits: {
				enabled:0
			},
            /*subtitle: {
                text: 'Source: WorldClimate.com',
                x: -20
            },*/
            xAxis: {
                //categories: ['Mar 1 - Mar 2', 'Mar 3 - Mar 9', 'Mar 10 - Mar 16', 'Mar 17 - Mar 23', 'Mar 24 - Mar 30', 'Mar 31 - Apr 6', 'Apr 7 - Apr 13', 'Apr 14 - Apr 20', 'Apr 21 - Apr 27', 'Apr 28 - Apr 30']
            	//categories: ['4-6-2013', '4-7-2013', '4-8-2013', '4-9-2013', '4-10-2013', '4-11-2013', '<span style="color:#ff0000;">4-12-2013</span>']
				categories: chartDetails.xAxis
			},
            yAxis: {
                title: {
                    text: chartDetails.yAxis
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                valueSuffix: chartDetails.valueSuffix
            },
            legend: {
                layout: 'horizontal',
                align: 'center',
                verticalAlign: 'bottom',               
				borderColor: '#CCCCCC',
				x: 10,
                y: 10
            },
			plotOptions: {
                series: {
                    cursor: 'pointer',
                }
            },
            series: [/*{
                name: 'Total Shifts',
                data: [50, 60, 55, 65, 70, 45, 60, 75, 48, 80, 90, 95]
            }, {
                name: 'Actually leased',
                data: [40, 55, 53, 60, 68, 44, 50, 60, 46, 60, 59, 70]
            }, */
			{
                name: chartDetails.name,
                data: chartDetails.data
            }/*, {
                name: 'London',
                data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
            }*/
			]
        });
	}
}
