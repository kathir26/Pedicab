var host = window.location.hostname;
if(host == "localhost") {
	var siteUrl	 = "http://"+host;
		siteUrl	+= "/pedicab/public";
} else {
	var siteUrl	 = "http://"+host;
}
var siteImageUrl = siteUrl + "/images";

jQuery(document).ready(function(e){
 // esc
	// Show the Body
//	$("#body").removeClass("visibility-hidden");
//	loadShowAndHide(2);
	
	// OverAll sorting class
	/*$("#listingContainer th a").live('click',function (e) {
		e.preventDefault();
		var obj 		= $(this).children();
		var newClass	= '';
//		console.log("==before==>" + obj.attr('class') + "<==");
		if(obj.hasClass('sortup-arrow') || obj.hasClass('sort-arrow')) {
			if(obj.hasClass('sortup-arrow')) {
				obj.removeClass('sortup-arrow');
				obj.addClass('sort-arrow');
			} else if(obj.hasClass('sort-arrow')) {
				obj.removeClass('sort-arrow');
				obj.addClass('sortup-arrow');
			}
		}
//		console.log("==after==>" + obj.attr('class') + "<==");
	});
	*/
	
 // Begin Pedicab login and forget password password
	// Binds form submission and fields to the validation engine
	jQuery("#pc_login_form").validationEngine({		
		promptPosition: "topLeft"
	});
	
	jQuery("#pc_forget_password_form").validationEngine({
		promptPosition: "topLeft",
		ajaxFormValidation: true,
		ajaxFormValidationMethod: 'post',
		ajaxFormValidationURL: siteUrl + '/usermanagement/index/ajax-forget-password',
		onAjaxFormComplete: ajaxForgotPasswordValidationCallback
	});
	
	if($("#loginErrorsFlag").length > 0 && $("#loginErrorsFlag").val()) {
		var fieldId  = 'pc_login_email';
		if($('#loginErrorMsg').val() == 1)
		{
			var msg		 = "Your Contract Expired.Please contact Manager/Owner";
		}
		else
		{
			var msg		 = $("#"+fieldId).attr("data-errormessage-custom-error");
		}
		showCustomPrompt(fieldId, msg, 1);
	}
	// forgetPasswordDiv, formContainer
	$("#pc_backto_login, #pc_forgot_password").click(function(e) {
		e.preventDefault();	
		var showFormId  = $(this).attr('id');
		var fadeInIds	= (showFormId == 'pc_backto_login') ? "formContainer" : "forgetPasswordDiv";
		var fadeOutIds	= (showFormId == 'pc_backto_login') ? "forgetPasswordDiv" : "formContainer";
		$("#"+fadeOutIds).fadeOut(function() {
			$("#pc_login_email, #pc_password, #pc_forget_password_email").val('');
			$("#"+fadeInIds).fadeIn();
		});
	});
	
	$("#pc_backForgotto_login").click(function(e) {
		e.preventDefault();
		var fadeInIds	= "formContainer";
		var fadeOutIds	= "forgetPasswordSuccessDiv";
		$("#"+fadeOutIds).fadeOut(function() {
			$("#pc_login_email, #pc_password, #pc_forget_password_email").val('');
			$("#"+fadeInIds).fadeIn();
		});
	});
	
	$(".paging a, .view-table th a, .icon-delete").live('click',function (e) {
		e.preventDefault();
	});
		
	// Called once the server replies to the ajax form validation request
	function ajaxForgotPasswordValidationCallback(status, form, json, options) {
		if (status === true) {
			$("#forgetPasswordDiv").hide();
			var statusMag	=	'<p>Username validation is success, <br>We have sent a link to your mail id to reset your password.</p>';
			$("#forgetPasswordSuccess").html(statusMag);
			$("#forgetPasswordSuccessDiv").show();
			// jQuery('#forgetPasswordSuccess').validationEngine('showPrompt', '<p>Username validation is success, <br>We have sent a link to your mail id to reset your password.</p>', 'pass', true, '');	//	bottomLeft
			// uncomment these lines to submit the form to form.action
			// form.validationEngine('detach');
			// form.submit();
			// or you may use AJAX again to submit the data
		}
	}
	
 // End Pedicab login and forget password password
 
	// Inner page menus
	if($('#smoothmenu1').hasClass('ddsmoothmenu')) {
		ddsmoothmenu.init({
			mainmenuid: "smoothmenu1",
			orientation: 'h',
			classname: 'ddsmoothmenu',		  
			contentsource: "markup"
		})
	}
});


/* Account & Location management */

//	Manage User Roles
function resetUserRoles(formId) {
	//	Todo : to reset the form values.
	return true;
}

jQuery(document).ready(function() {
	/*$(window).load(function(){
		$('#bodyDiv').css('visibility', 'visible');
	});*/
	
	// Add role and privelege
	
	/*$(".left-side a").click(function(e) {
		e.preventDefault();
	}); 
	*/
	
	$(".subMenuCheckbok").click(function(e) {
		var checkBokId	= $(this).attr("id");
		var status		= ($(this).is(':checked')) ? true : false;
		$("."+checkBokId).attr('checked', status);
	}); 
	
	jQuery("#pc_add_user_role_form").validationEngine({		
		promptPosition: "topLeft",
		ajaxFormValidation: true,	//	false 
		ajaxFormValidationMethod: 'post',
		ajaxFormValidationURL: siteUrl + '/usermanagement/role/ajax-add-role',
		onAjaxFormComplete: ajaxUserRoleValidationCallback
	});
	
	// Called once the server replies to the ajax form validation request
	function ajaxUserRoleValidationCallback(status, form, json, options) {
		if (status === true) {
			// uncomment these lines to submit the form to form.action
			 form.validationEngine('detach');
			 form.submit();
			// or you may use AJAX again to submit the data
		} else {
			backtoTop();
		}
	}
	
	//Add Location
	if($("#pc_add_loc_form").length)
	{
		$("#loc_launch_date,#loc_ses_open_date,#loc_ses_close_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		if($('#loc_same_addr').val() == 1)
		{
			$('#loc_mail_address').removeAttr('data-validation-engine');
		}
		$('#loc_same_addr').click(function(){
			if($(this).attr('checked') == 'checked')
			{
				$('#loc_mail_address').removeAttr('data-validation-engine');
			}
			else
			{
				$('#loc_mail_address').attr('data-validation-engine','validate[required]');
			}
		});
		
		jQuery("#pc_add_loc_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			//autoHidePrompt: true,
			ajaxFormValidation: true,	//	false 
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/usermanagement/location/ajax-add-location',
			onAjaxFormComplete: ajaxAddLocationValidationCallback
			//onBeforeAjaxFormValidation: ajaxAddUserValidationBeforeCall
		});
	}
	//Add Bike
	if($("#pc_add_bike_form").length)
	{
		$("#bike_age_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true,
			onSelect: function(dateText, inst) {
				dateText = dateText.replace(/\-/g,'/');
				var dob	 = getAge(dateText);
				if(dob >= 0)
				{
					$('#bike_age').val(dob);
				}
				else
				{
					alert('Age is less than zero');
					$('#bike_age').val(0);
				}
		    }
		});
		jQuery("#pc_add_bike_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			//autoHidePrompt: true,
			ajaxFormValidation: true,	//	false 
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/bikemanagement/bike/ajax-add-bike',
			onAjaxFormComplete: ajaxAddBikeValidationCallback
			//onBeforeAjaxFormValidation: ajaxAddUserValidationBeforeCall
		});
		$("#pc_add_bike_form input[type='file']").on('change',function (e) {
			var field		=	$(this);
			checkCustomFileUploads(field, 1, '', '', '');
		});
		$("#bike_change_image").on('click',function (e) {
			$('.bike_upload_image').slideToggle();
		});
	}
	// Add user
	
	if($("#pc_add_user, #pc_edit_user").length) {
		$("#user_drivers_license").change(function () { 
			$("#user_drivers_license_fakefilepc").val($("#user_drivers_license").val())
		});
		$("#user_profile_image").change(function () { 
			$("#user_profile_image_fakefilepc").val($("#user_profile_image").val())
		});
		$("#user_contract").change(function () { 
			$("#user_contract_fakefilepc").val($("#user_contract").val())
		});
		
		// Date picker
		$("#user_training_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$("#user_leasecontract_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#pc_add_user").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/usermanagement/user/ajax-add-user',
			onAjaxFormComplete: ajaxUserValidationCallback
		});
		
		// Condition handling for Edit mode
		if($("#pc_edit_user").length) {
			if($('#user_drivers_license_hidden').val() !='') {
				$('#user_drivers_license').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
			if($('#user_profile_image_hidden').val() !='') {
				$('#user_profile_image').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
			if($('#user_contract_hidden').val() !='') {
				$('#user_contract').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
		}
		
		jQuery("#pc_edit_user").validationEngine({
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/usermanagement/user/ajax-add-user',
			onAjaxFormComplete: ajaxUserValidationCallback
		});
		
		$("#pc_add_user input[type='file'], #pc_edit_user input[type='file']").on('change',function (e) {
			var field		=	$(this);
			checkCustomFileUploads(field, 1, '', '', '');
		});
		
		$("#user_role_id").on('change',function (evt) {
			if($(this).val() == 1) {			
				$(".role_sub_fields").show();
				$(".role_sub_fields").parent().parent().removeClass('padding_0');
			} else {
				$(".role_sub_fields").hide();
				$(".role_sub_fields").parent().parent().addClass('padding_0');
			}
		});
		
		$("#editPasswordSpan").on('click',function (e) {
			e.preventDefault();
			$(this).hide();
			$("#user_password, #user_confirm_password").val('');
			$(".password_sub_fields, #editPasswordSpan1").show();
		});
		$("#editPasswordSpan1").on('click',function (e) {
			e.preventDefault();
			$(this).hide();
			$("#user_password, #user_confirm_password").val('');
			$(".password_sub_fields").hide();
			$("#editPasswordSpan").show();
		});
		
		function ajaxAddUserValidationBeforeCall(form, options){
			/*
			if (console) 
			console.log("Right before the AJAX form validation call");
			*/
			return true;
		}
		
		// Show and hide Text address popup
		/*$("#text-adddress-pop").on('hover',function (e) {
			e.preventDefault();
			var divid	 = $(this).attr('id');
			if(divid == 'text-adddress-pop') {
				$('#text-adddress-pop-show').show();
			} else {
				$('#text-adddress-pop-show').hide();
			}
		});
		*/
		
		$("#text-adddress-pop, #text-adddress-pop-close").on('click',function (e) {
			e.preventDefault();
			var divid	 = $(this).attr('id');
			if(divid == 'text-adddress-pop') {				
				$('#text-adddress-pop-show').show();
			} else {
				$('#text-adddress-pop-show').hide();
			}
		});
		
		$(".text-adddress-pop-text").on('click',function (e) {
			e.preventDefault();
			var textValue	= $.trim($(this).attr('rel'));
			var telNo		= $.trim($("#user_telephone_number").val());
			$("#text-adddress-pop-close").click();
			if(telNo) {
				textValue	= telNo + '@' + textValue;
				$("#user_text_address").val(textValue);
			} else {
				var errorMsg = $.trim($("#user_telephone_number").attr('data-errormessage-value-missing'));
				showCustomPrompt("user_telephone_number", errorMsg, 1);
				$("#text-adddress-pop-close").click();
			}
		});
		
		function dynamicPositions(ids, type) {
			var idObj	=  (type == 2) ? $('.' + ids) : $('#' + ids);
			 
			idObj.css('left','');
			idObj.css('top','');			
			idObj.fadeIn();
			var center_top  = Math.max(0, (($(window).height() - idObj.outerHeight()) / 2) + $(window).scrollTop());
    		var center_left = Math.max(0, (($(window).width() - idObj.outerWidth()) / 2) + $(window).scrollLeft());
			idObj.css({
				'left'		: (center_left - 200) +'px',
				'top'		: (center_top - 100) +'px',
				'position'	: 'absolute',
				'z-index'	: '1000'
			});
		}
	}
	
	// user listing
	if($("#user_filter_form").length) {
		
		jQuery("#user_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
					var search_keyward_name	 = $("#search_keyward_name");
					var search_keyward_value = $("#search_keyward_value");
					var errorMsg			 = '';
					
					if($.trim(search_keyward_name.val()) != '' && $.trim(search_keyward_value.val()) == '') {
						errorMsg		 = search_keyward_value.attr("data-errormessage-value-missing");
						showCustomPrompt("search_keyward_value", errorMsg, 1);
					} else if($.trim(search_keyward_value.val()) != '' && $.trim(search_keyward_name.val()) == '' ) {
						errorMsg		 = search_keyward_name.attr("data-errormessage-value-missing");
						showCustomPrompt("search_keyward_name", errorMsg, 1);
					} else {
						form.validationEngine('detach');
						form.submit();
					}
				}
		});		
	}
	
	
	// Begin Manage Accidents	, 	Manage Bikes - Add Accident
	if($("#pc_add_accident_form, #pc_edit_accident_form").length) {
		
		$("#accident_image_one").change(function () { 
			$("#accident_image_one_fakefilepc").val($("#accident_image_one").val());
		});
		$("#accident_image_two").change(function () { 
			$("#accident_image_two_fakefilepc").val($("#accident_image_two").val());
		});
		$("#accident_image_three").change(function () { 
			$("#accident_image_three_fakefilepc").val($("#accident_image_three").val());
		});
		
		// Condition handling for Edit mode
		if($("#pc_edit_accident_form").length) {
			if($('#accident_image_one_hidden').val() !='') {
				$('#accident_image_one').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
			if($('#accident_image_two_hidden').val() !='') {
				$('#accident_image_two').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
			if($('#accident_image_three_hidden').val() !='') {
				$('#accident_image_three').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
		}
		
		$("#accident_time, #mechanic_inspection_time").timepicker({
			showSecond: false,//showSecond: true,
			/*addSliderAccess: true,
			sliderAccessArgs: { touchonly: false }*/
			timeFormat: 'hh:mm TT' //timeFormat: 'hh:mm:ss TT'
		});
		
		// Date picker
		$("#accident_date, #mechanic_inspection_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		/*
		jQuery("#pc_add_accident_form, #pc_edit_accident_form").validationEngine({
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/bikemanagement/accident/ajax-add-accident',
			onAjaxFormComplete: ajaxAccidentValidationCallback
		});
		*/
		
		jQuery("#pc_add_accident_form, #pc_edit_accident_form").validationEngine({
			promptPosition: "topLeft",
			onValidationComplete: function(form, status) {
				var settled  	 = $("input[name='accident_settled_status']:checked").val();
				var settled_note = $.trim($("#settlement_note").val()); 
				var errorMsg	 = '';
				var errorFlag	 = true;
				
				if(settled == 1 && settled_note == '') {
					errorMsg	 = $("#settlement_note").attr('data-errormessage-value-missing');
					showCustomPrompt("settlement_note", errorMsg, 1);
					errorFlag	 = false;
					backtoTopNew('settlement_note');
				}
						
				if(errorFlag && status) {	
					form.validationEngine('detach');
					form.submit();
				} else {
					return false;
				}
			}
		});
		
		$("#pc_add_accident_form input[type='file'], #pc_edit_accident_form input[type='file']").on('change',function (e) {
			var field		=	$(this);
			checkCustomFileUploads(field, 1, '', '', '');
		});
		
	}
	
	/*
	$(".divinputfile").on('click',function (e) {
		$(".filepc", this).click();
		console.log("==id==>" + $(".filepc", this).attr('id') + "<==");
	});
	*/
	
	// Accident listing, Filters for Both Unsettled Accidents and Settled Accidents	
	if($("#settled_accident_filter_form").length) {
		// Initial settled accident listing
		loadDiv('settledListingContainer', '/accident-page/1/1', '', '', 0);	
		
		// Date picker
		$("#unsettled_accident_filter_form #accident_date, #settled_accident_filter_form #accident_date_settled").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#unsettled_accident_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/bikemanagement/accident/accident-listing/ajax',
			onAjaxFormComplete: ajaxAccidentListingValidationCallback
		});
		
		jQuery("#settled_accident_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/bikemanagement/accident/accident-listing/ajax',
			onAjaxFormComplete: ajaxAccidentListingValidationCallback
		});
		
	}
	
	// user listing
	if($("#driver_accident_filter_form").length) {
		
		// Date picker
		$("#driver_accident_filter_form #accident_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#driver_accident_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false
		});		
	}
	
	// Assign drivers
	if($("#pc_assign_drivers_form").length) {
		
		$(".assign-drivers-radio input:radio").live('click',function (e) {
			checkSelectionErrorMsg(1);
			if($(this).val() == 1) {
				$('#notRequested_drivers_div').hide();
				$("#notRequested_drivers_div li").removeClass('sel');
				$("#notRequested_drivers_div input:checkbox").attr('checked', false);				
				$('#requested_drivers_div').show();
			} else {
				$('#requested_drivers_div').hide();
				$("#requested_drivers_div li").removeClass('sel');
				$("#requested_drivers_div input:checkbox").attr('checked', false);
				$('#notRequested_drivers_div').show();
			}
			checkSelectionErrorMsg(2);
		});
		
		// click events. requested drivers
		$("#requested_drivers_div li, #notRequested_drivers_div li").live('click',function (e) {
			e.preventDefault();
			checkSelectionErrorMsg(1);
			var liId     	=  $(this).attr('id');
			var checkBoxObj =  $("#"+liId + " input:checkbox");
			var countValue	=  ($('#shift_bike_available_hidden').val() * 1);
			var totalCount	=  ($('#shift_bike_available').val() * 1);
			
			if(checkBoxObj.is(':checked')) {
				$(this).removeClass('sel');
			} else {
				$(this).addClass('sel');
			}
			var status	 	= (checkBoxObj.is(':checked')) ? false : true;
			checkBoxObj.attr('checked', status);
			checkSelectionErrorMsg(2);
		});
		
		// click events. assigned drivers
		$("#confirmed_drivers_div li").live('click',function (e) {
			e.preventDefault();
			checkSelectionErrorMsg(1);
			if(confirm('Are you sure to remove the selected driver?')) {
				var tempIds		=  '';
				var newIds		=  '';
				var liHtml		=  '';
				var liId  		=  $(this).attr('id');
				var aTagObj 	=  $("#"+liId + " a");
				var toDivId		=  (aTagObj.attr('rel') == 'notRequested_drivers_div') ? 'notRequested_drivers_div' : 'requested_drivers_div';
				liHtml			=  $("#" +liId).html();
				tempIds			=  liId;
				tempIds			=  tempIds.split('_');
				newIds			=  (toDivId == 'notRequested_drivers_div') ? 'notRequested_drivers_li_'+tempIds.last() : 'requested_drivers_li_'+tempIds.last();
				$("#"+newIds+ " input[type=checkbox]").attr('checked', false);
				$("#"+newIds).show();
				$("#"+liId).remove();
				
				if(toDivId == "requested_drivers_div") {
					liHtml  =  liHtml.replace("confirmed_drivers_ids", "requested_drivers_ids");
					liHtml  =  liHtml.replace("confirmed_drivers_checkbok_", "requested_drivers_checkbok_");
					liHtml  =  liHtml.replace("confirmed_drivers_div", "requested_drivers_div");
				} else {
					liHtml  =  liHtml.replace("confirmed_drivers_ids", "notRequested_drivers_ids");
					liHtml  =  liHtml.replace("confirmed_drivers_checkbok_", "notRequested_drivers_checkbok_");
					liHtml  =  liHtml.replace("confirmed_drivers_div", "notRequested_drivers_div");
				}
			    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
				$("#"+toDivId+" ul").append(liHtml);
				$("#" + toDivId + " input[type=checkbox]").attr('checked', false);
				$("#" + toDivId + " li").removeClass('sel');
				$("#" + liId).remove();
				checkAndUpdateBikeAvailability(1, 1);
				
				// status msg				
				var LoadTypes = "";
				var msg 	  = "Selected Driver is successfully removed!";
				jQuery('#confirmed_drivers_div').validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
				
				// Reassign the classes
				var rowClass = ''
				$("#" + toDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
				// Reorder the Shift managers
				var manager_id		=  $('#shift_manager').val();
				var optionHtml		=  '<option value="">Select shift manager</option>';
				$('#shift_manager').html(optionHtml);
				$("#confirmed_drivers_div li").each(function(index) {
					var textVal  	=  $(this).text();
					var liId  	 	=  $(this).attr('id');
					var tempIds		=  liId.split('_');
					 	optionHtml	=  '<option value="'+tempIds.last()+'">'+textVal+'</option>';
					$('#shift_manager').append(optionHtml);
				});
				$('#shift_manager').val(manager_id);
				
			} else {
				return false;
			}
			checkSelectionErrorMsg(1);
		});
		
		function checkAndUpdateBikeAvailability(type, value) {
			var hiddenId	=  $('#shift_bike_available_hidden');
			var spanId		=  $('#driver_count');
			var count		=  (hiddenId.val() * 1);
				count		=  (type == 1) ? count + value : count - value;
			hiddenId.val(count);
			spanId.html(count);
		}
		
		$("#move_icon").live('click',function (e) {
			e.preventDefault();
			checkSelectionErrorMsg(2);
			if(confirm('Are you sure you want to move the selected drivers?')) {
				var parentDivId =  '';
				var liHtml		=  '';
				var tempIds		=  '';
				var newIds		=  '';
				var loopFlag	=  0;
				var countFlag	=  0;
				var toDivId		=  'confirmed_drivers_div';
				var fromDivId	=  ($("#requested_drivers_div").css('display') == 'block') ? 'requested_drivers_div' : 'notRequested_drivers_div';
				var totalCount	=  ($('#shift_bike_available').val() * 1);
				$("#" + fromDivId + " input[type=checkbox]:checked").each(function(e) {
					var countValue	=  ($('#shift_bike_available_hidden').val() * 1);
					if((countValue - 1) >= 0) {
					    parentDivId =  $(this).parent().parent().attr('id');
						liHtml		=  $("#"+parentDivId).html();
						tempIds		=  parentDivId;
						tempIds		=  parentDivId.split('_');
						newIds		=  'confirmed_drivers_li_'+tempIds.last();
						
						if(fromDivId == "requested_drivers_div") {
							liHtml  =  liHtml.replace("requested_drivers_ids", "confirmed_drivers_ids");
							liHtml  =  liHtml.replace("requested_drivers_checkbok_", "confirmed_drivers_checkbok_");
						} else {
							liHtml  =  liHtml.replace("notRequested_drivers_ids", "confirmed_drivers_ids");
							liHtml  =  liHtml.replace("notRequested_drivers_checkbok_", "confirmed_drivers_checkbok_");
						}
					    liHtml		=  '<li id="'+newIds+'">'+ liHtml +'</li>';
						$("#confirmed_drivers_div ul").append(liHtml);
						$("#" + newIds + " input[type=checkbox]").attr('checked', true);
						$("#" + parentDivId).remove();
						checkAndUpdateBikeAvailability(2, 1);
					} else {
						countFlag++;
						return false;
						e.stopPropagation();
					}
			        loopFlag++;
			    });
				// shift_bike_available_hidden
				// Reassign the classes
				var rowClass = ''
				$("#" + fromDivId + " li").each(function(index) {
					var liId  =  $(this).attr('id');
					if($('#'+liId).hasClass('row')) {
						$('#'+liId).removeClass('row')
					}
					rowClass	 = (index%2 == 0) ? "row" : "";
					$('#'+liId).addClass(rowClass);
				});
				
				// Reorder the Shift managers
				if(loopFlag) {
					var manager_id		=  $('#shift_manager').val();
					var optionHtml		=  '<option value="">Select shift manager</option>';
					$('#shift_manager').html(optionHtml);
					$("#confirmed_drivers_div li").each(function(index) {
						var textVal  	=  $(this).text();
						var liId  	 	=  $(this).attr('id');
						var tempIds		=  liId.split('_');
						 	optionHtml	=  '<option value="'+tempIds.last()+'">'+textVal+'</option>';
						$('#shift_manager').append(optionHtml);
					});
					$('#shift_manager').val(manager_id);
				}
				
				// Status msg	
				var LoadTypes 	  = (loopFlag) ? "" : "";
				if(countFlag) {
					var msg   	  = "Available Drivers is exist, You want to select more drivers, <br/>Please remove the existing drivers and then select the required drivers, <br/> No. of Drivers Needed : "+totalCount+" !";
					var errorDiv  = "confirmed_drivers_div";
				} else {
					var msg   	  = (loopFlag) ? "Selected Driver are successfully moved!" : "Select the drivers, It's required!";
					var errorDiv  = (loopFlag) ? "confirmed_drivers_div" : fromDivId;
				}				
				jQuery('#'+errorDiv).validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-20', true);	//	bottomLeft	// topRight:-250
			} else {
				return false;
			}
			checkSelectionErrorMsg(1);
		});
		
		jQuery("#pc_assign_drivers_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/schedulemanagement/shiftallocation/ajax-assign-drivers',
			onAjaxFormComplete: ajaxAssignDriversCallback
		});
		
	}
	
	//Add Shift
	if($("#pc_add_shift_form").length) {
		
		$(".check_radio_select").click(function(){
			if($(this).val() == 1)
			{
				$('.shift_date_check').fadeIn();
				$('.shift_event_check').fadeOut();
				$('#shift_type').removeAttr('disabled');
			}
			else
			{
				$('.shift_event_check').fadeIn();
				$('#shift_type').val('4');
				$('#shift_type').attr('disabled','disabled');
				$('.shift_date_check').fadeOut();
			}
		});
		$("#select_all").click(function(){
			if($(this).attr('checked') == 'checked')
			{
				$(".select_day").attr('checked','true');
			}
			else
			{
				$(".select_day").removeAttr('checked');
			}
		});
		$(".select_day").click(function(){
			if($(this).attr('checked') == undefined)
			{
				if($("#select_all").attr('checked') == 'checked')
				{
					alert('Uncheck option (All) then continue.');
					$(this).attr('checked','true');
				}
			}
		});
		$("#shift_start_time, #shift_end_time").timepicker({
			showSecond: false,//showSecond: true,
			/*addSliderAccess: true,
			sliderAccessArgs: { touchonly: false }*/
			timeFormat: 'hh:mm TT' //timeFormat: 'hh:mm:ss TT'
		});
		// Date picker
		$("#shift_st_date,#shift_end_date,#shift_event_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		
		jQuery("#pc_add_shift_form").validationEngine({
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/schedulemanagement/shift/save-shift',
			onAjaxFormComplete: ajaxShiftValidationCallback
		});
		
	}
	
	// Manage Inventory - Add Part
	if($("#pc_add_parts_form, #pc_edit_parts_form").length) {
		$("#parts_image").change(function () { 
			$("#parts_image_fakefilepc").val($("#parts_image").val())
		});
		
		jQuery("#pc_add_parts_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/maintenancemanagement/inventory/ajax-add-part',
			onAjaxFormComplete: ajaxPartsValidationCallback
		});
		
		// Condition handling for Edit mode
		if($("#pc_edit_parts_form").length) {
			if($("#parts_image_hidden").length && $('#parts_image_hidden').val() !='') {
				$('#parts_image').attr("data-validation-engine", "validate[funcCall[checkFileUploads]]");
			}
		}
		
		jQuery("#pc_edit_parts_form").validationEngine({
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/maintenancemanagement/inventory/ajax-add-part',
			onAjaxFormComplete: ajaxPartsValidationCallback
		});
		
		$("#pc_add_parts_form input[type='file'], #pc_edit_parts_form input[type='file']").on('change',function (e) {
			var field		=	$(this);
			checkCustomFileUploads(field, 1, '', '', '');
		});
		
	} // End
	
	// Begin : Driver login views	
	if($("#drive_shift_filter_form").length) {
		// Date picker
		$("#search_shift_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$(document).on('click','a.close_shift_cancel',function(){
		   	$(".driver_shift_cancel_div").fadeOut();
		});
		$(document).on('click','div.reason_cancelformError',function(e){
			$(this).remove();
			e.preventDefault();
		});
		$(document).on('click','.driver_valid-reason_text',function(){
			$('div.reason_cancelformError').remove();
			var text_cont	= $('#reason_cancel').val();
			if($.trim(text_cont) == '')
			{
				$('#reason_cancel').validationEngine('showPrompt','Reason is required' , '":"', 'topRight:-260', false);
				return false;
			}
			else
			{
				return cancelDriverShift();
			}
		});
		jQuery("#drive_shift_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
					form.validationEngine('detach');
					form.submit();
				}
		});		
	}
	// End : Driver login views 
	
	//Shift Manage List
	
	if($("#pc_manage_shift_old_form,#pc_manage_shift_new_form").length) {
		loadDiv('oldListingContainer', '/manage-shift-list/2/1', '', '', 0);	
		$("#pc_manage_shift_old_form #shift_date_old, #pc_manage_shift_new_form #shift_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_manage_shift_old_form, #pc_manage_shift_new_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: true,
			ajaxFormValidationMethod: 'post',
			ajaxFormValidationURL: siteUrl + '/schedulemanagement/shift/manage-shift/ajax',
			onAjaxFormComplete: ajaxShiftListingValidationCallback
		});
	}
	if($("#pc_driver_note_form").length)
	{
		$("#shift_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$('.sel_note_opt').click(function(){
			$('.select-drivers').hide();
			$('.select-drivers select option:selected').removeAttr('selected');
			$('.driver_div_'+$(this).val()).fadeIn('slow');
		});
		$('.close_driver-select').click(function(){
			$('.select-drivers').fadeOut('slow');
		});
		callCKEditor('note_message','myconfig');
		jQuery("#pc_driver_note_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
				if($.trim(CKEDITOR.instances.note_message.getData()) == '')
				{
					showCustomPrompt('hid_note_message', 'Message is required!', 1);
					return false;
				}
				else
				{
					
					if(status === true)
					{
						var serialise	= $("#pc_driver_note_form").serialize();
						var editor_data	= CKEDITOR.instances.note_message.getData();
						$.post(siteUrl + '/managernotemanagement/note/save-note',serialise+'&editor_data='+encodeURIComponent(editor_data),function(result){
							if(result.err == 1)
							{
								showCustomPrompt('hid_note_send_to', 'Selected shift has no drivers!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 2)
							{
								showCustomPrompt('hid_note_send_to', 'Select driver!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 0)
							{
								location.href = result.url;
							}
						},'json');
					}
					return false;
				}
			}
		});
	}
	if($("#pc_client_note_form").length)
	{
		callCKEditor('note_message','myconfig');
		jQuery("#pc_client_note_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
				if($.trim(CKEDITOR.instances.note_message.getData()) == '')
				{
					showCustomPrompt('hid_note_message', 'Message is required!', 1);
					return false;
				}
				else
				{
					
					if(status === true)
					{
						var serialise	= $("#pc_client_note_form").serialize();
						var editor_data	= CKEDITOR.instances.note_message.getData();
						$.post(siteUrl + '/managernotemanagement/note/save-client-note',serialise+'&editor_data='+encodeURIComponent(editor_data),function(result){
							if(result.err == 0)
							{
								location.href = result.url;
							}
						},'json');
					}
					return false;
				}
			}
		});
	}
	if($("#pc_mechanic_note_form").length)
	{
		$('.sel_note_opt').click(function(){
			$('.select-drivers').hide();
			$('.select-drivers select option:selected').removeAttr('selected');
			$('.driver_div_'+$(this).val()).fadeIn('slow');
		});
		$('.close_driver-select').click(function(){
			$('.select-drivers').fadeOut('slow');
		});
		callCKEditor('note_message','myconfig');
		jQuery("#pc_mechanic_note_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
				if($.trim(CKEDITOR.instances.note_message.getData()) == '')
				{
					showCustomPrompt('hid_note_message', 'Message is required!', 1);
					return false;
				}
				else
				{
					
					if(status === true)
					{
						var serialise	= $("#pc_mechanic_note_form").serialize();
						var editor_data	= CKEDITOR.instances.note_message.getData();
						$.post(siteUrl + '/managernotemanagement/note/save-mechanic-note',serialise+'&editor_data='+encodeURIComponent(editor_data),function(result){
							if(result.err == 1)
							{
								showCustomPrompt('hid_note_send_to', 'Selected shift has no drivers!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 2)
							{
								showCustomPrompt('hid_note_send_to', 'Select driver!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 0)
							{
								location.href = result.url;
							}
						},'json');
					}
					return false;
				}
			}
		});
	}
	if($("#pc_add_request_form").length)
	{
		$("#request_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
	}
	if($("#pc_location_note_form").length)
	{
		$("#shift_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$('.sel_note_opt').click(function(){
			$('.select-drivers').hide();
			$('.select-drivers select option:selected').removeAttr('selected');
			$('.driver_div_'+$(this).val()).fadeIn('slow');
		});
		$('.close_driver-select').click(function(){
			$('.select-drivers').fadeOut('slow');
		});
		callCKEditor('note_message','myconfig');
		jQuery("#pc_location_note_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			onValidationComplete: function(form, status) {
				if($.trim(CKEDITOR.instances.note_message.getData()) == '')
				{
					showCustomPrompt('hid_note_message', 'Message is required!', 1);
					return false;
				}
				else
				{
					
					if(status === true)
					{
						var serialise	= $("#pc_location_note_form").serialize();
						var editor_data	= CKEDITOR.instances.note_message.getData();
						$.post(siteUrl + '/managernotemanagement/note/save-location-note',serialise+'&editor_data='+encodeURIComponent(editor_data),function(result){
							if(result.err == 1)
							{
								showCustomPrompt('hid_note_send_to', 'Selected shift has no drivers!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 2)
							{
								showCustomPrompt('hid_note_send_to', 'Select driver!', 1);
								$('.hid_note_send_toformError').css('top','');
								$('.hid_note_send_toformError').css('top','0px');
							}
							else if(result.err == 0)
							{
								location.href = result.url;
							}
						},'json');
					}
					return false;
				}
			}
		});
	}
	if($("#pc_filter_note_form,#pc_filter_client_note_form,#pc_driver_receive_form,#pc_client_receive_form,#pc_filter_loc_note_form,#pc_location_receive_form,#pc_filter_mech_note_form,#pc_mechanic_receive_form").length)
	{
		$("#note_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_filter_note_form,#pc_filter_client_note_form,#pc_driver_receive_form,#pc_client_receive_form,#pc_filter_loc_note_form,#pc_location_receive_form,#pc_filter_mech_note_form,#pc_mechanic_receive_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: false
		});
	}
	if($("#parts_purchase_filter_form").length)
	{
		$("#search_purchase_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$(document).on('click','.edit-purchase-parts',function(){
			var edit_id	 		= $(this).attr('data-edId');
			if(edit_id != '')
			{
				$('.add_purchase').hide();
				var url_edit = siteUrl + '/maintenancemanagement/inventory/get-parts-purchase/'+edit_id;
				$.post(url_edit,function(result){
					if(result.parts_id != '')
					{
						$('html,body').animate({
						    scrollTop: 20
						}, 1000);
						$('#part_name_0').val(result.name);
						$('#job_number_0').val(result.job);
				        $('#parts_id_0').val(result.parts_id);
						$('#purchase_date_0').val(result.date);
						$('#quantity_0').val(result.qty);
						$('#quantity_old_0').val(result.qty);
						$('#purchase_id_0').val(result.pur_id);
						$('.multiple_purchase').slideDown();
						$('.show_purchase_content').removeClass('btn-plus').addClass('btn-minus');
					}
				},'json');
			}
		});
		jQuery("#parts_purchase_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: false
		});
	}
	if($("#pc_mechanic_filter_form").length) {
		$(document).on('click','.parentFormpc_mechanic_filter_form',function(){
			$(this).remove();
		});
		$("#search_job_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_mechanic_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: false
		});
	}
	if($("#add_multiple_purchase_form").length)
	{
		var html_dynamic         = $(".part_dynamic_content").html();
        var count                = $(".dynamic_content").size();
        if(count == 0)
        {
            $(".content_append_before").append('<div id="purchase_row_0"  class="dynamic_content">'+html_dynamic+'</div>');
			appendDatePicker(0,'add_multiple_purchase_form');     
        }
		$('.show_purchase_content').click(function(){
			$('.multiple_purchase').slideToggle();
			$(this).toggleClass('btn-plus btn-minus');
		});
		$(document).on('click','.formError',function(){
			$(this).remove();
		});
		$(document).on('click','.add_purchase',function(){
			var err = validateMultiplePurchase();
			if(err == '')
			{
	            var html_dynamic  = $(".part_dynamic_content").html();
	            var count         = $(".dynamic_content").size();
	            $(".content_append_before").append('<div id="purchase_row_'+(count)+'"  class="dynamic_content">'+html_dynamic+'</div>');
				appendDatePicker(count,'add_multiple_purchase_form');
			}
        });
		$(document).on('click','.delete_purchase',function(){
			var parent_id   = $(this).parents('.dynamic_content').attr('id');
		    $("#"+parent_id).remove();
		    $(".dynamic_content").each(function(i){
		        $(this).attr('id','purchase_row_'+i);
				appendDatePicker(i,'add_multiple_purchase_form');
		        i++;
		    });
		    var html_dynamic        = $(".part_dynamic_content").html();
		    var count               = $(".dynamic_content").size();
		    if(count == 0)
		    {
		        $(".content_append_before").append('<div id="purchase_row_0"  class="dynamic_content">'+html_dynamic+'</div>');
				appendDatePicker(0,'add_multiple_purchase_form');
		    }
		});
		$('#submit_purchase').click(function(){
			var err = validateMultiplePurchase();
			if(err != '')
			{
				return false;
			}
		});
		$(window).load(function(){
			appendDatePicker(0,'add_multiple_purchase_form');
		});
	}
	if($("#add_request_parts_form").length)
	{
		var html_dynamic         = $(".part_dynamic_content").html();
        var count                = $(".dynamic_content").size();
        if(count == 0)
        {
            $(".content_append_before").append('<div id="purchase_row_0"  class="dynamic_content">'+html_dynamic+'</div>');
			appendDatePicker(0,'add_request_parts_form');     
        }
		$('.show_purchase_content').click(function(){
			$('.multiple_purchase').slideToggle();
			$(this).toggleClass('btn-plus btn-minus');
		});
		$(document).on('click','.formError',function(){
			$(this).remove();
		});
		$(document).on('click','.add_purchase',function(){
			var err = validateMultiplePurchase();
			if(err == '')
			{
	            var html_dynamic  = $(".part_dynamic_content").html();
	            var count         = $(".dynamic_content").size();
	            $(".content_append_before").append('<div id="purchase_row_'+(count)+'"  class="dynamic_content">'+html_dynamic+'</div>');
				appendDatePicker(count,'add_request_parts_form');
			}
        });
		$(document).on('click','.delete_purchase',function(){
			var parent_id   = $(this).parents('.dynamic_content').attr('id');
		    $("#"+parent_id).remove();
		    $(".dynamic_content").each(function(i){
		        $(this).attr('id','purchase_row_'+i);
				appendDatePicker(i,'add_request_parts_form');
		        i++;
		    });
		    var html_dynamic        = $(".part_dynamic_content").html();
		    var count               = $(".dynamic_content").size();
		    if(count == 0)
		    {
		        $(".content_append_before").append('<div id="purchase_row_0"  class="dynamic_content">'+html_dynamic+'</div>');
				appendDatePicker(0,'add_request_parts_form');
		    }
		});
		$('#submit_purchase').click(function(){
			var err = validateMultiplePurchase();
			if(err != '')
			{
				return false;
			}
		});
		$(window).load(function(){
			appendDatePicker(0,'add_request_parts_form');
		});
	}
	if($("#parts_request_filter_form").length)
	{
		$("#search_purchase_date").datepicker({
			dateFormat: 'm-d-yy',	// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$(document).on('click','.edit-purchase-parts',function(){
			var edit_id	 		= $(this).attr('data-edId');
			if(edit_id != '')
			{
				$('.add_purchase').hide();
				var url_edit = siteUrl + '/maintenancemanagement/inventory/get-parts-request/'+edit_id;
				$.post(url_edit,function(result){
					if(result.parts_id != '')
					{
						$('html,body').animate({
						    scrollTop: 20
						}, 1000);
						$('#part_name_0').val(result.name);
						$('#job_number_0').val(result.job);
				        $('#parts_id_0').val(result.parts_id);
						$('#purchase_date_0').val(result.date);
						$('#quantity_0').val(result.qty);
						$('#quantity_old_0').val(result.qty);
						$('#purchase_id_0').val(result.pur_id);
						$('.multiple_purchase').slideDown();
						$('.show_purchase_content').removeClass('btn-plus').addClass('btn-minus');
					}
				},'json');
			}
		});
		jQuery("#parts_request_filter_form").validationEngine({
			promptPosition: "topLeft",
			scroll : false,
			showOneMessage: true,
			maxErrorsPerField:1,
			ajaxFormValidation: false
		});
	}
	if($("#pc_add_job_form").length)
	{
		$("#job_est_time").timepicker({
			showSecond: false,//showSecond: true,
			/*addSliderAccess: true,
			sliderAccessArgs: { touchonly: false }*/
			timeFormat: 'hh:mm' //timeFormat: 'hh:mm:ss'
		});
		$('.show_purchase_content').click(function(){
			$(this).toggleClass('btn-plus btn-minus');
			$('#add-job_sheet_div').slideToggle();
		});
		/*$('#job_date').datepicker({
			dateFormat: 'm-d-yy ',	// dd/mm/yyyy
			changeMonth: true,
	     	changeYear: true
		});*/
		$('.parts-chosen').chosen();
		var el = 1;
		$('.tabindex').each(function(){
			$(this).attr('tabindex',el);
			el++;
		});
		$('#job_bike').autocomplete({
	      source: function( request, response ) {
		  	var url_auto 	= siteUrl + '/maintenancemanagement/job/get-bike-details';
	        $.post(url_auto,'search='+request.term,function(result){
	        	response( $.map( result, function( item ) {
				  return {
	                label	: item.serial,
	                value	: item.bId,
					name	: item.name,
					model	: item.model
	              }
	            }));
	        },'json');
	      },
		  focus: function() {
	        return false;
	      },
	      select: function( event, ui ) {
			$('#job_bike').val(ui.item.label);
			$('#job_bike_id').val(ui.item.value);
			return false;
		  }
		});
		var old_chosen_val  = '';
		var err_new			= '';
		$('#pc_add_job_form').click(function(e){
			err_new			= 1;
			if(!$(e.target).is('.chzn-container *,a.search-choice-close, .chzn-drop *'))
			{
				var chosen_sel	= $('.parts-chosen').val();
				if(chosen_sel !== null && chosen_sel != 'null' && chosen_sel !== undefined)
				{
					if(old_chosen_val.toString() != chosen_sel.toString())
					{
						loadShowAndHide(1);
						var hid_job_id	= $('#job_id').val();
						var post_url	= siteUrl + '/maintenancemanagement/job/get-parts-details';
						$.post(post_url,'job_id='+hid_job_id+'&sel='+chosen_sel,function(result){
							if(result.err == 0)
							{
								old_chosen_val  = chosen_sel;
								var appnd_parts = '';
								appnd_parts		+= '<div class="appnd-parts"><table><tr><th>Parts Name</th><th>Available Quantity</th><th>Parts Needed</th></tr>';
								for(el in result)
								{
									if(result[el].id != undefined)
									{
										var stock_value = '';
										var stock_old = '';
										if(result[el].old_stock != '')
										{
											if($('#stocks_'+result[el].id).val() != undefined)
											{
												stock_value = $('#stocks_'+result[el].id).val();
											}
											else
											{
												stock_value = result[el].old_stock;
											}
											stock_old	= result[el].old_stock;
										}
										else if($('#stocks_'+result[el].id).val() != undefined)
										{
											stock_value = $('#stocks_'+result[el].id).val();
										}
										appnd_parts		+= '<tr>';
										appnd_parts		+= '<td>'+result[el].name+'</td><td class="text_center">'+result[el].stock+'<input type="hidden" name="stocks_min_qty[]" value="'+result[el].min_qty+'" id="stocks_min_qty_'+result[el].id+'"/><input type="hidden" name="stocks_available[]" value="'+result[el].stock+'" id="stocks_available_'+result[el].id+'"/></td><td><input type="text" name="stocks[]" dat-stock="'+result[el].stock+'" id="stocks_'+result[el].id+'" value="'+stock_value+'" class="stocks_need_cls wid100"/><input type="hidden" name="stocks_old[]" id="stocks_old_'+result[el].id+'" value="'+stock_old+'"/><input type="hidden" name="stocks_ids[]" value="'+result[el].stock_ids+'" id="stocks_ids_'+result[el].id+'"/></td>';
										appnd_parts		+= '</tr>';
									}
								}
								appnd_parts		+= '</table></div>';
								$('.appnd-parts').remove();
								$('.append-parts-td').append(appnd_parts);
								loadShowAndHide(2);
							}
							else
							{
								old_chosen_val  = '';
							}
						},'json');
					}
				}
				else
				{
					old_chosen_val  = '';
					$('.appnd-parts').remove();
				}
			}
		});
		jQuery("#pc_add_job_form").validationEngine({
			promptPosition: "topLeft",
			showOneMessage: true,
			maxErrorsPerField:1,
			onValidationComplete: function(form, status) {
				var err_msg = '';
				var len_parts = new Array();
				if($('.parts-chosen').val() != undefined)
				{
					if($('.parts-chosen').val() != null && $('.parts-chosen').val() != 'null')
					{
						len_parts	= $('.parts-chosen').val().length;
						var el = 0;
						$('.stocks_need_cls').each(function(){
							if($(this).val() == '')
							{
								err_msg += 1;
								jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Part Needed is required!', 1, 'topRight:-37', true);
							}
							else if($(this).val() > 0)
							{
								if($(this).val() > parseInt($(this).attr('dat-stock')))
								{
									err_msg += 1;
									jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Please enter parts less than or equal to parts available!', 1, 'topRight:-37', true);
								}
							}
							else
							{
								err_msg += 1;
								jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Please enter valid number!', 1, 'topRight:-37', true);
							}
							el++;
						});
						if(el == len_parts)
						{
							err_new = '';
						}
					}
					else
					{
						err_msg += 1;
						jQuery('#job_used_parts_chzn').validationEngine('showPrompt', 'Part Needed is required!', 1, 'topRight:-272', true);
					}
				}
				else if($('.parts-chosen').val() == null || $('.parts-chosen').val() == 'null')
				{
					if(typeof $('.parts-chosen').val() == 'undefined')
					{
						err_new = '';
					}
					else
					{
						err_msg += 1;
						jQuery('#job_used_parts_chzn').validationEngine('showPrompt', 'Part Needed is required!', 1, 'topRight:-272', true);
					}
				}
				else
				{
					err_new = '';
				}
				if(err_msg == '' && err_new == '')
				{
					if(status === true)
					{
						form.validationEngine('detach');
						form.submit();
					}
				}
				else
				{
					return false;
				}
			}
		});
		$(window).load(function(){
			$('#pc_add_job_form').click();
		});
	}
	if($("#pc_add_meeting_form,#pc_edit_meeting_form").length)
	{
		$("#meeting_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		$("#meeting_time").timepicker({
			showSecond: false,//showSecond: true,
			/*addSliderAccess: true,
			sliderAccessArgs: { touchonly: false }*/
			timeFormat: 'hh:mm TT' //timeFormat: 'hh:mm:ss TT'
		});
		$('#meeting_to').change(function(){
			if($(this).val() == 1)
			{
				$('#meeting_send_notif').attr('checked',true);
			}
			else
			{
				$('#meeting_send_notif').removeAttr('checked');
			}
		});
		jQuery("#pc_add_meeting_form,#pc_edit_meeting_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			ajaxFormValidation: false
		});
	}
	if($("#pc_filter_meeting_form").length)
	{
		$("#fil_meeting_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_filter_meeting_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			ajaxFormValidation: false
		});
	}
	if($("#pc_filter_document_form").length)
	{
		$("#fil_document_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_filter_document_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			ajaxFormValidation: false
		});
	}
	if($("#pc_add_document_form").length)
	{
		$('.show_add_document').click(function(){
			$(this).toggleClass('btn-plus btn-minus');
			$('#document_div_add').slideToggle();
		});
		var check_file = '';
		$('#document_file').change(function(){
			$('#document_fake_file').val($(this).val());
			check_file = checkFileUploadTypes($(this).val(), this, 'pdf|doc|docx|rtf|txt|xls|csv',1);
		});
		$(document).on('click','div.document_fileformError',function(){
			$(this).remove();
		});
		jQuery("#pc_add_document_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			onValidationComplete: function(form, status) {
				if(check_file == '' || check_file == undefined)
				{
					showCustomPrompt('document_file', 'Document is required', 1);
				}
				else if((check_file == true || check_file == 'true') && status === true)
				{
					form.validationEngine('detach');
					form.submit();
				}
				else
				{
					showCustomPrompt('document_file', check_file, 1);
					return false;
				}
			}
		});
	}
	if($("#pc_add_video_form").length)
	{
		$('.show_add_video').click(function(){
			$(this).toggleClass('btn-plus btn-minus');
			$('#video_div_add').slideToggle();
		});
		var check_file = '';
		$('#video_file').change(function(){
			$('#video_fake_file').val($(this).val());
			check_file = checkFileUploadTypes($(this).val(), this, 'mp4|flv|ogv|m4v|xls|doc|docx',2);//|webm|wmv|mkv|3gp|avi|mpeg|mpg|mov|
		});
		$(document).on('click','div.video_fileformError',function(){
			$(this).remove();
		});
		jQuery("#pc_add_video_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			onValidationComplete: function(form, status) {
				if(check_file == '' || check_file == undefined)
				{
					showCustomPrompt('video_file', 'Video is required', 1);
				}
				else if((check_file == true || check_file == 'true') && status === true)
				{
					form.validationEngine('detach');
					form.submit();
				}
				else
				{
					showCustomPrompt('video_file', check_file, 1);
					return false;
				}
			}
		});
	}
	if($("#pc_filter_video_form").length)
	{
		$("#fil_video_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_filter_video_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			ajaxFormValidation: false
		});
	}
	if($("#pc_contract_reminder_form").length)
	{
		$("#fil_start_date,#fil_end_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		jQuery("#pc_contract_reminder_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			ajaxFormValidation: false
		});
	}
	
	if($("#pc_add_reminder_form").length)
	{
		$('.show_contract_reminder').click(function(){
			$(this).toggleClass('btn-plus btn-minus');
			$('#contract_div_add').slideToggle();
		});
		$("#lease_date").datepicker({
			dateFormat: 'm-d-yy',// dd/mm/yyyy
			changeMonth: true,
      		changeYear: true
		});
		var check_file = '';
		$('#reminder_file').change(function(){
			$('#reminder_fake_file').val($(this).val());
			check_file = checkFileUploadTypes($(this).val(), this, 'pdf',2);//|webm|wmv|mkv|3gp|avi|mpeg|mpg|mov|
		});
		$(document).on('click','div.reminder_fileformError',function(){
			$(this).remove();
		});
		jQuery("#pc_add_reminder_form").validationEngine({	
			promptPosition: "topLeft",
			showOneMessage: true,
			onValidationComplete: function(form, status) {
				if(check_file == '' || check_file == undefined)
				{
					showCustomPrompt('reminder_file', 'Lease is required', 1);
				}
				else if((check_file == true || check_file == 'true') && status === true)
				{
					form.validationEngine('detach');
					form.submit();
				}
				else
				{
					showCustomPrompt('reminder_file', check_file, 1);
					return false;
				}
			}
		});
	}
});
function validateMultiplePurchase()
{
	var err = '';
	$('.formError').remove();
	$('.dynamic_content .autocomplete_job').each(function(){
		if($(this).val() == '')
		{
			err += 1;
			jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Part Name is required!', 1, 'topRight:-183', true);
		}
	});
	$('.dynamic_content .job_number_cls').each(function(){
		if($(this).val() == '')
		{
			err += 1;
			jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Job Number is required!', 1, 'topRight:-120', true);
		}
	});
	$('.dynamic_content .date_picker_job').each(function(){
		if($(this).val() == '')
		{
			err += 1;
			jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Purchase Date is required!', 1, 'topRight:-81', true);
		}
	});
	$('.dynamic_content .quantity_cls').each(function(){
		if($(this).val() == '')
		{
			err += 1;
			jQuery('#'+$(this).attr('id')).validationEngine('showPrompt', 'Quantity is required!', 1, 'topRight:-42', true);
		}
	});
	return err;
}
function appendDatePicker(count,formId)
{
	$('div#purchase_row_'+(count)+' .date_picker_job').attr('id','purchase_date_'+(count));
	$('div#purchase_row_'+(count)+' .autocomplete_job').attr('id','part_name_'+(count));
	$('div#purchase_row_'+(count)+' .job_number_cls').attr('id','job_number_'+(count));
	$('div#purchase_row_'+(count)+' .hidd_parts_id').attr('id','parts_id_'+(count));
	$('div#purchase_row_'+(count)+' .quantity_cls').attr('id','quantity_'+(count));
	$('div#purchase_row_'+(count)+' .hidd_quantity_old').attr('id','quantity_old_'+(count));
	$('div#purchase_row_'+(count)+' .hidd_purchase_id').attr('id','purchase_id_'+(count));
	$('#purchase_date_'+count).removeClass('hasDatepicker');
	$('#purchase_date_'+count).datepicker({
		dateFormat: 'm-d-yy',	// dd/mm/yyyy
		changeMonth: true,
     	changeYear: true
	}).datepicker('setDate',new Date());
	$('#part_name_'+count).autocomplete({
      source: function( request, response ) {
	  	var url_auto 	= siteUrl + '/maintenancemanagement/inventory/get-parts-details';
		var exclude_ids	= '';
		exclude_ids		= $('#'+formId+' .hidd_parts_id').serialize();
		var curr_val    = $('#parts_id_'+count).val();
        $.post(url_auto,'search='+request.term+'&curr='+curr_val+'&'+exclude_ids,function(result){
			if(result.length == 0)
			{
				$('#job_number_'+count).val('');
			}
        	response( $.map( result, function( item ) {
			  return {
                label	: item.name,
                value	: item.id,
				job		: item.job,
				qbp		: item.qbp
              }
            }));
        },'json');
      },
	  focus: function() {
        return false;
      },
      select: function( event, ui ) {
		$('#part_name_'+count).val(ui.item.label);
		$('#job_number_'+count).val(ui.item.job);
        $('#parts_id_'+count).val(ui.item.value);
		return false;
	  }
	});
}

function ajaxAccidentListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');			// unsettled_accident_filter_form settled_accident_filter_form
		
		if(formId && formId == 'settled_accident_filter_form') {
			loadDiv('settledListingContainer', '/accident-page/1', '', '', 0);
		} else {
			loadDiv('unsettledListingContainer', '/accident-page/2', '', '', 0);
		}
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message		
	}
	return false;
}

// Called once the server replies to the ajax form validation request
function ajaxAccidentValidationCallback(status, form, json, options) {
	if (status === true) {
		// uncomment these lines to submit the form to form.action
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message
		location.href = siteUrl+json.redirect_url;
	} else {
		backtoTop();
	}
}

function ajaxAssignDriversCallback(status, form, json, options) {
	if (status === true) {
		// form.validationEngine('detach');
		// form.submit();
		// or you may use AJAX again to submit the data
		// Todo : need to Show Success message
		location.href = siteUrl+json.redirect_url;
	} else {
		// $("#confirmed_drivers_div input:checkbox").attr('disabled','disabled');
		backtoTop();
	}
}

function ajaxAddLocationValidationCallback(status, form, json, options)
{			
	if (status === true)
	{
		if(json.err_msg == 1)
		{
			showCustomPrompt('loc_title', 'Location Title already exists!', 1);
			//$('#loc_title').before('<div class="loc_titleformError parentFormpc_add_loc_form formError" style="opacity: 1; position: absolute; top: 61px; left: 182px; margin-top: -39px;"><div class="formErrorContent">Location Title already exists!<br></div><div class="formErrorArrow"><div class="line10"><!-- --></div><div class="line9"><!-- --></div><div class="line8"><!-- --></div><div class="line7"><!-- --></div><div class="line6"><!-- --></div><div class="line5"><!-- --></div><div class="line4"><!-- --></div><div class="line3"><!-- --></div><div class="line2"><!-- --></div><div class="line1"><!-- --></div></div></div>');
		}
		else
		{
			location.href = siteUrl+json.redirect;
		}
	}
	else
	{
		backtoTop();
	}
}
function ajaxShiftValidationCallback(status, form, json, options)
{			
	if (status === true)
	{
		if(json.err == 1)
		{
			showCustomPrompt('shift_st_date', 'Shift Timing already exists!', 1);
		}
		if(json.err == 2)
		{
			showCustomPrompt('shift_st_date', 'Shift days not found in between days!', 1);
		}
		else if(json.err == 0)
		{
			location.href = siteUrl+json.redirect;
		}
	}
	else
	{
		backtoTop();
	}
}
function ajaxnoteValidationCallback(status, form, json, options)
{			
	if (status === true)
	{
//		console.log(status);
	}
	else
	{
		backtoTop();
	}
}

// Called once the server replies to the ajax form validation request
function ajaxUserValidationCallback(status, form, json, options) {			
	if (status === true) {
		// uncomment these lines to submit the form to form.action
		form.validationEngine('detach');
		form.submit();
		// or you may use AJAX again to submit the data
	} else {
		backtoTop();
	}
}

// Called once the server replies to the ajax form validation request
function ajaxPartsValidationCallback(status, form, json, options) {		
	if (status === true) {
		// uncomment these lines to submit the form to form.action
		form.validationEngine('detach');
		form.submit();
		// or you may use AJAX again to submit the data
	} else {
		backtoTop();
	}
}

function showCustomPrompt(fieldId, msg, LoadType) {
	// No option, take default one
	// jQuery('#url').validationEngine('showPrompt', 'This a custom msg', 'error', true)
	var LoadTypes	=	(LoadType == 1) ? "error" : "";
	jQuery('#'+fieldId).validationEngine('showPrompt', msg, LoadTypes, '', true);	//	bottomLeft
}

var commonImageSize	= 3145728;							//	3 Mb
var commonFileSize	= 5242880;							//	5 Mb
var commonImageType	= 'jpg|jpeg|pjpeg|gif|png|bmp';
var commonFileType	= 'pdf';							//	pdf|doc|docx|rtf|txt

function checkCustomFileUploads(thisObj, callType, rules, i, options) {
	// callType	1 = onchange, 2 = submit	validation types
	var fieldId 	= thisObj.attr("id");
	
	var fileType 	= (fieldId == "user_contract") ? commonFileType : commonImageType;
	
	var extensions  = new RegExp( fileType+'$', 'i' );
	var showTypes	= getShowFileFormat(fileType, "|", ", ");
	
	var fileSize 	= (fieldId == "user_contract") ?  commonFileSize : commonImageSize;
	
	var sizeInMB 	= (fileSize / (1024*1024)).toFixed(2);	
	var file    	= thisObj.prop('files')[0];
	var	msg			= '';
	
	if (file) {
	   var fileName = getFileName(file.name);
	   
		 //  validate File Extension 
		if(!extensions.test(fileName)){
			msg				= "Invalid format, upload only ("+showTypes+")";
			if(callType == 1) {
				showCustomPrompt(fieldId, msg, 1);
				return false;
			} else {
				return msg;
			}
		}
		
		// validate File size
		if((file.size > fileSize)) {
			msg		=	"Size should be less than "+sizeInMB+"MB";
			if(callType == 1) {
				showCustomPrompt(fieldId, msg, 1);
				return false;
			} else {
				return msg;
			}
		}
		
		if (!!file.type.match(/image.*/)) {
			if ( window.FileReader ) {
				reader 			 = new FileReader();
				reader.onloadend = function (e) {
					$('#'+fieldId+'_pro-img img').attr({"src" : e.target.result, "title" : file.fileName});
					$('#'+fieldId+'_pro-img').show();
				};
				reader.readAsDataURL(file);
			}
		} else {
			var htmls = '<img src="'+siteImageUrl+'/spacer.png" class="icon-pdf" />' + fileName;
			$('#'+fieldId+'_pro-file').html(htmls);
		}
	}
}

function checkFileUploads(field, rules, i, options) {
	return checkCustomFileUploads(field, 2, rules, i, options);
}
function checkBikeFileUploads(field, rules, i, options) {
	return checkCustomFileUploads(field, 2, rules, i, options);
}
function getFileName(file) {
	if (file.indexOf('/') > -1){
		file = file.substring(file.lastIndexOf('/') + 1);
	} else if (file.indexOf('\\') > -1){
		file = file.substring(file.lastIndexOf('\\') + 1);
	}
	return file;
}
function validateFileName(filename) {
	var extensions = new RegExp( fileType+'$', 'i' );
	return (extensions.test(filename)) ? filename : -1;
}

function getShowFileFormat(fileTypes, findChar, replaceChar) {
	fileTypes = fileTypes.split(findChar).join(replaceChar);  
	return fileTypes;
}

Array.prototype.last = function() {
	return this[this.length-1];
}

function loadDiv(divId, url, sortBy, sortType, urlType) {
	loadShowAndHide(1);
	var url	=	(urlType == 1) ? url : siteUrl + url;
	if(sortBy != '' && sortBy != 'undefined') {
		url	= url+'/'+sortBy;
	}
	if(sortType != '' && sortType != 'undefined') {
		url	= url+'/'+sortType;
	}
	
	$.post(url, function(data){
		$('#'+divId).html(data);
		loadShowAndHide(2);
	});
}

function deleteAction(deleteurl, listingUrl, listingContainer) {
	if(confirm('Are you sure to delete this item?')) {
		var url		=  deleteurl;
		var urlType =  (listingContainer && (listingContainer == 'settledListingContainer' || listingContainer == 'unsettledListingContainer')) ? 0 : 1;
		$.post(url, function(data) {
			loadDiv(listingContainer, listingUrl, '', '', 1);
		});
	}
}

function deleteLocation(locId, pageNum, listingContainer)
{
	if(confirm('Are you sure to delete this location?'))
	{
		var url	=	siteUrl + '/usermanagement/location/delete-manage-location/'+locId;
		$.post(url, function(data){
			loadDiv('listingContainer', '/usermanagement/location/manage-location-list/'+pageNum, '', '', 0);
		});
	}
}

function callPerPage(action, count, listingContainer) {
	action	= '/' + action + '/' + count;
	loadDiv(listingContainer, action, '', '', 0);
}

function backtoTop(){
	jQuery('html, body').animate({scrollTop:0}, 'slow'); 
	return false; 
}

function backtoTopNew(elements){
	var topScroller  = 0;
	if(elements != '') {
		var offset   = $("#" + elements).offset();
		if(offset.top >= 100) {
			topScroller  = (offset.top * 1) - 100;
		} else {
			topScroller	 = offset.top;
		}
	}
	jQuery('html, body').animate({scrollTop:topScroller}, 'slow'); 
	return false; 
}

function ajaxAddBikeValidationCallback(status, form, json, options)
{			
	if (status === true)
	{
		if(json.err_msg == 1)
		{
			showCustomPrompt('bike_name', 'Bike Name already exists!', 1);
			//$('#bike_name').before('<div class="bike_nameformError parentFormpc_add_bike_form formError" style="opacity: 1; position: absolute; top: 61px; left: 182px; margin-top: -39px;"><div class="formErrorContent">Bike Name already exists!<br></div><div class="formErrorArrow"><div class="line10"><!-- --></div><div class="line9"><!-- --></div><div class="line8"><!-- --></div><div class="line7"><!-- --></div><div class="line6"><!-- --></div><div class="line5"><!-- --></div><div class="line4"><!-- --></div><div class="line3"><!-- --></div><div class="line2"><!-- --></div><div class="line1"><!-- --></div></div></div>');
		}
		else
		{
			form.validationEngine('detach');
			form.submit();
		}
	}
	else
	{
		backtoTop();
	}
}
function deleteBike(bikeId, pageNum, listingContainer)
{
	if(confirm('Are you sure to delete this bike?'))
	{
		var url	=	siteUrl + '/bikemanagement/bike/delete-bike/'+bikeId;
		$.post(url, function(data){
			loadDiv('listingContainer', '/bikemanagement/bike/bike-list/'+pageNum, '', '', 0);
		});
	}
}

function driverShiftRequest(shiftArgs, requestDivId) {
	if(shiftArgs != '')
	{
		var url		= siteUrl + shiftArgs;
		var imgId	= requestDivId + "_img";
	
		$.post(url, function(data) {		
			
			var status	  =	$.trim(data);
			var add_class = '';
			var msg = '';
			if(status == 1)
			{
				add_class	= 'icon-29 icon-request-shift';
				msg			= 'Driver shift request successfully logged!';
			}
			else if(status == 2)
			{
				add_class	= 'icon-29 icon-contact-manager';
				msg			= 'Driver shift confirmed successfully!';
			}
			else if(status == 3)
			{
				add_class	= 'icon-29 icon-oncall';
				msg			= 'Driver shift request is in on call list!';
			}
			if(status != 5)
			{
				$('#'+imgId).removeClass().addClass(add_class);
			}
			else
			{
				msg			= 'Already you have confirmed Shift/Event in this date.';
			}
	
			var LoadTypes = (status == 1) ? "" : "";
			jQuery('#'+requestDivId).validationEngine('showPrompt', msg, LoadTypes, 'topRight:-250', false);	//	bottomLeft
		});
	}
}

function checkSelectionErrorMsg(checkType) {
  	//	1 - Hide after 5000 miliseconds, 2 - Hide immidiate
	if(checkType == 1) {
		setTimeout(function() {
					var obj	= $(".assign-drivers .formError");
					hideInOutTimeError(obj);
				}, 20000);
	} else {
		var obj	= $(".assign-drivers .formError");
		hideInOutTimeError(obj);
	}
}

function hideInOutTimeError(obj) {
	$(obj).fadeTo(200, 300, function() {
		 $(obj).remove();
	 });
}

var driverLoginFlags	=	false;
jQuery(document).ready(function() {
	// error Msg hide	
	 $(".onchange .formError").live('click',function (e) {
		e.preventDefault();
		hideInOutTimeError(this);
	});
	
	if($("#driver_login_shifts").length) {
		// Drivers In and Out times
		var onchange_checkbox = ($('.onchange :checkbox')).iphoneStyle({
	        onChange: function(elem, value) {
			  var status	  =  value.toString();
			  
			  var ajaxCall	  =  '';				
				if(status == 'true') {
					ajaxCall  =  'Out-Time';
				} else if(status == 'false') {
					ajaxCall  =  'In-Time';
				}
			   
			   var checkBoxId = elem.attr('id');			   
			   //	New mods done on 15th Apr 2013.
			   if(driverLoginFlags == true) {
			   	   var tempChange = (status == 'true') ? false : true;
				   $("#"+checkBoxId).attr('checked', tempChange);
				   return true;
			   } else {
			   	   driverLoginFlags	= true;
				   var viewId	  = checkBoxId+"_view";
				   var viewUrl	  = $("#"+checkBoxId+"_url").attr('rel');
				   	   viewUrl	 += (status == 'true') ? '_2' : '_1';
				   $("#"+viewId).attr('data-rel', viewUrl);
				   $("#"+viewId).click();
				   var tempChange = (status == 'true') ? false : true;
				   $("#"+checkBoxId).attr('checked', tempChange);
				   return true;
			   }
			   //	End
			   
			   /*
			   var aTagsId	  = checkBoxId+"_a";
			   var args		  = $("#"+aTagsId).attr('rel');
			   var url		  = siteUrl + args;
			   var tempIds	  = '';
			   var shiftArgs  = '';
			   
			   if((ajaxCall == 'Out-Time') || (ajaxCall == 'In-Time')) {
			   	   loadShowAndHide(1);
				   $.post(url, function(data) {
				   		loadShowAndHide(2);
						var aStatus	=  $.trim(data);
						tempIds	    = args.split('/');
				  		shiftArgs   = '/' + tempIds[1] + '/' + tempIds[2] + '/' + aStatus;
						$("#"+checkBoxId+"_a").attr('rel', shiftArgs);
						
						var LoadTypes = (aStatus == 1) ? "" : "";
						if(aStatus) {
							var msg = (aStatus == 'out') ? "Out-time is successfully logged!" : "In-time is successfully logged!";
							if(aStatus == 'out') {
								// elem.attr('disabled', 'disabled');
								$("#"+checkBoxId+"_a").parent().remove();
								$("#"+checkBoxId+"_outerDiv1 .logout_done").removeClass('visibility-hidden');
								aTagsId  =  checkBoxId+"_outerDiv1 .logout_done";
							}
						} else {
							var msg = "Try after some time!";
						}
						jQuery('#'+aTagsId).validationEngine('showPrompt', msg, LoadTypes, 'topRight:-140', false);	//	bottomLeft
						
						setTimeout(function() {
							var obj	= $(".onchange .formError, .in-out .formError");
							hideInOutTimeError(obj);
						}, 5000);
					});
				} else {
						var msg = "Out-time is already logged!";
						jQuery('#'+aTagsId).validationEngine('showPrompt', msg, '', 'topRight:-140', false);	//	bottomLeft
						setTimeout(function() {
							var obj	= $(".onchange .formError");
							hideInOutTimeError(obj);
						}, 5000);
				}
				*/
	        }
	      });
	 }
	 
	 $("#mechanic_login_shifts_button, #mechanic_login_shifts_close").live('click',function (e) {
		e.preventDefault();
		var ids	= $(this).attr('id');
		
		if(ids == 'mechanic_login_shifts_close') {
			$("#mechanic_login_shifts").addClass('visibility-hidden');
		} else {
			if($('#mechanic_login_shifts').hasClass('visibility-hidden')) {
				$("#mechanic_login_shifts").removeClass('visibility-hidden');
			} else {
				$("#mechanic_login_shifts").addClass('visibility-hidden');
			}
		}
	 });
	 
	 if($("#mechanic_login_shifts").length) {
		// Drivers In and Out times
		var onchange_checkbox = ($('.onchange :checkbox')).iphoneStyle({
	        onChange: function(elem, value) {
			  var status	  =  value.toString();
			  
			  var ajaxCall	  =  '';				
				if(status == 'true') {
					ajaxCall  =  'Out-Time';
				} else if(status == 'false') {
					ajaxCall  =  'In-Time';
				}
			   
			   var checkBoxId = elem.attr('id');
			   var aTagsId	  = 'mechanic_login_shifts_a';
			   var args		  = $("#"+aTagsId).attr('rel');
			   var url		  = siteUrl + args;
			   
			   if((ajaxCall == 'Out-Time') || (ajaxCall == 'In-Time')) {
				   loadShowAndHide(1);
				   $.post(url, function(data) {
				   		loadShowAndHide(2);
						var aStatus	=  $.trim(data);						
						var LoadTypes = (aStatus == 1) ? "" : "";
						if(aStatus) {
							var msg = (aStatus == '2') ? "Out-time is successfully logged!" : "In-time is successfully logged!";
						} else {
							var msg = "Try after some time!";
						}
						jQuery('#'+aTagsId).validationEngine('showPrompt', msg, LoadTypes, 'topLeft:-120', false);	//	bottomLeft	//	topRight:-140
						
						setTimeout(function() {
							var obj	= $(".onchange .formError, .in-out .formError");
							// hideInOutTimeError(obj);
						}, 5000);
					});
				}
	        }
	      });
		  /*
		  var msg = "In-time is successfully logged!";
		  jQuery('#mechanic_login_shifts_a').validationEngine('showPrompt', msg, '', 'topRight:-80', false);	//	bottomLeft	//	topRight:-140
		  */
	 }
});

function deleteShift(eventId, shiftId)
{
	if(confirm('Are you sure to delete this event?'))
	{
		var url	=	siteUrl + '/schedulemanagement/shift/delete-shift/'+eventId+'/'+shiftId;
		$.post(url, function(data){
			if(data == 1)
			{
				location.href = '/schedulemanagement/shift/shift-calendar';
			}
		});
	}
}

function loadShowAndHide (type) {
	if(type == 1) {
		$('#divLoader').show();
	} else {
		$('#divLoader').hide();
	}
}
function deleteShiftEvents(sh_ev_id, fkshiftId,occurs)
{
	var shift_text	= '';
	if(occurs == 1)
	{
		shift_text	= 'shift';
	}
	else
	{
		shift_text	= 'event';
	}
	if(confirm('Are you sure to delete this '+shift_text+'?'))
	{
		var url	=	siteUrl + '/schedulemanagement/shift/delete-shift-event/'+sh_ev_id+'/'+fkshiftId+'/'+occurs;
		$.post(url, function(data){
			if(data == 1)
			{
				location.href = '/schedulemanagement/shift/manage-shift';
			}
		});
	}
}
function callCKEditor(id,config_name)
{
	CKEDITOR.replace( id, {
		customConfig	: '/js/ckeditor/'+config_name+'.js'
	});
}
function deleteDriverNote(driv_id,type)
{
	if(confirm('Are you sure to delete this note?'))
	{
		if(driv_id != '')
		{
			var url	=	siteUrl + '/managernotemanagement/note/delete-driver-note/'+driv_id+'/'+type;
			$.post(url, function(data){
				if(data == 1)
				{
					if(type == 1)
					{
						location.href = '/managernotemanagement/note/driver-note-listing';
					}
					else
					{
						location.href = '/managernotemanagement/note/driver-receive-listing';
					}
				}
			});
		}
	}
}
function deleteClientNote(client_id,type)
{
	if(confirm('Are you sure to delete this note?'))
	{
		if(client_id != '')
		{
			var url	=	siteUrl + '/managernotemanagement/note/delete-client-note/'+client_id+'/'+type;
			$.post(url, function(data){
				if(data == 1)
				{
					if(type == 1)
					{
						location.href = '/managernotemanagement/note/client-note-listing';
					}
					else
					{
						location.href = '/managernotemanagement/note/client-receive-listing';
					}
				}
			});
		}
	}
}
function deleteLocationNote(loc_id,type)
{
	if(confirm('Are you sure to delete this note?'))
	{
		if(loc_id != '')
		{
			var url	=	siteUrl + '/managernotemanagement/note/delete-location-note/'+loc_id+'/'+type;
			$.post(url, function(data){
				if(data == 1)
				{
					if(type == 1)
					{
						location.href = '/managernotemanagement/note/location-note-listing';
					}
					else
					{
						location.href = '/managernotemanagement/note/location-receive-listing';
					}
				}
			});
		}
	}
}
function deleteMechanicNote(mech_id,type)
{
	if(confirm('Are you sure to delete this note?'))
	{
		if(mech_id != '')
		{
			var url	=	siteUrl + '/managernotemanagement/note/delete-mechanic-note/'+mech_id+'/'+type;
			$.post(url, function(data){
				if(data == 1)
				{
					if(type == 1)
					{
						location.href = '/managernotemanagement/note/mechanic-note-listing';
					}
					else
					{
						location.href = '/managernotemanagement/note/mechanic-receive-listing';
					}
				}
			});
		}
	}
}
var driver_img_id = '';
function driverCancelShifts(requestDivId) {
	if(requestDivId != '')
	{
		var requestDivId	= requestDivId+'_img';
		driver_img_id		= requestDivId;
		if(confirm('Are you sure to cancel this shift?'))
		{
			$('#reason_cancel').val('');
			$('.driver_shift_cancel_div #reason_cancel').attr({
				'dat-shift'		: $('#'+requestDivId).attr('dat-shift'),
				'dat-sdt'		: $('#'+requestDivId).attr('dat-sdt'),
				'dat-occ'		: $('#'+requestDivId).attr('dat-occ'),
				'dat-req'		: $('#'+requestDivId).attr('dat-req'),
				'dat-stat'		: $('#'+requestDivId).attr('dat-stat')
			});
			$('.driver_shift_cancel_div').fadeIn();
			var center_top  = Math.max(0, (($(window).height() - $('.driver_shift_cancel_div').outerHeight()) / 2) + $(window).scrollTop());
    		var center_left = Math.max(0, (($(window).width() - $('.driver_shift_cancel_div').outerWidth()) / 2) + $(window).scrollLeft());
			$('.driver_shift_cancel_div').css({
				'left'		: (center_left + 50) +'px',
				'top'		: (center_top) +'px',
				'position'	: 'absolute',
				'z-index'	: '1000'
			});
		}
	}
}
function cancelDriverShift()
{
	var shift_id		= $('#reason_cancel').attr('dat-shift');
	var shift_dt_id		= $('#reason_cancel').attr('dat-sdt');
	var shift_occurs	= $('#reason_cancel').attr('dat-occ');
	var req_id			= $('#reason_cancel').attr('dat-req');
	var req_stat		= $('#reason_cancel').attr('dat-stat');
	var text_cont		= $('#reason_cancel').val();
	var url_path		= siteUrl+"/driver-shift-cancel/"+shift_id+"/"+shift_occurs+"/"+shift_dt_id+"/"+req_id+"/"+req_stat;
	$.post(url_path,'reason='+encodeURIComponent(text_cont),function(result){
		$('.driver_shift_cancel_div').fadeOut();
		if(result.err == 0)
		{
			$('#'+driver_img_id).removeAttr('onclick');
			$('#'+driver_img_id).removeClass().addClass('icon-29 icon-cancel');
			$('#'+driver_img_id).validationEngine('showPrompt','Shift has been cancelled successfully!' , '":"', 'topRight:-37', false);
		}
		else if(result.err == 2)
		{
			$('#'+driver_img_id).validationEngine('showPrompt','Sorry! You will not able to cancel your shift before cut off period.' , '":"', 'topRight:-37', false);
		}
	},'json');
}
function deleteJobSheet(jobId)
{
	if(jobId != '')
	{
		if(confirm('Are you sure to delete this job sheet?'))
		{
			var url_path		= siteUrl+'/maintenancemanagement/job/delete-job-sheet/';
			$.post(url_path,'jobId='+jobId,function(result){
				if(result == 1)
				{
					location.href = '/maintenancemanagement/job/job-listing';
				}
			});
		}
	}
}
function deleteMeetingSchedule(MeetingId)
{
	if(MeetingId != '')
	{
		if(confirm('Are you sure to delete this meeting?'))
		{
			var url_path		= siteUrl+'/miscellaneousmanagement/schedule/delete-meeting/';
			$.post(url_path,'meetingId='+MeetingId,function(result){
				if(result == 1)
				{
					location.href = '/miscellaneousmanagement/schedule';
				}
			});
		}
	}
}
function deleteDocument(documentId)
{
	if(documentId != '')
	{
		if(confirm('Are you sure to delete this document?'))
		{
			var url_path		= siteUrl+'/miscellaneousmanagement/document/delete-document/';
			$.post(url_path,'documentId='+documentId,function(result){
				if(result == 1)
				{
					location.href = '/miscellaneousmanagement/document/manage-documents';
				}
			});
		}
	}
}
function deleteVideo(videoId)
{
	if(videoId != '')
	{
		if(confirm('Are you sure to delete this video?'))
		{
			var url_path		= siteUrl+'/miscellaneousmanagement/document/delete-video/';
			$.post(url_path,'videoId='+videoId,function(result){
				if(result == 1)
				{
					location.href = '/miscellaneousmanagement/document/video';
				}
			});
		}
	}
}
function getAge(dateString)
{
    var today = new Date();
    var birthDate = new Date(dateString);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
}

function ajaxShiftListingValidationCallback(status, form, json, options) {
	if (status === true) {
		var formId	=  form.attr('id');
		
		if(formId && formId == 'pc_manage_shift_old_form') {
			loadDiv('oldListingContainer', '/manage-shift-list/2', '', '', 0);
		} else {
			loadDiv('newListingContainer', '/manage-shift-list/1', '', '', 0);
		}
	}
	return false;
}

function requestToWorkJob(jobId)
{
	if(jobId)
	{
		if(confirm('Are you sure to work in this job sheet?'))
		{
			var url_path		= siteUrl+'/maintenancemanagement/job/request-job-sheet/';
			$.post(url_path,'jobId='+jobId,function(result){
				if(result.err == 0)
				{
					location.href = '/maintenancemanagement/job/mechanic-request-listing';
				}
				else
				{
					$('#job_req_'+jobId).validationEngine('showPrompt','Sorry! Job sheet has been assigned to another mechanic.' , '":"', 'topRight:-87', false);
				}
			},'json');
		}
	}
}
$(document).keyup(function(e) //Escape is pressed
{
  if(e.keyCode == 27)
  {
  	 $('.esc-class').fadeOut();
  }
});
function checkFileUploadTypes(value, thisObj, param,type) 
{
	var fieldId 	= $(thisObj).attr("id");
	var callType	= 1;
	var fileType 	= param;
	var extensions  = new RegExp( fileType+'$', 'i' );
	var showTypes	= getShowFileFormat(fileType, "|", ", ");
	if(type == 2)
	{
		var fileSize 	= 15728640;//15728640
	}
	else
	{
		var fileSize 	= 5242880;
	}
	var sizeInMB 	= (fileSize / (1024*1024)).toFixed(2);	
	var file    	= $(thisObj).prop('files')[0];
	var	msg			= '';
	
	if (file) {
	   var fileName = getFileName(file.name);
		 //  validate File Extension 
		if(!extensions.test(fileName)){
			msg				= "Invalid format, upload only ("+showTypes+")";
			showCustomPrompt(fieldId, msg, 1);
			return msg;
		}
		// validate File size
		if((file.size > fileSize)) {
			msg		=	"Size should be less than "+sizeInMB+"MB";
			showCustomPrompt(fieldId, msg, 1);
			return msg;
		}
		return true;
	}
}
function editContract(uId)
{
	if(uId)
	{
		var url_path		= siteUrl+'/miscellaneousmanagement/reminder/edit-reminder/'+uId;
		$.post(url_path,function(result){
			if(result.err == 0)
			{
				$('html,body').animate({
				    scrollTop: 20
				}, 1000);
				$('#user_id').val(result.id);
				$('#role_name').val(result.name);
				$('#contract_div_add').slideDown();
				$('.show_contract_reminder').removeClass('btn-plus').addClass('btn-minus');
			}
		},'json');
	}
}