<?php
//�����������������������������������
// Change the session timeout value to 30 minutes
$sessionMaxlifetime	 =  60;		//	30*60
ini_set("session.gc_maxlifetime", $sessionMaxlifetime);
//ini_set("session.gc_probability",1);
//ini_set("session.gc_divisor",1);
/*
$sessionCookieExpireTime=8*60*60;
session_set_cookie_params($sessionCookieExpireTime);
*/
session_start();
//������������������������������������

/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */
chdir(dirname(__DIR__));

// Time Setup :
if(!in_array($_SERVER['HTTP_HOST'],array('www.pedicablocal.com','192.168.1.250')))
{
	date_default_timezone_set('America/Los_Angeles');
}

/*
$script_tz = date_default_timezone_get();

if (strcmp($script_tz, ini_get('date.timezone'))){
    echo 'Script timezone differs from ini-set timezone.';
} else {
    echo 'Script timezone and ini-set timezone match.';
}
*/

// Setup autoloading
require 'init_autoloader.php';
require './vendor/excelClasses/PHPExcel.php';

// Site settings
$sitePath			 =  'http://' . $_SERVER['HTTP_HOST'];
$siteImagePath		 =  $sitePath;
if($_SERVER['HTTP_HOST'] == "localhost") {
	$sitePath		.=  "/pedicab/public";
	$siteImagePath	.=  "/pedicab/public/images";
} else {
	$siteImagePath	.=  "/images";
}
define('SITE_PATH', $sitePath);
define('SITE_IMAGE_PATH', $siteImagePath);
define('SITE_IMAGE_PATH_UPLOAD', getcwd().'/public/images');
define('SITE_PUBLIC_PATH', getcwd().'/public/');

// Run the application!
Zend\Mvc\Application::init(require 'config/application.config.php')->run();
