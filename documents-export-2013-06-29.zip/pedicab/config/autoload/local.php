<?php
/**
 * Local Configuration Override
 *
 * This configuration override file is for overriding environment-specific and
 * security-sensitive configuration information. Copy this file without the
 * .dist extension at the end and populate values as needed.
 *
 * @NOTE: This file is ignored from Git by default with the .gitignore included
 * in ZendSkeletonApplication. This is a good practice, as it prevents sensitive
 * credentials from accidentally being committed into version control.
 */
if($_SERVER['HTTP_HOST'] == "localhost") {
	return array(
	    'db' => array(
	        'username' => 'root',
	        'password' => '',
	    ),
	);
} else if($_SERVER['HTTP_HOST'] == "pedicab.sdiphp.com") {
	return array(
	    'db' => array(
	        'username' => 'pedicabdb',
	        'password' => 'pedicab123',
	    ),
	);
} else {
	return array(
	    'db' => array(
	        'username' => 'pedicab',
	        'password' => 'pedicab',
	    ),
	);
}
