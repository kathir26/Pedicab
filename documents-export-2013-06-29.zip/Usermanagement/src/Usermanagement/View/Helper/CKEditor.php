<?php
namespace Usermanagement\View\Helper;

use Zend\View\Helper\AbstractHelper,
    Zend\ServiceManager\ServiceLocatorAwareInterface,
    Zend\ServiceManager\ServiceLocatorInterface,
    Zend\View\Exception;
	
//	Session
use Zend\Session\Container;

/**
* 	CommonData helper
*/
class CKEditor extends AbstractHelper
{
    /**
	 * Type of image
	 * 
	 * @var array image types
	 */
    private $imageTypes	=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
	
	
	public function __construct()
    {
        // Todo : We do some thing
    }
	
    public function getCKEditors($elementId)
    {
		
		return $elementId;
    }
	
}