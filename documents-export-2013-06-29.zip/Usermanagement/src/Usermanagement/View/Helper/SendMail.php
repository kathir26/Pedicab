<?php
namespace Usermanagement\View\Helper;

use Zend\View\Helper\AbstractHelper,
    Zend\ServiceManager\ServiceLocatorAwareInterface,
    Zend\ServiceManager\ServiceLocatorInterface,
    Zend\View\Exception;
use Usermanagement\View\Helper\Datetime;
	
//	Session
use Zend\Session\Container;

// Mail
use Zend\Mail;
use Zend\Mime\Part as MimePart;
use Zend\Mime\Message as MimeMessage;

/**
* 	CommonData helper
*/
class SendMail extends AbstractHelper
{
	/**
	 * per transport
	 * 
	 * @var object transport
	 */
	private $transport;
	
	public function __construct()
    {
        // Todo : We do some thing
		// setup SMTP options
		$options = new Mail\Transport\SmtpOptions(array(
		            'name' => 'localhost',
		            'host' => 'smtp.gmail.com',
		            'port'=> 587,
		            'connection_class' => 'login',
		            'connection_config' => array(
		                'username' => 'vijayakumars@sdi.la',
		                'password' => 'kumar301187',
		                'ssl'=> 'tls',
		            ),
		));
		
		// Transport
		$this->transport = new Mail\Transport\Smtp($options);	//	$options
    }
	
	/*	Action	: 	Mail Send
	*	Detail	:	Send the mails
	*/
	public function mailSend($mailArray = '')
    {
		/*
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==mailSend==><pre>"; print_r($mailArray); echo "</pre><==";
		return false;
		*/
		
		// make a header as html
		$content	= $mailArray['content'];
		$html 		= new MimePart($content);
		$html->type = "text/html";
		$body 		= new MimeMessage();
		$body->setParts(array($html,));
		
		// instance mail
		$mail = new Mail\Message();
		$mail->setBody($body); 						// will generate our code html from template.phtml
		$mail->setFrom($mailArray['from_email'], $mailArray['from_name']);
		$mail->setTo($mailArray['to_email']);
		$mail->setSubject($mailArray['subject']);
		
		if(isset($mailArray['cc_mail']) && !empty($mailArray['cc_mail'])) {
			$mail->setCc($mailArray['cc_mail']);
		}
		
		// Send mail
		$this->transport->send($mail);
		return false;
	}
	
	/*	Action	: 	Preview Mail Send
	*	Detail	:	Send the mails
	*/
	public function previewMailSend($mailArray = '')
    {
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==previewMailSend==><pre>"; print_r($mailArray['content']); echo "</pre><==";
		echo "<pre>"; print_r($mailArray['content']); echo "</pre>";
		return false;
	}
}