<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class AddLocationForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_loc_form');
		$this->setAttribute('id', 'pc_add_loc_form');
		
		$this->add(array(
            'name' => 'loc_id',
            'attributes' => array(
                'type'  							=> 'hidden',
				'id'								=> 'loc_id'
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'loc_title',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'loc_title',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Location Title is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'loc_address',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'loc_address',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Location Address is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'name' => 'loc_postal_code',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'loc_postal_code',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Postal Code is required!',
            ),
            'options' => array(
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Checkbox',
            'name' => 'loc_same_addr',
			'attributes' => array(
				'id'   => 'loc_same_addr',
				'value'=> 1,
			),
            'options' => array(
                
            ),
        ));
		
		$this->add(array(
            'name'		 => 'loc_mail_address',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'loc_mail_address',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Mailing Address is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'loc_launch_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'loc_launch_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Date of Location Launch is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'loc_ses_open_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'loc_ses_open_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Season Opening Date is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'loc_ses_close_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'loc_ses_close_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[date]]',	// validate[optional,maxSize[6]]custom[date]
				'data-errormessage-value-missing' 	=> 'Season Closing Date is required!',
            ),
            'options' => array(
            ),
        ));
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'loc_status',
            'options' => array(
                'value_options' => array(
                    '1' => 'Active',
                    '0' => 'Inactive',
                ),
            ),
            'attributes' => array(
                'value' => '1', 		//set checked to '1'
				'style' => '',
				'class' => '',
				'id'   => 'loc_status'
            )
        ));
		// validate[required,custom[date]]
        $this->add(array(
            'name' 		=> 'loc_save',
            'attributes'=> array(
				'id'	=> 'loc_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'loc_reset',
            'attributes' => array(
				'id'	=> 'loc_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>