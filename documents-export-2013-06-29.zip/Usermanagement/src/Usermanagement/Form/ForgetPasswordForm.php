<?php
// module/Usermanagement/src/Usermanagement/Form/LoginForm.php:
namespace Usermanagement\Form;

use Zend\Form\Form;

class ForgetPasswordForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', 'form-horizontal');
		
		$this->add(array(
            'name' 		 => 'pc_forget_password_email',
            'attributes' => array(
				                'type'  							=> 'Zend\Form\Element\Email',
								'id'								=> 'pc_forget_password_email',
								'class'								=> '',
								'autofocus'							=> '',
								'PlaceHolder' 						=> 'Username',
								'data-validation-engine' 			=> 'validate[required,custom[email]]',
								'data-errormessage-value-missing' 	=> 'Email is required!',
								'data-errormessage-custom-error' 	=> 'Can you enter some thing as : abc@abc.abc',
								'data-errormessage' 			 	=> 'Entered Email is Invalid',
				            ),
            'options' => array(),
        ));
        $this->add(array(
            'name' 		 => 'reset_password',
            'attributes' => array(
                'type'   => 'submit',
                'value'  => 'Continue',	//	Reset Password
				'class'	 => '',
                'id'     => 'reset_password',
            ),
        ));
    }
}
?>