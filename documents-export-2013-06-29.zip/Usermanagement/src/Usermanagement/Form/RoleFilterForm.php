<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class RoleFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'role_filter_form');
		$this->setAttribute('name', 'role_filter_form');
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'search_role_name',
			'id'   => 'search_role_name',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Role Name',
                ),
            ),
            'attributes' => array(
                'value' => ''
            )
        ));
		
        $this->add(array(
            'name' => 'search_role_submit',
			'id'   => 'search_role_submit',
            'attributes' => array(
                'type'  => 'submit',
                'value' => 'Search',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_role_reset',
			'id'   => 'search_role_reset',
            'attributes' => array(
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> '',
            ),
        ));
    }
}
?>