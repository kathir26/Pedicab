<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class LocationFilterForm extends Form
{
    public function __construct($name = null)
    {
		// we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'location_filter_form');
		$this->setAttribute('name', 'location_filter_form');
		
		$this->add(array(
            'name' => 'loc_title_sch',
            'attributes' => array(
                'type'  		=> 'text',
				'id'			=> 'loc_title_sch',
				'class'			=> 'wid240',
				'autofocus'		=> '',
				'PlaceHolder' 	=> 'Location Title',
            ),
            'options' => array(
            )
        ));
		
        $this->add(array(
            'name' => 'search_loc_submit',
            'attributes' => array(
                'type'  		=> 'submit',
                'value' 		=> 'Search',
				'class'			=> '',
				'id'   			=> 'search_loc_submit',
            ),
        ));
		
		$this->add(array(
            'name' => 'search_loc_reset',
            'attributes' => array(
                'type'  		=> 'reset',
                'value' 		=> 'Reset',
				'class'			=> '',
				'id'   			=> 'search_loc_reset',
            ),
        ));
    }
}
?>