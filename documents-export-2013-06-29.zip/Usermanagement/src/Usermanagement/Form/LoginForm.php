<?php
// module/Usermanagement/src/Usermanagement/Form/LoginForm.php:
namespace Usermanagement\Form;

use Zend\Form\Form;

class LoginForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', 'form-horizontal');
		$this->setAttribute('id', 'login_form');
		/*
		data-validation-engine="validate[required,custom[email]]"
    data-errormessage-value-missing="Email is required!" 
    data-errormessage-custom-error="Let me give you a hint: someone@nowhere.com" 
    data-errormessage="This is the fall-back error message."
		*/
        $this->add(array(
		            'name' 		 => 'pc_login_email',
		            'attributes' => array(
						                'type'  							=> 'text',
										'id'								=> 'pc_login_email',
										'class'								=> '',
										'autofocus'							=> '',
										'PlaceHolder' 						=> 'Username',
										'data-validation-engine' 			=> 'validate[required,custom[email]]',
										'data-errormessage-value-missing' 	=> 'Email is required!',
										'data-errormessage-custom-error' 	=> 'Entered Username or Password is incorrect',
										'data-errormessage' 			 	=> 'Entered Email is Incorrect',
						            ),
		            'options' => array(),
		        ));
        $this->add(array(
		            'name' 		 => 'pc_password',
		            'attributes' =>  array(
						                'type'  							=> 'password',
										'id'								=> 'pc_password',
										'class' 							=> '',
										'PlaceHolder' 						=> 'Password',
										'data-validation-engine' 			=> 'validate[required]',
										'data-errormessage-value-missing' 	=> 'Password is required!',
	           						 ),
		            'options' 	 => array(),
       			 ));
		$this->add(array(
		             'type' 		=> 'Zend\Form\Element\Checkbox',
		             'name' 		=> 'pc_remember',
					 'attributes' 	=> array(
										 'id' 		=> 'pc_remember',
										 //'checked' 	=> 'checked',
									 	),
		             'options' 		=> array(
					                     'checked_value' 	=> '1',
					                     'unchecked_value' 	=> '0'
					              		)
			    ));
        $this->add(array(
            'name' 		 => 'submit',
            'attributes' => array(
                'type'   => 'submit',
                'value'  => 'Login',
				'class'	 => '',
                'id'     => 'submitbutton',
				//'onclick'	=> 'return validateLogin();',
            ),
        ));
    }
}
?>