<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class AddRoleForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('class', '');
		$this->setAttribute('id', 'pc_add_user_role_form');
		$this->setAttribute('name', 'pc_add_user_role_form');
		/*
			data-validation-engine="validate[required,custom[email]]"
		    data-errormessage-value-missing="Email is required!"
		    data-errormessage-custom-error="Let me give you a hint: someone@nowhere.com"
		    data-errormessage="This is the fall-back error message."
		*/
        $this->add(array(
            'name' 		 => 'pc_role_name',
            'attributes' => array(
				                'type'  							=> 'text',
								'id'								=> 'pc_role_name',
								'autofocus'							=> '',
								'PlaceHolder' 						=> 'Role Name',
								'class' 							=> '',
								'data-validation-engine' 			=> 'validate[required]',
								'data-errormessage-value-missing' 	=> 'Role Name is required!',
				            ),
            'options' => array(),
        ));
        
		$this->add(array(
            'name' 		 => 'pc_role_id',
            'attributes' => array(
				                'type'  		=> 'hidden',
								'id'			=> 'pc_role_id',
								'class' 		=> '',
				            ),
            'options' => array(),
        ));
		
        $this->add(array(
            'name' 		 => 'pc_user_role_save',
            'attributes' => array(
                'type'   => 'submit',
                'value'  => 'Save',
				'class'	 => '',
                'id'     => 'pc_user_role_save',
            ),
        ));
		
        $this->add(array(
            'name' 		 => 'pc_user_role_reset',
            'attributes' => array(
                'type'   => 'reset',
                'value'  => 'Reset',
				'class'	 => '',
                'id'     => 'pc_user_role_save',
				//'onclick'	=> 'return resetUserRoles("pc_add_user_role_form");',
            ),
        ));
    }
}
?>