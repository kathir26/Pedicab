<?php
namespace Usermanagement\Form;

use Zend\Form\Form;

class AddUserForm extends Form
{
    public function __construct($name = null)
    {
        // we want to ignore the name passed
        parent::__construct('usermanagement');
        $this->setAttribute('method', 'post');
		$this->setAttribute('enctype','multipart/form-data');
		$this->setAttribute('class', '');
		$this->setAttribute('name', 'pc_add_user');
		$this->setAttribute('id', 'pc_add_user');
		
		$this->add(array(
            'name' => 'user_id',
            'attributes' => array(
                'type'  => 'hidden',
				'id'	=> 'user_id',
            ),
        ));
		
		$this->add(array(
            'name' => 'location_id',
            'attributes' => array(
                'type'  => 'hidden',
				'id'	=> 'location_id',
            ),
        ));
		
        $this->add(array(
            'name' => 'user_firstname',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_firstname',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'First Name is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' => 'user_lastname',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_lastname',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Last Name is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'user_gender',
			'id'   => 'user_gender',
            'options' => array(
                'value_options' => array(
                    '1' => 'Male',
                    '2' => 'Female',
                ),
            ),
            'attributes' => array(
                'value' => '1', 		//set checked to '1'
				'style' => '',
				'class' => '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Gender is required!',
            )
        ));
		
		$this->add(array(
            'name'		 => 'user_mailing_address',
            'attributes' => array(
                'type'  							=> 'textarea',
				'id'								=> 'user_mailing_address',
				'class'								=> '',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Mailing Address is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_telephone_number',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_telephone_number',
				'class'								=> 'in-wid211',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[required,custom[phone],custom[integer],minSize[10], maxSize[20]]',	// validate[optional,maxSize[6]]
				'data-errormessage-value-missing' 	=> 'Phone Number is required!',
				'data-errormessage-range-underflow' => 'Please enter a phone number minimum <br/>or morethan 10 digits',
				'data-errormessage-range-overflow' 	=> 'Please enter a phone number maximum <br/>or lessthan 20 digits',
				'data-errormessage' 			 	=> 'Please enter a valid Phone number',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_text_address',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_text_address',
				'class'								=> 'in-wid266',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional]',
				'data-errormessage-value-missing' 	=> 'Text Address is required!',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_email',
            'attributes' => array(
				                'type'  							=> 'Zend\Form\Element\Email',
								'id'								=> 'user_email',
								'class'								=> '',
								'autofocus'							=> '',
								'PlaceHolder' 						=> '',
								'data-validation-engine' 			=> 'validate[required,custom[email]]',
								'data-errormessage-value-missing' 	=> 'Email is required!',
								'data-errormessage-custom-error' 	=> 'Can you enter some thing as : abc@abc.abc',
								'data-errormessage' 			 	=> 'Entered Email is Invalid',
				            ),
            'options' => array(),
        ));
		
        $this->add(array(
	         'name' 	  => 'user_password',
	         'attributes' =>  array(
		                'type'  							=> 'password',
						'id'								=> 'user_password',
						'class' 							=> '',
						'PlaceHolder' 						=> '',
						'data-validation-engine' 			=> 'validate[required,minSize[6]]',
						'data-errormessage-value-missing' 	=> 'Password is required!',
						'data-errormessage-range-underflow' => 'Minimum 6 characters required',
	       			),
	         'options' 	 => array(),
	  	));
		
		$this->add(array(
	         'name' 	  => 'user_confirm_password',
	         'attributes' =>  array(
		                'type'  							=> 'password',
						'id'								=> 'user_confirm_password',
						'class' 							=> '',
						'PlaceHolder' 						=> '',
						'data-validation-engine' 			=> 'validate[required,minSize[6],equals[user_password]]',
						'data-errormessage-value-missing' 	=> 'Confirm Password is required!',
						'data-errormessage-custom-error' 	=> 'Can you check your confirm password',
						'data-errormessage-range-underflow' => 'Minimum 6 characters required',
						'data-errormessage' 			 	=> 'Confirm Password is mismatch, <br/>Please Check !',
	       			),
	         'options' 	 => array(),
	  	));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Radio',
            'name' => 'user_status',
			'id'   => 'user_status',
            'options' => array(
                'value_options' => array(
                    '1' => 'Active',
                    '0' => 'Inactive',
                ),
            ),
            'attributes' => array(
                'value' => '1', 		//set checked to '1'
				'style' => '',
				'class' => ''
            )
        ));
		
		$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'user_role_id',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Role',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'   								=> 'user_role_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Role name is required!',
            )
        ));
		
		/*$this->add(array(
            'type' => 'Zend\Form\Element\Select',
            'name' => 'location_id',
            'options' => array(
                'value_options' => array(
                    '' => 'Select Location',
                ),
            ),
            'attributes' => array(
                'value' 							=> '',
				'id'   								=> 'location_id',
				'data-validation-engine' 			=> 'validate[required]',
				'data-errormessage-value-missing' 	=> 'Location is required!',
            )
        ));*/
		
		$this->add(array(
            'name' 		 => 'user_profile_image',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'user_profile_image',
				'class'								=> 'filepc',
				'size'								=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Profile Image is required!',
				//'data-errormessage' 			 	=> 'Profile Image is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_drivers_license',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'user_drivers_license',
				'class'								=> 'filepc',
				'size'								=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> "Driver's License is required!",
				//'data-errormessage' 			 	=> "Driver�s License is Incorrect",
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_contract',
            'attributes' => array(
                'type'  							=> 'file',
				'id'								=> 'user_contract',
				'class'								=> 'filepc',
				'size'								=> '30',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,funcCall[checkFileUploads]]',		//	custom[fileupload],
				'data-errormessage-value-missing' 	=> 'Upload Signed Contract is required!',
				//'data-errormessage' 			 	=> 'Upload Signed Contract is Incorrect',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_training_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_training_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Training Date is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_leasecontract_date',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_leasecontract_date',
				'class'								=> 'calc-txbox datepicker',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> 'validate[optional,custom[date]]',
				'data-errormessage-value-missing' 	=> 'Date of Lease Contract is required!',
				'data-errormessage' 			 	=> 'Invalid date, must be in MM-DD-YYYY format',
            ),
            'options' => array(
            ),
        ));
		
		$this->add(array(
            'name' 		 => 'user_citylicense_permit',
            'attributes' => array(
                'type'  							=> 'text',
				'id'								=> 'user_citylicense_permit',
				'class'								=> 'in-wid211',
				'autofocus'							=> '',
				'PlaceHolder' 						=> '',
				'data-validation-engine' 			=> '',
				'data-errormessage-value-missing' 	=> 'City License Permit is required!',
            ),
            'options' => array(
            ),
        ));
		
		// validate[required,custom[date]]
        $this->add(array(
            'name' 		=> 'user_save',
            'attributes'=> array(
				'id'	=> 'user_save',
                'type'  => 'submit',
                'value' => 'Save',
				'class'	=> '',
            ),
        ));
		
		$this->add(array(
			'name'	=> 'user_reset',
            'attributes' => array(
				'id'	=> 'user_reset',
                'type'  => 'reset',
                'value' => 'Reset',
				'class'	=> 'btn',
            ),
        ));
    }
}
?>