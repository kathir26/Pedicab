<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

//	Forms
use Usermanagement\Form\AddRoleForm,
	Usermanagement\Form\RoleFilterForm;

//	Models
use Usermanagement\Model\Users;
use Usermanagement\Model\Role;
use Usermanagement\Model\Aclresources;
use Usermanagement\Model\MyAuthenticationAdapter;

use Zend\Validator\File\Size;

// Flash messanger
use Zend\Mvc\Controller\Plugin\FlashMessenger;

class RoleController extends AbstractActionController
{
	protected $roleTable;
	protected $roleTypeTable;
	protected $usersTable;
	protected $driverInfoTable;
	protected $aclresourcesTable;
	protected $pcUser;
	protected $imageTypes;
	protected $imageSizes;
	protected $fileTypes;
	protected $fileSizes;
	protected $siteImageUploadPath;
	protected $siteImagePath;
	protected $sitePath;
	protected $defaultPerPage;
	protected $perPageArray;
	protected $commonData;
	
	public function __construct()
    {
        // Image and file
		$this->imageTypes	 		=  array('gif', 'jpg', 'pjpeg', 'png', 'jpeg','bmp');
		$this->imageSizes	 		=  '3145728';		//	3 Mb
		$this->fileTypes	 		=  array('pdf');	// 'doc', 'docx', 'rtf', 'txt'
		$this->fileSizes	 		=  '5242880';		//	5 Mb
		$this->siteImageUploadPath 	=  SITE_IMAGE_PATH_UPLOAD;
		$this->siteImagePath 		=  SITE_IMAGE_PATH;
		$this->sitePath 			=  SITE_PATH;
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');
		
		//	Session for users
		$userSession 		=   new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	=   $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	public function callTesting($method, $args)	//	__call
	{
		
	}
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	private function getTable($tableName)
    {
        $tableArray			 	=  array("roleTable" => "Role-Table", "roleTypeTable" => "Role-Type-Table", "usersTable" => "Users-Table", "driverInfoTable" => "Driver-Info-Table", "aclresourcesTable" => "Aclresources-Table");
		if (!isset($this->$tableName)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->$tableName 	=  $sm->get($tableArray[$tableName]);
        }
        return $this->$tableName;
    }
	
	/*	Action: Index
	*	Type:	Action
	*/
	public function indexAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
	}
	
	/*	Action	: 	Role listing
	*	Detail	:	This Action is used to list the Role details
	*/
	public function roleListingAction()
    {
		$request =  $this->getRequest();
		$auth 	 =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==translate==>".$this->translate('Controller')."<==";
		//
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$roleFilterForm = new RoleFilterForm();
		
		//	Destroy listing Session Vars
		$listingSession = new Container('roleListing');
		$sessionArray	= array();
		foreach($listingSession->getIterator() as $key => $value) {
			$sessionArray[]	= $key;
		}
		foreach($sessionArray as $key => $value) {
			$listingSession->offsetUnset($value);
		}
		
		if ($request->isPost()) {
			$roleFilterForm->setData($request->getPost());
			$formData	=  $request->getPost();
			if(isset($formData['search_role_name']) && !empty($formData['search_role_name']))
				$listingSession->role_name	= $formData['search_role_name'];
			else
				$listingSession->role_name	= '';
		}
		
		// Get the All roles
		$roleSession 			= new Container('allRoles');
		if($roleSession->offsetExists('rolesAll') && $roleSession->rolesAll != '' ) {
			$roleFilterOptions	= $roleSession->rolesAll;
		} else {
			$roleFilterOptions	= array(''  => 'Select Role Name');
			$roles				= $this->getTable('roleTable')->getAllRoles();
			if($roles) {
				foreach($roles as $role) {
					$roleFilterOptions[$role->role_name]	=  $role->role_name;
				}
			}
			$roleSession->rolesAll = $roleFilterOptions;
		}
		
		$roleFilterForm->get('search_role_name')->setValueOptions($roleFilterOptions);
		if($listingSession->offsetExists('role_name') && $listingSession->role_name != '' ) {
			$roleFilterForm->get('search_role_name')->setValue($listingSession->role_name);
		}
		
		// Get All User Count By Role
		$userCountByRole		= array();
		$userCountByRoleSession = new Container('allUserCountByRole');
		if($userCountByRoleSession->offsetExists('userCountByRoleAll') && $userCountByRoleSession->userCountByRoleAll != '' ) {
			$userCountByRole	= $userCountByRoleSession->userCountByRoleAll;
		} else {
			$results	 		= $this->getTable('usersTable')->getUserCountByRole();
			if($results) {
				$resultToArrays	= $results->toArray();
				foreach($resultToArrays as $result) {
					$userCountByRole[$result["user_role_id"]] = $result;
				}
			}
			$userCountByRoleSession->userCountByRoleAll	 	  =	$userCountByRole;
		}
		
		/*
		$return = array('success' => true);
	    $flashMessenger = $this->flashMessenger();
	    if ($flashMessenger->hasMessages()) {
	        $return['messages'] = $flashMessenger->getMessages();
	    }
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==return==><pre>"; print_r($return); echo "</pre><==";
		*/
		
		// Pagging
		$perPage				= $this->defaultPerPage;
		$message				= '';
		$iteratorAdapter		= new \Zend\Paginator\Adapter\Iterator($this->getTable('roleTable')->getRolesList());
		$paginator				= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		$activeArrray			= array('0' => 'Inactive', '1' => 'Active');
		$userCountsArray		= array();		//	Todo : Need to get the User Count values
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'roleFilterForm'	=> $roleFilterForm,
			'pc_users'			=> $this->pcUser,
			'message'		 	=> $message,
			'page'			 	=> $page,
			'sortBy'		 	=> $sortBy,
			'paginator'		 	=> $paginator,
			'perPage'		 	=> $perPage,
			'activeArrray'	 	=> $activeArrray,
			'userCountsArray'	=> $userCountsArray,
			'userCountByRole'	=> $userCountByRole,
			'perPageArray'		=> $this->perPageArray,
			'controller'	 	=> $this->params('controller')
		));
    }
	
	/*	Action	: 	Role list , Ajax action
	*	Detail	:	This Action is used to list the Role details via Ajax
	*/
	public function roleListAction()
    {
		$result 	= new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		//	Session for Role listing
		$listingSession = new Container('roleListing');
		$columnFlag		= 0;
		if($sortBy != '') {
			if($listingSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$listingSession->sortBy	= $sortBy;
		} else if($listingSession->offsetExists('sortBy')) {
			$sortBy	= $listingSession->sortBy;
		}
		if($sortType != '') {
			if($listingSession->sortType == $sortType && $columnFlag == 1)
				$listingSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$listingSession->sortType	= $sortType;
		} else if($listingSession->offsetExists('sortType')) {
			$sortType	= $listingSession->sortType;
		}
		//	Perpage
		if($perPage != '') {
			$listingSession->perPage	= $perPage;
		} else if($listingSession->offsetExists('perPage')) {
			$perPage		= $listingSession->perPage;
		} else {
			$perPage		= $this->defaultPerPage;
		}
		
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getTable('roleTable')->getRolesList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		
		// Get All User Count By Role
		$userCountByRole		= array();
		$userCountByRoleSession = new Container('allUserCountByRole');
		if($userCountByRoleSession->offsetExists('userCountByRoleAll') && $userCountByRoleSession->userCountByRoleAll != '' ) {
			$userCountByRole	= $userCountByRoleSession->userCountByRoleAll;
		}
		
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		$userCountsArray	= array();		//	Todo : Need to get the User Count values
		$result->setVariables(array(
				'message'		 	=> $message,
				'page'			 	=> $page,
				'sortBy'		 	=> $sortBy,
				'paginator'		 	=> $paginator,
				'perPage'		 	=> $perPage,
				'activeArrray'	 	=> $activeArrray,
				'userCountsArray'	=> $userCountsArray,
				'userCountByRole'	=> $userCountByRole,
				'perPageArray'		=> $this->perPageArray,
				'controller'	 	=> $this->params('controller')));
		return $result;
    }
	
	/*	Action	: 	View Role , Ajax action
	*	Detail	:	This Action is used to view the role details for perticular role
	*/
	public function viewRoleAction()
    {
		$result  	  =  new ViewModel();
	    $result->setTerminal(true);
		$auth 		  =  new AuthenticationService();
		
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		$role_id 	= (int) $this->params()->fromRoute('id', 0);
		$message 	= '';
		
		if ($role_id) {
			// Get All Priveleges list
			$aclresourceResults = array();
			$results				= $this->getTable('aclresourcesTable')->getAllAclResources();
			if($results) {
				$aclresourceDetails	= $results->toArray();
				foreach($aclresourceDetails as $key => $resource) {
					$aclresourceResults[$resource["parent_id"]][]	=	$resource;
				}
			}
			
			// Get priveleges for particular Role, Todo : Later it's should be a saved as cache.
			$rolePrivelegesResults 		= array();
			$rolePrivelegesResult		= $this->getTable('roleTypeTable')->getRolePrivileges($role_id);
			if($rolePrivelegesResult) {
				$rolePrivelegesDetails	= $rolePrivelegesResult->toArray();
				foreach($rolePrivelegesDetails as $key => $privelege) {
					$rolePrivelegesResults[$privelege["role_type_privileges_id"]] =	$privelege["resource_id"];
				}
			}
			
			$roles						=  $this->getTable('roleTable')->getRoles($role_id);
			$roleDetails				=  '';
			if($roles) {
				foreach($roles as $role) {
					$roleDetails		=  $role;
				}
			}
			$PrivilegesArray			=  array(1, 2, 3);
			
			$result->setVariables(array(
				'page' 				 	=> 1,
				'userObject'		 	=> $identity,
				'message'			 	=> $message,
				'PrivilegesArray'	 	=> $PrivilegesArray,
				'aclresourceResults' 	=> $aclresourceResults,
				'rolePrivelegesResults' => $rolePrivelegesResults,
				'pc_users'			 	=> $this->pcUser,
				'role_id'			 	=> $role_id,
				'roleDetails'			=> $roleDetails,
				'controller'	 		=> $this->params('controller')
		  ));
		} else {
			$message					=  'Invalid Role id';
			$result->setVariables(array(
				'page' 				 	=> 1,
				'userObject'		 	=> $identity,
				'message'			 	=> $message,
				'pc_users'			 	=> $this->pcUser,
				'role_id'			 	=> $role_id,
				'controller'	 		=> $this->params('controller')
		  ));
		}
		return $result;
    }
	
	/*	Action	: 	Edit Role
	*	Detail	:	Used to edit the Role details
	*/
	public function editRoleAction()
    {
		$auth 		  = new AuthenticationService();
		$request 	  =  $this->getRequest();
		$message	  =  '';
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$role_id = (int) $this->params()->fromRoute('id', 0);
        if ($role_id) {
			
			// Get All Priveleges list
			$aclresourceResults 	= array();
			$results				= $this->getTable('aclresourcesTable')->getAllAclResources();
			if($results) {
				$aclresourceDetails	= $results->toArray();
				foreach($aclresourceDetails as $key => $resource) {
					$aclresourceResults[$resource["parent_id"]][]	=	$resource;
				}
			}
			
			// Get Roles priveleges
			$rolePrivelegesResults 		= array();
			$rolePrivelegesResult		= $this->getTable('roleTypeTable')->getRolePrivileges($role_id);
			if($rolePrivelegesResult) {
				$rolePrivelegesDetails	= $rolePrivelegesResult->toArray();
				foreach($rolePrivelegesDetails as $key => $privelege) {
					$rolePrivelegesResults[$privelege["role_type_privileges_id"]] =	$privelege["resource_id"];
				}
			}
			
			$addUserRoleForm 		=  new AddRoleForm();
		 	
			if ($request->isPost()) {
	            $roleModel			=  new Role();
	            $addUserRoleForm->setInputFilter($roleModel->getInputFilterForAddUserRole());
	            $addUserRoleForm->setData($request->getPost());
				$getPost			=  $request->getPost();
				$rolePrivileges		=  $getPost["privileges"];
				
				//	Get Adapter
				$sm 				=  $this->getServiceLocator();
	            $this->dbAdapter 	=  $sm->get('db-adapter');
				
	            if ($addUserRoleForm->isValid()) {
					$formData 	 	= $addUserRoleForm->getData();
					$excludeClause	= " role_id != '".addslashes($getPost['pc_role_id'])."' AND role_isdelete = 0";
					//	Check that the email address exists in the database
					$validator = new RecordExists(
					    array(
					        'table' 	=> 'role',
					        'field' 	=> 'role_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Role Name already exist.',
							'exclude' 	=> $excludeClause,
					    )
					);
					
					if ($validator->isValid($formData['pc_role_name'])) {
						$errorMessages	= $validator->getMessages();
						$message		= 'Role Name already exist.';
						$errorMessage	= '1';
						
					} else {
						
						$roleArray					= array();
						$datetime					= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate				= $datetime(time(), 0, 'Y-m-d H:i:s');
						
						$roleArray['role_created']	= $createdDate;
						$roleArray['role_updated']	= $createdDate;
						$roleArray['role_status']	= 1;
						$roleArray['role_id']		= $getPost['pc_role_id'];
						$roleArray['role_name']		= $formData['pc_role_name'];
						$roleId  					=  $getPost['pc_role_id'];
						
						$newPrivileges				=  array_diff($rolePrivileges, $rolePrivelegesResults);
						$deletePrivileges			=  array_diff($rolePrivelegesResults, $rolePrivileges);
						
						$roleModel->exchangeArray($roleArray);
						$this->getTable("roleTable")->saveRole($roleModel);																					//	Update the Role
						
						if(isset($deletePrivileges) && is_array($deletePrivileges) && count($deletePrivileges)) {
							$deletePrivilegesStatus =  $this->getTable("roleTypeTable")->deleteRolePrivileges($roleId, $deletePrivileges);				//	Delete the Role privileges
						}
						if(isset($newPrivileges) && is_array($newPrivileges) && count($newPrivileges)) {
							$rolePrivilegesStatus  	=  $this->getTable("roleTypeTable")->saveRolePrivileges($roleId, $newPrivileges);					//	Insert the Role privileges
						}
						$message	= 'Role Updated successfully.';
//						$this->flashMessenger()->addMessage($message);
						$status	 		= $this->getCommonDataObj()->destroySessionVariables(array('allMenuTabLinks'));
						return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
					}
				} else {
					$errorMessages	= $addUserRoleForm->getMessages();
				}
	        } else {
					$message		= 'Role Name already exist.';
			}
			
			$addUserRoleForm->get('pc_role_id')->setValue($role_id);
			$roles					=  $this->getTable('roleTable')->getRoles($role_id);
			if($roles) {
				foreach($roles as $role) {
					$roleDetails	=  $role;
				}
			}
			$roleName				=  $roleDetails->role_name;
			$addUserRoleForm->get('pc_role_name')->setValue($roleName);
			$PrivilegesArray		=	array(1, 2, 3);
			
			return new ViewModel(array(
				'page' 				 	=> 1,
				'userObject'		 	=> $identity,
				'addUserRoleForm'	 	=> $addUserRoleForm,
				'message'			 	=> $message,
				'PrivilegesArray'	 	=> $PrivilegesArray,
				'aclresourceResults' 	=> $aclresourceResults,
				'rolePrivelegesResults' => $rolePrivelegesResults,
				'pc_users'			 	=> $this->pcUser,
				'role_id'			 	=> $role_id,
			));
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
		}
	}
	
	/*	Action	: 	Add Role
	*	Detail	:	Used to Add a Role
	*/
	public function addRoleAction()
    {
		$auth 		  =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity =  $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$results	  =  $this->getTable('aclresourcesTable')->getAllAclResources();
		if($results) {
			$aclresourceDetails	= $results->toArray();
			$aclresourceResults = array();
			foreach($aclresourceDetails as $key => $resource) {
				$aclresourceResults[$resource["parent_id"]][]	=	$resource;
			}
		}
		
		$addUserRoleForm 		=  new AddRoleForm();
	 	$request 				=  $this->getRequest();
		$message				=  '';
		
		if ($request->isPost()) {
            $roleModel			=  new Role();
            $addUserRoleForm->setInputFilter($roleModel->getInputFilterForAddUserRole());
            $addUserRoleForm->setData($request->getPost());
			$getPost			=  $request->getPost();
			$rolePrivileges		=  $getPost["privileges"];
			
			//	Get Adapter
			$sm 				=  $this->getServiceLocator();
            $this->dbAdapter 	=  $sm->get('db-adapter');
			
            if ($addUserRoleForm->isValid()) {
				$formData 	 	= $addUserRoleForm->getData();
				$excludeClause	= " role_isdelete = 0";
				//	Check that the email address exists in the database
				$validator = new RecordExists(
				    array(
				        'table' 	=> 'role',
				        'field' 	=> 'role_name',
						'adapter'	=> $this->dbAdapter,
						'message'	=> 'Role Name already exist.',
						'exclude'	=> $excludeClause
				    )
				);
				
				if ($validator->isValid($formData['pc_role_name'])) {
					$errorMessages	= $validator->getMessages();
					$message		= 'Role Name already exist.';
					$errorMessage	= '1';
				} else {
					$roleArray					= array();
					$datetime					= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
					$createdDate				= $datetime(time(), 0, 'Y-m-d H:i:s');
					
					$roleArray['role_created']	= $createdDate;
					$roleArray['role_updated']	= $createdDate;
					$roleArray['role_status']	= 1;
					$roleArray['role_isdelete']	= 0;
					$roleArray['role_name']		= $formData['pc_role_name'];
					
					$roleModel->exchangeArray($roleArray);
					$roleId  					=  $this->getTable("roleTable")->saveRole($roleModel);											//	Insert the Role
					$rolePrivilegesStatus  		=  $this->getTable("roleTypeTable")->saveRolePrivileges($roleId, $rolePrivileges);				//	Insert the Role privileges
					
					$message	= 'Role added successfully.';
					$status	 	=  $this->getCommonDataObj()->destroySessionVariables(array('allRoles', 'allRole', 'allMenuTabLinks'));
					return $this->redirect()->toRoute('usermanagement', array('controller' => 'role', 'action' => 'role-listing'));
				}
			} else {
				$errorMessages	= $addUserRoleForm->getMessages();
			}
        } else {
				$message		= 'Role Name already exist.';
		}
		
		$PrivilegesArray	=	array(1, 2, 3);
		
		return new ViewModel(array(
			'page' 				 => 1,
			'userObject'		 => $identity,
			'addUserRoleForm'	 => $addUserRoleForm,
			'message'			 => $message,
			'PrivilegesArray'	 => $PrivilegesArray,
			'aclresourceResults' => $aclresourceResults,
			'pc_users'			 => $this->pcUser,
		));
    }
	
	/*	Action	: 	Ajax Add Role
	*	Detail	:	Used to Validate the Role name already exist or Available, via Ajax
	*	TODO	:	Mail sending is inprocess
	*/
	public function ajaxAddRoleAction()
	{
		$addUserRoleForm 	 = new AddRoleForm();
	 	$request 			 = $this->getRequest();
		$message			 = '';
		if($request->isPost()) {
            $roleModel		 = new Role();
            $addUserRoleForm->setInputFilter($roleModel->getInputFilterForAddUserRole());
            $addUserRoleForm->setData($request->getPost());
			$postDatas		 =  $request->getPost();
			
			//	Get Adapter
			$sm 			 =  $this->getServiceLocator();
            $this->dbAdapter =  $sm->get('db-adapter');
			
			// RETURN VALUE
			$arrayToJs 	  	 = array();
			$arrayToJs[0] 	 = array();
			$arrayToJs[0][0] = 'pc_role_name';
			
            if ($addUserRoleForm->isValid()) {
				$formData 	 = $addUserRoleForm->getData();
                // Todo : User Role insertion process
            	
				//Check that the email address exists in the database
				if(isset($postDatas['pc_role_id']) && !empty($postDatas['pc_role_id'])) {
					$excludeClause  = " role_id != '".addslashes($postDatas['pc_role_id'])."' AND role_isdelete = 0";
					$validator 		= new RecordExists(
					    array(
					        'table' 	=> 'role',
					        'field' 	=> 'role_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Role Name already exist.',
							'exclude'   => $excludeClause
					    )
					);
				} else {
					$excludeClause  = " role_isdelete = 0";
					$validator 		= new RecordExists(
					    array(
					        'table' 	=> 'role',
					        'field' 	=> 'role_name',
							'adapter'	=> $this->dbAdapter,
							'message'	=> 'Role Name already exist.',
							'exclude'   => $excludeClause
					    )
					);
				}
				
				if ($validator->isValid($formData['pc_role_name'])) {
					//	Send error message.
					$arrayToJs[0][1] = false;
					$arrayToJs[0][2] = "Role Name already exist";
				} else {
					$arrayToJs[0][1] = true;
					//$arrayToJs[0][2] = "Role Name validation success";
				}
			} else {
					$arrayToJs[0][1] = false;
					$arrayToJs[0][2] = "Role Name already exist";
			}
			echo json_encode($arrayToJs);
		}
		return $this->getResponse();
	}
	
	/*	Action	: 	Delete Role
	*	Detail	:	Used to delete the selected role
	*/
	public function deleteRoleAction()
    {
		$role_id = (int) $this->params()->fromRoute('id', 0);
        if ($role_id) {
			$this->getTable("roleTable")->deleteRole($role_id);
			$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('allRoles', 'allRole', 'allMenuTabLinks'));
		}
        return $this->getResponse();
    }
	
	public function testAction()
	{
		echo '<br>==>'.__LINE__.'==>'.__FILE__.'==>';
		$auth = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
			echo '<pre>'; print_r($identity); echo '</pre>';
		} else {
			return $this->redirect()->toRoute('usermanagement', array('action' => 'index'));
		}
		return $this->getResponse();
	}
}
/*
	http://unofficial-zf2.readthedocs.org/en/test/modules/zend.validator.db.html
*/