<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller\Plugin;
 
use Zend\Mvc\Controller\Plugin\AbstractPlugin,
    Zend\Session\Container as SessionContainer;

class MyFileUpload extends AbstractPlugin
{
	public $fileTypes;
	public $fileSizes;
	public $uploadPath;
	
	public function checkUploadFiles($fileNameArray) {
		$fileTransfer 	= new \Zend\File\Transfer\Adapter\Http();
		$fileInfo 	  	= $fileTransfer->getFileInfo();
		$errorMessages	= '';
		$fileTransfer->addValidator('Extension', false, $this->fileTypes);
		$fileTransfer->addValidator('Size', false, $this->fileSizes);
		
		//$fileTransfer->setDestination($this->uploadPath);
		
		// check image validation 
		foreach ($fileInfo as $file => $info) {
			if ($fileInfo[$file]['name']) {
				if( in_array($file, $fileNameArray)) {
					if(!$fileTransfer->isValid($file)) {
						foreach ($fileTransfer->getMessages() as $key =>$message) {
							$errorMessages[$key] = $key;
						}
					}
				}
			}
		}
		return $errorMessages;
	}
	
	public function uploadFiles($userId, $fileNameArray) {
		$fileTransfer 	= new \Zend\File\Transfer\Adapter\Http();
		$fileInfo 	  	= $fileTransfer->getFileInfo();
		$errorMessages	= '';
		$extensionArray	= array('pjpeg','jpeg','jpg','gif','png','bmp');
		//$fileTransfer->addValidator('Extension', false, $this->fileTypes);
		//$fileTransfer->addValidator('Size', false, $this->fileSizes);
		
		//$fileTransfer->setDestination($this->uploadPath);
		$uploadPath		=	$this->uploadPath;
		//die ("<br/>==Line==".__LINE__."==File==".__FILE__."====>");
		foreach ($fileInfo as $file => $info) {
			if ($fileInfo[$file]['name'] !='' && in_array($file, $fileNameArray)) {
				$mminsertArr			= array();
				$mminsertArr['name']	= $fileInfo[$file]['name'];
				$extension				= $this->stripExtension($mminsertArr['name']);
				$mminsertArr['type']	= $this->getImageType(strtolower($extension));
				if(isset($extension) && in_array(strtolower($extension),$extensionArray))
				{
					$originalFileName		= 'Org_'.$userId.'.'.strtolower($extension);
				}
				else
				{
					$originalFileName		= $userId.'.'.strtolower($extension);
				}
				$uploadFileName			= $userId.'.'.strtolower($extension);
				$path 					= $uploadPath.'/'.$originalFileName;
				$newPath				= $uploadPath.'/'.$uploadFileName;
//				return $uploadFileName;
				
				$this->makeDirectory($path);
				move_uploaded_file($fileInfo[$file]['tmp_name'], $path);   /// copy image
				if(in_array(strtolower($extension),$extensionArray))
				{
					$this->resizePicture($path, $newPath, 150, 150);
				}
				return $uploadFileName;
			}
		}
	}
	
	public function uploadMultipleFiles($userId, $fileNameArray, $fileName) {
		$fileTransfer 	= new \Zend\File\Transfer\Adapter\Http();
		$fileInfo 	  	= $fileTransfer->getFileInfo();
		$errorMessages	= '';
		$extensionArray	= array('pjpeg','jpeg','jpg','gif','png','bmp');
		$uploadPath		=	$this->uploadPath;
		foreach ($fileInfo as $file => $info) {
			if ($fileInfo[$file]['name'] == $fileName['name']) {
				$mminsertArr			= array();
				$mminsertArr['name']	= $fileInfo[$file]['name'];
				$extension				= $this->stripExtension($mminsertArr['name']);
				$mminsertArr['type']	= $this->getImageType(strtolower($extension));
				if(isset($extension) && in_array(strtolower($extension),$extensionArray))
				{
					$originalFileName		= 'Org_'.$userId.'.'.strtolower($extension);
				}
				else
				{
					$originalFileName		= $userId.'.'.strtolower($extension);
				}
				$uploadFileName			= $userId.'.'.strtolower($extension);
				$path 					= $uploadPath.'/'.$originalFileName;
				$newPath				= $uploadPath.'/'.$uploadFileName;
//				return $uploadFileName;
				
				$this->makeDirectory($path);
				move_uploaded_file($fileInfo[$file]['tmp_name'], $path);   /// copy image
				if(in_array(strtolower($extension),$extensionArray))
				{
					$this->resizePicture($path, $newPath, 150, 150);
				}
				return $uploadFileName;
			}
		}
	}
	
	public function unlinkFile($fileAbsolutePath) {
		if(isset($fileAbsolutePath) && $fileAbsolutePath != '')
		{
			$fileExplodeArray 		= array();
			$imageTypeArray			= array();
			$orgImageReplace 		= '';
			$endSlash 				= '';
			$fileExplodeArray		= explode('/',$fileAbsolutePath);
			$extensionArray			= array('pjpeg','jpeg','jpg','gif','png','bmp');
			if(is_array($fileExplodeArray) && count($fileExplodeArray) > 0)
			{
				$endSlash			= array_pop($fileExplodeArray);
				//Original Image replace
				$imageTypeArray		= explode(".",$endSlash);
				if(is_array($imageTypeArray) && count($imageTypeArray) > 0)
				{
					if(isset($imageTypeArray[1]) && in_array(strtolower($imageTypeArray[1]),$imageTypeArray))
					{
						$orgImageReplace	= str_replace($endSlash,"Org_".$endSlash,$fileAbsolutePath);
						if(file_exists($orgImageReplace))
						{
							unlink($orgImageReplace);
						}
					}
				}
			}
		}
		if(file_exists($fileAbsolutePath) )
			unlink($fileAbsolutePath);
	}
	
	// get image extension for given url
	public function  stripExtension($filename  = '') {
	    if (!empty($filename)) {
		    $filename 	= strtolower($filename);
	        $extArray 	= explode(".", $filename);
	        $p 			= count($extArray)-1;
	        $extension 	= $extArray[$p];
	        return $extension;
	    } else {
	        return false;
	    }
	}
	
	/**
	 * gets image type
	 * 
	 * @param string ext of the image
	 * @return the int type, if exist
	 */
	 public function getImageType($extension)
	 {
		$type = '';
		if (($extension == 'pjpeg') or ($extension == 'jpeg'))
			$extension = 'jpg';
		if ($extension == 'jpg')
			$type = 'jpg';
		if ($extension == 'gif')
			$type = 'gif';
		if ($extension == 'png')
			$type = 'png';
		if ($extension == 'bmp')
			$type = 'bmp';
		return $type;
	 }
	 
	/**
	 * gets file type
	 * 
	 * @param string ext of the image
	 * @return the int type, if exist
	 */
	 public function getFileType($extension)
	 { 	// 'doc', 'docx', 'rtf', 'txt', 'pdf'
		$type  =  '';
		if (($extension == 'doc') or ($extension == 'docx'))
			$extension = 'doc';
		if ($extension == 'doc')
			$type = 'doc';
		else if ($extension == 'rtf')
			$type = 'rtf';
		else if ($extension == 'txt')
			$type = 'txt';
		else if ($extension == 'pdf')
			$type = 'pdf';
		return $type;
	 }
	 
	 /**
	 * make directory
	 * 
	 * @param string path
	 * @param int optional for write permission
	 */
	 public function makeDirectory($path , $rights = 0777) 
	 {
		$folder_path = array(strstr($path, '.') ? dirname($path) : $path);
		while(!@is_dir(dirname(end($folder_path)))
	         && dirname(end($folder_path)) != '/'
	         && dirname(end($folder_path)) != '.'
	         && dirname(end($folder_path)) != '')
	   		array_push($folder_path, dirname(end($folder_path)));
		while($parent_folder_path = array_pop($folder_path)) {
			clearstatcache();
			if(!is_dir($parent_folder_path))
				@mkdir($parent_folder_path);
			@chmod($parent_folder_path, 0777);
		}
	 }
	 
	/**
	 * make permission
	 * 
	 * @param string path
	 * @param int optional for write permission
	 */
	public function makePermission($path , $rights = 0777)
	{	if(is_dir($path)) {
	 		$permission   	=  substr(sprintf('%o', fileperms($path)), -4);
			if($permission != $rights) {
			   @chmod($path, $rights);
			}
		}
	}
	
	/*
		*Image Resize and compress
	*/
	public function resizePicture($path, $new_path, $new_width, $new_height, $proportion = false)
	{
    	$size = getimagesize($path);
   		$x = 0;
    	$y = 0;
	    switch($size['mime'])
		{
	        case 'image/jpeg':
	            $picture = imagecreatefromjpeg($path);
	        break;
	        case 'image/png':
	            $picture = imagecreatefrompng($path);
	        break;
	        case 'image/gif':
	            $picture = imagecreatefromgif($path);
	        break;
	        default:
	            return false;
	        break;
	    }
	    $width = $size[0];
	    $height = $size[1];
	    $frame = imagecreatetruecolor($new_width, $new_height);
	    if($size['mime'] == 'image/jpeg')
		{
	        $bg = imagecolorallocate($frame, 255, 255, 255);
	        imagefill($frame, 0, 0, $bg);
	    }
		else if($size['mime'] == 'image/gif' or $size['mime'] == 'image/png')
		{
	        $bg = imagecolorallocate($frame, 255, 255, 255);
	        imagefill($frame, 0, 0, $bg);
			imagealphablending($picture, false);
	        imagesavealpha($picture, true);
	        imagealphablending($frame, false);
	        imagesavealpha($frame, true);
	    }
	    if($width < $new_width and $height < $new_height)
		{
	        $x = ($new_width - $width) / 2;
	        $y = ($new_height - $height) / 2;
	        imagecopy($frame, $picture, $x, $y, 0, 0, $width, $height);
	    }
		else
		{
	        if($proportion and $width != $height)
			{
	            if($width > $height)
				{
	                $old_height = $new_height;
	                $new_height = $height * $new_width / $width;
	                $y = abs($old_height - $new_height) / 2;
	            }
				else
				{
	                $old_width = $new_width;
	                $new_width = $width * $new_height / $height;
	                $x = abs($old_width - $new_width) / 2;
	            }
	        }
	        imagecopyresampled($frame, $picture, $x, $y, 0, 0, $new_width, $new_height, $width, $height);
	    }
	    switch($size['mime'])
		{
	        case 'image/jpeg':
	            imagejpeg($frame, $new_path, 85);
	        break;
	        case 'image/png':
	            imagepng($frame, $new_path, 8);
	        break;
	        case 'image/gif':
	            imagegif($frame, $new_path);
	        break;
	        default:
	            return false;
	        break;
	    }
	}
}