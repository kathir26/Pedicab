<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller\Plugin;
 
use Zend\Mvc\Controller\Plugin\AbstractPlugin,
    Zend\Session\Container as SessionContainer,
    Zend\Permissions\Acl\Acl,
    Zend\Permissions\Acl\Role\GenericRole as Role,
    Zend\Permissions\Acl\Resource\GenericResource as Resource;
    
class Myplugin extends AbstractPlugin
{
    protected $sesscontainer ;
	protected $loaded ;
	protected $acl ;
	
    private function getSessContainer()
    {
        if (!$this->sesscontainer) {
            $this->sesscontainer = new SessionContainer('zftutorial');
        }
        return $this->sesscontainer;
    }
    
    public function doAuthorization($e)
    {
		//setting ACL...
        $acl = new Acl();
        //add role ..
        $acl->addRole(new Role('anonymous'));
        $acl->addRole(new Role('user'),  'anonymous');
        $acl->addRole(new Role('admin'), 'user');
        
        $acl->addResource(new Resource('Index'));
		$acl->addResource(new Resource('Application'));
        //$acl->addResource(new Resource('Login'));
        
        //$acl->deny('anonymous', 'Login', 'view');
        $acl->allow('anonymous', 'Index', array('index', 'dashboard', 'logout'));		//	User type, Controller name, Action name.
        
        $acl->allow('user',
            array('Index'),
            array('view')
        );
        
        //admin is child of user, can publish, edit, and view too !
        $acl->allow('admin',
            array('Index'),
            array('publish', 'edit')
        );
		$actions		 =	$e->getRouteMatch()->getParam('action', 'index');
		$controller	 	 =	$e->getRouteMatch()->getParam('controller', 'index');
		$controllerArray =  explode("\\", $controller);
		$modules	 	 =	current($controllerArray);
		$namespace	 	 =	end($controllerArray);
		/*
        $controller 	 = $e->getTarget();
        $controllerClass = get_class($controller);
        $namespace 		 = substr($controllerClass, 0, strpos($controllerClass, '\\'));
		*/
        $role = (! $this->getSessContainer()->role ) ? 'anonymous' : $this->getSessContainer()->role;
        if ( ! $acl->isAllowed($role, $namespace, $actions)){
            $router = $e->getRouter();
            $url    = $router->assemble(array(), array('name' => 'usermanagement'));
        	
            $response = $e->getResponse();
            $response->setStatusCode(302);
            //redirect to login route...
            /* change with header('location: '.$url); if code below not working */
            $response->getHeaders()->addHeaderLine('Location', $url);
            $e->stopPropagation();
        }
    }
}
