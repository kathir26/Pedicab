<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller\Plugin;
 
use Zend\Mvc\Controller\Plugin\AbstractPlugin,
    Zend\Session\Container as SessionContainer,
    Zend\Permissions\Acl\Acl,
    Zend\Permissions\Acl\Role\GenericRole as Role,
    Zend\Permissions\Acl\Resource\GenericResource as Resource;
    
use Usermanagement\Model\AclresourcesTable;
	
class Myplugin extends AbstractPlugin
{
    protected $sesscontainer;
	protected $loaded;
	protected $acl;
	protected $table;
	
    private function getSessContainer()
    {
        if (!$this->sesscontainer) {
            $this->sesscontainer = new SessionContainer('zftutorial');
        }
        return $this->sesscontainer;
    }
	public function initAclConfigs($e)
    {
		if (!$this->loaded) {
			if (!$this->acl) {
				$this->acl = new Acl();
			}
			//add role ..
	        $this->acl->addRole(new Role('anonymous'));
	        $this->acl->addRole(new Role('user'),  'anonymous');
	        $this->acl->addRole(new Role('admin'), 'user');
	        
	        $this->acl->addResource(new Resource('Index'));
	        //$this->acl->addResource(new Resource('Login'));
	        
	        //$this->acl->deny('anonymous', 'Login', 'view');
	        $this->acl->allow('anonymous', 'Index', array('index', 'logout'));		//	User type, Controller name, Action name.
			$this->acl->allow('anonymous', 'Role', array('role-listing'));			//	User type, Controller name, Action name.
	        
	        $this->acl->allow('user',array('Index'), array('view'));
	        
	        //admin is child of user, can publish, edit, and view too !
	        $this->acl->allow('admin', array('Index'), array('publish', 'edit'));
			$this->loaded = true;
		}
	}
    
    public function doAuthorization($e)
    {
		return true;	//	testing process
		
		if (!$this->loaded) {
			$this->initAclConfigs($e);
		}
		$application    = $e->getApplication();
		$sm             = $application->getServiceManager();
        $this->table	= $sm->get('Aclresources-Table');
		$details		= $this->table->getAllAclResources();
		/*
		foreach($details as $key => $detail) {
			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==resource_id==>".$detail["resource_id"];
			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==detail==><pre>"; print_r($detail); echo "</pre><==";
		}
		*/
		
		/*
		//setting ACL...
        $acl = new Acl();
        //add role ..
        $acl->addRole(new Role('anonymous'));
        $acl->addRole(new Role('user'),  'anonymous');
        $acl->addRole(new Role('admin'), 'user');
        
        $acl->addResource(new Resource('Index'));
        //$acl->addResource(new Resource('Login'));
        
        //$acl->deny('anonymous', 'Login', 'view');
        $acl->allow('anonymous', 'Index', array('role', 'role-listing', 'logout'));		//	User type, Controller name, Action name.
        
        $acl->allow('user',
            array('Index'),
            array('view')
        );
        
        //admin is child of user, can publish, edit, and view too !
        $acl->allow('admin',
            array('Index'),
            array('publish', 'edit')
        );
		*/
		$actions		 =	$e->getRouteMatch()->getParam('action', 'index');
		$controller	 	 =	$e->getRouteMatch()->getParam('controller', 'index');
		$controllerArray =  explode("\\", $controller);
		$modules	 	 =	current($controllerArray);
		$namespace	 	 =	end($controllerArray);
		/*
        $controller 	 = $e->getTarget();
        $controllerClass = get_class($controller);
        $namespace 		 = substr($controllerClass, 0, strpos($controllerClass, '\\'));
		*/
        $role = (! $this->getSessContainer()->role ) ? 'anonymous' : $this->getSessContainer()->role;
        if ( ! $this->acl->isAllowed($role, $namespace, $actions)){
            $router = $e->getRouter();
            $url    = $router->assemble(array(), array('name' => 'usermanagement'));
        	
            $response = $e->getResponse();
            $response->setStatusCode(302);
            //redirect to login route...
            /* change with header('location: '.$url); if code below not working */
            $response->getHeaders()->addHeaderLine('Location', $url);
            $e->stopPropagation();
        }
    }
}
