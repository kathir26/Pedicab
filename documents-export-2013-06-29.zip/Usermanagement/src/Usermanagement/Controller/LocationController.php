<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Usermanagement\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;

//	Session
use Zend\Session\Container;
use Zend\Validator\Db\RecordExists;

// Cookie
use Zend\Http\Header\SetCookie;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

//	Forms
use Usermanagement\Form\AddLocationForm,
	Usermanagement\Form\LocationFilterForm;

//	Models
use Usermanagement\Model\Location;
use Usermanagement\Model\Aclresources;
use Usermanagement\Model\MyAuthenticationAdapter;

class LocationController extends AbstractActionController
{
	protected $defaultPerPage;
	protected $commonData;
	protected $perPageArray;
	
	public function __construct()
    {
		$this->defaultPerPage 		=  10;
		$this->perPageArray			=  array('5', '10', '25', '50', '100');		//	array('10', '20', '30', '40', '50');
		//	Session for user_role_id
		$userSession 		= new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$this->pcUser	= $userSession->pc_users;
		} else {
			$this->pcUser	= '';
		}
    }
	
	private function getCommonDataObj()
    {
		//	Get common data
		if (!isset($this->commonData)) {
            $sm 		 	 	=  $this->getServiceLocator();
            $this->commonData 	=  $sm->get('viewhelpermanager')->get('commonData');
			$this->commonData->set($sm);
			$this->renderer 	=  $this->getServiceLocator()->get('ViewRenderer');
			$this->commonData->renderer($this->renderer);
        }
        return $this->commonData;
    }
	
	public function manageLocationAction()
    {
		$auth 	 =  new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		// assign default
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		
		// Create Filter form
		$locationFilterForm 	=  new LocationFilterForm();
		$request 				=  $this->getRequest();
		//	Destroy listing Session Vars
		$locationSession 		= new Container('locationListing');
		$sessionArray			= array();
		foreach($locationSession->getIterator() as $key => $value) {
			$sessionArray[]		= $key;
		}
		foreach($sessionArray as $key => $value) {
			$locationSession->offsetUnset($value);
		}
		
		if ($request->isPost()) {
			$locationFilterForm->setData($request->getPost());
			$formData			=  $request->getPost();
			if(isset($formData['loc_title_sch']) && !empty($formData['loc_title_sch']))
				$locationSession->loc_title	= $formData['loc_title_sch'];
			else
				$locationSession->loc_title	= '';
		}
		/*$locationFilterForm->get('loc_title_sch')->setValueOptions($locationSession->loc_title);
		if($locationSession->offsetExists('loc_title') && !empty($locationSession->loc_title)) {
			$locationFilterForm->get('loc_title_sch')->setValue($locationSession->loc_title);
		}*/
		$no_of_driver = $no_of_bikes = '';
		$bike_count_array = $driver_count_array = array();
		$no_of_bikes		= $this->getLocationTable()->getBikeCount();
		if(is_object($no_of_bikes) && count($no_of_bikes) > 0)
		{
			foreach($no_of_bikes as $bike_key => $bike_value)
			{
				$bike_count_array[$bike_value['fk_location_id']]	= $bike_value['bike_count'];
			}
		}
		$no_of_driver		= $this->getLocationTable()->getDriverCount();
		if(is_object($no_of_driver) && count($no_of_driver) > 0)
		{
			foreach($no_of_driver as $driver_key => $driver_value)
			{
				$driver_count_array[$driver_value['location_id']]	= $driver_value['driver_count'];
			}
		}
		$perPage			= $this->defaultPerPage;
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getLocationTable()->getAllLocationList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'locationFilterForm'=> $locationFilterForm,
			'pc_users'			=> $this->pcUser,
			'message'		 	=> $message,
			'page'			 	=> $page,
			'sortBy'		 	=> $sortBy,
			'paginator'		 	=> $paginator,
			'perPage'		 	=> $perPage,
			'perPageArray'		=> $this->perPageArray,
			'activeArrray'	 	=> $activeArrray,
			'bike_count_array'	=> $bike_count_array,
			'driver_count_array'=> $driver_count_array,
			'controller'	 	=> $this->params('controller')
		));
    }
	public function addLocationAction()
    {
		$auth 	 		=  new AuthenticationService();
		$locationForm	=  new AddLocationForm();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		
		return new ViewModel(array(
			'userObject'		=> $identity,
			'locationForm'		=> $locationForm,
			'pc_users'			=> $this->pcUser,
		));
    }
	public function ajaxAddLocationAction()
    {
		$auth 		  = new AuthenticationService();
		if ($auth->hasIdentity()) {
		    $identity = $auth->getIdentity();
		} else {
			return $this->redirect()->toRoute('usermanagement', array('controller' => 'index', 'action' => 'index'));
		}
		$locationForm			=  new AddLocationForm();
		//$addUserRoleForm 		=  new AddUserRoleForm();
	 	$request 				=  $this->getRequest();
		$message = $location_array = $chk_loct_details = '';
		$json_array = array();
		if ($request->isPost()) {
            $locationModel			=  new Location();
            $locationForm->setInputFilter($locationModel->getInputFilterForAddLocation());
            $locationForm->setData($request->getPost());
			$getPost			=  $request->getPost();
			$rolePrivileges		=  $getPost["privileges"];
			//	Get Adapter
			$sm 				=  $this->getServiceLocator();
            $this->dbAdapter 	=  $sm->get('db-adapter');
            if ($locationForm->isValid())
			{
				$formData 	 = $locationForm->getData();
				$chk_loct_details	= $this->getLocationTable()->checkLocationDetails($formData);
				if(is_object($chk_loct_details) && count($chk_loct_details) > 0)
				{
					$json_array['loc_title']	= false;
					$json_array['err_msg']		= 1;
				}
				else
				{
					$json_array['err_msg']		= 0;
					$json_array['loc_title']	= true;
					$loc_date = $ses_ope_date = $ses_clos_date = '';
					$location_array							= array();
					$location_array['loc_title']			= $formData['loc_title'];
					$location_array['loc_address']			= $formData['loc_address'];
					if(isset($formData['loc_same_addr']) && $formData['loc_same_addr'] == 1)
					{
						$location_array['loc_mail_address']	= $formData['loc_address'];
						$location_array['loc_same_addr']	= $formData['loc_same_addr'];
					}
					else
					{
						$location_array['loc_mail_address']	= $formData['loc_mail_address'];
						$location_array['loc_same_addr']	= $formData['loc_same_addr'];
					}
					$location_array['loc_postal_code']		= $formData['loc_postal_code'];
					if(isset($formData['loc_launch_date']) && $formData['loc_launch_date'] != '')
					{
						$location_date						= explode('-',$formData['loc_launch_date']);
						if(is_array($location_date) && count($location_date) > 0)
						{
							$loc_date						= $location_date[2]."-".$location_date[0]."-".$location_date[1];
						}
					}
					if(isset($formData['loc_ses_open_date']) && $formData['loc_ses_open_date'] != '')
					{
						$sess_open_date						= explode('-',$formData['loc_ses_open_date']);
						if(is_array($sess_open_date) && count($sess_open_date) > 0)
						{
							$ses_ope_date					= $sess_open_date[2]."-".$sess_open_date[0]."-".$sess_open_date[1];
						}
					}
					if(isset($formData['loc_ses_close_date']) && $formData['loc_ses_close_date'] != '')
					{
						$sess_close_date					= explode('-',$formData['loc_ses_close_date']);
						if(is_array($sess_close_date) && count($sess_close_date) > 0)
						{
							$ses_clos_date					= $sess_close_date[2]."-".$sess_close_date[0]."-".$sess_close_date[1];
						}
					}
					$location_array['loc_date_launch']		= $loc_date;
					$location_array['loc_seas_open_date']	= $ses_ope_date;
					$location_array['loc_seas_close_date']	= $ses_clos_date;
					$location_array['loc_status']			= $formData['loc_status'];
					$location_array['loc_isdelete']			= 0;
					if(isset($formData['loc_id']) && $formData['loc_id'] != '')
					{
						$location_array['loc_id']			= $formData['loc_id'];
						$locationModel->exchangeArray($location_array);
						$this->getLocationTable()->updateLocation($locationModel);
					}
					else
					{
						$datetime								= $this->getServiceLocator()->get('viewhelpermanager')->get('datetime');
						$createdDate							= $datetime(time(), 0, 'Y-m-d H:i:s');
						$location_array['loc_creation_date']	= $createdDate;
						$locationModel->exchangeArray($location_array);
						$lastInsertId							= $this->getLocationTable()->insertLocation($locationModel);
						$alertDetails							= $insertAlertArray = array();
						$insertAlertArrayString					= '';
						$alertDetails  							= $this->getLocationTable()->getAlertDetails(1);
						if(is_object($alertDetails) && count($alertDetails) > 0)
						{
							foreach($alertDetails as $alertKey => $alertValue)
							{
								$insertAlertArray[]				= "'".addslashes($alertValue['alert_title'])."', '".addslashes($alertValue['alert_type'])."', '".addslashes($alertValue['alert_days'])."', '".addslashes($alertValue['alert_desc'])."','".addslashes($lastInsertId)."',now()";
							}
							if(is_array($insertAlertArray) && count($insertAlertArray) > 0)
							{
								$insertAlertArrayString			= "(".implode("),(",$insertAlertArray).")";
								if(isset($insertAlertArrayString) && $insertAlertArrayString != '')
								{
									$this->getLocationTable()->insertLocationAlert($insertAlertArrayString);
								}
							}
						}
						if(isset($identity->user_role_id) && $identity->user_role_id == 5)
						{
							$allLocationDetails					= $this->getLocationTable()->getAllLocationDetails();
							$allLocationDetailSession			= new Container('allLocationDetailsSession');
							foreach($allLocationDetails as $locKey => $locValue)
							{
								$allLocationDetailSession[$locValue->loc_id] = (array)$locValue;	//	$locValue->loc_title
							}
						}
					}
					//$flashMessenger 						= $this->_helper->FlashMessenger;
					//$flashMessenger->addMessage('Location added successfully');
					$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('allLocations'));
					$json_array['redirect']					= '/usermanagement/location/manage-location';
				}
			}
			else
			{
				$json_array['loc_title']	= false;
				$json_array['err_msg']		= 1;
			}
        }
		else
		{
				$json_array['loc_title']	= false;
				$json_array['err_msg']		= 1;
		}
		echo json_encode($json_array);
		return $this->getResponse();
    }
	public function manageLocationListAction()
    {
		$result = new ViewModel();
	    $result->setTerminal(true);
		
		$matches	= $this->getEvent()->getRouteMatch();
		$page		= $matches->getParam('id', 1);
		$sortBy		= $matches->getParam('sortBy', '');
		$sortType	= $matches->getParam('sortType', '');
		$perPage	= $matches->getParam('perPage', '');
		//	Session for Location listing
		$locationSession = new Container('locationListing');
		
		$columnFlag		= 0;
		if($sortBy != '') {
			if($locationSession->sortBy == $sortBy)
				$columnFlag	= 1;
			$locationSession->sortBy	= $sortBy;
		} else if($locationSession->offsetExists('sortBy')) {
			$sortBy	= $locationSession->sortBy;
		}
		if($sortType != '') {
			if($locationSession->sortType == $sortType && $columnFlag == 1)
				$locationSession->sortType	= ($sortType == 1) ? 0 : 1;
			else
				$locationSession->sortType	= $sortType;
		} else if($locationSession->offsetExists('sortType')) {
			$sortType	= $locationSession->sortType;
		}
		//	Perpage
		if($perPage != '') {
			$locationSession->perPage	= $perPage;
		} else if($locationSession->offsetExists('perPage')) {
			$perPage	= $locationSession->perPage;
		} else {
			$perPage	= $this->defaultPerPage;
		}
		
		$no_of_driver = $no_of_bikes = '';
		$bike_count_array = $driver_count_array = array();
		$no_of_bikes		= $this->getLocationTable()->getBikeCount();
		if(is_object($no_of_bikes) && count($no_of_bikes) > 0)
		{
			foreach($no_of_bikes as $bike_key => $bike_value)
			{
				$bike_count_array[$bike_value['fk_location_id']]	= $bike_value['bike_count'];
			}
		}
		$no_of_driver		= $this->getLocationTable()->getDriverCount();
		if(is_object($no_of_driver) && count($no_of_driver) > 0)
		{
			foreach($no_of_driver as $driver_key => $driver_value)
			{
				$driver_count_array[$driver_value['location_id']]	= $driver_value['driver_count'];
			}
		}
		$message			= '';
		$iteratorAdapter	= new \Zend\Paginator\Adapter\Iterator($this->getLocationTable()->getAllLocationList());
		$paginator			= new \Zend\Paginator\Paginator($iteratorAdapter);
		$paginator->setCurrentPageNumber($page);
		$paginator->setItemCountPerPage($perPage);
		$activeArrray		= array('0' => 'Inactive', '1' => 'Active');
		$result->setVariables(array(
				'message'		 	=> $message,
				'page'			 	=> $page,
				'sortBy'		 	=> $sortBy,
				'paginator'		 	=> $paginator,
				'perPage'		 	=> $perPage,
				'activeArrray'	 	=> $activeArrray,
				'perPageArray'		=> $this->perPageArray,
				'bike_count_array'	=> $bike_count_array,
				'driver_count_array'=> $driver_count_array,
				'controller'	 	=> $this->params('controller')
		));
		return $result;
    }
	public function deleteManageLocationAction()
    {
		$location_id = (int) $this->params()->fromRoute('id', 0);
        if($location_id)
		{
			$this->getLocationTable()->deleteLocation($location_id);
			$status	 =  $this->getCommonDataObj()->destroySessionVariables(array('allLocations'));
		}
        return $this->getResponse();
    }
	public function viewLocationAction()
    {
		$result 		= new ViewModel();
	    $result->setTerminal(true);
		$location_id = (int) $this->params()->fromRoute('id', 0);
		$json_view_array = array();
		if($location_id)
		{
			$view_details_array		= $this->getLocationTable()->getLocationDetails($location_id);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$json_view_array[]	= $view_value;
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'viewArray'			=> $json_view_array
		));
		return $result;
    }
	public function editLocationAction()
    {
		$result 			= new ViewModel();
	    $editlocationForm	=  new AddLocationForm();
		$location_id = (int) $this->params()->fromRoute('id', 0);
		if($location_id)
		{
			$view_details_array		= $this->getLocationTable()->getLocationDetails($location_id);
			if(is_object($view_details_array) && count($view_details_array) > 0)
			{
				foreach($view_details_array as $view_key => $view_value)
				{
					$editlocationForm->get('loc_title')->setValue(stripslashes($view_value['loc_title']));
					$editlocationForm->get('loc_id')->setValue($view_value['loc_id']);
					$editlocationForm->get('loc_address')->setValue(stripslashes($view_value['loc_address']));
					if(isset($view_value['loc_same_addr']) && $view_value['loc_same_addr'] == 1)
					{
						$editlocationForm->get('loc_same_addr')->setValue($view_value['loc_same_addr']);
					}
					else
					{
						$editlocationForm->get('loc_mail_address')->setValue(stripslashes($view_value['loc_mail_addr']));
					}
					$editlocationForm->get('loc_postal_code')->setValue(stripslashes($view_value['loc_postal_code']));
					$editlocationForm->get('loc_status')->setValue(stripslashes($view_value['loc_status']));
					$editlocationForm->get('loc_launch_date')->setValue(date('n-j-Y',strtotime($view_value['loc_date_launch'])));
					$editlocationForm->get('loc_ses_open_date')->setValue(date('n-j-Y',strtotime($view_value['loc_seas_open_date'])));
					$editlocationForm->get('loc_ses_close_date')->setValue(date('n-j-Y',strtotime($view_value['loc_seas_close_date'])));
				}
			}
		}
		$result->setVariables(array(
				'controller'	 	=> $this->params('controller'),
				'locationForm'		=> $editlocationForm,
				'pc_users'			=> $this->pcUser
		));
		return $result;
    }
	public function getLocationTable()
    {
		if (!isset($this->LocationTable)) {
            $sm = $this->getServiceLocator();
            $this->LocationTable = $sm->get('Location-Table');
        }
        return $this->LocationTable;
    }
}
