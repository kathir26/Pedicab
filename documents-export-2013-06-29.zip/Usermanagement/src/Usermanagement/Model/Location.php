<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Location implements InputFilterAwareInterface
{
    public $loc_title;
    public $loc_address;
    public $loc_mail_address;
	public $loc_same_addr;
	public $loc_launch_date;
	public $loc_ses_open_date;
	public $loc_ses_close_date;
	public $loc_status;
	public $loc_isdelete;
	public $loc_id;
	public $loc_creation_date;
	public $loc_postal_code;
	
    public function exchangeArray($data)
    {
		$this->loc_id				= (isset($data['loc_id'])) ? $data['loc_id'] : null;
		$this->loc_title			= (isset($data['loc_title'])) ? $data['loc_title'] : null;
        $this->loc_address			= (isset($data['loc_address'])) ? $data['loc_address'] : null;
        $this->loc_mail_address		= (isset($data['loc_mail_address'])) ? $data['loc_mail_address'] : null;
		$this->loc_same_addr		= (isset($data['loc_same_addr'])) ? $data['loc_same_addr'] : 0;
		$this->loc_postal_code		= (isset($data['loc_postal_code'])) ? $data['loc_postal_code'] : null;
		$this->loc_launch_date		= (isset($data['loc_date_launch'])) ? $data['loc_date_launch'] : null;
		$this->loc_ses_open_date	= (isset($data['loc_seas_open_date'])) ? $data['loc_seas_open_date'] : null;
		$this->loc_ses_close_date	= (isset($data['loc_seas_close_date'])) ? $data['loc_seas_close_date'] : null;
		$this->loc_status			= (isset($data['loc_status'])) ? $data['loc_status'] : null;
		$this->loc_isdelete			= (isset($data['loc_isdelete'])) ? $data['loc_isdelete'] : null;
		$this->loc_creation_date	= (isset($data['loc_creation_date'])) ? $data['loc_creation_date'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddLocation()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			$inputFilter->add($factory->createInput(array(
                'name'     => 'loc_title',
				'id'       => 'loc_title',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
				'validators' => array(
                    array(
                      'name' =>'NotEmpty', 
                        'options' => array(
                            'messages' => array(
                                \Zend\Validator\NotEmpty::IS_EMPTY => 'Location Title can not be empty.'
                            ),
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 1,
                            'max' => 200,
                            'messages' => array(
                                'stringLengthTooShort' => 'Please enter Location Title between 1 to 200 character!',
                                'stringLengthTooLong' => 'Please enter Location Title between 1 to 200 character!'
                            ),
                        ),
                    ),
                ),
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
