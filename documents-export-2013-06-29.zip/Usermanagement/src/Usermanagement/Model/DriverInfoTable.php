<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class DriverInfoTable extends AbstractTableGateway
{
    protected $table = 'driver_info';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new DriverInfo());
        $this->initialize();
    }
	
	public function getDriverInfo($user_id) {
		$result  = $this->select(function (Select $select) use ($user_id){
						$select->where(array('user_id' => $user_id));
//						echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
    public function getAllDriverInfo() {
		$result  = $this->select(function (Select $select) {
						$select->where(array('role_status' => 1, 'role_isdelete' => '0'));
//						echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
	public function getDriverInfoList()
	{
		$whereClause	= '';
		$auth 			= new AuthenticationService();
		$user 			= $auth->getIdentity();
		$whereClause   .= ' WHERE 1 And role_isdelete = 0 ';
		
		$listingSession 	= new Container('roleListing');
		$whereClause	    .= '';
		
		if($listingSession->offsetExists('role_name') && $listingSession->role_name != '') {
			$whereClause	.= ' AND role_name = "' . $listingSession->role_name. '"';
		}
		
		$orderClause		 = '';
		
		if($listingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		$sql	= 'SELECT * FROM role' . $whereClause . ' ' . $orderClause;
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==sql==>".$sql;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
    public function getDriverInfoId($id)
    {
        $id  	= (int) $id;
        $rowset = $this->select(array('user_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	/*
	*	Save the Role details
	*/
    public function saveDriverInfo($driverInfo)
    {
       $data = array(
            'user_training_date'	  => $driverInfo['user_training_date'],
			'user_citylicense_permit' => $driverInfo['user_citylicense_permit'],
        );
		
		if(isset($driverInfo['user_drivers_license']) && !empty($driverInfo['user_drivers_license'])) {
			$data['user_drivers_license']  = $driverInfo['user_drivers_license'];
		}
        $user_id = (int)$driverInfo["user_id"];
        if ($this->getDriverInfo($user_id)) {
//			echo "<br/>==Line==".__LINE__."==File==".__FILE__."==saveDriverInfo==><pre>"; print_r($data); echo "</pre><==";
            $this->update($data, array('user_id' => $user_id));
    		return $user_id;
        } else {
			$data['user_id']    =  $driverInfo['user_id'];
//            echo "<br/>==Line==".__LINE__."==File==".__FILE__."==saveDriverInfo==><pre>"; print_r($data); echo "</pre><==";
        	$this->insert($data);
 			$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			return $lastInsertId;
        }
    }
	
    public function deleteDriverInfo($user_id)
    {
       $this->delete(array('user_id' => $user_id));
    }
	
}