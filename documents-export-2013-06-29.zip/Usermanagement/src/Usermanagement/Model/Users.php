<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Users implements InputFilterAwareInterface
{
    public $user_id;
    public $user_role_id;
    public $user_email;
	public $user_firstname;
	public $user_lastname;
	public $user_password;
	public $user_status;
	public $user_createddate;
	public $user_updateddate;
	public $user_leasecontract_date;
	public $location_id;
	
    public function exchangeArray($data)
    {
        $this->user_id					= (isset($data['user_id'])) ? $data['user_id'] : null;
        $this->user_role_id				= (isset($data['user_role_id'])) ? $data['user_role_id'] : null;
        $this->user_email				= (isset($data['user_email'])) ? $data['user_email'] : null;
		$this->user_firstname			= (isset($data['user_firstname'])) ? $data['user_firstname'] : null;
		$this->user_lastname			= (isset($data['user_lastname'])) ? $data['user_lastname'] : null;
		$this->user_password			= (isset($data['user_password'])) ? $data['user_password'] : null;
		$this->user_status				= (isset($data['user_status'])) ? $data['user_status'] : null;
		$this->user_createddate			= (isset($data['user_createddate'])) ? $data['user_createddate'] : null;
		$this->user_updateddate			= (isset($data['user_updateddate'])) ? $data['user_updateddate'] : null;
		$this->user_leasecontract_date	= (isset($data['user_leasecontract_date'])) ? $data['user_leasecontract_date'] : null;
		$this->location_id				= (isset($data['location_id'])) ? $data['location_id'] : null;
    }
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                'name'     => 'pc_login_email',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 250,
                        ),
                    ),
                ),
            )));
			
            $inputFilter->add($factory->createInput(array(
                'name'     => 'pc_password',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 250,
                        ),
                    ),
                ),
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getInputFilterForgetPassword()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'pc_forget_password_email',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 250,
                        ),
                    ),
                ),
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getInputFilterForAddUser()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
            $inputFilter->add($factory->createInput(array(
                'name'     => 'user_firstname',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 200,
                        ),
                    ),
                ),
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'user_lastname',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 200,
                        ),
                    ),
                ),
            )));
			
            $inputFilter->add($factory->createInput(array(
                'name'     => 'user_mailing_address',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
                'validators' => array(
                    array(
                        'name'    => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min'      => 1,
                            'max'      => 200,
                        ),
                    ),
                ),
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'user_gender',
                'required' => true
            )));
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'user_status',
                'required' => true
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	
}