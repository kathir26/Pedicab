<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

class AclresourcesTable extends AbstractTableGateway
{
    protected $table  = 'acl_resources';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
    }
	
    public function getAllAclResources() {
		// SELECT distinct LOWER(controller_name) as controller, module_name, action_name FROM acl_resources
		$result  = $this->select(function (Select $select) {
						$select->where(array('status' => 1, 'acl_isdelete' => 0))
				         	   ->order('sort_order ASC');
							// echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		/*$count 	 = $result->count();
		$toArray = $result->toArray();
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==count==>".$count;
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==toArray==><pre>"; print_r($toArray); echo "</pre><==";
		
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getDataSource==><pre>"; print_r($result->getDataSource()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getFieldCount==><pre>"; print_r($result->getFieldCount()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==next==><pre>"; print_r($result->next()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==key==><pre>"; print_r($result->key()); echo "</pre><==";
		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==current==><pre>"; print_r($result->current()); echo "</pre><==";
		*/
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
    public function deleteUser($id)
    {
       //  $this->delete(array('user_id' => $id));
    }
	
	public function sampleFetchAll() {
        /*
		$resultSet = $this->select(function (Select $select) {
	                    $select->order('sort_order ASC')
						 	   ->limit(5)
						 	   ->offset(1);
						echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
	                 });
		*/
		$id = '';
		$result  = $this->select(function (Select $select) use ($id) {
				        $select->order('sort_order ASC')
						 	   ->limit(5)
						 	   ->offset(1);
						// echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		return $result;
		/*
		$result  = $this->select(function (Select $select) use ($id){
				        $select->where(array('album_id'=>$id));
				        $select->join('album', 'tracks.album_id = album.id');
				     });
        return $result;
		*/
		/*
		$sql 	    = "SELECT * FROM acl_resources";
		$statement = $this->adapter->query($sql);
		$results   = $statement->execute();
		//echo "<br/>==Line==".__LINE__."==File==".__FILE__."====><pre>"; print_r($results); echo "</pre><==";
		return $results;
		*/
    }
	
	public function getAllMenusTabs($userRoleId = 0)
    {
		$whereClaus 	 = ' where 1 and acl_resources.left_nav = 1 and acl_resources.acl_isdelete = 0';
		if(!empty($userRoleId)) {
			$whereClaus .= ' and role_type_privileges.role_type_id='.$userRoleId;
		}
		$sql		= "SELECT acl_resources.resource_id, acl_resources.title, acl_resources.description, acl_resources.module_name, acl_resources.controller_name, 
					   acl_resources.action_name, acl_resources.param_id, acl_resources.parent_id, acl_resources.sort_order, acl_resources.status, acl_resources.left_nav,
					   acl_resources.is_clickable, acl_resources.icon_class, acl_resources.acl_isdelete
					   FROM acl_resources as acl_resources
					   left join role_type_privileges as role_type_privileges on (role_type_privileges.resource_id = acl_resources.resource_id)";
		$sql       .=  $whereClaus;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getAllMenusLists==>".$sql."<==";
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
	/*
	*	Testing Process
	*/
	public function getRequiredMenus($resourceIds)
    {
		//	SELECT * FROM acl_resources where parent_id in (SELECT resource_id FROM acl_resources where parent_id in(1,2,3,4,5,6,7,8,9,10,11) or resource_id in(1,2,3,4,5,6,7,8,9,10,11)) or resource_id in(1,2,3,4,5,6,7,8,9,10,11)
		
		
		$sql		= "SELECT * FROM acl_resources where 
					   parent_id in (SELECT resource_id FROM acl_resources where parent_id in(".$resourceIds.") or resource_id in(".$resourceIds.")) 
					   or resource_id in(".$resourceIds.")";
		$sql       .=  $whereClaus;
		
//		echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getAllMenusLists==>".$sql."<==";
		
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
}	//  AclresourcesTable class