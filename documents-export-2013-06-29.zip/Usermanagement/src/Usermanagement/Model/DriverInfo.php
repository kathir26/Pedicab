<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class DriverInfo implements InputFilterAwareInterface
{
    public $user_id;
    public $user_training_date;
    public $user_drivers_license;
	public $user_citylicense_permit;
	
    public function exchangeArray($data)
    {
        $this->user_id					= (isset($data['user_id'])) ? $data['user_id'] : null;
        $this->user_training_date		= (isset($data['user_training_date'])) ? $data['user_training_date'] : null;
        $this->user_drivers_license		= (isset($data['user_drivers_license'])) ? $data['user_drivers_license'] : null;
		$this->user_citylicense_permit	= (isset($data['user_citylicense_permit'])) ? $data['user_citylicense_permit'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
