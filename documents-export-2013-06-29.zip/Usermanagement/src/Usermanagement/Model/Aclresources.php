<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Aclresources
{
    public $resource_id;
    public $title;
    public $description;
	public $module_name;
	public $controller_name;
	public $action_name;
	public $parent_id;
	public $sort_order;
	public $status;
	public $left_nav;
	public $is_clickable;
	
    public function exchangeArray($data)
    {
		$this->resource_id		= (isset($data['resource_id'])) ? $data['resource_id'] : null;
        $this->title			= (isset($data['title'])) ? $data['title'] : null;
        $this->description		= (isset($data['description'])) ? $data['description'] : null;
		$this->module_name		= (isset($data['module_name'])) ? $data['module_name'] : null;
		$this->controller_name	= (isset($data['controller_name'])) ? $data['controller_name'] : null;
		$this->action_name		= (isset($data['action_name'])) ? $data['action_name'] : null;
		$this->parent_id		= (isset($data['parent_id'])) ? $data['parent_id'] : null;
		$this->sort_order		= (isset($data['sort_order'])) ? $data['sort_order'] : null;
		$this->status			= (isset($data['status'])) ? $data['status'] : null;
		$this->left_nav			= (isset($data['left_nav'])) ? $data['left_nav'] : null;
		$this->is_clickable		= (isset($data['is_clickable'])) ? $data['is_clickable'] : null;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
}