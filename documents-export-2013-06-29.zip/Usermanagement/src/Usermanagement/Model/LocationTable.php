<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Sql;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class LocationTable extends AbstractTableGateway
{
    protected $table = 'location';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Location());
        $this->initialize();
    }
	public function checkLocationDetails($formData)
    {
		$where_new  = '';
		$sql 		= new Sql($this->adapter); //Zend2 Sql query execution
		$select 	= $sql->select();
		if(isset($formData['loc_id']) && $formData['loc_id'] != '')
		{
			$where_new		= ' AND loc_id != '.$formData['loc_id'];
		}
		$select->from('location')->columns(array('loc_id', 'loc_title'))->where(array('loc_title = "'.addslashes($formData["loc_title"]).'"','loc_isdelete = 0'.$where_new));
		$statement 	= $sql->getSqlStringForSqlObject($select);
		$statement 	= $this->adapter->query($statement);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
    }
	public function insertLocation(Location $location)
    {
		$data = array(
			'loc_title'				=> $location->loc_title,
            'loc_address'			=> $location->loc_address,
			'loc_mail_addr'			=> $location->loc_mail_address,
            'loc_same_addr'			=> $location->loc_same_addr,
			'loc_postal_code'		=> $location->loc_postal_code,
			'loc_date_launch' 		=> $location->loc_launch_date,
			'loc_seas_open_date'	=> $location->loc_ses_open_date,
			'loc_seas_close_date'	=> $location->loc_ses_close_date,
            'loc_status'			=> $location->loc_status,
			'loc_isdelete' 			=> $location->loc_isdelete,
			'loc_creation_date'		=> $location->loc_creation_date,
        );
        $this->insert($data);
		$lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
	public function updateLocation($location)
    {
	    $data = array(
			'loc_title'				=> $location->loc_title,
            'loc_address'			=> $location->loc_address,
			'loc_mail_addr'			=> $location->loc_mail_address,
            'loc_same_addr'			=> $location->loc_same_addr,
			'loc_postal_code'		=> $location->loc_postal_code,
			'loc_date_launch' 		=> $location->loc_launch_date,
			'loc_seas_open_date'	=> $location->loc_ses_open_date,
			'loc_seas_close_date'	=> $location->loc_ses_close_date,
            'loc_status'			=> $location->loc_status,
			'loc_isdelete' 			=> $location->loc_isdelete,
			'loc_updated_date'		=> date('Y-m-d H:i:s')
        );
		$this->update($data, array('loc_id' => $location->loc_id));
    }
	public function getAllLocationList()
	{
		$whereClause	= '';
		$auth 			= new AuthenticationService();
		$user 			= $auth->getIdentity();
		$whereClause   .= ' WHERE loc_isdelete = 0 and loc_id = '.$user->location_id;
		
		$locationSession 	= new Container('locationListing');
		$whereClause	    .= '';
		
		if($locationSession->offsetExists('loc_title') && $locationSession->loc_title != '') {
			$whereClause	.= ' AND loc_title like "' . addslashes($locationSession->loc_title). '%"';
		}
		
		$orderClause		 = '';
		if($locationSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$locationSession->sortBy;
		}
		
		if($locationSession->offsetExists('sortType') && $locationSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		if(!$orderClause)
		{
			$orderClause	.= ' ORDER BY loc_id DESC';
		}
		$sql		= 'SELECT * FROM location' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	public function deleteLocation($location_id)
    {
        $data = array(
			'loc_isdelete'	=> '1'
        );
		$this->update($data, array('loc_id' => $location_id));
    }
	public function getLocationDetails($location_id)
	{
		$sql 		= new Sql($this->adapter); //Zend2 Sql query execution
		$select 	= $sql->select();
		$select->from('location')->where(array('loc_id = '.$location_id));
		$statement 	= $sql->getSqlStringForSqlObject($select);
		$statement 	= $this->adapter->query($statement);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getAllLocationDetails()
	{
		$sql		= 'SELECT * FROM location where loc_status = 1 and loc_isdelete = 0';
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getBikeCount()
	{
		$sql		= 'SELECT count(bike_id) as bike_count,fk_location_id FROM bike where bike_isdelete = 0 group by fk_location_id';
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result->buffer();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getDriverCount()
	{
		$sql		= 'SELECT count(user_id) as driver_count,location_id FROM user where user_status = 1 and user_isdelete = 0 and user_role_id = 1  group by location_id';
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result->buffer();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function getAlertDetails($locationId)
	{
		$where		= '';
		if(isset($locationId) && $locationId != '')
		{
			$where	.= " and fk_location_id = ".$locationId;
		}
		$sql 		= "Select * from alert_reminder where alert_isdelete = 0 ".$where;
		$statement 	= $this->adapter->query($sql);
		$result		= $statement->execute();
        if (!$result) {
            throw new \Exception("Could not find row data");
        }
        return $result;
	}
	public function insertLocationAlert($insertString)
    {
		$sql 				= " INSERT INTO alert_reminder (alert_title,alert_type,alert_days,alert_desc,fk_location_id,alert_created_date) values ".$insertString;
		$statement 			= $this->adapter->query($sql);
		$result				= $statement->execute();
		$lastInsertId  		= $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
		return $lastInsertId;
    }
}