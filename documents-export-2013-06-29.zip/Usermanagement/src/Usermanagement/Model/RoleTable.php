<?php
namespace Usermanagement\Model;

use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Sql\Select;

//	Session
use Zend\Session\Container;

//	Auth
use Zend\Authentication,
	Zend\Authentication\Result,
	Zend\Authentication\AuthenticationService;

class RoleTable extends AbstractTableGateway
{
    protected $table = 'role';
	
    public function __construct(Adapter $adapter)
    {
        $this->adapter 			  = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new Role());
        $this->initialize();
    }
	
	public function getRoles($role_id) {
		$result  = $this->select(function (Select $select) use ($role_id){
						$select->where(array('role_id' => $role_id));
//						echo "<br/>==Line==".__LINE__."==File==".__FILE__."==getSqlString==>".$select->getSqlString();
				     });
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
    public function getAllRoles() {
		$result  = $this->select(function (Select $select) {
						$select->where(array('role_status' => 1, 'role_isdelete' => '0'));
				     });
		if($result && $result->count()) {
			return $result;
		} else {
			return false;
		}
    }
	
	public function getRolesList()
	{
		// Todo : Location based search
		$userSession = new Container('pcUsers');
		if($userSession->offsetExists('pc_users')) {
			$pcUser	 = $userSession->pc_users;
		}
		
		$userRoleId	 	  	= $pcUser->user_role_id;
		
		$whereClause   		= ' WHERE 1 And role_isdelete = 0 ';
		
		if($userRoleId == 3) {
			$whereClause   	.= ' And role_id Not in (4,5)';
		}
		
		$listingSession 	= new Container('roleListing');
		
		if($listingSession->offsetExists('role_name') && $listingSession->role_name != '') {
			$whereClause	.= ' AND role_name = "' . $listingSession->role_name. '"';
		}
		
		$orderClause		 = '';
		if($listingSession->offsetExists('sortBy')) {
			$orderClause	.= ' ORDER BY '.$listingSession->sortBy;
		}
		
		if($listingSession->offsetExists('sortType') && $listingSession->sortType == 1) {
			$orderClause	.= ' DESC';
		}
		
		if($orderClause == '') {
			$orderClause	.= ' ORDER BY role_id DESC';
		}
		
		$sql		= 'SELECT * FROM role' . $whereClause . ' ' . $orderClause;
		$statement	= $this->adapter->query($sql);
		$result		= $statement->execute();
		$result		= $this->resultSetPrototype->initialize($result);
		$result->buffer();
		$result->next();
		return $result;
	}
	
    public function getRoleId($id)
    {
        $id  	= (int) $id;
        $rowset = $this->select(array('role_id' => $id));
        $row 	= $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
	
	/*
	*	Save the Role details
	*/
    public function saveRole(Role $roles)
    {
        $data = array(
			'role_id'			=> $roles->role_id,
            'role_name'			=> $roles->role_name,
			'role_status'		=> $roles->role_status,
            'role_updated'		=> $roles->role_updated,
			'role_isdelete' 	=> $roles->role_isdelete,
        );
        $role_id 	= (int)$roles->role_id;
        if ($role_id == 0) {
			 $data['role_created']	=  $roles->role_created;
           	 $this->insert($data);
			 $lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			 return $lastInsertId;
        } else {
            if ($this->getRoleId($role_id)) {
               $this->update($data, array('role_id' => $role_id));
			   $lastInsertId  		=  $this->adapter->getDriver()->getConnection()->getLastGeneratedValue();
			   return $lastInsertId;
            } else {
                throw new \Exception('Form id does not exist');
            }
        }
    }
	
    public function deleteRole($role_id)
    {
        $data = array(
			'role_isdelete'	=> '1'
        );
		$this->update($data, array('role_id' => $role_id));
    }
}