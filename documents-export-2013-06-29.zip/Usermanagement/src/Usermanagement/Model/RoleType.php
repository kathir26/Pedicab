<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class RoleType implements InputFilterAwareInterface
{
    public $role_type_privileges_id;
    public $role_type_id;
    public $resource_id;
	
	
    public function exchangeArray($data)
    {
        $this->role_type_privileges_id	= (isset($data['role_type_privileges_id'])) ? $data['role_type_privileges_id'] : null;
        $this->role_type_id				= (isset($data['role_type_id'])) ? $data['role_type_id'] : null;
        $this->resource_id				= (isset($data['resource_id'])) ? $data['resource_id'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
}
