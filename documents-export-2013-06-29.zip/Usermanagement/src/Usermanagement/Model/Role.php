<?php
namespace Usermanagement\Model;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class Role implements InputFilterAwareInterface
{
    public $role_id;
    public $role_name;
    public $role_status;
	public $role_created;
	public $role_updated;
	public $role_isdelete;
	
    public function exchangeArray($data)
    {
        $this->role_id			= (isset($data['role_id'])) ? $data['role_id'] : null;
        $this->role_name		= (isset($data['role_name'])) ? $data['role_name'] : null;
        $this->role_status		= (isset($data['role_status'])) ? $data['role_status'] : null;
		$this->role_created		= (isset($data['role_created'])) ? $data['role_created'] : null;
		$this->role_updated		= (isset($data['role_updated'])) ? $data['role_updated'] : null;
		$this->role_isdelete	= (isset($data['role_isdelete'])) ? $data['role_isdelete'] : null;
    }
	
	public function __construct() {
		// Todo : Need to work for exchange array as custom function.
		$classVariables	  		= get_class_vars(__CLASS__);
	}
	
	public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }
	
	public function getInputFilter()
    {
       // Todo
    }
	
	public function getInputFilterForAddUserRole()
    {
        if (!isset($this->inputFilter) || !($this->inputFilter)) {
            $inputFilter = new InputFilter();
            $factory     = new InputFactory();
			
			$inputFilter->add($factory->createInput(array(
                'name'     => 'pc_role_name',
				'id'       => 'pc_role_name',
                'required' => true,
                'filters'  => array(
                    array('name' => 'StripTags'),
                    array('name' => 'StringTrim'),
                ),
				'validators' => array(
                    array(
                      'name' =>'NotEmpty', 
                        'options' => array(
                            'messages' => array(
                                \Zend\Validator\NotEmpty::IS_EMPTY => 'User name can not be empty.'
                            ),
                        ),
                    ),
                    array(
                        'name' => 'StringLength',
                        'options' => array(
                            'encoding' => 'UTF-8',
                            'min' => 1,
                            'max' => 200,
                            'messages' => array(
                                'stringLengthTooShort' => 'Please enter User Name between 1 to 200 character!',
                                'stringLengthTooLong' => 'Please enter User Name between 1 to 200 character!'
                            ),
                        ),
                    ),
                ),
            )));
			
            $this->inputFilter = $inputFilter;
        }
		
        return $this->inputFilter;
    }
	
	public function getArrayCopy()
    {
        return get_object_vars($this);
    }
	
	public function getObjectIntoArray($result)
    {
     	if($result) {
			return $result->toArray();
		} else {
			return false;
		}
    }
	
}
