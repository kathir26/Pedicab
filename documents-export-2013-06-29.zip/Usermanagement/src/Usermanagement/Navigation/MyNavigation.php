<?php
namespace Usermanagement\Navigation;
 
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\Navigation\Service\DefaultNavigationFactory;

//	Session
use Zend\Session\Container;
 
class MyNavigation extends DefaultNavigationFactory
{
    protected function getPages(ServiceLocatorInterface $serviceLocator)
    {
        if (null === $this->pages) {
            $configuration['navigation'][$this->getName()] = array();
			
			// Get the Logged Users Detail
			$userSession 	 = new Container('pcUsers');
			$pcUser	 	 	 = '';
			if($userSession->offsetExists('pc_users')) {
				$pcUser	 	 = $userSession->pc_users;
			}
			$userRoleId		 = (isset($pcUser->user_role_id)) ? $pcUser->user_role_id : 0;
			
			/*
			* 	Special Case Handling For Manager Notes, Edit Profile for Drivers, Mechanic and Clients
			*/
			$specialMenus	 = array(
				'1'			=>	array(
					'10'		=>	array(
						'205'	=>	array( 'action_name'	=>	'add-driver-note'),
						'207'	=>	array( 'action_name'	=>	'driver-note-listing'),
						'210'	=>	array( 'action_name'	=>	'driver-receive-listing'),
					),
					'16'		=>	array(
						'244'	=>	array( 'action_name'	=>	'edit-user')
					),
					'11'		=>	array( 'action_name'	=>	'driver-dashboard')
				),
				'2'			=>	array(
					'10'		=>	array(
						'205'	=>	array( 'action_name'	=>	'add-mechanic-note'),
						'207'	=>	array( 'action_name'	=>	'mechanic-note-listing'),
						'210'	=>	array( 'action_name'	=>	'mechanic-receive-listing'),
					),
					'16'		=>	array(
						'244'	=>	array( 'action_name'	=>	'edit-user')
					),
					'11'		=>	array( 'action_name'	=>	'mechanic-dashboard')
				),
				'6'			=>	array(
					'10'		=>	array(
						'205'	=>	array( 'action_name'	=>	'add-client-note'),
						'207'	=>	array( 'action_name'	=>	'client-note-listing'),
						'210'	=>	array( 'action_name'	=>	'client-receive-listing'),
					),
					'16'		=>	array(
						'244'	=>	array( 'action_name'	=>	'edit-client')
					),
					'11'		=>	array( 'action_name'	=>	'client-dashboard')
				),
				'3'			=>	array(
					'11'		=>	array( 'action_name'	=>	'shift-calendar')
				),
			);
			
			// Finding Actions
			$application 	 =  $serviceLocator->get('Application');
            $routeMatch  	 =  $application->getMvcEvent()->getRouteMatch();
			$actions		 =	$routeMatch->getParam('action', 'index');
			$namespace	 	 =	$routeMatch->getParam('controller', 'index');
			$controllerArray =  explode("\\", $namespace);
			$modules	 	 =	current($controllerArray);
			$controllers	 =	end($controllerArray);
			
			//	Condition handling for Menu Tabs
			$allMenuTabLinksSession = new Container('allMenuTabLinks');
			$aclresourceResults 	= array();
			if($allMenuTabLinksSession->offsetExists('allMenuTab') && $allMenuTabLinksSession->allMenuTab != '' ) {
				$aclresourceResults	= $allMenuTabLinksSession->allMenuTab;
			} else {
				$results    		= $serviceLocator->get('aclresourcesTable')->getAllMenusTabs($userRoleId);
				if($results) {
					foreach($results as $key => $resource) {
						$aclresourceResults[$resource["parent_id"]][] = $resource;
					}
				}
				
				$allMenuTabLinksSession->allMenuTab  =  $aclresourceResults;
			}
			
			if(isset($aclresourceResults) && is_array($aclresourceResults) && count($aclresourceResults)) :
				$resources			=	$aclresourceResults[0];
				foreach($resources as $resultKey => $results) :
					$parent_id		=	$results["resource_id"];
					if(array_key_exists($parent_id, $aclresourceResults)) :
						$subMenus		=	$aclresourceResults[$parent_id];
						$subParentArray =   array();
						$pagesArray 	=   array();
						foreach($subMenus as $subMenuKey => $subMenuValue) :
							$subParent_id	=	$subMenuValue["resource_id"];
							
							if(array_key_exists($subParent_id, $aclresourceResults)) :
								$subMenus1	=	$aclresourceResults[$subParent_id];
								$pagesArray =   array();
								foreach($subMenus1 as $subMenu1Key => $subMenu1Value) :
									//if($subMenu1Value["left_nav"] == 1) {
										$uri			= '/'.$subMenu1Value['module_name'].'/'.$subMenu1Value['controller_name'].'/'.$subMenu1Value['action_name'];
										$subClass		= (strtolower($subMenu1Value['module_name']) == strtolower($modules) && strtolower($subMenu1Value['controller_name']) == strtolower($controllers) && strtolower($subMenu1Value['action_name']) == strtolower($actions) ) ? 'subnav-sel' : '';
										
										$pagesArray[]	=  array(
							                    'label' 	 => $subMenu1Value['title'],
												'title'      => $subMenu1Value['title'],
												'module' 	 => $subMenu1Value['module_name'],
												'controller' => $subMenu1Value['controller_name'],
												'action' 	 => $subMenu1Value['action_name'],
												'param_id' 	 => $subMenu1Value['param_id'],
												'is_clickable' => $subMenu1Value['is_clickable'],
												'class' 	 => $subClass,
												'uri' 	 	 => $uri,
							                    //'route' => $row['route'],
							                );
									//}
								endforeach;
							endif;
							
							// Special Case Handling for Special Menus
							$subMenuValue['action_name']	= (isset($specialMenus[$userRoleId][$results['resource_id']][$subMenuValue['resource_id']]['action_name'])) ?$specialMenus[$userRoleId][$results['resource_id']][$subMenuValue['resource_id']]['action_name'] : $subMenuValue['action_name'];
							
							$uri			=   '/'.$subMenuValue['module_name'].'/'.$subMenuValue['controller_name'].'/'.$subMenuValue['action_name'];
							$subClass		=   (strtolower($subMenuValue['module_name']) == strtolower($modules) && strtolower($subMenuValue['controller_name']) == strtolower($controllers) && strtolower($subMenuValue['action_name']) == strtolower($actions) ) ? 'subnav-sel' : '';
							$subParentArray[]	 =  array(
				                    'label' 	 => $subMenuValue['title'],
									'title'      => $subMenuValue['title'],
									'module' 	 => $subMenuValue['module_name'],
									'controller' => $subMenuValue['controller_name'],
									'action' 	 => $subMenuValue['action_name'],
									'param_id' 	 => $subMenuValue['param_id'],
									'class' 	 => $subClass,
									'uri' 	 	 => $uri,
									'is_clickable' => $subMenuValue['is_clickable'],
				                    //'route' 	 => $row['route'],
									'pages'      => $pagesArray
				                );
								$pagesArray 	 =   array();
						endforeach;
					endif;
					$label		=	$results['title'];		//	description
					
					// Special Case Handling for Special Menus
					$results['action_name']	= (isset($specialMenus[$userRoleId][$results['resource_id']]['action_name'])) ?$specialMenus[$userRoleId][$results['resource_id']]['action_name'] : $results['action_name'];
					
					$uri		=   '/'.$results['module_name'].'/'.$results['controller_name'].'/'.$results['action_name'];
					
					$iconClass	=   (isset($results['icon_class']) && !empty($results['icon_class'])) ? $results['icon_class'] : '';
					$menuFlag	=   (strtolower($results['module_name']) == strtolower($modules)) ? true : false;
					$class		=   ($menuFlag) ? 'nav-sel' : '';
					
					$configuration['navigation'][$this->getName()][$results['resource_id']] = array(
	                    'label' 	 => $label,
						'title'      => $results['title'],
						'module' 	 => $results['module_name'],
						'controller' => $results['controller_name'],
						'action' 	 => $results['action_name'],
						'param_id' 	 => $results['param_id'],
						'class' 	 => $class,
						'iconClass'  => $iconClass,
						'menuFlag' 	 => $menuFlag,
						'uri' 	 	 => $uri,
	                    //'route' => $row['route'],
						'is_clickable' => $results['is_clickable'],
						'pages'      => $subParentArray
	                );
					$subParentArray =   array();
				endforeach;
			endif;
			
            if (!isset($configuration['navigation'])) {
                throw new Exception\InvalidArgumentException('Could not find navigation configuration key');
            }
            if (!isset($configuration['navigation'][$this->getName()])) {
                throw new Exception\InvalidArgumentException(sprintf(
                    'Failed to find a navigation container by the name "%s"',
                    $this->getName()
                ));
            }
 			
            $application = $serviceLocator->get('Application');
            $routeMatch  = $application->getMvcEvent()->getRouteMatch();
            $router      = $application->getMvcEvent()->getRouter();
            $pages       = $this->getPagesFromConfig($configuration['navigation'][$this->getName()]);
			
            $this->pages = $this->injectComponents($pages, $routeMatch, $router);
        }
        return $this->pages;
    }
}
?>